import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("❌ Masukkan prompt.\nContoh:\n#aianime cat on the fire")

    if (!global.neoxr) return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/ai-anime", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data.status || !data.data?.url)
            return m.reply("❌ Gagal generate gambar.")

        const result = data.data

        await conn.sendMessage(m.chat, {
            image: {
                url: result.url
            },
            caption: `
🎨 *AI Anime Generator*

📝 Prompt:
${result.prompt}

Powered by Neoxr API
`.trim()
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("AI ANIME ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat generate gambar.")
    }
}

handler.command = ["aianime"]
handler.tags = ["ai"]
handler.help = ["aianime <prompt>"]

export default handler