import axios from "axios"

const styles = [

    (q, res) => `╭───〔 AI RESPONSE SYSTEM 〕───
│
│ 👤 *Pertanyaan Pengguna*
│ ${q}
│
│ 🤖 *Jawaban AI*
│
${res}
│
├────────────────────
│ Sistem AI ini menggunakan model
│ bahasa modern yang dirancang
│ untuk membantu menjawab berbagai
│ pertanyaan, memberikan penjelasan,
│ serta membantu pengguna memahami
│ suatu topik dengan lebih mudah.
│
│ Jika jawaban terasa kurang jelas,
│ kamu bisa bertanya ulang dengan
│ detail tambahan agar sistem dapat
│ memberikan penjelasan yang lebih
│ akurat dan mendalam.
╰────────────────────`,

    (q, res) => `📡 *AI INTERACTION RESULT*

Topik yang kamu tanyakan:
"${q}"

AI telah memproses permintaan tersebut dan menghasilkan jawaban berikut:

${res}

━━━━━━━━━━━━━━━━━━

Catatan tambahan:
Sistem AI bekerja dengan memproses pola bahasa dan konteks dari pertanyaan pengguna. Karena itu, semakin jelas pertanyaan yang diberikan, semakin baik pula kualitas jawaban yang dihasilkan.

Terus eksplorasi pertanyaanmu. Kadang satu pertanyaan sederhana bisa membuka banyak informasi baru.`,

    (q, res) => `〔 Artificial Intelligence Response 〕

Permintaan yang diterima oleh sistem:
${q}

Setelah melalui proses analisis bahasa dan pemrosesan konteks, sistem menghasilkan penjelasan berikut:

${res}

────────────────────

Informasi tambahan:
Model AI yang digunakan dirancang untuk membantu berbagai kebutuhan seperti penjelasan konsep, diskusi ide, hingga membantu memahami teknologi atau pengetahuan umum.

Gunakan fitur ini secara bijak dan jangan ragu mencoba berbagai jenis pertanyaan untuk mendapatkan jawaban yang lebih luas.`

]

let handler = async (m, {
    text
}) => {

    if (!text) {
        return m.reply(
            `Gunakan perintah seperti berikut:

.ai apa itu javascript
.ai cara membuat bot whatsapp
.ai jelaskan tentang black hole`
        )
    }

    await m.react("⏳")

    try {

        let {
            data
        } = await axios.post(
            "https://api.alyachan.dev/api/ai/completion", {
                model: "gpt-5-nano",
                messages: [{
                        role: "system",
                        content: "Be a helpful assistant"
                    },
                    {
                        role: "user",
                        content: text
                    }
                ]
            }, {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                }
            }
        )

        if (!data.status) throw "API Error"

        let answer = data.data.choices[0].message.content

        let style = styles[Math.floor(Math.random() * styles.length)]

        await m.reply(style(text, answer))

        await m.react("✅")

    } catch (e) {

        console.log(e)
        await m.react("❌")
        m.reply("Terjadi kesalahan saat memproses permintaan AI.")

    }

}

handler.command = ["ai", "chatgpt", "ask"]
handler.tags = ["ai"]
handler.help = ["ai <pertanyaan>"]

export default handler