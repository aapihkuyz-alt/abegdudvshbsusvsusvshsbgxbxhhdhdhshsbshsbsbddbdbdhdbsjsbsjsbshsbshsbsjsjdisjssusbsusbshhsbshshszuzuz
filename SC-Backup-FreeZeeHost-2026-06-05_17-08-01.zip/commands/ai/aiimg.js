import { proto, generateWAMessageFromContent } from "baileys";
import axios from "axios";
import { smartFetch } from "../../core/apiWrapper.js";

let handler = async (m, { conn, text, Func, usedPrefix, command }) => {
    if (!text) return m.reply(`Contoh penggunaan:\n${usedPrefix}${command} cute cat sitting on a moon`)

    // Jika ini adalah trigger dari button (misal: "Regenerate")
    const isRegen = m.text.includes("|regen")
    const prompt = isRegen ? text.split("|")[0] : text

    await m.react("🎨");
    await m.reply("🎨 *Sedang membuat gambar dengan Multi-API System...*")
    
    try {
        // Menggunakan Universal Failover Wrapper
        const data = await smartFetch("image", prompt);
        
        let buffer;
        // Jika data adalah Buffer
        if (Buffer.isBuffer(data)) {
            buffer = data;
        } 
        // Jika data adalah JSON yang berisi URL (Standar Alyachan/Neoxr JSON)
        else if (data?.data?.url || data?.url) {
            const url = data?.data?.url || data?.url;
            const res = await axios.get(url, { responseType: 'arraybuffer' });
            buffer = Buffer.from(res.data);
        } else {
            throw new Error("Invalid API response format");
        }

        // Jika ini Telegram (conn.waUploadToServer tidak ada)
        if (!conn.waUploadToServer) {
            return await conn.sendMessage(m.chat, {
                image: buffer,
                caption: `✅ *AI Image Generated*\n\nPrompt: _${prompt}_`
            }, { quoted: m });
        }

        const msg = generateWAMessageFromContent(m.chat, {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `✅ *AI Image Generated*\n\nPrompt: _${prompt}_`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: "Powered by " + global.botname
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: "💠 DIFFUSION ENGINE",
                    hasMediaAttachment: true,
                    imageMessage: (await prepareWAMessageMedia({ image: buffer }, { upload: conn.waUploadToServer })).imageMessage
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "🔄 REGENERATE",
                                id: `${usedPrefix}${command} ${prompt}|regen`
                            })
                        },
                        {
                            name: "cta_url",
                            buttonParamsJson: JSON.stringify({
                                display_text: "🖼️ HD VERSION",
                                url: `https://api.neoxr.eu/api/remini?image=${global.website}&apikey=${global.neoxr}` // Contoh link upsclae
                            })
                        }
                    ]
                }),
                contextInfo: {
                    mentionedJid: [m.sender]
                }
            })
        }, { quoted: m })

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

    } catch (e) {
        console.error(e)
        m.reply("❌ Terjadi kesalahan saat membuat gambar. Pastikan apikey valid atau coba prompt lain.")
    }
}

handler.help = ["aiimg", "diffusion", "genimg"]
handler.tags = ["ai"]
handler.command = ["aiimg", "diffusion", "genimg"]
handler.limit = true
handler.register = true

export default handler
