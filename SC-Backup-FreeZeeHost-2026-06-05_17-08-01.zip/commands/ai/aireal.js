import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan prompt.\nContoh: #aireal cat and rat are smile")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/ai-real", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal generate gambar.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `🖼️ AI Real Result\n\n📝 Prompt: ${text}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("AIREAL ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat generate gambar.")
    }
}

handler.command = ["aireal"]
handler.tags = ["ai"]
handler.help = ["aireal <prompt>"]

export default handler