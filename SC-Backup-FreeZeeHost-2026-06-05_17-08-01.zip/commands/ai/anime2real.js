import axios from "axios"
import FormData from "form-data"

let handler = async (m, {
    conn
}) => {

    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""

    if (!mime.startsWith("image/")) {
        return m.reply("Reply gambar anime.")
    }

    await m.react("⏳")

    try {

        let buffer = await q.download()

        /* upload catbox */

        let form = new FormData()
        form.append("reqtype", "fileupload")
        form.append("fileToUpload", buffer, "anime.jpg")

        let {
            data: catbox
        } = await axios.post(
            "https://catbox.moe/user/api.php",
            form, {
                headers: form.getHeaders()
            }
        )

        let imageUrl = catbox.trim()

        /* request alyachan */

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/anime2real", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`
                },
                params: {
                    image_url: imageUrl
                }
            }
        )

        if (!data.status) {
            throw "API gagal"
        }

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption: "✨ Anime → Real"
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (err) {

        console.log(err)
        await m.react("❌")
        m.reply("Gagal convert anime.")

    }

}

handler.command = ["anime2real"]
handler.tags = ["ai"]
handler.help = ["anime2real"]

export default handler