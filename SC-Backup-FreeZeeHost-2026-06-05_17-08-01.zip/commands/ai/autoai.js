import axios from "axios";
import fs from "fs";
import { exec } from "child_process";
import path from "path";
import chalk from "chalk";
import TaskQueue from "../../core/queue.js";
import { GoogleGenerativeAI } from "@google/generative-ai";

/**
 * ADVANCED AUTO AI (GEMINI 1.5 FLASH + LOAD BALANCER + TASK QUEUE)
 * Features: Official SDK, API Key Rotation, Model Fallback, Smart Retry.
 */

// --- TOOLS DEFINITION ---
const tools = [
    {
        function_declarations: [
            {
                name: "generate_image",
                description: "Generate an image based on a descriptive prompt.",
                parameters: {
                    type: "object",
                    properties: {
                        prompt: { type: "string", description: "Detailed description of the image to generate." }
                    },
                    required: ["prompt"]
                }
            },
            {
                name: "generate_audio",
                description: "Convert text to speech (TTS). Useful for sending voice notes.",
                parameters: {
                    type: "object",
                    properties: {
                        text: { type: "string", description: "The text to convert to speech." }
                    },
                    required: ["text"]
                }
            }
        ]
    }
];

// --- HANDLER FUNCTIONS ---
async function runImageGen(prompt, m, conn) {
    try {
        await m.react("🎨");
        const res = await axios.get("https://api.alyachan.dev/api/ai/diffusion", {
            headers: { Authorization: `Bearer ${global.alyachan}` },
            params: { prompt }
        });
        if (res.data?.status) {
            await conn.sendMessage(m.chat, { image: { url: res.data.data.url }, caption: `✨ *AI Image Result*\n📌 *Prompt:* ${prompt}` }, { quoted: m });
            return "Image successfully generated and sent to user.";
        }
        return "Failed to generate image via API.";
    } catch (e) {
        return `Error generating image: ${e.message}`;
    }
}

async function runAudioGen(text, m, conn) {
    try {
        await m.react("🎙️");
        const res = await axios.get("https://api.neoxr.eu/api/qwen-tts", {
            params: { text, voice: "0x1994", apikey: global.neoxr }
        });
        if (res.data?.status && res.data.data?.url) {
            const wavPath = path.join(process.cwd(), `temp_auto_${Date.now()}.wav`);
            const oggPath = path.join(process.cwd(), `temp_auto_${Date.now()}.ogg`);
            
            const wav = await axios.get(res.data.data.url, { responseType: "arraybuffer" });
            fs.writeFileSync(wavPath, wav.data);

            await new Promise((resolve, reject) => {
                exec(`ffmpeg -i ${wavPath} -c:a libopus -b:a 128k ${oggPath} -y`, (err) => err ? reject(err) : resolve());
            });

            const oggBuffer = fs.readFileSync(oggPath);
            await conn.sendMessage(m.chat, { audio: oggBuffer, mimetype: "audio/ogg; codecs=opus", ptt: true }, { quoted: m });
            
            if (fs.existsSync(wavPath)) fs.unlinkSync(wavPath);
            if (fs.existsSync(oggPath)) fs.unlinkSync(oggPath);
            
            return "Audio successfully generated and sent as voice note.";
        }
        return "Failed to generate audio via API.";
    } catch (e) {
        return `Error generating audio: ${e.message}`;
    }
}

const handler = async (m, { text, usedPrefix, db, isOwner, isAdmin }) => {
    if (m.isGroup && !isAdmin && !isOwner) return m.reply("Hanya admin yang bisa mengatur Auto AI.");

    let chat = m.isGroup ? db.get("group", m.chat) : db.get("user", m.sender);
    if (!chat) return m.reply("Data database tidak ditemukan.");

    if (!text) return m.reply(`Gunakan: ${usedPrefix}autoai on/off/reset`);

    if (text === 'on') {
        chat.autoAi = true;
        await db.save();
        return m.reply("✅ *Auto AI* dinyalakan. Bot akan merespon chat biasa, foto, and VN dengan Gemini.");
    } else if (text === 'off') {
        chat.autoAi = false;
        await db.save();
        return m.reply("❌ *Auto AI* dimatikan.");
    } else if (text === 'reset') {
        const user = db.get("user", m.sender);
        if (user) user.history = [];
        await db.save();
        return m.reply("🧹 *Chat Memory* berhasil dibersihkan.");
    } else {
        return m.reply(`Gunakan: ${usedPrefix}autoai on/off/reset`);
    }
};

handler.onMessage = async (m, { conn, sock, db, settings, usedPrefix, isOwner }) => {
  if (!sock) sock = conn;
    if (m.fromMe || m.isBaileys) return;
    if (usedPrefix && m.text?.startsWith(usedPrefix)) return;

    const chatData = m.isGroup ? db.get("group", m.chat) : db.get("user", m.sender);
    if (!chatData?.autoAi) return;

    const userData = db.get("user", m.sender) || {};
    if (!userData.history) userData.history = [];

    const isText = !!m.text;
    const isImage = m.type === "imageMessage";
    const isAudio = m.type === "audioMessage";

    if (!isText && !isImage && !isAudio) return;

    const executeAiTask = async () => {
        const version = "3.3.0-MultiModal";
        try {
            await m.react("🔍").catch(() => {});
            if (!global.neoxr) return m.reply("❌ API Key Neoxr belum diset.");

            console.log(chalk.cyan(`[AUTO AI v${version}] Processing request for ${m.sender}`));

            const sessionId = m.sender.replace(/[^0-9]/g, "");
            let responseText = "";
            const currentQuery = isImage ? "[User sent an image]" : isAudio ? "[User sent a voice note]" : m.text;
            const botSettings = settings || global.db.list().settings || {};
            
            // --- 1. HANDLING IMAGE (VISION) ---
            if (isImage) {
                await m.react("👁️");
                const buffer = await m.download();
                const { uploadImage } = await import("../../core/uploadImage.js");
                const imageUrl = await uploadImage(buffer);
                
                const { data } = await axios.get("https://api.neoxr.eu/api/gemini-vision", {
                    params: {
                        image: imageUrl,
                        q: m.text || "Jelaskan gambar ini dengan singkat and keren.",
                        apikey: global.neoxr
                    }
                });
                responseText = data?.status ? data.data.message : "Saya melihat gambar ini, tapi gagal menganalisanya.";
            }

            // --- 2. HANDLING AUDIO (WHISPER) ---
            else if (isAudio) {
                await m.react("👂");
                const buffer = await m.download();
                const { uploadMedia } = await import("../../core/uploader/index.js");
                const audioUrl = await uploadMedia(buffer);

                // Transcribe first
                const transcribeRes = await axios.get("https://api.neoxr.eu/api/whisper", {
                    params: { url: audioUrl, apikey: global.neoxr }
                });

                if (transcribeRes.data?.status) {
                    const textFromVoice = transcribeRes.data.data.text;
                    try {
                        const { data } = await axios.get("https://api.neoxr.eu/api/gpt4-session", {
                            params: { q: textFromVoice, session: sessionId, apikey: global.neoxr },
                            timeout: 30000
                        });
                        const { resetApiHealth } = await import("../../core/logger.js");
                        resetApiHealth("neoxr");
                        responseText = data?.status ? `_(Voice Detected: "${textFromVoice}")_\n\n${data.data.message}` : "Saya dengar suaramu, tapi gagal merespon.";
                    } catch (e) {
                        const { trackApiFailure } = await import("../../core/logger.js");
                        trackApiFailure("neoxr", e.message, conn);
                        responseText = "Maaf, sistem AI sedang sibuk merespon suaramu.";
                    }
                } else {
                    responseText = "Maaf, suara kamu kurang jelas atau gagal diproses.";
                }
            }

            // --- 3. HANDLING TEXT ONLY ---
            else {
                const { data } = await axios.get("https://api.neoxr.eu/api/gpt4-session", {
                    params: {
                        q: m.text,
                        session: sessionId,
                        apikey: global.neoxr
                    },
                    timeout: 30000
                });
                responseText = data?.status ? data.data.message : null;
            }

            if (responseText) {
                // --- AI VOICE RESPONSE ---
                if (botSettings.autovn_ai && !isAudio) {
                    try {
                        const ttsUrl = `https://api.neoxr.eu/api/qwen-tts?text=${encodeURIComponent(responseText)}&voice=0x1994&apikey=${global.neoxr}`;
                        await conn.sendMessage(m.chat, { 
                            audio: { url: ttsUrl }, 
                            mimetype: "audio/mpeg", 
                            ptt: true,
                            contextInfo: {
                                forwardingScore: 999,
                                isForwarded: true
                            }
                        }, { quoted: m });
                    } catch (ttsErr) {
                        console.error("AI TTS Error:", ttsErr.message);
                        await m.reply(responseText);
                    }
                } else {
                    await m.reply(responseText);
                }
                
                // Update history
                if (userData) {
                    userData.history = userData.history || [];
                    userData.history.push({ role: 'user', text: isImage ? '[Image]' : isAudio ? '[VN]' : m.text });
                    userData.history.push({ role: 'assistant', text: responseText });
                    if (userData.history.length > 5) userData.history = userData.history.slice(-5);
                    await db.save();
                }
            }

            await m.react("✨").catch(() => {});

        } catch (e) {
            console.error(chalk.red("[AUTO AI ERROR]"), e.message);
            if (isOwner) m.reply(`❌ *Auto AI MultiModal Error:* ${e.message}`);
        }
    };

    TaskQueue.push(executeAiTask, m);
};

handler.command = ['autoai', 'resetai'];
handler.tags = ['ai'];
handler.help = ['autoai on/off/reset', 'resetai'];

export default handler;
