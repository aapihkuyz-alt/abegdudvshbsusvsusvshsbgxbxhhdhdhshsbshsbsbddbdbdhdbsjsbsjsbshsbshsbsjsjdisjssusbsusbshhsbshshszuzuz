import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan pertanyaan.\nContoh: .bard hi")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🤖", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/bard", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.message)
            return m.reply("❌ Gagal mendapatkan jawaban dari Bard.")

        await conn.sendMessage(m.chat, {
            text: `🤖 *Bard Response*\n\n${data.data.message}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("BARD ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi kesalahan saat memproses permintaan.")
    }
}

handler.command = ["bard"]
handler.tags = ["ai"]
handler.help = ["bard <text>"]

export default handler