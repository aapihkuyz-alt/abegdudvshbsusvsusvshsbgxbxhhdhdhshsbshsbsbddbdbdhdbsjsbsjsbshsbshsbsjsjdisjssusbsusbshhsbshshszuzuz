import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan prompt.\nContoh: .bardimg cute orange cat")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/bardimg", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 120000
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal generate gambar.")

        const result = data.data

        await conn.sendMessage(m.chat, {
            image: {
                url: result.url
            },
            caption: `🖼️ *Bard Image Generated*

📌 Prompt:
${result.prompt}

📦 Size: ${result.size}
🧾 File: ${result.filename}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("BARDIMG ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi kesalahan saat generate gambar.")
    }
}

handler.command = ["bardimg"]
handler.tags = ["ai"]
handler.help = ["bardimg <prompt>"]

export default handler