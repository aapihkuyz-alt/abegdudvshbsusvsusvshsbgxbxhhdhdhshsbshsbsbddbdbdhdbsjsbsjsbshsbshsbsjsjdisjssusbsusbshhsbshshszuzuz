import axios from 'axios'

const handler = async (m, {
    text,
    conn
}) => {
    if (!text) return m.reply('Masukkan pertanyaanmu, contoh: Apa arti Yohanes 3:16?')

    await m.reply('⏳ Sedang mencari jawaban dari Kitab Suci...')

    try {
        const url = `https://api.apocalypse.web.id/ai/bible?text=${encodeURIComponent(text)}`
        const res = await axios.get(url)
        const data = res.data

        if (!data.status || !data.result) {
            throw data.message || 'Tidak ada hasil ditemukan.'
        }

        let hasil = (data.result.answer || '')
            .replace(/\[[^\]]*?\]/g, '')
            .replace(/\s+([.,!?;:])/g, '$1')
            .replace(/\s+/g, ' ')
            .trim()

        if (Array.isArray(data.result.sources) && data.result.sources.length > 0) {
            const refs = data.result.sources
                .map(v => `- ${v.text}`)
                .join('\n')

            hasil += `\n\n📖 Referensi Ayat:\n${refs}`
        }

        await conn.sendMessage(
            m.chat, {
                text: hasil
            }, {
                quoted: m
            }
        )

    } catch (error) {
        await conn.sendMessage(
            m.chat, {
                text: `Terjadi kesalahan: ${
                    error.response?.data?.message ||
                    error.message ||
                    String(error)
                }`
            }, {
                quoted: m
            }
        )
    }
}

handler.help = ['bibleai']
handler.tags = ['ai']
handler.command = /^(bibleai)$/i
handler.limit = false

export default handler