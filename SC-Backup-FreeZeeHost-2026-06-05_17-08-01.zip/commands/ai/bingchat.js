import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("❌ Masukkan pertanyaan.\nContoh:\n#bingchat kamu siapa?")

    if (!global.neoxr) return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🤖", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/bing-chat", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data.status || !data.data?.message)
            return m.reply("❌ Gagal mendapatkan jawaban.")

        await conn.sendMessage(m.chat, {
            text: `
🤖 *Bing AI Response*

${data.data.message}
`.trim()
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("BING CHAT ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat menghubungi AI.")
    }
}

handler.command = ["bingchat", "bingai"]
handler.tags = ["ai"]
handler.help = ["bingchat <pertanyaan>"]

export default handler