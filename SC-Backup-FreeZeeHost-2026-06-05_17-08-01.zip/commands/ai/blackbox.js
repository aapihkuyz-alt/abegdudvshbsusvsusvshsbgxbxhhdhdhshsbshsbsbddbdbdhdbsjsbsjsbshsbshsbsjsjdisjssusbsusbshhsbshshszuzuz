import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply("Contoh:\n.blackbox Hi")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🤖",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/blackbox", {
                params: {
                    q: text,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.message)
            throw new Error("API Error")

        const reply = data.data.message

        await conn.sendMessage(
            m.chat, {
                text: `🤖 *Blackbox AI*\n\n${reply}`
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("BLACKBOX ERROR:", e.response?.data || e.message)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Blackbox AI sedang error atau API limit.")
    }
}

handler.help = ["blackbox <text>", "blackboxai <text>"]
handler.tags = ["ai"]
handler.command = ["blackbox", "blackboxai"]

export default handler