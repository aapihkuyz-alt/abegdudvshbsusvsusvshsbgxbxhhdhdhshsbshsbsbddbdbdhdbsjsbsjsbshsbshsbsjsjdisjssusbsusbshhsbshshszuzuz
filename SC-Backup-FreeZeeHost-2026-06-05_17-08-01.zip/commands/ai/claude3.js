import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan pertanyaan.\nContoh:\n#claude hi")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🧠", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/claude", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.message)
            return m.reply("❌ Gagal mendapatkan jawaban dari Claude.")

        await conn.sendMessage(m.chat, {
            text: `
🧠 *Claude AI Response*

${data.data.message}
`.trim()
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("CLAUDE ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat menghubungi Claude AI.")
    }
}

handler.command = ["claude", "claudeai"]
handler.tags = ["ai"]
handler.help = ["claude <pertanyaan>"]

export default handler