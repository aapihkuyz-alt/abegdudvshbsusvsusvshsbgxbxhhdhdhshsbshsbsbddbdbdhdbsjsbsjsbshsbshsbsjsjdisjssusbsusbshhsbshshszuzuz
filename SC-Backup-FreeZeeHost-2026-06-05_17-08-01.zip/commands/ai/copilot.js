import axios from "axios"

let handler = async (m, {
    text
}) => {

    if (!text) {
        return m.reply(
            `Contoh penggunaan:

.copilot apa itu artificial intelligence
.copilot jelaskan cara kerja blockchain
.copilot apa fungsi nodejs`
        )
    }

    await m.react("🧠")

    try {

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/copilot", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                },
                params: {
                    prompt: text
                }
            }
        )

        if (!data.status) throw "API gagal"

        let ai = data.data.content

        let teks = `┏━━〔 🤖 AI COPILOT RESPONSE 〕━━┓

➤ Prompt
${text}

➤ Jawaban AI

${ai}

┗━━━━━━━━━━━━━━━━━━━━━━┛`

        await m.reply(teks)

        await m.react("✅")

    } catch (err) {

        console.log(err)

        await m.react("❌")

        m.reply("Gagal mengambil jawaban AI.")

    }

}

handler.command = ["copilot"]
handler.tags = ["ai"]
handler.help = ["copilot <pertanyaan>"]

export default handler