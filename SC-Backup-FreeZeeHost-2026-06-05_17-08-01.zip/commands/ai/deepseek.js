import axios from "axios"

let handler = async (m, {
    text
}) => {

    if (!text) {
        return m.reply(
            `Contoh penggunaan:

.deepseek apa itu artificial intelligence
.deepseek jelaskan cara kerja internet
.deepseek bagaimana cara membuat bot whatsapp`
        )
    }

    await m.react("🔍")

    try {

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/deepseek", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                },
                params: {
                    prompt: text,
                    thinking: "no",
                    legacy: "yes"
                }
            }
        )

        if (!data.status) throw "API gagal"

        let ai = data.data.content.replace("FINISHED", "").trim()

        let teks = `╭━━━〔 🧠 DEEPSEEK AI RESPONSE 〕━━━⬣
┃
┃ 📌 Prompt
┃ ${text}
┃
┃ 💡 Jawaban
┃
${ai}
┃
╰━━━━━━━━━━━━━━━━━━━━⬣`

        await m.reply(teks)

        await m.react("✅")

    } catch (err) {

        console.log(err)

        await m.react("❌")

        m.reply("Gagal mendapatkan jawaban dari DeepSeek AI.")

    }

}

handler.command = ["deepseek", "seek"]
handler.tags = ["ai"]
handler.help = ["deepseek <pertanyaan>"]

export default handler