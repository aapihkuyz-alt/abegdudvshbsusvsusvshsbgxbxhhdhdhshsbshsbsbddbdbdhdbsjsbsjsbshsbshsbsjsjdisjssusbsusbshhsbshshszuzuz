import axios from "axios"
import FormData from "form-data"

async function uploadCatbox(buffer) {
    const form = new FormData()
    form.append("reqtype", "fileupload")
    form.append("fileToUpload", buffer, "image.jpg")

    let {
        data
    } = await axios.post(
        "https://catbox.moe/user/api.php",
        form, {
            headers: form.getHeaders()
        }
    )

    return data
}

let handler = async (m, {
    text
}) => {

    let url = text

    if (m.quoted && m.quoted.isMedia) {
        await m.react("📤")
        let buffer = await m.quoted.download()
        url = await uploadCatbox(buffer)
    }

    if (!url) {
        return m.reply(
            `Reply gambar atau kirim link.

Contoh:
.detectai https://example.com/image.png`
        )
    }

    await m.react("🔎")

    try {

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/content/detector", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                },
                params: {
                    input: url,
                    type: "image"
                }
            }
        )

        if (!data.status) throw "API gagal"

        let prob = data.data.probability
        let percent = (prob * 100).toFixed(2)

        let status = "Kemungkinan besar dibuat manusia"

        if (prob > 0.6) status = "Kemungkinan besar dibuat AI"
        else if (prob > 0.3) status = "Ada indikasi konten AI"

        let teks = `╭━━━〔 🧠 AI CONTENT SCANNER 〕━━━⬣
┃
┃ 📥 Target
┃ ${url}
┃
┃ 📊 AI Probability
┃ ${percent}%
┃
┃ 🧾 Result
┃ ${status}
┃
┃ 🧪 Analisis
┃ Sistem membandingkan pola visual
┃ gambar dengan karakteristik yang
┃ sering muncul pada konten AI.
┃
╰━━━━━━━━━━━━━━━━━━⬣`

        await m.reply(teks)

        await m.react("✅")

    } catch (err) {

        console.log(err)

        await m.react("❌")

        m.reply("Gagal menganalisis gambar.")

    }

}

handler.command = ["detectai", "aidetect"]
handler.tags = ["ai"]
handler.help = ["detectai <reply image / url>"]

export default handler