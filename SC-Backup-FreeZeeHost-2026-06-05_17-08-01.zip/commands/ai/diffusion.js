import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) {
        return m.reply(
            `Contoh penggunaan:

.diffusion anime girl
.diffusion cyberpunk city night
.diffusion futuristic robot warrior`
        )
    }

    await m.react("🎨")

    try {

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/diffusion", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                },
                params: {
                    prompt: text
                }
            }
        )

        if (!data.status) throw "API gagal"

        let img = data.data.url

        let caption = `┏━━〔 🎨 AI IMAGE GENERATOR 〕━━┓

➤ Prompt
${text}

➤ Seed
${data.data.seed}

➤ Cost
${data.data.cost}

┗━━━━━━━━━━━━━━━━━━━━━━┛`

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: img
                },
                caption
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (err) {

        console.log(err)

        await m.react("❌")

        m.reply("Gagal membuat gambar dari AI.")

    }

}

handler.command = ["diffusion", "aiimg"]
handler.tags = ["ai"]
handler.help = ["diffusion <prompt>"]

export default handler