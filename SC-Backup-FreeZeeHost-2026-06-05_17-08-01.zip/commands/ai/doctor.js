import axios from "axios"

let handler = async (m, {
    text
}) => {

    if (!text) {
        return m.reply(
            `Contoh penggunaan:

.doctor penyebab batuk
.doctor cara mengatasi sakit kepala
.doctor kenapa perut sering sakit`
        )
    }

    await m.react("🩺")

    try {

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/doctor", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                },
                params: {
                    prompt: text
                }
            }
        )

        if (!data.status) throw "API gagal"

        let ai = data.data.content

        let teks = `╭━━━〔 🩺 AI MEDICAL ASSISTANT 〕━━━⬣
┃
┃ 📌 Pertanyaan
┃ ${text}
┃
┃ 📖 Penjelasan
┃
${ai}
┃
┃ ℹ️ Catatan
┃ Informasi ini bersifat edukatif dan
┃ tidak menggantikan diagnosis medis
┃ langsung dari tenaga kesehatan.
┃ Jika gejala berlangsung lama atau
┃ terasa semakin parah, sebaiknya
┃ konsultasikan dengan dokter.
┃
╰━━━━━━━━━━━━━━━━━━━━⬣`

        await m.reply(teks)

        await m.react("✅")

    } catch (err) {

        console.log(err)

        await m.react("❌")

        m.reply("Gagal mendapatkan informasi medis.")

    }

}

handler.command = ["doctor", "medic"]
handler.tags = ["ai"]
handler.help = ["doctor <pertanyaan kesehatan>"]

export default handler