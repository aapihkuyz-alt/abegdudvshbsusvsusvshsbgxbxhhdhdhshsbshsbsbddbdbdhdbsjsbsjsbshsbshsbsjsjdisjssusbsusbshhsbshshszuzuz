import axios from 'axios'
import FormData from 'form-data'
import { fileTypeFromBuffer } from 'file-type'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''

    if (!mime) throw `Balas gambar dengan caption *${usedPrefix + command} <prompt>*`
    if (!/image\/(jpe?g|png)/.test(mime)) throw `Format gambar tidak didukung! Pastikan yang Anda kirim adalah foto (JPEG/PNG).`
    if (!text) throw `Silakan masukkan instruksi editnya.\nContoh: *${usedPrefix + command} jadikan hitam putih*`

    await m.react("⏳")

    try {
        // 1. Download Media
        let img = await q.download().catch(() => null)
        if (!img) throw 'Gagal mengunduh gambar. Pastikan pesan media masih tersedia.'

        let { ext } = await fileTypeFromBuffer(img) || { ext: 'jpg' }
        
        // 2. Upload ke Catbox (Dapatkan URL)
        let form = new FormData()
        form.append('fileToUpload', img, `image.${ext}`)
        form.append('reqtype', 'fileupload')

        const catbox = await axios.post('https://catbox.moe/user/api.php', form, {
            headers: { ...form.getHeaders() }
        })
        let imageUrl = String(catbox.data).trim()
        if (!imageUrl.startsWith('http')) throw 'Gagal mengupload gambar ke server penyimpanan.'

        // 3. Hit API Alyachan
        const { data } = await axios.get('https://api.alyachan.dev/api/ai/edit', {
            params: {
                image_url: imageUrl,
                prompt: text
            },
            headers: {
                'Authorization': `Bearer ${global.alyachan}`,
                'Content-Type': 'application/json'
            }
        })

        if (!data.status) throw data.message || 'Gagal memproses gambar melalui AI.'
        let resultUrl = data.data.images?.[0]?.url
        if (!resultUrl) throw 'Gagal mendapatkan URL hasil edit.'

        // 4. Polling Hasil (Max 12 kali / 1 menit)
        let buffer
        let maxRetries = 12
        let retries = 0

        while (retries < maxRetries) {
            try {
                let res = await axios.get(resultUrl, {
                    responseType: 'arraybuffer',
                    timeout: 10000
                })
                if (res.status === 200) {
                    buffer = res.data
                    break
                }
            } catch (e) {
                // Gambar belum siap atau error network
                retries++
                if (retries >= maxRetries) throw 'Waktu tunggu habis. Server AI terlalu lama memproses gambar Anda.'
                await new Promise(resolve => setTimeout(resolve, 5000))
            }
        }

        // 5. Kirim Hasil
        if (buffer) {
            await conn.sendFile(m.chat, Buffer.from(buffer), 'edited.jpg', `✨ *HASIL EDIT AI*\n📌 *Prompt:* ${text}`, m)
            await m.react("✅")
        }

    } catch (e) {
        console.error("EDITAI ERROR:", e)
        await m.react("❌")
        m.reply(`❌ *Error:* ${e.message || e || 'Terjadi kesalahan internal.'}`)
    }
}

handler.help = ['aiedit <prompt>', 'editai <prompt>']
handler.tags = ['ai']
handler.command = /^(aiedit|editai)$/i
handler.limit = true

export default handler
