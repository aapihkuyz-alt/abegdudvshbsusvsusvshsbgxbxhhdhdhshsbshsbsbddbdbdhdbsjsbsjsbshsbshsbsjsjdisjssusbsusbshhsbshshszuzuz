import axios from "axios"
import FormData from "form-data"

async function uploadCatbox(buffer) {
    const form = new FormData()
    form.append("reqtype", "fileupload")
    form.append("fileToUpload", buffer, "image.jpg")

    let {
        data
    } = await axios.post(
        "https://catbox.moe/user/api.php",
        form, {
            headers: form.getHeaders()
        }
    )

    return data
}

let handler = async (m, {
    text
}) => {

    let url = text

    if (m.quoted && m.quoted.isMedia) {

        await m.react("📤")

        let buffer = await m.quoted.download()

        url = await uploadCatbox(buffer)

    }

    if (!url) {
        return m.reply(
            `Reply gambar atau kirim link.

Contoh:
.facedetect
.facedetect https://example.com/image.jpg`
        )
    }

    await m.react("🔍")

    try {

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/face/detector", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                },
                params: {
                    image_url: url
                }
            }
        )

        if (!data.status) throw "API gagal"

        let gender = data.data.gender
        let age = data.data.age

        let teks = `╭━━━〔 🧠 FACE DETECTION 〕━━━⬣
┃
┃ 📥 Image
┃ ${url}
┃
┃ 👤 Gender
┃ ${gender}
┃
┃ 🎂 Estimated Age
┃ ${age} years
┃
┃ ℹ️ Note
┃ Hasil ini merupakan estimasi AI
┃ berdasarkan analisis wajah pada
┃ gambar yang diproses.
┃
╰━━━━━━━━━━━━━━━━━━━━⬣`

        await m.reply(teks)

        await m.react("✅")

    } catch (err) {

        console.log(err)

        await m.react("❌")

        m.reply("Gagal menganalisis wajah.")

    }

}

handler.command = ["facedetect", "faceai"]
handler.tags = ["ai"]
handler.help = ["facedetect <reply image / url>"]

export default handler