import axios from "axios"
import FormData from "form-data"

async function uploadCatbox(buffer) {
    const form = new FormData()
    form.append("reqtype", "fileupload")
    form.append("fileToUpload", buffer, "image.jpg")

    let {
        data
    } = await axios.post(
        "https://catbox.moe/user/api.php",
        form, {
            headers: form.getHeaders()
        }
    )

    return data
}

let handler = async (m, {
    conn,
    text
}) => {

    let url = ""
    let setting = {
        rotate_pitch: 0,
        rotate_yaw: 0,
        rotate_roll: 0,
        blink: 0,
        eyebrow: 0,
        wink: 0,
        pupil_x: 0,
        pupil_y: 0,
        aaa: 0,
        eee: 0,
        woo: 0,
        smile: 0
    }

    if (m.quoted && m.quoted.isMedia) {

        await m.react("📤")

        let buffer = await m.quoted.download()

        url = await uploadCatbox(buffer)

        if (text === "wink") setting.wink = 24
        else if (text === "smile") setting.smile = 20
        else if (text === "blink") setting.blink = 20
        else if (text === "surprise") setting.aaa = 30

    } else {

        let args = text.split("|")

        if (args.length < 2) {
            return m.reply(
                `Gunakan format:

Reply gambar:
.faceexp wink
.faceexp smile

Atau pakai link:
.faceexp https://gambar.jpg | smile`
            )
        }

        url = args[0].trim()
        let mode = args[1].trim()

        if (mode === "wink") setting.wink = 24
        else if (mode === "smile") setting.smile = 20
        else if (mode === "blink") setting.blink = 20
        else if (mode === "surprise") setting.aaa = 30

    }

    await m.react("🎭")

    try {

        let {
            data
        } = await axios.post(
            "https://api.alyachan.dev/api/ai/face/expression", {
                image_url: url,
                setting
            }, {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                }
            }
        )

        if (!data.status) throw "API gagal"

        let img = data.data.url

        let caption = `╭━━━〔 🎭 FACE EXPRESSION AI 〕━━━⬣
┃
┃ 📥 Source
┃ ${url}
┃
┃ 🎬 Expression Mode
┃ ${text || "custom"}
┃
┃ ⚙️ Status
┃ Expression successfully applied
┃
┃ ℹ️ Info
┃ Sistem AI memodifikasi ekspresi
┃ wajah berdasarkan parameter
┃ yang diberikan pada model.
┃
╰━━━━━━━━━━━━━━━━━━━━⬣`

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: img
                },
                caption
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (err) {

        console.log(err)

        await m.react("❌")

        m.reply("Gagal memproses ekspresi wajah.")

    }

}

handler.command = ["faceexp", "expression"]
handler.tags = ["ai"]
handler.help = ["faceexp <reply image / url | mode>"]

export default handler