import axios from "axios"
import FormData from "form-data"

global.swapAlbum = global.swapAlbum || {}

async function uploadCatbox(buffer) {
    const form = new FormData()
    form.append("reqtype", "fileupload")
    form.append("fileToUpload", buffer, "image.jpg")

    let {
        data
    } = await axios.post(
        "https://catbox.moe/user/api.php",
        form, {
            headers: form.getHeaders()
        }
    )

    return data
}

let handler = async (m, {
    conn
}) => {

    if (!m.isMedia) return
    if (!/image/.test(m.msg?.mimetype || "")) return

    let group = m.msg?.contextInfo?.mediaGroupId
    if (!group) return

    global.swapAlbum[group] = global.swapAlbum[group] || []

    let buffer = await m.download()

    global.swapAlbum[group].push(buffer)

    if (global.swapAlbum[group].length < 2) return

    try {

        await m.react("🧠")

        let face = global.swapAlbum[group][0]
        let base = global.swapAlbum[group][1]

        delete global.swapAlbum[group]

        let faceUrl = await uploadCatbox(face)
        let baseUrl = await uploadCatbox(base)

        let {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/face/swapper", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`
                },
                params: {
                    face_image_url: faceUrl,
                    base_image_url: baseUrl
                }
            }
        )

        if (!data.status) throw "API gagal"

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption: "🎭 *FACE SWAP BERHASIL*"
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (e) {
        console.log(e)
        await m.react("❌")
    }

}

handler.command = ["faceswap", "fswap"]
handler.tags = ["ai"]
handler.help = ["faceswap (kirim 2 gambar album)"]

export default handler