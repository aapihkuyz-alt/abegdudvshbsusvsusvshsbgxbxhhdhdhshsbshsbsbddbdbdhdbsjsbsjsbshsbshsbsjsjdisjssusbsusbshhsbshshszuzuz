import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan pertanyaan.\nContoh:\n#felo halo")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🤖", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/felo", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.message)
            return m.reply("❌ Gagal mendapatkan jawaban dari Felo AI.")

        let result = `
🤖 *Felo AI Response*

${data.data.message}
`.trim()

        if (data.data.relatedQuestions?.length) {
            result += "\n\n🔎 *Related Questions:*"
            data.data.relatedQuestions.slice(0, 3).forEach((q, i) => {
                result += `\n${i + 1}. ${q}`
            })
        }

        await conn.sendMessage(m.chat, {
            text: result
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("FELO ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat menghubungi Felo AI.")
    }
}

handler.command = ["felo"]
handler.tags = ["ai"]
handler.help = ["felo <pertanyaan>"]

export default handler