import axios from "axios"
import FormData from "form-data"

const styles = [
    "Anime", "Dreamy", "Shonen", "Ninja", "Cartoon", "3D Toon",
    "Illustration", "Action Figure", "Yellowtopia", "Cyberpunk",
    "Claymation", "Fairy Tale", "Ricky", "Family", "Oil Painting",
    "Pop Art", "Arcane", "Vaporwave", "Fantasy Art", "Mosaic"
]

async function uploadCatbox(buffer) {
    const form = new FormData()
    form.append("reqtype", "fileupload")
    form.append("fileToUpload", buffer, "image.jpg")

    const {
        data
    } = await axios.post(
        "https://catbox.moe/user/api.php",
        form, {
            headers: form.getHeaders()
        }
    )

    return data
}

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) {
        return m.reply(
            `🎨 *Filter AI Image*\n\nGunakan dengan cara:\nReply gambar lalu kirim:\n\n#filter <style>\n\n📜 *Style tersedia:*\n\n${styles.join("\n")}`
        )
    }

    if (!styles.includes(text)) {
        return m.reply(
            `❌ Style *${text}* tidak tersedia.\n\n📜 *Style yang tersedia:*\n\n${styles.join("\n")}`
        )
    }

    if (!m.quoted)
        return m.reply("Reply gambar yang ingin difilter.")

    let mime = m.quoted?.msg?.mimetype || ""

    if (!/image/.test(mime))
        return m.reply("Yang direply harus gambar.")

    try {

        await m.react("🎨")

        let buffer = await m.quoted.download()

        let imageUrl = await uploadCatbox(buffer)

        let res = await axios.get(
            "https://api.alyachan.dev/api/ai/filter", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`
                },
                params: {
                    image_url: imageUrl,
                    model: text
                }
            }
        )

        let data = res.data

        if (!data.status)
            return m.reply("API gagal memproses gambar.")

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption: `✨ *Filter berhasil diterapkan*\n\n🎨 Style : ${text}`
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (e) {

        console.log(e)

        await m.react("❌")

        m.reply("Terjadi error saat memproses gambar.")

    }

}

handler.command = /^(filter)$/i
handler.tags = ["ai"]
handler.help = ["filter <style>"]

export default handler