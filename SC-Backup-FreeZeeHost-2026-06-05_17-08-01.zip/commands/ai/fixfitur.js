import axios from 'axios';
import { GoogleGenerativeAI } from '@google/generative-ai';
import fs from 'fs';
import path from 'path';

/**
 * 🛠️ AI AUTO-FIXER & APPLY (ALYA + GEMINI FALLBACK)
 */

const handler = async (m, { conn, text, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let codeToFix = q.text || q.caption || "";
    let targetPath = text ? text.trim() : "";

    if (!codeToFix) {
        return m.reply(`*Format Salah!*\n\n1. Reply kode/error yang mau diperbaiki.\n2. Ketik: *${usedPrefix + command} path/file.js*\n\nContoh: *${usedPrefix + command} commands/tools/ping.js*`);
    }

    if (!targetPath) {
        return m.reply(`⚠️ *Path File Belum Diisi!*\n\nAbang mau perbaikan ini diterapin ke file mana?\nContoh: *${usedPrefix + command} commands/tools/test.js*`);
    }

    let absolutePath = path.resolve(process.cwd(), targetPath);
    if (!fs.existsSync(absolutePath)) {
        return m.reply(`❌ *File Tidak Ditemukan!*\nPastikan path filenya bener Bang:\n${targetPath}`);
    }

    await m.react("⏳");
    let { key } = await m.reply("🔍 *[ ANALYZING ]* Mencari solusi perbaikan...");

    const updateStatus = async (teks) => {
        try {
            await conn.sendMessage(m.chat, { text: teks, edit: key });
        } catch (e) {
            let res = await m.reply(teks);
            key = res.key;
        }
    };

    try {
        const systemInstruction = `Kamu adalah Senior Programmer AI.
Tugasmu:
1. Perbaiki kode/error yang diberikan.
2. HANYA JAWAB DENGAN FULL KODE YANG SUDAH DIPERBAIKI.
3. JANGAN berikan penjelasan, jangan pake markdown (tanpa \`\`\`), jangan ada teks apapun selain kode.
4. Pastikan formatnya ESM (export default handler).
KODINGAN/ERROR:
${codeToFix}`;

        let fixedCode;
        
        // 1. Coba pake Alyachan GPT-4
        try {
            const res = await axios.get("https://api.alyachan.dev/api/ai/gpt4", {
                headers: { Authorization: `Bearer ${global.alyachan}` },
                params: { prompt: systemInstruction },
                timeout: 30000
            });
            fixedCode = res.data?.data?.content;
        } catch (e) {
            // 2. Fallback Gemini SDK
            try {
                const genAI = new GoogleGenerativeAI(global.googleAiApiKey);
                const model = genAI.getGenerativeModel({ model: "gemini-3.1-pro" });
                const result = await model.generateContent(systemInstruction);
                fixedCode = result.response.text();
            } catch (e2) {
                throw new Error("Semua layanan AI sedang sibuk.");
            }
        }

        if (!fixedCode) throw new Error("AI tidak memberikan respon kode.");

        // Bersihkan jika AI masih ngeyel pake markdown
        fixedCode = fixedCode.replace(/^```[a-z]*\n?/gm, '').replace(/```$/gm, '').trim();

        await updateStatus(`💾 *[ APPLYING ]* Menerapkan perbaikan ke:\n_${targetPath}_`);

        // Terapkan ke file
        fs.writeFileSync(absolutePath, fixedCode);

        let report = `✅ *[ AUTO-FIX SUCCESS ]*

📁 *File:* ${targetPath}
✨ *Status:* Kode telah diperbarui secara otomatis.

_Sistem akan memuat ulang file ini dalam beberapa detik. Silakan coba fitur yang tadi error Bang!_`;

        await updateStatus(report);
        await m.react("✅");

    } catch (e) {
        console.error("FIXFITUR ERROR:", e);
        await updateStatus(`❌ *[ ERROR ]* Gagal menerapkan perbaikan: ${e.message}`);
        await m.react("❌");
    }
};

handler.help = ["fixfitur <path>"];
handler.command = ["fixfitur", "fixft", "debug", "perbaiki"];
handler.tags = ["ai"];
handler.owner = true;

export default handler;
