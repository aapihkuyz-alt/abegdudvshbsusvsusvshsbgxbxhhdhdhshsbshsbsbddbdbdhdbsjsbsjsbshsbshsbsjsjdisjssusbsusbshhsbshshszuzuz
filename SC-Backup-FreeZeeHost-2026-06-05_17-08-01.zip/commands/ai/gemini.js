import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply("Contoh:\n.gemini Hi")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "✨",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/gemini-chat", {
                params: {
                    q: text,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.message)
            throw new Error("API Error")

        const reply = data.data.message

        // jaga-jaga kalau terlalu panjang
        const max = 3500
        const output = reply.length > max ?
            reply.slice(0, max) + "\n\n...(Jawaban dipotong karena terlalu panjang)" :
            reply

        await conn.sendMessage(
            m.chat, {
                text: `✨ *Gemini AI*\n\n${output}`
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("GEMINI ERROR:", e.response?.data || e.message)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gemini sedang error atau API limit.")
    }
}

handler.help = ["gemini <text>", "geminiai <text>"]
handler.tags = ["ai"]
handler.command = ["gemini", "geminiai"]

export default handler