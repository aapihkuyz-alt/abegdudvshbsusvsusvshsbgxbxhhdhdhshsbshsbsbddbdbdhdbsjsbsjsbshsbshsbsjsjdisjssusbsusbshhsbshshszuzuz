import axios from "axios"

let handler = async (m, {
    conn,
    text,
    command,
    usedPrefix
}) => {

    if (!text) {
        await m.react("❌")
        return m.reply(`Contoh:
${usedPrefix + command} apa itu AI`)
    }

    await m.react("⏳")

    try {

        let res = await axios.get("https://api.alyachan.dev/api/ai/gemini", {
            headers: {
                Authorization: `Bearer ${global.alyachan}`,
                "Content-Type": "application/json"
            },
            params: {
                prompt: text
            }
        })

        let result = res.data?.data?.content || "AI tidak memberikan respon."

        await conn.sendMessage(m.chat, {
            text: `🤖 *${command.toUpperCase()} RESPONSE*

${result}

Ketik:
${usedPrefix + command} <pertanyaan>`
        }, {
            quoted: m
        })

        await m.react("✅")

    } catch (e) {

        console.log(e)

        await m.react("❌")
        m.reply("Gagal menghubungi AI.")

    }

}

handler.command = ["geminii"]
handler.tags = ["ai"]
handler.help = ["ai <pertanyaan>", "gemini <pertanyaan>"]

export default handler