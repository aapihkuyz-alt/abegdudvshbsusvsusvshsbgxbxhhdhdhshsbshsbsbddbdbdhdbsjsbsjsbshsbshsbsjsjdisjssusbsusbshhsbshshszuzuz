import axios from "axios"
import FormData from "form-data"

let handler = async (m, {
    conn
}) => {

    if (!m.quoted)
        return m.reply("❌ Reply gambar yang ingin dianalisa.")

    const mime =
        m.quoted.mimetype ||
        m.quoted.msg?.mimetype ||
        m.quoted.mediaType ||
        ""

    if (!/image/.test(mime))
        return m.reply("❌ File harus berupa gambar.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🔍", m.key)

        const media = await m.quoted.download()
        if (!media)
            return m.reply("❌ Gagal download gambar.")

        // ===== Upload ke tmpfiles =====
        const form = new FormData()
        form.append("file", media, "image.jpg")

        const upload = await axios.post(
            "https://tmpfiles.org/api/v1/upload",
            form, {
                headers: form.getHeaders()
            }
        )

        if (!upload.data?.data?.url)
            return m.reply("❌ Gagal upload gambar.")

        const rawUrl = upload.data.data.url
        const imageUrl = rawUrl.replace("tmpfiles.org/", "tmpfiles.org/dl/")

        // ===== Request API Gemini Vision =====
        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/gemini-vision", {
                params: {
                    image: imageUrl,
                    lang: "id",
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.description)
            return m.reply("❌ Gagal memproses gambar.")

        await conn.sendMessage(m.chat, {
            image: {
                url: imageUrl
            },
            caption: `🧠 *Gemini Vision Result*\n\n${data.data.description}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("GEMINI ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses gambar.")
    }
}

handler.command = ["geminivision", "gvision"]
handler.tags = ["ai"]
handler.help = ["geminivision (reply image)"]

export default handler