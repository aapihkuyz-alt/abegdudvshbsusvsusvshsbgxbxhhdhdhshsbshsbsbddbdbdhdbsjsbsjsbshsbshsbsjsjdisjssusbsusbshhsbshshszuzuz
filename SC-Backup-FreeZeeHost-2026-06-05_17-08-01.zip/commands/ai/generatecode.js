import axios from "axios"
import { GoogleGenerativeAI } from '@google/generative-ai';

let handler = async (m, {
    text,
    conn,
    usedPrefix,
    command
}) => {

    if (!text) {
        return m.reply(
            `📌 Contoh penggunaan:

${usedPrefix + command} buat server express
${usedPrefix + command} bot whatsapp baileys
${usedPrefix + command} website login sederhana`
        )
    }

    await m.react("⏳")

    let fullPrompt = text;
    if (command === "getcode") {
        fullPrompt = `Buatkan fitur bot WhatsApp dengan fungsionalitas: ${text}. Gunakan format Plugin ESM (export default handler) untuk Baileys.`;
    }

    try {
        // Method 1: Alyachan API (Primary)
        const config = {
            method: 'GET',
            url: 'https://api.alyachan.dev/api/ai/generator/code',
            headers: { 
                'Authorization': `Bearer ${global.alyachan}`,
                'Content-Type': 'application/json'
            },
            params: {
                "prompt": fullPrompt,
                "language": "js"
            },
            timeout: 45000 
        };

        const response = await axios.request(config);
        const data = response.data;

        if (!data || !data.status) throw new Error("API Alyachan gagal merespon.");

        let codeResult = data.data?.code || "Tidak ada kode yang dihasilkan.";

        let teks = `╭─❍ *AI CODE GENERATOR*
│
│ 🤖 *Sistem:* Alyachan AI
│ 📌 *Prompt:* ${text}
│
├────────────────

${codeResult}

├────────────────
│
│ 🚀 Terus eksplorasi teknologi
│ dan kembangkan proyek Anda!
│
╰─❍ *FreeZeeHost Systems*`

        await m.reply(teks)
        await m.react("✅")

    } catch (err) {
        console.error("ALYACHAN ERROR:", err.message);

        // Method 2: Gemini API SDK (Fallback)
        try {
            if (!global.googleAiApiKey || global.googleAiApiKey === "API_KEY_DISINI") throw new Error("Gemini key not set");

            const genAI = new GoogleGenerativeAI(global.googleAiApiKey);
            const model = genAI.getGenerativeModel({ model: "gemini-3.1-pro" });

            const systemInstruction = "Kamu adalah Senior Programmer AI. Buatkan kode lengkap dan fungsional sesuai permintaan user. Berikan penjelasan singkat di akhir. Jika untuk bot WhatsApp, gunakan format Plugin ESM.";
            const finalPrompt = `${systemInstruction}\n\nPermintaan: ${fullPrompt}`;

            const result = await model.generateContent(finalPrompt);
            const geminiText = result.response.text();

            if (!geminiText) throw new Error("Gemini tidak merespon.");

            let teks = `╭─❍ *AI CODE GENERATOR (GEMINI)*
│
│ 🤖 *Sistem:* Gemini AI (Backup)
│ 📌 *Prompt:* ${text}
│
├────────────────

${geminiText}

├────────────────
│
╰─❍ *FreeZeeHost Systems*`

            await m.reply(teks);
            await m.react("✅");

        } catch (err2) {
            console.error("GEMINI ERROR:", err2.message);
            await m.react("❌");
            m.reply(`❌ *Semua Layanan Gangguan*\n\nAlyachan: ${err.message}\nGemini: ${err2.message}`);
        }
    }
}

handler.command = ["generatecode", "codegen", "code", "gencode", "getcode"]
handler.tags = ["ai"]
handler.help = ["code <prompt>"]

export default handler