import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan prompt gambar.\nContoh:\n#genimg black cat")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/genimg", {
                params: {
                    prompt: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal generate gambar.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `🖼️ *AI Generated Image*\n\n📝 Prompt: ${data.data.prompt}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("GENIMG ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat generate gambar.")
    }
}

handler.command = ["genimg"]
handler.tags = ["ai"]
handler.help = ["genimg <prompt>"]

export default handler