import axios from 'axios'

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) {
        return m.reply(`Masukkan pertanyaan.\n\nContoh:\n${usedPrefix + command} apa itu cosmic indifference?`)
    }

    try {
        // React robot 🤖
        await conn.sendMessage(m.chat, {
            react: {
                text: '🤖',
                key: m.key
            }
        })

        const result = await g.search(text)

        if (!result || typeof result !== 'string') {
            return m.reply('API gagal merespon dengan benar.')
        }

        m.reply(result.slice(0, 4000))

    } catch (e) {
        console.error('[GPT ERROR]', e)
        m.reply('Terjadi kesalahan saat mengambil jawaban.')
    }
}

handler.help = ['gpt <query>']
handler.tags = ['ai']
handler.command = /^(gpt|chatgpt)$/i
handler.limit = true
handler.description = 'Chat dengan GPT menggunakan API Neoxr.'

export default handler

// =======================
// GPT CORE
// =======================

const g = {
    async search(query) {
        if (!global.neoxr) {
            return 'API key tidak ditemukan di global.neoxr'
        }

        try {
            const res = await axios.get('https://api.neoxr.eu/api/gpt-oss', {
                params: {
                    q: query,
                    apikey: global.neoxr
                },
                timeout: 20000
            })

            if (!res.data?.status) {
                return null
            }

            return res.data?.data?.message || null

        } catch (err) {
            console.log(err)
            return null
        }
    }
}