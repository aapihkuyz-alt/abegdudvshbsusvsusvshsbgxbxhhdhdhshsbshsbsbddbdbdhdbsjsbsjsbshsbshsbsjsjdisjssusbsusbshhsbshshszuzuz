import axios from "axios"

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text)
        return m.reply(`Contoh:\n${usedPrefix + command} Apa itu sistem elektronik`)

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🤖",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.alyachan.dev/api/ai/gpt4", {
                headers: {
                    Authorization: `Bearer ${global.alyachan}`,
                    "Content-Type": "application/json"
                },
                params: {
                    prompt: text
                }
            }
        )

        if (!data?.status) throw "API gagal"

        const result = data.data

        let reply = `🤖 *GPT-4 AI*\n\n${result.content}`

        if (Array.isArray(result.related) && result.related.length) {
            reply += `\n\n📌 *Pertanyaan Terkait*\n`
            reply += result.related.map(v => `• ${v}`).join("\n")
        }

        await conn.sendMessage(m.chat, {
            text: reply
        }, {
            quoted: m
        })

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {
        console.error("GPT ERROR:", e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("Terjadi error saat memanggil AI.")
    }
}

handler.help = ["gpt <pertanyaan>"]
handler.tags = ["ai"]
handler.command = ["gpt4"]

export default handler