import axios from "axios"
import FormData from "form-data"

let handler = async (m, {
    conn,
    text
}) => {

    if (!m.quoted)
        return m.reply("❌ Reply gambar.\nContoh:\n#img2vid jadikan video")

    const mime =
        m.quoted.mimetype ||
        m.quoted.msg?.mimetype ||
        ""

    if (!/image/.test(mime))
        return m.reply("❌ File harus berupa gambar.")

    if (!text)
        return m.reply("❌ Masukkan prompt.\nContoh:\n#img2vid jadikan video")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎬", m.key)

        const media = await m.quoted.download()
        if (!media) return m.reply("❌ Gagal download gambar.")

        // Upload ke telegra.ph
        const form = new FormData()
        form.append("file", media, "image.jpg")

        const upload = await axios.post(
            "https://telegra.ph/upload",
            form, {
                headers: form.getHeaders()
            }
        )

        if (!upload.data?.[0]?.src)
            return m.reply("❌ Gagal upload gambar.")

        const imageUrl = "https://telegra.ph" + upload.data[0].src

        await conn.sendMessage(m.chat, {
            text: "🎬 Sedang membuat video...\nMohon tunggu..."
        }, {
            quoted: m
        })

        // Request pertama
        let response = await axios.get(
            "https://api.neoxr.eu/api/img2vid", {
                params: {
                    image: imageUrl,
                    prompt: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        let result = response.data?.data

        // Kalau belum COMPLETE, tunggu dan coba lagi sekali
        if (result?.status !== "COMPLETE") {

            await new Promise(res => setTimeout(res, 15000))

            response = await axios.get(
                "https://api.neoxr.eu/api/img2vid", {
                    params: {
                        image: imageUrl,
                        prompt: text,
                        apikey: global.neoxr
                    },
                    timeout: 60000
                }
            )

            result = response.data?.data
        }

        if (!result?.url)
            return m.reply("❌ Gagal membuat video.")

        await conn.sendMessage(m.chat, {
            video: {
                url: result.url
            },
            caption: "🎬 Video berhasil dibuat!"
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("IMG2VID ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat membuat video.")
    }
}

handler.command = ["img2vid"]
handler.tags = ["ai"]
handler.help = ["img2vid (reply image)"]

export default handler