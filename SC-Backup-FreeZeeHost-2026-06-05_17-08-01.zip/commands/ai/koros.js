import axios from "axios"
import FormData from "form-data"

let handler = async (m, {
    conn,
    text
}) => {

    if (!m.quoted)
        return m.reply("❌ Reply gambar dan beri pertanyaan.\nContoh: #koros kisaran umur berapa")

    const mime =
        m.quoted.mimetype ||
        m.quoted.msg?.mimetype ||
        ""

    if (!/image/.test(mime))
        return m.reply("❌ File harus berupa gambar.")

    if (!text)
        return m.reply("❌ Masukkan pertanyaan.\nContoh: #koros kisaran umur berapa")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🔎", m.key)

        const media = await m.quoted.download()
        if (!media)
            return m.reply("❌ Gagal download gambar.")

        // ===== Upload ke tmpfiles =====
        const form = new FormData()
        form.append("file", media, "image.jpg")

        const upload = await axios.post(
            "https://tmpfiles.org/api/v1/upload",
            form, {
                headers: form.getHeaders()
            }
        )

        if (!upload.data?.data?.url)
            return m.reply("❌ Gagal upload gambar.")

        const rawUrl = upload.data.data.url
        const imageUrl = rawUrl.replace("tmpfiles.org/", "tmpfiles.org/dl/")

        // ===== Request ke API Neoxr =====
        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/koros", {
                params: {
                    image: imageUrl,
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.description)
            return m.reply("❌ Gagal memproses gambar.")

        await conn.sendMessage(m.chat, {
            text: `🖼 *Koros Vision Result*\n\n${data.data.description}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("KOROS ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses gambar.")
    }
}

handler.command = ["koros"]
handler.tags = ["ai"]
handler.help = ["koros <pertanyaan> (reply image)"]

export default handler