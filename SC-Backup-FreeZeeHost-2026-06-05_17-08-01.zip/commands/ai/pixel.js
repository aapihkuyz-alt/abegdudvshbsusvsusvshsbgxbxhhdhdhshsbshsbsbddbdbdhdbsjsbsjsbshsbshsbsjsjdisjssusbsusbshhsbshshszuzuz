import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan prompt.\nContoh: #aipixel black cat")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/ai-pixel", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal generate pixel image.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `🧩 *AI Pixel Result*\n\nPrompt: ${text}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("AI PIXEL ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat generate gambar.")
    }
}

handler.command = ["aipixel", "pixelimg", "pixel"]
handler.tags = ["ai"]
handler.help = ["aipixel <prompt>"]

export default handler