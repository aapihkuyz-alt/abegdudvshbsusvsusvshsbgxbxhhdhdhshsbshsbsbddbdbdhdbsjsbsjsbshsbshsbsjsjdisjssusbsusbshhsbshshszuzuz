import axios from "axios"
import fs from "fs"
import {
    exec
} from "child_process"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan teks.\nContoh: #ttsai halo dunia")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎙️", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/qwen-tts", {
                params: {
                    text,
                    voice: "0x1994",
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal generate suara.")

        // Download WAV
        const wav = await axios.get(data.data.url, {
            responseType: "arraybuffer"
        })

        const wavPath = "./temp.wav"
        const oggPath = "./temp.ogg"

        fs.writeFileSync(wavPath, wav.data)

        // Convert ke ogg opus
        await new Promise((resolve, reject) => {
            exec(
                `ffmpeg -i ${wavPath} -c:a libopus -b:a 128k ${oggPath} -y`,
                (err) => err ? reject(err) : resolve()
            )
        })

        const oggBuffer = fs.readFileSync(oggPath)

        await conn.sendMessage(m.chat, {
            audio: oggBuffer,
            mimetype: "audio/ogg; codecs=opus",
            ptt: true
        }, {
            quoted: m
        })

        fs.unlinkSync(wavPath)
        fs.unlinkSync(oggPath)

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("QWEN TTS ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat membuat suara.")
    }
}

handler.command = ["qwentts", "ttsai"]
handler.tags = ["ai"]
handler.help = ["ttsai <text>"]

export default handler