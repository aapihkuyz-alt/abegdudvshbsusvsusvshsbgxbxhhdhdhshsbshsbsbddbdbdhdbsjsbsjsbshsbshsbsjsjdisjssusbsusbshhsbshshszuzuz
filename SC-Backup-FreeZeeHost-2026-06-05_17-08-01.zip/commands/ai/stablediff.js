import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(
            "❌ Masukkan prompt.\n" +
            "Contoh:\n#stablediff a black cat on the chair\n\n" +
            "Format lengkap:\n#stablediff prompt|model|orientation"
        )

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        // Split opsi
        let [prompt, model, orientation] = text.split("|")

        prompt = prompt?.trim()
        model = model?.trim() || "origami"
        orientation = orientation?.trim() || "potrait"

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/stablediff", {
                params: {
                    prompt,
                    model,
                    orientation,
                    apikey: global.neoxr
                },
                timeout: 120000
            }
        )

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal generate gambar.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `🖼️ Stable Diffusion Result\n\n` +
                `📝 Prompt: ${prompt}\n` +
                `🧠 Model: ${model}\n` +
                `📐 Orientation: ${orientation}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("STABLEDIFF ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat generate gambar.")
    }
}

handler.command = ["stablediff"]
handler.tags = ["ai"]
handler.help = ["stablediff <prompt>|model|orientation"]

export default handler