import axios from "axios"
import FormData from "form-data"

let handler = async (m, {
    conn
}) => {

    if (!m.quoted)
        return m.reply("❌ Reply gambar yang ingin diubah.")

    const mime =
        m.quoted.mimetype ||
        m.quoted.msg?.mimetype ||
        m.quoted.mediaType ||
        ""

    if (!/image/.test(mime))
        return m.reply("❌ File harus berupa gambar.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const media = await m.quoted.download()
        if (!media)
            return m.reply("❌ Gagal download gambar.")

        // ===== Upload ke tmpfiles =====
        const form = new FormData()
        form.append("file", media, "image.jpg")

        const upload = await axios.post(
            "https://tmpfiles.org/api/v1/upload",
            form, {
                headers: form.getHeaders()
            }
        )

        if (!upload.data?.data?.url)
            return m.reply("❌ Gagal upload gambar.")

        // Ubah ke direct link
        const rawUrl = upload.data.data.url
        const imageUrl = rawUrl.replace("tmpfiles.org/", "tmpfiles.org/dl/")

        // ===== Request API Neoxr =====
        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/toghibli", {
                params: {
                    image: imageUrl,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal convert ke style Ghibli.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: "✨ Ghibli Style Result"
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("TOGHIBLI ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat convert gambar.")
    }
}

handler.command = ["toghibli", "togibli"]
handler.tags = ["ai"]
handler.help = ["toghibli (reply image)"]

export default handler