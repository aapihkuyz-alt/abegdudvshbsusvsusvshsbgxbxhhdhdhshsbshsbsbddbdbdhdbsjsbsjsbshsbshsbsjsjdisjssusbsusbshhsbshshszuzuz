import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan prompt.\nContoh:\n#waifudiff long hair")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/waifudiff", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 120000
            }
        )

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal generate waifu.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `🌸 Waifu Diffusion Result\n\n` +
                `📝 Prompt: ${text}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("WAIFUDIFF ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat generate waifu.")
    }
}

handler.command = ["waifudiff", "Waifuai"]
handler.tags = ["ai"]
handler.help = ["waifudiff <prompt>"]

export default handler