import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan pertanyaan.\nContoh:\n#you tanggal berapa sekarang?")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🤖", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/you", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.message)
            return m.reply("❌ Gagal mendapatkan jawaban.")

        await conn.sendMessage(m.chat, {
            text: `🤖 YOU AI\n\n` +
                `${data.data.message}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("YOU AI ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses permintaan.")
    }
}

handler.command = ["you"]
handler.tags = ["ai"]
handler.help = ["you <pertanyaan>"]

export default handler