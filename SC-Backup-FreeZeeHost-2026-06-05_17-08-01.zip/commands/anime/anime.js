import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan judul anime.\n\nContoh:\n.anime jujutsu kaisen")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🔎",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/anime", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data?.length)
            throw new Error("Anime tidak ditemukan")

        const results = data.data

        const native_flow_button = [{
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: "🎌 Pilih Anime",
                sections: [{
                    title: `Hasil untuk: ${text}`,
                    rows: results.map(v => ({
                        header: "Anime Result",
                        title: v.title,
                        description: `⭐ Score: ${v.score || "N/A"} • 📺 ${v.type}`,
                        id: `.animeget ${v.url}`
                    }))
                }]
            })
        }]

        const caption = `
╭━━━〔 🎌 ANIME SEARCH 〕━━━╮
┃ 🔎 Query :
┃ ➜ *${text}*
┃
┃ 📚 Ditemukan :
┃ ➜ *${results.length} Result*
┃
┃ ⚡ Pilih dari tombol di bawah
╰━━━━━━━━━━━━━━━━━━━━━━╯
✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                text: caption,
                footer: "Anime Fun System",
                interactive: native_flow_button
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("ANIME ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Anime tidak ditemukan atau API error.")
    }
}

handler.command = ["anime"]
handler.tags = ["anime"]
handler.help = ["anime <judul>"]

export default handler