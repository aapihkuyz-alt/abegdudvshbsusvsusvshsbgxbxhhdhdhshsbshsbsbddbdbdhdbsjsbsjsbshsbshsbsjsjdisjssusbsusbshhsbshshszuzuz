import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan URL anime.\n\nContoh:\n.animeget https://www.animebatch.id/xxxx")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🎌",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/anime-get", {
                params: {
                    url: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Detail anime tidak ditemukan")

        const res = data.data

        const caption = `
╭━━━〔 🎌 ANIME DETAIL 〕━━━╮
┃ 📺 Title    : ${res.title}
┃ 📊 Status   : ${res.status}
┃ 🎬 Type     : ${res.type}
┃ 🏢 Studio   : ${res.studio}
┃ ⏱ Duration  : ${res.duration}
┃ 🎭 Genre    : ${res.genre}
┃ ⭐ Score     : ${res.score || "N/A"}
┃ 👁 Views     : ${res.views}
╰━━━━━━━━━━━━━━━━━━━━━━╯

📖 ${res.description?.slice(0, 500) || "-"}
`.trim()

        // ===== BUILD ROWS =====
        const rows = res.episode.map(ep => {

            // Cari kualitas 720P
            const q720 = ep.link.find(q =>
                q.quality?.toUpperCase() === "720P"
            )

            if (!q720) {
                return {
                    header: "Episode",
                    title: ep.episode,
                    description: "720P tidak tersedia",
                    id: "not_available"
                }
            }

            // Prioritas GDrive
            let selected =
                q720.url.find(u =>
                    u.server.toLowerCase().includes("gdrive")
                ) || q720.url[0]

            return {
                header: "Episode",
                title: ep.episode,
                description: `Download 720P (${selected.server})`,
                id: `.gdrivedl ${selected.url}`
            }
        })

        const native_flow_button = [{
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: "📥 Pilih Episode (720P)",
                sections: [{
                    title: "Daftar Episode",
                    rows
                }]
            })
        }]

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: res.thumbnail
                },
                caption,
                footer: "Anime Fun System",
                interactive: native_flow_button
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("ANIMEGET ERROR:", e.response?.data || e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil detail anime.")
    }
}

handler.command = ["animeget"]
handler.tags = ["anime"]
handler.help = ["animeget <url anime>"]

export default handler