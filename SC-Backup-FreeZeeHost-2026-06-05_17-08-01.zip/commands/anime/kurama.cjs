
const axios = require("axios");
const cheerio = require("cheerio");

class kurama {
  constructor() {
    this.u = 'https://v8.kuramanime.tel';
    this.targetEnv = 'data-kk';
    this.is = axios.create({
      baseURL: this.u,
      headers: {
        'user-agent': 'Mozilla/5.0 (Linux; Android 16; NX729J) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7499.34 Mobile Safari/537.36',
        'origin': this.u,
        'referer': this.u,
      }
    });
  }

  async search(query, page = 1, order_by = "latest") {
  try {
    const f = await this.is.get(`/anime`, {
      params: {
        order_by,
        search: query,
        page,
        need_json: true
      }
    }).then(i => i.data);

    const nextPage = f.animes.next_page_url 
      ? f.animes.next_page_url.split('page=')?.[1] 
      : null;

    const res = {
      animes: f.animes.data.map(p => ({
        url: this.u + `/anime/${p.id}/${p.slug}`,
        ...p
      })),
      hasNextPage: !!f.animes.next_page_url,
      nextPage
    };

    return res;
  } catch (error) {
    console.error('Error in kurama.search:', error);
    throw error;
  }
}

  async detail(url, page = 0) {
    try {
      const wb = await this.is.get(url, {
          params: {
            page
          }
        }),
        $ = cheerio.load(wb.data),
        [tp, episode, related, tags, fn] = [
          ...Array.from({
            length: 4
          }).map(i => ([])),
          (x, z) => $(x).each((_, l) => z(l))
        ]

      const detail = {
        title: $('.anime__details__title h3').text().trim(),
        alternativeTitle: $('.anime__details__title span').text().trim(),
        rating: $('.anime__details__pic__mobile .ep').text().trim(),
        img: $('.anime__details__pic__mobile').attr('data-setbg'),
        sinopsis: $('#synopsisField').text().trim()
      };

      fn('.anime__details__widget ul li .row', l => {
        let [t1, t2, t3] = [
          $(l).find('.col-3 span').text().replace(/:/, '').toLowerCase(), $(l).find('.col-9')
        ]
        if ($(t2).find('a').length >= 2) {
          t3 = [];
          $(t2).find('a').each((_, h) => {
            t3.push($(h).text().trim())
          });
          if (t1 === 'tayang') t3 = t3.join(' ');
        } else {
          t3 = t2.text().trim()
        }
        detail[t1] = t3;
      });

      const strEps = cheerio.load($('#episodeLists').attr('data-content') || '');
      strEps('.btn-danger').each((_, el) => {
        const title = $(el).text().trim()
        const link = $(el).attr('href')
        tp.push({
          title,
          episode: parseInt(title.replace(/\D/g, '')),
          link
        })
      })

      tp.reverse().forEach((ep, id) => episode.push({
        index: id + 1,
        ...ep
      }));

      fn('.anime__details__review .breadcrumb__links__v2 div a', l => {
        related.push({
          title: $(l).text().slice(2).trim(),
          url: $(l).attr('href')
        });
      });

      fn('#tagSection .breadcrumb__links__v2__tags a', l => {
        tags.push($(l).text().trim().replace(',', ''));
      });

      const nextPage = strEps.html().match(/page=(.*?)" (.*)fa-forward/)?.[1]

      return {
        id: $('input#animeId').attr('value'),
        detail,
        episode,
        related,
        tags,
        nextEpsode: !!nextPage,
        pageNextEpsode: nextPage,
      };
    } catch (error) {
      throw error;
    }
  }

  async ex(a, b) {
    try {
      const c = cheerio.load(b.data)(`.row div[${this.targetEnv}]`).attr(this.targetEnv),
        d = await this.is.get(`/assets/js/${c}.js`),
        e = d.data.match(/= ({[\s\S]*?});/)?.[1],
        [j1, j2, j3] = [
          e.match(/MIX_AUTH_ROUTE_PARAM: '(.*?)',/)?.[1],
          e.match(/MIX_PAGE_TOKEN_KEY: '(.*?)',/)?.[1],
          e.match(/MIX_STREAM_SERVER_KEY: '(.*?)',/)?.[1]
        ],
        f = await this.is.get(`/assets/${j1}`),
        param = [
          [j2, f.data.trim()],
          [j3, 'kuramadrive'],
          ['page', '1']
        ],
        g = new URL(a);
      param.map(i => g.searchParams.set(...i));
      return g.toString();
    } catch (e) {
      throw "Failed to init url"
    }
  }

  async episode(url) {
    try {
      const t = await this.is.get(url),
        k = await this.ex(url, t),
        a = await axios.get(k, {
          headers: {
            cookie: t.headers['set-cookie'].map(i => `${i};`).join('')
          }
        }),
        [$, fn] = [
          cheerio.load(a.data), (x, z) => $(x).each((_, l) => z(l))
        ]

      const result = {
        id: $('input#animeId').attr('value'),
        postId: $('input#postId').attr('value'),
        title: $('title').text(),
        lastUpdated: $('.breadcrumb__links__v2 > span:nth-child(2)').text().split("\n")[0],
        batch: $('a.ep-button[type="batch"]').attr('href') || null,
        episode: [],
        download: [],
        video: []
      }

      fn('a.ep-button[type="episode"]', l => {
        if ($(l).text().trim()) result.episode.push({
          episode: $(l).text().trim(),
          url: $(l).attr('href')
        });
      });

      $('#animeDownloadLink').find('h6').each((_, l) => {
        let [ne, reso] = [
          $(l).next(), {
            type: $(l).text().trim(),
            links: []
          }
        ]
        while (ne.length && !ne.is('h6') && !ne.is('br')) {
          if (ne.is('a')) {
            reso.links.push({
              name: ne.text().trim(),
              url: ne.attr('href'),
              recommended: ne.find('i.fa-fire').length > 0
            });
          }
          ne = ne.next();
        }
        if (reso.links.length > 0) {
          result.download.push(reso);
        }
      });

      fn('#player source', l => {
        result.video.push({
          quality: $(l).attr('size'),
          url: $(l).attr('src')
        });
      });

      return result
    } catch (e) {
      throw e
    }
  }

  async schedule(day, page = 1) {
    try {
      const f = await this.is.get('/schedule', {
        params: {
          scheduled_day: day,
          page,
          need_json: true
        }
      }).then(i => i.data)

      const res = {
        animes: f.animes.data.map(p => ({
          url: this.u + `/anime/${p.id}/${p.slug}`,
          ...p
        })),
        hasNextPage: !!f.animes.next_page_url,
        nextPage: f.animes.next_page_url.split('page=')?.[1],
      }
      return res
    } catch (e) {
      throw e
    }
  }

  async ongoing(page = 1) {
    try {
      const f = await this.is.get('/', {
        params: {
          page,
          need_json: true
        }
      }).then(i => i.data)

      const res = {
        animes: f.ongoingAnimes.data.map(p => ({
          url: this.u + `/anime/${p.id}/${p.slug}`,
          ...p
        })),
        hasNextPage: !!f.ongoingAnimes.next_page_url,
        nextPage: f.ongoingAnimes.next_page_url.split('page=')?.[1],
      }
      return res
    } catch (e) {
      throw e
    }
  }

  async finished(page = 1) {
    try {
      const f = await this.is.get('/', {
        params: {
          page,
          need_json: true
        }
      }).then(i => i.data)

      const res = {
        animes: f.finishedAnimes.data.map(p => ({
          url: this.u + `/anime/${p.id}/${p.slug}`,
          ...p
        })),
        hasNextPage: !!f.finishedAnimes.next_page_url,
        nextPage: f.finishedAnimes.next_page_url.split('page=')?.[1],
      }
      return res
    } catch (e) {
      throw e
    }
  }

  async movie(page = 1) {
    try {
      const f = await this.is.get('/', {
        params: {
          page,
          need_json: true
        }
      }).then(i => i.data)

      const res = {
        animes: f.movieAnimes.data.map(p => ({
          url: this.u + `/anime/${p.id}/${p.slug}`,
          ...p
        })),
        hasNextPage: !!f.movieAnimes.next_page_url,
        nextPage: f.movieAnimes.next_page_url.split('page=')?.[1],
      }
      return res
    } catch (e) {
      throw e
    }
  }
}


const handler = async (m, {
  command,
  text,
  conn,
  args
}) => {
  const kuramaClient = new kurama();
  const subCommand = args[0]?.toLowerCase();
  const query = args.slice(1).join(' ');

  const formatAnimeList = (title, animes) => {
    if (!animes || animes.length === 0) return `No results found for ${title}.`;
    let msg = `*${title}*\n\n`;
    animes.forEach((anime, index) => {
      msg += `*${index + 1}. ${anime.title}*\n`;
      msg += `Status: ${anime.status}\n`;
      msg += `Rating: ${anime.rating || 'N/A'}\n`;
      msg += `URL: ${anime.url}\n\n`;
    });
    return msg.trim();
  };

  try {
    switch (subCommand) {
      case 'search':
        if (!query) return m.reply(`Please provide a search query.\nExample: .${command} search Naruto`);
        m.reply('Searching, please wait...');
        const searchResult = await kuramaClient.search(query);
        await m.reply(formatAnimeList(`Search Results for "${query}"`, searchResult.animes));
        break;

      case 'detail':
  if (!query || !query.startsWith('http')) 
    return m.reply(`Please provide a valid Kuramanime URL.\nExample: .${command} detail ${kuramaClient.u}/anime/...`);

  await m.reply('Fetching details, please wait...');

  const detailResult = await kuramaClient.detail(query);

  // Bangun pesan teks
  let detailMsg = `*Title:* ${detailResult.detail.title}\n`;
  if (detailResult.detail.alternativeTitle) 
    detailMsg += `*Alternative:* ${detailResult.detail.alternativeTitle}\n`;
  detailMsg += `*Rating:* ${detailResult.detail.rating}\n\n`;
  detailMsg += `*Synopsis:*\n${detailResult.detail.sinopsis}\n\n`;

  for (const key in detailResult.detail) {
    if (['title', 'alternativeTitle', 'rating', 'sinopsis', 'img'].includes(key)) continue;
    let value = detailResult.detail[key];
    if (Array.isArray(value)) value = value.join(', ');
    detailMsg += `*${key.charAt(0).toUpperCase() + key.slice(1)}:* ${value}\n`;
  }

  detailMsg += `\n*Total Episodes:* ${detailResult.episode.length}`;
  if (detailResult.tags.length > 0) 
    detailMsg += `\n*Tags:* ${detailResult.tags.join(', ')}`;

  // Kirim gambar + caption jika ada, atau teks saja
  if (detailResult.detail.img) {
    const ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch(_ => global.thumbreply);
    await conn.sendMessage(m.chat, {
      image: { url: detailResult.detail.img },
      caption: detailMsg,
      contextInfo: {
        mentionedJid: [m.sender]
      }
    }, { quoted: m });
  } else {
    await m.reply(detailMsg); // teks saja
  }
break;

      case 'episode':
        if (!query || !query.startsWith('http')) return m.reply(`Please provide a valid Kuramanime episode URL.\nExample: .${command} episode ${kuramaClient.u}/episode/...`);
        m.reply('Fetching episode links, please wait...');
        const episodeResult = await kuramaClient.episode(query);
        let episodeMsg = `*${episodeResult.title}*\n\n`;
        if (episodeResult.video.length > 0) {
          episodeMsg += '*Video Streams:*\n';
          episodeResult.video.forEach(v => {
            episodeMsg += `- Quality ${v.quality}: ${v.url}\n`;
          });
          episodeMsg += '\n';
        }
        if (episodeResult.download.length > 0) {
          episodeMsg += '*Download Links:*\n';
          episodeResult.download.forEach(d => {
            episodeMsg += `*${d.type}:*\n`;
            d.links.forEach(link => {
              episodeMsg += `- ${link.name}${link.recommended ? ' 🔥' : ''}: ${link.url}\n`;
            });
          });
        }
        await m.reply(episodeMsg.trim());
        break;

      case 'schedule':
        const days = ['senin', 'selasa', 'rabu', 'kamis', 'jumat', 'sabtu', 'minggu'];
        if (!query || !days.includes(query.toLowerCase())) return m.reply(`Please provide a valid day.\nAvailable: ${days.join(', ')}\nExample: .${command} schedule senin`);
        m.reply(`Fetching schedule for ${query}, please wait...`);
        const scheduleResult = await kuramaClient.schedule(query);
        await m.reply(formatAnimeList(`Anime Schedule for ${query.charAt(0).toUpperCase() + query.slice(1)}`, scheduleResult.animes));
        break;

      case 'ongoing':
        m.reply('Fetching ongoing anime, please wait...');
        const ongoingResult = await kuramaClient.ongoing();
        await m.reply(formatAnimeList('Ongoing Anime', ongoingResult.animes));
        break;

      case 'finished':
        m.reply('Fetching finished anime, please wait...');
        const finishedResult = await kuramaClient.finished();
        await m.reply(formatAnimeList('Finished Anime', finishedResult.animes));
        break;

      case 'movie':
        m.reply('Fetching anime movies, please wait...');
        const movieResult = await kuramaClient.movie();
        await m.reply(formatAnimeList('Anime Movies', movieResult.animes));
        break;

      default:
        let helpMsg = `*Kuramanime Plugin*\n\nAvailable commands:\n\n`;
        handler.help.forEach(h => helpMsg += `• .${h}\n`);
        helpMsg += `\nExample: .${command} search one piece`;
        await m.reply(helpMsg);
        break;
    }
  } catch (e) {
    console.error(e);
    await m.reply("An error occurred while processing your request. Please try again later.");
  }
};

handler.help = [
  'search <query>',
  'detail <url>',
  'episode <url>',
  'schedule <day>',
  'ongoing',
  'finished',
  'movie'
].map(v => 'kurama ' + v);

handler.command = /^(kurama)$/i;
handler.tags = ['anime'];
handler.description = 'Interact with Kuramanime to search, get details, and find download links for anime.';

module.exports = handler;

