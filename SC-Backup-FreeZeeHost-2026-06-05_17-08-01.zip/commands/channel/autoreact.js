let handler = async (m, {
    command,
    text
}) => {

    if (!global.channels) global.channels = []
    if (global.autoReactCh === undefined) global.autoReactCh = false

    if (command === "addch") {

        if (!text) return m.reply("Masukkan ID channel")

        if (global.channels.includes(text))
            return m.reply("Channel sudah ada")

        global.channels.push(text)

        return m.reply(`✅ Channel ditambahkan\n${text}`)
    }

    if (command === "delch") {

        if (!text) return m.reply("Masukkan ID channel")

        global.channels = global.channels.filter(v => v !== text)

        return m.reply(`❌ Channel dihapus\n${text}`)
    }

    if (command === "listch") {

        if (!global.channels.length)
            return m.reply("Belum ada channel")

        let txt = "📡 LIST CHANNEL AUTO REACT\n\n"

        for (let ch of global.channels) {
            txt += `• ${ch}\n`
        }

        return m.reply(txt)
    }

    if (command === "autoreactch") {

        if (!text) return m.reply("Gunakan on / off")

        if (text === "on") {
            global.autoReactCh = true
            return m.reply("✅ Auto react channel diaktifkan")
        }

        if (text === "off") {
            global.autoReactCh = false
            return m.reply("❌ Auto react channel dimatikan")
        }

    }

}

handler.command = ["addch", "delch", "listch", "autoreactch"]
handler.owner = true
handler.tags = ["owner"]

export default handler


handler.all = async (m, {
    conn
}) => {

    if (!global.autoReactCh) return
    if (!m.isNewsletter) return
    if (!global.channels.includes(m.from)) return
    if (!m.serverId) return

    try {

        await conn.newsletterReactMessage(
            m.from,
            m.serverId,
            "🦖"
        )

    } catch {}

}