let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(
            "❌ Masukkan link / kode invite / JID newsletter.\n\nContoh:\n#cekidch https://whatsapp.com/channel/0029Vb6w7eO9sBIEUYRgeC30"
        )

    try {

        await conn.sendReact(m.chat, "🔍", m.key)

        let value = text.trim()

        // ================= NORMALISASI INPUT =================
        // kalau link channel
        if (value.includes("whatsapp.com/channel/")) {
            value = value.split("channel/")[1]
        }

        let type = "invite"

        // kalau JID newsletter
        if (value.endsWith("@newsletter")) {
            type = "jid"
        }

        const newsletter = await conn.newsletterMetadata(type, value)

        if (!newsletter)
            return m.reply("❌ Newsletter tidak ditemukan.")

        const idNewsletter = newsletter.id || "-"

        const caption = `
╭━━━〔 📢 CHANNEL INFO 〕━━━⬣
┃ 🏷 Nama        : ${newsletter.name || "-"}
┃ 🆔 ID          : ${idNewsletter}
┃ 👥 Subscribers : ${newsletter.subscribers || 0}
┃ 🔒 Verified    : ${newsletter.verification || "No"}
┃ 📅 Created     : ${newsletter.creation_time 
      ? new Date(newsletter.creation_time * 1000).toLocaleString()
      : "-"}
╰━━━━━━━━━━━━━━━━━━━━⬣

📝 Deskripsi:
${newsletter.description || "-"}
`.trim()

        const buttons = [{
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
                display_text: "📋 Copy Newsletter ID",
                copy_code: idNewsletter
            })
        }]

        await conn.sendMessage(m.chat, {
            text: caption,
            footer: `${global.botname} Channel System`,
            viewOnce: true,
            interactive: buttons
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("CEKIDCH ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Gagal mengambil metadata newsletter.")
    }
}

handler.command = ["cekidch", "detailch"]
handler.tags = ["channel"]
handler.help = ["cekidch <link | invite_code | jid@newsletter>"]

export default handler