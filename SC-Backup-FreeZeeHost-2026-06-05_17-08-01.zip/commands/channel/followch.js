let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(
            `❌ Masukkan link atau JID newsletter.

Contoh:
#followch https://whatsapp.com/channel/0029Vb6w7eO9sBIEUYRgeC30
#followch 120363421570647022@newsletter`
        )

    try {

        await conn.sendReact(m.chat, "🔄", m.key)

        let input = text.trim()
        let jid = ""

        // Pakai link
        if (input.includes("whatsapp.com/channel/")) {
            let code = input.split("channel/")[1].split("?")[0]
            const meta = await conn.newsletterMetadata("invite", code)
            jid = meta?.id || meta?.jid
        }

        // Pakai JID langsung
        else if (input.endsWith("@newsletter")) {
            jid = input
        } else {
            return m.reply("❌ Format tidak valid. Gunakan link atau JID.")
        }

        if (!jid)
            return m.reply("❌ Gagal mendapatkan JID newsletter.")

        await conn.newsletterFollow(jid)

        await conn.sendReact(m.chat, "✅", m.key)

        m.reply(`✅ Berhasil follow channel:\n${jid}`)

    } catch (err) {
        console.log("FOLLOW ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Gagal follow newsletter.")
    }
}

handler.command = ["followch"]
handler.tags = ["channel"]
handler.help = ["followch <link | jid@newsletter>"]
handler.owner = true

export default handler