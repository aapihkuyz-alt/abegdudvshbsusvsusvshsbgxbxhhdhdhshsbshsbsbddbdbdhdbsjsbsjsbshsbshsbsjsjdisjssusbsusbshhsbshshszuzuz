import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    try {

        if (!global.channels || !Array.isArray(global.channels))
            return m.reply("❌ global.channels belum diset di setting.js")

        let videoBuffer = null

        await conn.sendMessage(m.chat, {
            react: {
                text: "📡",
                key: m.key
            }
        })

        /* ================= REPLY VIDEO ================= */
        if (m.quoted) {
            const quoted = m.quoted.message
            if (quoted?.videoMessage) {
                videoBuffer = await m.quoted.download()
            }
        }

        /* ================= VIDEO LANGSUNG ================= */
        if (!videoBuffer && m.message?.videoMessage) {
            videoBuffer = await m.download()
        }

        /* ================= LINK VIDEO ================= */
        if (!videoBuffer && text && text.startsWith("http")) {
            const res = await axios.get(text, {
                responseType: "arraybuffer",
                timeout: 60000
            })
            videoBuffer = res.data
        }

        if (!videoBuffer) {
            return m.reply(
                "Reply video asli / kirim video / masukkan link mp4.\nJangan reply preview doang."
            )
        }

        /* ================= KIRIM KE CHANNEL ================= */
        for (let ch of global.channels) {

            await conn.sendMessage(
                ch, {
                    video: videoBuffer,
                    ptv: true,
                    mimetype: "video/mp4"
                }
            )
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

        m.reply(`🎬 PTV berhasil dikirim ke ${global.channels.length} channel.`)

    } catch (err) {

        console.error("PTVCH ERROR:", err)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal kirim ke channel.")
    }
}

handler.command = ["ptvch"]
handler.tags = ["converter"]
handler.help = ["ptvch <reply video / link>"]

export default handler