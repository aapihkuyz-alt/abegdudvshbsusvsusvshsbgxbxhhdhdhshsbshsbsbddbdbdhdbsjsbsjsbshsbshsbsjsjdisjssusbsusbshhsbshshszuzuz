let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("Contoh:\n#reactch https://whatsapp.com/channel/xxxx/123 | 😭🗿😏")

    let [link, emoji] = text.split("|").map(v => v.trim())

    if (!link) return m.reply("Link channel tidak valid")

    let match = link.match(/channel\/([A-Za-z0-9]+)\/(\d+)/)

    if (!match) return m.reply("Format link salah")

    let invite = match[1]
    let serverId = match[2]

    let emojis = emoji ? emoji.split("") : ["🗿"]

    try {

        // ambil metadata channel
        let meta = await conn.newsletterMetadata("invite", invite)

        let jid = meta.id

        for (let e of emojis) {

            await conn.newsletterReactMessage(
                jid,
                serverId,
                e
            )

        }

        m.reply(`✅ React terkirim\n\nChannel: ${meta.name}\nMessage: ${serverId}`)

    } catch (err) {

        console.log(err)

        m.reply("❌ Gagal react channel")

    }

}

handler.command = ["reactchh"]
handler.owner = true
handler.tags = ["owner"]
handler.help = ["reactch link | emoji"]

export default handler