let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(
            `❌ Masukkan link atau JID newsletter.

Contoh:
#unfollowch https://whatsapp.com/channel/0029Vb6w7eO9sBIEUYRgeC30
#unfollowch 120363421570647022@newsletter`
        )

    try {

        await conn.sendReact(m.chat, "🔄", m.key)

        let input = text.trim()
        let jid = ""

        if (input.includes("whatsapp.com/channel/")) {
            let code = input.split("channel/")[1].split("?")[0]
            const meta = await conn.newsletterMetadata("invite", code)
            jid = meta?.id || meta?.jid
        } else if (input.endsWith("@newsletter")) {
            jid = input
        } else {
            return m.reply("❌ Format tidak valid. Gunakan link atau JID.")
        }

        if (!jid)
            return m.reply("❌ Gagal mendapatkan JID newsletter.")

        await conn.newsletterUnfollow(jid)

        await conn.sendReact(m.chat, "✅", m.key)

        m.reply(`✅ Berhasil unfollow channel:\n${jid}`)

    } catch (err) {
        console.log("UNFOLLOW ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Gagal unfollow newsletter.")
    }
}

handler.command = ["unfollowch", "unfolch"]
handler.tags = ["channel"]
handler.help = ["unfollowch <link | jid@newsletter>"]
handler.owner = true

export default handler