import { listZones, getZoneSetting, listDnsRecords, resolveAccountId, listTunnels, getTunnelConfig } from "../../core/cloudflare.js";

let handler = async (m) => {
    try {
        const zones = await listZones();
        const accountId = await resolveAccountId().catch(() => null);
        const tunnels = accountId ? await listTunnels(accountId).catch(() => []) : [];

        let totalDns = 0;
        let proxiedDns = 0;
        let underAttack = 0;
        let pausedZones = 0;
        let totalTunnelRoutes = 0;

        for (const zone of zones.slice(0, 20)) {
            if (zone.paused) pausedZones += 1;

            try {
                const records = await listDnsRecords(zone.id);
                totalDns += records.length;
                proxiedDns += records.filter((record) => record.proxied).length;
            } catch {
            }

            try {
                const security = await getZoneSetting(zone.id, "security_level");
                if (security?.value === "under_attack") underAttack += 1;
            } catch {
            }
        }

        for (const tunnel of tunnels.slice(0, 20)) {
            try {
                const config = await getTunnelConfig(accountId, tunnel.id);
                const ingress = Array.isArray(config?.config?.ingress) ? config.config.ingress : [];
                totalTunnelRoutes += ingress.filter((rule) => rule.hostname).length;
            } catch {
            }
        }

        return m.reply(
            `☁️ *CF SUMMARY*\n\n` +
            `Total Zone        : ${zones.length}\n` +
            `Paused Zone       : ${pausedZones}\n` +
            `Under Attack      : ${underAttack}\n` +
            `Total DNS Record  : ${totalDns}\n` +
            `Proxied DNS       : ${proxiedDns}\n` +
            `DNS Only          : ${totalDns - proxiedDns}\n` +
            `Total Tunnel      : ${tunnels.length}\n` +
            `Total Route       : ${totalTunnelRoutes}`
        );
    } catch (error) {
        return m.reply(`❌ Gagal ambil CF summary.\n${error.message}`);
    }
};

handler.command = ["cfsummary", "cloudflaresummary"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["cfsummary"];

export default handler;
