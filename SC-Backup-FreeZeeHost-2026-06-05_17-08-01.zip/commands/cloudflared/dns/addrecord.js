import { listZones, requireZone, createDnsRecord, findRecordByName, normalizeRecordName } from "../../../core/cloudflare.js";

async function createRecord(zoneName, hostRaw, contentRaw) {
    const zone = await requireZone(zoneName);
    const name = normalizeRecordName(zone.name, hostRaw);
    const existing = await findRecordByName(zone.id, name);

    if (existing) {
        throw new Error(`Record ${name} sudah ada`);
    }

    const record = await createDnsRecord(zone.id, {
        type: "A",
        name,
        content: contentRaw,
        proxied: false
    });

    return { zone, record };
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        return m.reply("Format salah.\n.addrecord nama,ip\nContoh: .addrecord api,1.1.1.1");
    }

    if (raw.startsWith("--exec,")) {
        const [, zoneNameRaw, hostRaw, contentRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw || !hostRaw || !contentRaw) {
            return m.reply("Payload addrecord tidak valid.");
        }

        try {
            const { zone, record } = await createRecord(zoneNameRaw, hostRaw, contentRaw);
            return m.reply(`✅ Record berhasil ditambahkan.\n\nZone   : ${zone.name}\nName   : ${record.name}\nType   : ${record.type}\nValue  : ${record.content}\nProxy  : ${record.proxiable ? (record.proxied ? "on" : "off") : "n/a"}`);
        } catch (error) {
            return m.reply(`❌ Gagal tambah record.\n${error.message}`);
        }
    }

    const [hostRaw, contentRaw] = raw.split(",").map((v) => v?.trim());
    if (!hostRaw || !contentRaw) {
        return m.reply("Format salah.\n.addrecord nama,ip\nContoh: .addrecord api,1.1.1.1");
    }

    try {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: `☁️ *PILIH DOMAIN UNTUK RECORD BARU*\n\nHost : ${hostRaw}\nIP   : ${contentRaw}\nType : A\nProxy: off\n\nPilih salah satu domain di bawah untuk lanjut create record.`,
            footer: "Cloudflare Add Record",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Add record target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Create ${hostRaw}.${zone.name} -> ${contentRaw}`,
                            id: `.addrecord --exec,${zone.name},${hostRaw},${contentRaw}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal buka daftar domain.\n${error.message}`);
    }
};

handler.command = ["addrecord"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["addrecord nama,ip"];

export default handler;
