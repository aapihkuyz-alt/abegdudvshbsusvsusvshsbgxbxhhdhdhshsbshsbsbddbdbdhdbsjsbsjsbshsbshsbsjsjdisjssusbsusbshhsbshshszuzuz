import { listZones, requireZone, listDnsRecords, deleteDnsRecord } from "../../../core/cloudflare.js";

async function executeDelete(zoneName, recordId) {
    const zone = await requireZone(zoneName);
    const records = await listDnsRecords(zone.id);
    const record = records.find((item) => item.id === recordId);

    if (!record) {
        throw new Error(`Record dengan id ${recordId} tidak ditemukan`);
    }

    await deleteDnsRecord(zone.id, record.id);
    return { zone, record };
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        try {
            const zones = await listZones();
            if (!zones.length) {
                return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
            }

            return conn.sendMessage(m.chat, {
                text: "🗑️ *PILIH DOMAIN UNTUK HAPUS RECORD*\n\nPilih domain dulu, lalu bot akan menampilkan daftar record di domain tersebut.",
                footer: "Cloudflare Delete Record",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Pilih Domain",
                        sections: [{
                            title: "Zone List",
                            highlight_label: "Delete record target",
                            rows: zones.slice(0, 20).map((zone) => ({
                                header: "ZONE",
                                title: zone.name,
                                description: `Buka daftar record ${zone.name}`,
                                id: `.delrecord --zone,${zone.name}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal buka daftar domain.\n${error.message}`);
        }
    }

    if (raw.startsWith("--zone,")) {
        const [, zoneNameRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw) {
            return m.reply("Payload delrecord zone tidak valid.");
        }

        try {
            const zone = await requireZone(zoneNameRaw);
            const records = await listDnsRecords(zone.id);

            if (!records.length) {
                return m.reply(`⚠️ Zone *${zone.name}* belum punya DNS record.`);
            }

            return conn.sendMessage(m.chat, {
                text: `🗑️ *PILIH RECORD YANG MAU DIHAPUS*\n\nZone : ${zone.name}\nTotal: ${records.length}\n\nPilih salah satu record di bawah.`,
                footer: "Cloudflare Delete Record",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: `Records ${zone.name}`,
                        sections: [{
                            title: `Delete Record (${Math.min(records.length, 20)}/${records.length})`,
                            highlight_label: "Danger zone",
                            rows: records.slice(0, 20).map((record) => ({
                                header: record.type,
                                title: record.name,
                                description: `${record.content} | proxy: ${record.proxied ? "on" : "off"}`,
                                id: `.delrecord --exec,${zone.name},${record.id}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal ambil daftar record.\n${error.message}`);
        }
    }

    if (raw.startsWith("--exec,")) {
        const [, zoneNameRaw, recordIdRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw || !recordIdRaw) {
            return m.reply("Payload delrecord exec tidak valid.");
        }

        try {
            const { zone, record } = await executeDelete(zoneNameRaw, recordIdRaw);
            return m.reply(`✅ Record berhasil dihapus.\n\nZone  : ${zone.name}\nName  : ${record.name}\nType  : ${record.type}\nValue : ${record.content}`);
        } catch (error) {
            return m.reply(`❌ Gagal hapus record.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.delrecord");
};

handler.command = ["delrecord", "deldomainrecord"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["delrecord"];

export default handler;
