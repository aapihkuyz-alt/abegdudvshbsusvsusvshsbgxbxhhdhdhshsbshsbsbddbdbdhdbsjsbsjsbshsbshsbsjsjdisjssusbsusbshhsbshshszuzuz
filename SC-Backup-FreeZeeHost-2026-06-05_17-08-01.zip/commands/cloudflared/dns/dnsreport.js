import { listZones, requireZone, listDnsRecords } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "📄 *PILIH DOMAIN UNTUK DNS REPORT*\n\nPilih zone untuk melihat ringkasan DNS record.",
            footer: "Cloudflare DNS Report",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "DNS report target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Status: ${zone.status}`,
                            id: `.dnsreport --exec,${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const zoneName = raw.startsWith("--exec,") ? raw.slice(7).trim() : raw;
    if (!zoneName) return m.reply("Format salah.\n.dnsreport zone.com");

    try {
        const zone = await requireZone(zoneName);
        const records = await listDnsRecords(zone.id);

        const byType = records.reduce((acc, record) => {
            acc[record.type] = (acc[record.type] || 0) + 1;
            return acc;
        }, {});

        const typeLines = Object.entries(byType)
            .sort((a, b) => b[1] - a[1])
            .map(([type, total]) => `- ${type}: ${total}`)
            .join("\n") || "- Tidak ada record";

        const proxiedCount = records.filter((r) => r.proxied).length;
        const sampleLines = records.slice(0, 10).map((record, index) => (
            `${index + 1}. ${record.name}\n` +
            `   ${record.type} -> ${record.content}\n` +
            `   Proxy: ${record.proxiable ? (record.proxied ? "on" : "off") : "n/a"}`
        )).join("\n\n") || "-";

        return m.reply(
            `📄 *DNS REPORT*\n\n` +
            `Zone        : ${zone.name}\n` +
            `Total       : ${records.length}\n` +
            `Proxied     : ${proxiedCount}\n` +
            `DNS Only    : ${records.length - proxiedCount}\n\n` +
            `Type Count:\n${typeLines}\n\n` +
            `Sample Record:\n${sampleLines}`
        );
    } catch (error) {
        return m.reply(`❌ Gagal ambil DNS report.\n${error.message}`);
    }
};

handler.command = ["dnsreport"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["dnsreport zone.com"];

export default handler;
