import { listZones, requireZone, findRecordByName, normalizeRecordName, getZoneDetails, listDnsRecords } from "../../../core/cloudflare.js";

async function resolveRecordTarget(input) {
    const raw = String(input || "").trim().toLowerCase();
    if (!raw) return null;

    if (raw.includes(",")) {
        const [zoneNameRaw, hostRaw] = raw.split(",").map((v) => v?.trim()).filter(Boolean);
        if (!zoneNameRaw || !hostRaw) return null;
        return {
            zoneName: zoneNameRaw,
            recordName: normalizeRecordName(zoneNameRaw, hostRaw)
        };
    }

    const zones = await listZones();
    const zone = zones.find((item) => raw === item.name.toLowerCase() || raw.endsWith(`.${item.name.toLowerCase()}`));
    if (!zone) return null;

    return {
        zoneName: zone.name,
        recordName: raw
    };
}

let handler = async (m, { conn, text }) => {
    const target = await resolveRecordTarget(text);
    if (!target) {
        return m.reply("Format salah.\n.domaindetail zone.com,host\natau\n.domaindetail sub.domain.com");
    }

    try {
        const zone = await requireZone(target.zoneName);
        if (String(target.recordName).toLowerCase() === String(zone.name).toLowerCase()) {
            const detail = await getZoneDetails(zone.id);
            const records = await listDnsRecords(zone.id).catch(() => []);
            const nameservers = Array.isArray(detail.name_servers) && detail.name_servers.length
                ? detail.name_servers.join(", ")
                : "-";

            return conn.sendMessage(m.chat, {
                text:
                    `☁️ *DOMAIN DETAIL*\n\n` +
                    `Domain    : ${detail.name}\n` +
                    `Zone ID   : ${detail.id}\n` +
                    `Status    : ${detail.status}\n` +
                    `Type      : ${detail.type}\n` +
                    `Paused    : ${detail.paused ? "yes" : "no"}\n` +
                    `Plan      : ${detail.plan?.name || "-"}\n` +
                    `Records   : ${records.length}\n` +
                    `Created   : ${detail.created_on || "-"}\n` +
                    `Active    : ${detail.activated_on || "-"}\n` +
                    `NS        : ${nameservers}`,
                footer: "Cloudflare Domain Detail",
                interactive: [
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Zone ID",
                            copy_code: detail.id
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📄 List Record",
                            id: `.listrecord ${detail.name}`
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📊 Report",
                            id: `.domenreport ${detail.name}`
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📦 Zone Info",
                            id: `.zoneinfo ${detail.name}`
                        })
                    }
                ]
            }, { quoted: m });
        }

        const record = await findRecordByName(zone.id, target.recordName);

        if (!record) {
            return m.reply(`❌ Record *${target.recordName}* tidak ditemukan.`);
        }

        const quick = [
            {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "📋 Copy Value",
                    copy_code: record.content
                })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: record.proxiable && record.proxied ? "🟠 Proxy Off" : "🟠 Proxy On",
                    id: `.setproxy --record,${zone.name},${record.id},${record.proxied ? "off" : "on"}`
                })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "✏️ Edit",
                    id: `.editrecord --exec,${zone.name},${record.id},${record.content},${record.ttl},${record.proxied ? "on" : "off"}`
                })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "🗑️ Hapus",
                    id: `.delrecord --exec,${zone.name},${record.id}`
                })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "📋 List",
                    id: `.listrecord ${zone.name}`
                })
            },
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "📊 Report",
                    id: `.domenreport ${zone.name}`
                })
            }
        ];

        return conn.sendMessage(m.chat, {
            text: `☁️ *DOMAIN DETAIL*\n\nZone     : ${zone.name}\nRecord   : ${record.name}\nType     : ${record.type}\nContent  : ${record.content}\nTTL      : ${record.ttl}\nProxy    : ${record.proxiable ? (record.proxied ? "on" : "off") : "n/a"}\nCreated  : ${record.created_on || "-"}\nUpdated  : ${record.modified_on || "-"}`,
            footer: "Cloudflare DNS Detail",
            interactive: quick
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil detail domain.\n${error.message}`);
    }
};

handler.command = ["domaindetail", "detaildomen"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["domaindetail zone.com,host"];

export default handler;
