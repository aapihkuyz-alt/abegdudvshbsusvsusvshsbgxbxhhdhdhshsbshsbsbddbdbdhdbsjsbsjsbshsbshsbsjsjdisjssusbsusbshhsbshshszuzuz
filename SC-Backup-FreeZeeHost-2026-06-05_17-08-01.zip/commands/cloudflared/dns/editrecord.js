import { listZones, requireZone, listDnsRecords, updateDnsRecord } from "../../../core/cloudflare.js";

async function executeEdit(zoneName, recordId, contentRaw, ttlRaw, proxyRaw) {
    const zone = await requireZone(zoneName);
    const records = await listDnsRecords(zone.id);
    const record = records.find((item) => item.id === recordId);

    if (!record) {
        throw new Error(`Record dengan id ${recordId} tidak ditemukan`);
    }

    const ttl = ttlRaw ? Number(ttlRaw) : record.ttl;
    const payload = {
        content: contentRaw || record.content,
        ttl: Number.isFinite(ttl) ? ttl : record.ttl
    };

    if (record.proxiable && proxyRaw) {
        payload.proxied = /^on|true|1$/i.test(proxyRaw);
    }

    const updated = await updateDnsRecord(zone.id, record.id, payload);
    return { zone, record: updated };
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "✏️ *PILIH DOMAIN UNTUK EDIT RECORD*\n\nPilih domain dulu, lalu pilih record yang mau diedit.",
            footer: "Cloudflare Edit Record",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Edit target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Buka record ${zone.name}`,
                            id: `.editrecord --zone,${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    if (raw.startsWith("--zone,")) {
        const [, zoneNameRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw) return m.reply("Payload editrecord zone tidak valid.");

        try {
            const zone = await requireZone(zoneNameRaw);
            const records = await listDnsRecords(zone.id);

            if (!records.length) {
                return m.reply(`⚠️ Zone *${zone.name}* belum punya DNS record.`);
            }

            return conn.sendMessage(m.chat, {
                text: `✏️ *PILIH RECORD UNTUK EDIT*\n\nZone : ${zone.name}\nTotal: ${records.length}\n\nPilih record yang mau diedit.`,
                footer: "Cloudflare Edit Record",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: `Records ${zone.name}`,
                        sections: [{
                            title: `Edit Record (${Math.min(records.length, 20)}/${records.length})`,
                            highlight_label: "Edit target",
                            rows: records.slice(0, 20).map((record) => ({
                                header: record.type,
                                title: record.name,
                                description: `${record.content} | ttl: ${record.ttl} | proxy: ${record.proxied ? "on" : "off"}`,
                                id: `.editrecord --record,${zone.name},${record.id}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal ambil daftar record.\n${error.message}`);
        }
    }

    if (raw.startsWith("--record,")) {
        const [, zoneNameRaw, recordIdRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw || !recordIdRaw) {
            return m.reply("Payload editrecord record tidak valid.");
        }

        try {
            const zone = await requireZone(zoneNameRaw);
            const records = await listDnsRecords(zone.id);
            const record = records.find((item) => item.id === recordIdRaw);

            if (!record) {
                return m.reply("❌ Record tidak ditemukan.");
            }

            return m.reply(
                `Gunakan format ini untuk edit record:\n` +
                `.editrecord --exec,${zone.name},${record.id},${record.content},${record.ttl},${record.proxied ? "on" : "off"}`
            );
        } catch (error) {
            return m.reply(`❌ Gagal siapkan edit record.\n${error.message}`);
        }
    }

    if (raw.startsWith("--exec,")) {
        const [, zoneNameRaw, recordIdRaw, contentRaw, ttlRaw, proxyRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw || !recordIdRaw || !contentRaw) {
            return m.reply("Payload editrecord exec tidak valid.");
        }

        try {
            const { zone, record } = await executeEdit(zoneNameRaw, recordIdRaw, contentRaw, ttlRaw, proxyRaw);
            return m.reply(`✅ Record berhasil diupdate.\n\nZone   : ${zone.name}\nName   : ${record.name}\nType   : ${record.type}\nValue  : ${record.content}\nTTL    : ${record.ttl}\nProxy  : ${record.proxiable ? (record.proxied ? "on" : "off") : "n/a"}`);
        } catch (error) {
            return m.reply(`❌ Gagal edit record.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.editrecord");
};

handler.command = ["editrecord", "editdomen", "editdomain"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["editrecord"];

export default handler;
