import { requireZone, listDnsRecords } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const zoneName = text?.trim();
    if (!zoneName) {
        return m.reply("Format salah.\n.listrecord zone.com");
    }

    try {
        const zone = await requireZone(zoneName);
        const records = await listDnsRecords(zone.id);

        if (!records.length) {
            return m.reply(`⚠️ Zone *${zone.name}* belum punya DNS record.`);
        }

        const buttons = [{
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: `Records ${zone.name}`,
                sections: [{
                    title: `DNS Records (${Math.min(records.length, 20)}/${records.length})`,
                    highlight_label: "Manage record",
                    rows: records.slice(0, 20).map((record) => ({
                        header: record.type,
                        title: record.name,
                        description: `${record.content} | proxy: ${record.proxied ? "on" : "off"}`,
                        id: `.domaindetail ${record.name}`
                    }))
                }]
            })
        }];

        return conn.sendMessage(m.chat, {
            text: `📄 *LIST RECORD DOMAIN*\n\nZone   : ${zone.name}\nTotal  : ${records.length}\n\nSemua record tersedia di panel pilih bawah.`,
            footer: "Cloudflare Record List",
            interactive: buttons
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil record.\n${error.message}`);
    }
};

handler.command = ["listrecord"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["listrecord zone.com"];

export default handler;
