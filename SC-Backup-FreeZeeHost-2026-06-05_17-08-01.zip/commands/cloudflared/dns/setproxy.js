import { listZones, requireZone, listDnsRecords, updateDnsRecord } from "../../../core/cloudflare.js";

async function executeProxy(zoneName, recordId, stateRaw) {
    const zone = await requireZone(zoneName);
    const records = await listDnsRecords(zone.id);
    const record = records.find((item) => item.id === recordId);

    if (!record) {
        throw new Error(`Record dengan id ${recordId} tidak ditemukan`);
    }

    if (!record.proxiable) {
        throw new Error(`Record ${record.name} tidak mendukung proxy`);
    }

    const proxied = /^on|true|1$/i.test(stateRaw);
    const updated = await updateDnsRecord(zone.id, record.id, { proxied });
    return { zone, record: updated };
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "🟠 *PILIH DOMAIN UNTUK SET PROXY*\n\nPilih domain dulu, lalu pilih record mana yang mau diubah status proxynya.",
            footer: "Cloudflare Set Proxy",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Proxy target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Buka record ${zone.name}`,
                            id: `.setproxy --zone,${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    if (raw.startsWith("--zone,")) {
        const [, zoneNameRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw) return m.reply("Payload setproxy zone tidak valid.");

        try {
            const zone = await requireZone(zoneNameRaw);
            const records = (await listDnsRecords(zone.id)).filter((record) => record.proxiable);

            if (!records.length) {
                return m.reply(`⚠️ Zone *${zone.name}* tidak punya record yang mendukung proxy.`);
            }

            return conn.sendMessage(m.chat, {
                text: `🟠 *PILIH RECORD UNTUK SET PROXY*\n\nZone : ${zone.name}\nTotal: ${records.length}\n\nPilih record yang mau diubah.`,
                footer: "Cloudflare Set Proxy",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: `Records ${zone.name}`,
                        sections: [{
                            title: `Proxy Record (${Math.min(records.length, 20)}/${records.length})`,
                            highlight_label: "Toggle proxy",
                            rows: records.slice(0, 20).map((record) => ({
                                header: record.type,
                                title: record.name,
                                description: `${record.content} | proxy: ${record.proxied ? "on" : "off"}`,
                                id: `.setproxy --record,${zone.name},${record.id},${record.proxied ? "off" : "on"}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal ambil daftar record proxy.\n${error.message}`);
        }
    }

    if (raw.startsWith("--record,")) {
        const [, zoneNameRaw, recordIdRaw, stateRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw || !recordIdRaw || !stateRaw) {
            return m.reply("Payload setproxy record tidak valid.");
        }

        try {
            const { zone, record } = await executeProxy(zoneNameRaw, recordIdRaw, stateRaw);
            return m.reply(`✅ Proxy record berhasil diubah.\n\nZone   : ${zone.name}\nName   : ${record.name}\nProxy  : ${record.proxied ? "on" : "off"}\nType   : ${record.type}\nValue  : ${record.content}`);
        } catch (error) {
            return m.reply(`❌ Gagal set proxy.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.setproxy");
};

handler.command = ["setproxy", "proxydomen"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["setproxy"];

export default handler;
