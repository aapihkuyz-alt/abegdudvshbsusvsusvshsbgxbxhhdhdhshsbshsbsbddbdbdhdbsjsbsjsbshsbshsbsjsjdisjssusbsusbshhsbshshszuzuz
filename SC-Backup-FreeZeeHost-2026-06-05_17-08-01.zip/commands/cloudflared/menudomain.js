import { listZones } from "../../core/cloudflare.js";

let handler = async (m, { conn }) => {
    try {
        const zones = await listZones();

        const zoneRows = zones.slice(0, 10).map((zone) => ({
            header: "ZONE",
            title: zone.name,
            description: `Status: ${zone.status} | buka detail domain`,
            id: `.domaindetail ${zone.name}`
        }));

        const sections = [
            {
                title: "Cloudflare Quick Actions",
                highlight_label: "Domain Manager",
                rows: [
                    {
                        header: "ZONE",
                        title: "➕ Tambah Domain",
                        description: "Format: .adddomen domain.com",
                        id: ".adddomen"
                    },
                    {
                        header: "TUNNEL",
                        title: "➕ Tambah Tunnel",
                        description: "Format: .addtunnel nama-tunnel",
                        id: ".addtunnel"
                    },
                    {
                        header: "ADD",
                        title: "➕ Tambah Record",
                        description: "Format: .addrecord nama,ip",
                        id: ".addrecord"
                    },
                    {
                        header: "DELETE",
                        title: "🗑️ Hapus Record",
                        description: "Format: .delrecord",
                        id: ".delrecord"
                    },
                    {
                        header: "EDIT",
                        title: "✏️ Edit Record",
                        description: "Format: .editrecord",
                        id: ".editrecord"
                    },
                    {
                        header: "PROXY",
                        title: "🟠 Set Proxy",
                        description: "Format: .setproxy",
                        id: ".setproxy"
                    },
                    {
                        header: "ZONE",
                        title: "🗑️ Hapus Domain",
                        description: "Format: .deldomen",
                        id: ".deldomen"
                    },
                    {
                        header: "TUNNEL",
                        title: "📋 List Tunnel",
                        description: "Lihat semua Cloudflare Tunnel",
                        id: ".listtunnel"
                    },
                    {
                        header: "TUNNEL",
                        title: "📋 List Route Tunnel",
                        description: "Lihat hostname route tunnel",
                        id: ".listtunnelroute"
                    },
                    {
                        header: "TUNNEL",
                        title: "🗑️ Hapus Tunnel",
                        description: "Format: .deltunnel",
                        id: ".deltunnel"
                    },
                    {
                        header: "TUNNEL",
                        title: "📡 Route Tunnel",
                        description: "Format: .routetunnel host.domain.com,http://localhost:3000",
                        id: ".routetunnel"
                    },
                    {
                        header: "TUNNEL",
                        title: "🧹 Hapus Route Tunnel",
                        description: "Format: .untunnelroute",
                        id: ".untunnelroute"
                    },
                    {
                        header: "TUNNEL",
                        title: "🔑 Tunnel Token",
                        description: "Ambil token run/install tunnel",
                        id: ".tunntoken"
                    },
                    {
                        header: "ZONE",
                        title: "📦 Info Zone",
                        description: "Pilih zone untuk lihat info",
                        id: ".zoneinfo"
                    },
                    {
                        header: "ZONE",
                        title: "🧭 NS Check",
                        description: "Cek nameserver aktif domain",
                        id: ".nscheck"
                    },
                    {
                        header: "ZONE",
                        title: "📊 Domain Report",
                        description: "Ringkasan status zone/domain",
                        id: ".domainreport"
                    },
                    {
                        header: "DNS",
                        title: "📄 DNS Report",
                        description: "Ringkasan record DNS zone",
                        id: ".dnsreport"
                    },
                    {
                        header: "TUNNEL",
                        title: "📡 Tunnel Report",
                        description: "Ringkasan semua tunnel",
                        id: ".tunnelreport"
                    },
                    {
                        header: "CF",
                        title: "☁️ CF Summary",
                        description: "Ringkasan keseluruhan akun",
                        id: ".cfsummary"
                    },
                    {
                        header: "ZONE",
                        title: "🛡️ Domain DDoS",
                        description: "Cek report status DDoS domain",
                        id: ".domenddos"
                    },
                    {
                        header: "ZONE",
                        title: "🛡️ Set DDoS Mode",
                        description: "Toggle Under Attack mode",
                        id: ".setddos"
                    },
                    {
                        header: "ZONE",
                        title: "🧹 Purge Cache",
                        description: "Purge all cache zone",
                        id: ".cachepurge"
                    },
                    {
                        header: "ZONE",
                        title: "⏸️ Pause Zone",
                        description: "Toggle paused mode zone",
                        id: ".zonepause"
                    },
                    {
                        header: "ZONE",
                        title: "🔐 SSL Mode",
                        description: "Set SSL mode zone",
                        id: ".sslmode"
                    },
                    {
                        header: "ZONE",
                        title: "🔒 Always HTTPS",
                        description: "Toggle Always Use HTTPS",
                        id: ".alwayshttps"
                    },
                    {
                        header: "ZONE",
                        title: "🛠️ Dev Mode",
                        description: "Toggle development mode",
                        id: ".devmode"
                    },
                    {
                        header: "ZONE",
                        title: "🛡️ Security Level",
                        description: "Set security level zone",
                        id: ".securitylevel"
                    },
                    {
                        header: "ZONE",
                        title: "⏳ Browser Cache TTL",
                        description: "Set browser cache TTL",
                        id: ".browsercachettl"
                    },
                    {
                        header: "ZONE",
                        title: "📦 Cache Level",
                        description: "Set cache level zone",
                        id: ".cachelevel"
                    },
                    {
                        header: "ZONE",
                        title: "🗜️ Auto Minify",
                        description: "Toggle css/html/js minify",
                        id: ".minify"
                    },
                    {
                        header: "ZONE",
                        title: "🚀 Rocket Loader",
                        description: "Toggle rocket loader",
                        id: ".rocketloader"
                    },
                    {
                        header: "EXPORT",
                        title: "📤 Export DNS",
                        description: "Pilih zone lalu export DNS",
                        id: ".exportdomen"
                    },
                    {
                        header: "CHECK",
                        title: "🔄 Activation Check",
                        description: "Pilih zone lalu cek aktivasi",
                        id: ".cekaktivasi"
                    }
                ]
            }
        ];

        if (zoneRows.length) {
            sections.push({
                title: "Zone List",
                highlight_label: "Tap untuk lihat record",
                rows: zoneRows
            });
        }

        return conn.sendMessage(m.chat, {
            text: `☁️ *FREEZEEHOST CLOUDFLARE PANEL*\n\nZones: ${zones.length}\nToken: ${global.cftoken ? "ready" : "missing"}\n\nPilih aksi atau zone dari panel di bawah.`,
            footer: "Cloudflare Domain Manager",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Open Domain Panel",
                    sections
                })
            }]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal buka panel domain.\n${error.message}`);
    }
};

handler.command = ["menudomain", "domainpanel", "cloudflarepanel"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["menudomain"];

export default handler;
