import { resolveAccountId, createTunnel } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const name = String(text || "").trim();
    if (!name) {
        return m.reply("Format salah.\n.addtunnel nama-tunnel");
    }

    try {
        const accountId = await resolveAccountId();
        const tunnel = await createTunnel(accountId, {
            name,
            config_src: "cloudflare"
        });

        const installCmd = `cloudflared service install ${tunnel.token}`;
        const runCmd = `cloudflared tunnel run --token ${tunnel.token}`;

        return conn.sendMessage(m.chat, {
            text:
                `✅ Tunnel berhasil dibuat.\n\n` +
                `Name      : ${tunnel.name}\n` +
                `Tunnel ID : ${tunnel.id}\n` +
                `Created   : ${tunnel.created_at || "-"}\n` +
                `Token     : ${tunnel.token}\n\n` +
                `Gunakan tombol copy di bawah untuk salin token, run command, atau install command.`,
            footer: "Cloudflare Add Tunnel",
            interactive: [
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Copy Token",
                        copy_code: tunnel.token
                    })
                },
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "▶️ Copy Run",
                        copy_code: runCmd
                    })
                },
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "⚙️ Copy Install",
                        copy_code: installCmd
                    })
                }
            ]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal membuat tunnel.\n${error.message}`);
    }
};

handler.command = ["addtunnel", "createtunnel"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["addtunnel nama-tunnel"];

export default handler;
