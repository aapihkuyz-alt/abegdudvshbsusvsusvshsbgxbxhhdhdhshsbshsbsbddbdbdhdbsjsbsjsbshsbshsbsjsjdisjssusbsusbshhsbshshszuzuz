import { resolveAccountId, listTunnels, deleteTunnel } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        try {
            const accountId = await resolveAccountId();
            const tunnels = await listTunnels(accountId);

            if (!tunnels.length) {
                return m.reply("⚠️ Belum ada tunnel yang bisa dihapus.");
            }

            return conn.sendMessage(m.chat, {
                text: "🗑️ *PILIH TUNNEL YANG MAU DIHAPUS*\n\nPilih salah satu tunnel di bawah.",
                footer: "Cloudflare Delete Tunnel",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Pilih Tunnel",
                        sections: [{
                            title: "Tunnel List",
                            highlight_label: "Danger zone",
                            rows: tunnels.slice(0, 20).map((tunnel) => ({
                                header: "TUNNEL",
                                title: tunnel.name,
                                description: tunnel.id,
                                id: `.deltunnel --exec,${tunnel.id}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal buka daftar tunnel.\n${error.message}`);
        }
    }

    if (raw.startsWith("--exec,")) {
        const [, tunnelId] = raw.split(",").map((v) => v?.trim());
        if (!tunnelId) return m.reply("Payload deltunnel tidak valid.");

        try {
            const accountId = await resolveAccountId();
            await deleteTunnel(accountId, tunnelId);
            return m.reply(`✅ Tunnel berhasil dihapus.\n\nTunnel ID : ${tunnelId}`);
        } catch (error) {
            return m.reply(`❌ Gagal hapus tunnel.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.deltunnel");
};

handler.command = ["deltunnel", "deletetunnel"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["deltunnel"];

export default handler;
