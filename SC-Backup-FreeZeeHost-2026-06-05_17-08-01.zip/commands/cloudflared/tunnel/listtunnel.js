import { resolveAccountId, listTunnels } from "../../../core/cloudflare.js";

let handler = async (m, { conn }) => {
    try {
        const accountId = await resolveAccountId();
        const tunnels = await listTunnels(accountId);

        if (!tunnels.length) {
            return m.reply("⚠️ Belum ada Cloudflare Tunnel di akun ini.");
        }

        const lines = tunnels.slice(0, 20).map((tunnel, index) => (
            `${index + 1}. ${tunnel.name}\n` +
            `   ID     : ${tunnel.id}\n` +
            `   Status : ${tunnel.status || tunnel.conns_active_at ? "active" : "unknown"}`
        ));

        return conn.sendMessage(m.chat, {
            text: `☁️ *CLOUDFLARE TUNNEL LIST*\n\n${lines.join("\n\n")}`,
            footer: "Tap tunnel untuk detail",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Tunnel List",
                    sections: [{
                        title: `Tunnels (${Math.min(tunnels.length, 20)}/${tunnels.length})`,
                        highlight_label: "Tunnel manager",
                        rows: tunnels.slice(0, 20).map((tunnel) => ({
                            header: "TUNNEL",
                            title: tunnel.name,
                            description: `${tunnel.id} | ${tunnel.created_at || "-"}`,
                            id: `.tunneldetail ${tunnel.id}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil daftar tunnel.\n${error.message}`);
    }
};

handler.command = ["listtunnel", "tunnels"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["listtunnel"];

export default handler;
