import { resolveAccountId, listTunnels, getTunnelConfig } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        try {
            const accountId = await resolveAccountId();
            const tunnels = await listTunnels(accountId);

            if (!tunnels.length) return m.reply("⚠️ Belum ada tunnel di akun ini.");

            return conn.sendMessage(m.chat, {
                text: "📋 *PILIH TUNNEL UNTUK LIHAT ROUTE*\n\nPilih salah satu tunnel.",
                footer: "Cloudflare Tunnel Routes",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Pilih Tunnel",
                        sections: [{
                            title: "Tunnel List",
                            highlight_label: "Route list target",
                            rows: tunnels.slice(0, 20).map((tunnel) => ({
                                header: "TUNNEL",
                                title: tunnel.name,
                                description: tunnel.id,
                                id: `.listtunnelroute --exec,${tunnel.id}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal buka daftar tunnel.\n${error.message}`);
        }
    }

    if (raw.startsWith("--exec,")) {
        const [, tunnelId] = raw.split(",").map((v) => v?.trim());
        if (!tunnelId) return m.reply("Payload listtunnelroute tidak valid.");

        try {
            const accountId = await resolveAccountId();
            const config = await getTunnelConfig(accountId, tunnelId);
            const ingress = Array.isArray(config?.config?.ingress) ? config.config.ingress : [];
            const hostnameRules = ingress.filter((rule) => rule.hostname);

            if (!hostnameRules.length) return m.reply(`⚠️ Tunnel *${tunnelId}* belum punya hostname route.`);

            const lines = hostnameRules.map((rule, index) => (
                `${index + 1}. ${rule.hostname}\n` +
                `   Service: ${rule.service || "-"}`
            ));

            return m.reply(`📡 *TUNNEL ROUTE LIST*\n\nTunnel ID: ${tunnelId}\n\n${lines.join("\n\n")}`);
        } catch (error) {
            return m.reply(`❌ Gagal ambil route tunnel.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.listtunnelroute");
};

handler.command = ["listtunnelroute", "tunnelroutes"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["listtunnelroute"];

export default handler;
