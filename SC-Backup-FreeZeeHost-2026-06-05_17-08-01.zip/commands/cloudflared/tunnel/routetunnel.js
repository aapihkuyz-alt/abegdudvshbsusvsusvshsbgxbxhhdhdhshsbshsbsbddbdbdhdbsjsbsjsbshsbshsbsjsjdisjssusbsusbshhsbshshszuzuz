import { resolveAccountId, listTunnels, getTunnelConfig, putTunnelConfig } from "../../../core/cloudflare.js";

async function applyRoute(accountId, tunnelId, hostname, service) {
    const current = await getTunnelConfig(accountId, tunnelId).catch(() => ({}));
    const currentIngress = Array.isArray(current?.config?.ingress) ? current.config.ingress : [];
    const filtered = currentIngress.filter((rule) => rule.hostname !== hostname && rule.service !== "http_status:404");
    const nextIngress = [
        ...filtered,
        {
            hostname,
            service,
            originRequest: {}
        },
        {
            service: "http_status:404"
        }
    ];

    return await putTunnelConfig(accountId, tunnelId, {
        config: {
            ingress: nextIngress
        }
    });
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        return m.reply("Format salah.\n.routetunnel host.domain.com,http://localhost:3000");
    }

    if (raw.startsWith("--exec,")) {
        const [, tunnelId, hostname, service] = raw.split(",").map((v) => v?.trim());
        if (!tunnelId || !hostname || !service) {
            return m.reply("Payload routetunnel tidak valid.");
        }

        try {
            const accountId = await resolveAccountId();
            await applyRoute(accountId, tunnelId, hostname, service);
            return conn.sendMessage(m.chat, {
                text:
                    `✅ Route tunnel berhasil disimpan.\n\n` +
                    `Tunnel ID : ${tunnelId}\n` +
                    `Hostname  : ${hostname}\n` +
                    `Service   : ${service}`,
                footer: "Cloudflare Tunnel Route",
                interactive: [
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Hostname",
                            copy_code: hostname
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Service",
                            copy_code: service
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📡 Detail Tunnel",
                            id: `.tunneldetail ${tunnelId}`
                        })
                    }
                ]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal simpan route tunnel.\n${error.message}`);
        }
    }

    const [hostname, service] = raw.split(",").map((v) => v?.trim());
    if (!hostname || !service) {
        return m.reply("Format salah.\n.routetunnel host.domain.com,http://localhost:3000");
    }

    try {
        const accountId = await resolveAccountId();
        const tunnels = await listTunnels(accountId);

        if (!tunnels.length) {
            return m.reply("⚠️ Belum ada tunnel. Buat dulu dengan .addtunnel nama-tunnel");
        }

        return conn.sendMessage(m.chat, {
            text: `📡 *PILIH TUNNEL UNTUK ROUTE HOSTNAME*\n\nHostname : ${hostname}\nService  : ${service}\n\nPilih tunnel target di bawah.`,
            footer: "Cloudflare Tunnel Route",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Tunnel",
                    sections: [{
                        title: "Tunnel List",
                        highlight_label: "Route target",
                        rows: tunnels.slice(0, 20).map((tunnel) => ({
                            header: "TUNNEL",
                            title: tunnel.name,
                            description: `${hostname} -> ${service}`,
                            id: `.routetunnel --exec,${tunnel.id},${hostname},${service}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal buka daftar tunnel.\n${error.message}`);
    }
};

handler.command = ["routetunnel", "tunnelroute"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["routetunnel host.domain.com,http://localhost:3000"];

export default handler;
