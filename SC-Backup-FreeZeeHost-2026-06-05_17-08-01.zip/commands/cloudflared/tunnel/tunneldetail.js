import { resolveAccountId, listTunnels, getTunnelConfig } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const tunnelId = String(text || "").trim();
    if (!tunnelId) {
        return m.reply("Format salah.\n.tunneldetail tunnel-id");
    }

    try {
        const accountId = await resolveAccountId();
        const tunnels = await listTunnels(accountId);
        const tunnel = tunnels.find((item) => item.id === tunnelId || item.name === tunnelId);

        if (!tunnel) {
            return m.reply("❌ Tunnel tidak ditemukan.");
        }

        let configInfo = "Belum ada config route"
        try {
            const config = await getTunnelConfig(accountId, tunnel.id)
            const ingress = config?.config?.ingress || []
            configInfo = ingress.length ? ingress.map((rule, i) => `${i + 1}. ${rule.hostname || "*"} -> ${rule.service}`).join("\n") : "Belum ada config route"
        } catch {
        }

        return conn.sendMessage(m.chat, {
            text:
                `☁️ *TUNNEL DETAIL*\n\n` +
                `Name      : ${tunnel.name}\n` +
                `Tunnel ID : ${tunnel.id}\n` +
                `Created   : ${tunnel.created_at || "-"}\n` +
                `Deleted   : ${tunnel.deleted_at || "-"}\n` +
                `Routes    : \n${configInfo}`,
            footer: "Cloudflare Tunnel Manager",
            interactive: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📡 Route",
                        id: `.routetunnel ${tunnel.id}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🗑️ Delete",
                        id: `.deltunnel --exec,${tunnel.id}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 List",
                        id: `.listtunnel`
                    })
                }
            ]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil detail tunnel.\n${error.message}`);
    }
};

handler.command = ["tunneldetail", "detailtunnel"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["tunneldetail tunnel-id"];

export default handler;
