import { resolveAccountId, listTunnels, getTunnelConfig } from "../../../core/cloudflare.js";

let handler = async (m) => {
    try {
        const accountId = await resolveAccountId();
        const tunnels = await listTunnels(accountId);

        if (!tunnels.length) {
            return m.reply("⚠️ Belum ada Cloudflare Tunnel di akun ini.");
        }

        const reports = []
        for (const tunnel of tunnels.slice(0, 10)) {
            let routeCount = 0
            try {
                const config = await getTunnelConfig(accountId, tunnel.id)
                const ingress = Array.isArray(config?.config?.ingress) ? config.config.ingress : []
                routeCount = ingress.filter((rule) => rule.hostname).length
            } catch {
            }

            reports.push(
                `${reports.length + 1}. ${tunnel.name}\n` +
                `   ID      : ${tunnel.id}\n` +
                `   Routes  : ${routeCount}\n` +
                `   Created : ${tunnel.created_at || "-"}`
            )
        }

        return m.reply(`📡 *TUNNEL REPORT*\n\nTotal Tunnel: ${tunnels.length}\n\n${reports.join("\n\n")}`);
    } catch (error) {
        return m.reply(`❌ Gagal ambil tunnel report.\n${error.message}`);
    }
};

handler.command = ["tunnelreport"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["tunnelreport"];

export default handler;
