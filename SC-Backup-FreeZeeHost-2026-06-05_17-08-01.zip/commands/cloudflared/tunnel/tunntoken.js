import { resolveAccountId, listTunnels, getTunnelToken } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        try {
            const accountId = await resolveAccountId();
            const tunnels = await listTunnels(accountId);

            if (!tunnels.length) {
                return m.reply("⚠️ Belum ada tunnel di akun ini.");
            }

            return conn.sendMessage(m.chat, {
                text: "🔑 *PILIH TUNNEL UNTUK AMBIL TOKEN*\n\nPilih tunnel target di bawah.",
                footer: "Cloudflare Tunnel Token",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Pilih Tunnel",
                        sections: [{
                            title: "Tunnel List",
                            highlight_label: "Token target",
                            rows: tunnels.slice(0, 20).map((tunnel) => ({
                                header: "TUNNEL",
                                title: tunnel.name,
                                description: tunnel.id,
                                id: `.tunntoken --exec,${tunnel.id}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal buka daftar tunnel.\n${error.message}`);
        }
    }

    if (raw.startsWith("--exec,")) {
        const [, tunnelId] = raw.split(",").map((v) => v?.trim());
        if (!tunnelId) return m.reply("Payload tunntoken tidak valid.");

        try {
            const accountId = await resolveAccountId();
            const tokenData = await getTunnelToken(accountId, tunnelId);
            const token = tokenData?.token || tokenData?.value || tokenData;
            const runCmd = `cloudflared tunnel run --token ${token}`;
            const installCmd = `cloudflared service install ${token}`;

            return conn.sendMessage(m.chat, {
                text:
                    `🔑 *TUNNEL TOKEN*\n\n` +
                    `Tunnel ID : ${tunnelId}\n` +
                    `Token     : ${token}\n\n` +
                    `Gunakan tombol copy di bawah untuk salin token, run command, atau install command.`,
                footer: "Cloudflare Tunnel Token",
                interactive: [
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📋 Copy Token",
                            copy_code: token
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "▶️ Copy Run",
                            copy_code: runCmd
                        })
                    },
                    {
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                            display_text: "⚙️ Copy Install",
                            copy_code: installCmd
                        })
                    }
                ]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal ambil token tunnel.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.tunntoken");
};

handler.command = ["tunntoken", "tunneltoken"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["tunntoken"];

export default handler;
