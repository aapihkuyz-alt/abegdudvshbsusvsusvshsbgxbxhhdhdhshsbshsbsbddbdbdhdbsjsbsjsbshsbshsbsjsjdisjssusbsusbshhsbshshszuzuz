import { resolveAccountId, listTunnels, getTunnelConfig, putTunnelConfig } from "../../../core/cloudflare.js";

async function removeRoute(accountId, tunnelId, hostname) {
    const current = await getTunnelConfig(accountId, tunnelId);
    const currentIngress = Array.isArray(current?.config?.ingress) ? current.config.ingress : [];
    const nextIngress = currentIngress.filter((rule) => rule.hostname !== hostname);

    if (nextIngress.length === currentIngress.length) {
        throw new Error(`Hostname ${hostname} tidak ditemukan di tunnel ini`);
    }

    const finalIngress = nextIngress.some((rule) => rule.service === "http_status:404")
        ? nextIngress
        : [...nextIngress, { service: "http_status:404" }];

    return await putTunnelConfig(accountId, tunnelId, {
        config: {
            ingress: finalIngress
        }
    });
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        try {
            const accountId = await resolveAccountId();
            const tunnels = await listTunnels(accountId);

            if (!tunnels.length) {
                return m.reply("⚠️ Belum ada tunnel di akun ini.");
            }

            return conn.sendMessage(m.chat, {
                text: "🧹 *PILIH TUNNEL UNTUK HAPUS ROUTE*\n\nPilih tunnel target, lalu bot akan tampilkan hostname route di tunnel itu.",
                footer: "Cloudflare Tunnel Route Delete",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Pilih Tunnel",
                        sections: [{
                            title: "Tunnel List",
                            highlight_label: "Route delete target",
                            rows: tunnels.slice(0, 20).map((tunnel) => ({
                                header: "TUNNEL",
                                title: tunnel.name,
                                description: tunnel.id,
                                id: `.untunnelroute --tunnel,${tunnel.id}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal buka daftar tunnel.\n${error.message}`);
        }
    }

    if (raw.startsWith("--tunnel,")) {
        const [, tunnelId] = raw.split(",").map((v) => v?.trim());
        if (!tunnelId) return m.reply("Payload untunnelroute tunnel tidak valid.");

        try {
            const accountId = await resolveAccountId();
            const config = await getTunnelConfig(accountId, tunnelId);
            const ingress = (config?.config?.ingress || []).filter((rule) => rule.hostname);

            if (!ingress.length) {
                return m.reply("⚠️ Tunnel ini belum punya hostname route.");
            }

            return conn.sendMessage(m.chat, {
                text: `🧹 *PILIH HOSTNAME ROUTE YANG MAU DIHAPUS*\n\nTunnel ID : ${tunnelId}`,
                footer: "Cloudflare Tunnel Route Delete",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Pilih Hostname",
                        sections: [{
                            title: `Hostname Route (${ingress.length})`,
                            highlight_label: "Danger zone",
                            rows: ingress.slice(0, 20).map((rule) => ({
                                header: "HOSTNAME",
                                title: rule.hostname,
                                description: `${rule.service || "-"}`,
                                id: `.untunnelroute --exec,${tunnelId},${rule.hostname}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal ambil route tunnel.\n${error.message}`);
        }
    }

    if (raw.startsWith("--exec,")) {
        const [, tunnelId, hostname] = raw.split(",").map((v) => v?.trim());
        if (!tunnelId || !hostname) return m.reply("Payload untunnelroute exec tidak valid.");

        try {
            const accountId = await resolveAccountId();
            await removeRoute(accountId, tunnelId, hostname);
            return m.reply(`✅ Route tunnel berhasil dihapus.\n\nTunnel ID : ${tunnelId}\nHostname  : ${hostname}`);
        } catch (error) {
            return m.reply(`❌ Gagal hapus route tunnel.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.untunnelroute");
};

handler.command = ["untunnelroute", "deltunnelroute"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["untunnelroute"];

export default handler;
