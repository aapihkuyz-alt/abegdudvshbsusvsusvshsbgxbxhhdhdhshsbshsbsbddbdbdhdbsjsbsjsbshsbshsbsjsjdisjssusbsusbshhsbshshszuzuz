import { createZone, findZoneByName, resolveAccountId } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const domainRaw = String(text || "").trim();
    if (!domainRaw) {
        return m.reply("Format salah.\n.adddomen domain.com");
    }

    try {
        const domain = domainRaw.toLowerCase();
        const existing = await findZoneByName(domain);

        if (existing) {
            return m.reply(`⚠️ Zone *${domain}* sudah ada di akun ini.\nGunakan .zoneinfo ${domain}`);
        }

        const accountId = await resolveAccountId();
        const zone = await createZone({
            account: { id: accountId },
            name: domain,
            type: "full"
        });

        const nameservers = Array.isArray(zone.name_servers) ? zone.name_servers : [];
        const primaryNs = nameservers[0] || "-";
        const secondaryNs = nameservers[1] || "-";

        return conn.sendMessage(m.chat, {
            text:
                `✅ *DOMAIN BERHASIL DITAMBAHKAN KE CLOUDFLARE*\n\n` +
                `Domain       : ${zone.name}\n` +
                `Status       : ${zone.status}\n` +
                `Type         : ${zone.type}\n` +
                `Zone ID      : ${zone.id}\n\n` +
                `Hostname NS1 : ${primaryNs}\n` +
                `Hostname NS2 : ${secondaryNs}\n\n` +
                `Langkah berikutnya:\n` +
                `Ubah nameserver domain di registrar ke hostname Cloudflare di atas.`,
            footer: "Cloudflare Add Domain Result",
            interactive: [
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Copy Zone ID",
                        copy_code: zone.id
                    })
                },
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Copy NS1",
                        copy_code: primaryNs
                    })
                },
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Copy NS2",
                        copy_code: secondaryNs
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📦 Zone Info",
                        id: `.zoneinfo ${zone.name}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📄 List Record",
                        id: `.listrecord ${zone.name}`
                    })
                }
            ]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal tambah domain ke akun Cloudflare.\n${error.message}`);
    }
};

handler.command = ["adddomen", "adddomain"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["adddomen domain.com"];

export default handler;
