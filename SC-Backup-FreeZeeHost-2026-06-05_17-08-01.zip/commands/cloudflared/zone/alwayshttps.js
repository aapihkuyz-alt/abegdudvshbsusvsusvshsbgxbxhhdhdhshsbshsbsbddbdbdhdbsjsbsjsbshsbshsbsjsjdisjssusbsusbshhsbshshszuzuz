import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "🔒 *ALWAYS USE HTTPS*\n\nFormat manual:\n.alwayshttps zone.com,on/off",
            footer: "Cloudflare Always HTTPS",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "HTTPS target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Enable Always Use HTTPS",
                            id: `.alwayshttps ${zone.name},on`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, state] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !state) return m.reply("Format salah.\n.alwayshttps zone.com,on/off");

    try {
        const zone = await requireZone(zoneName);
        const value = /^on|true|1$/i.test(state) ? "on" : "off";
        await updateZoneSetting(zone.id, "always_use_https", value);
        return m.reply(`✅ Always Use HTTPS berhasil diubah.\n\nZone  : ${zone.name}\nValue : ${value}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah Always Use HTTPS.\n${error.message}`);
    }
};

handler.command = ["alwayshttps", "forcehttps"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["alwayshttps zone.com,on/off"];

export default handler;
