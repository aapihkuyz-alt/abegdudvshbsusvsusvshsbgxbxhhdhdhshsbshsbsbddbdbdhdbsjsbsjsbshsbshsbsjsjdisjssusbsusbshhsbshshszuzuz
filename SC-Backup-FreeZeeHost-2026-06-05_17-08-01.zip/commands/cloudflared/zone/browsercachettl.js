import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "⏳ *BROWSER CACHE TTL*\n\nFormat manual:\n.browsercachettl zone.com,14400\nNilai contoh: 0, 30, 60, 300, 1200, 3600, 14400, 86400, 604800, 2592000",
            footer: "Cloudflare Browser Cache TTL",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Browser cache target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Set browser cache TTL 4 jam",
                            id: `.browsercachettl ${zone.name},14400`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, ttlRaw] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !ttlRaw) {
        return m.reply("Format salah.\n.browsercachettl zone.com,14400");
    }

    try {
        const zone = await requireZone(zoneName);
        const value = Number(ttlRaw);
        if (!Number.isFinite(value)) {
            return m.reply("TTL harus berupa angka.");
        }
        await updateZoneSetting(zone.id, "browser_cache_ttl", value);
        return m.reply(`✅ Browser cache TTL berhasil diubah.\n\nZone  : ${zone.name}\nTTL   : ${value}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah browser cache TTL.\n${error.message}`);
    }
};

handler.command = ["browsercachettl", "cachettl"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["browsercachettl zone.com,14400"];

export default handler;
