import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "📦 *CACHE LEVEL*\n\nFormat manual:\n.cachelevel zone.com,bypass|basic|simplified|aggressive",
            footer: "Cloudflare Cache Level",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Cache level target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Set cache level aggressive",
                            id: `.cachelevel ${zone.name},aggressive`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, levelRaw] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !levelRaw) {
        return m.reply("Format salah.\n.cachelevel zone.com,bypass|basic|simplified|aggressive");
    }

    try {
        const zone = await requireZone(zoneName);
        const value = levelRaw.toLowerCase();
        await updateZoneSetting(zone.id, "cache_level", value);
        return m.reply(`✅ Cache level berhasil diubah.\n\nZone  : ${zone.name}\nValue : ${value}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah cache level.\n${error.message}`);
    }
};

handler.command = ["cachelevel"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["cachelevel zone.com,aggressive"];

export default handler;
