import { listZones, requireZone, purgeZoneCache } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "🧹 *PILIH DOMAIN UNTUK PURGE CACHE*\n\nPilih zone untuk purge semua cache Cloudflare.",
            footer: "Cloudflare Cache Purge",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Purge target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Purge all cached content",
                            id: `.cachepurge --exec,${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    if (raw.startsWith("--exec,")) {
        const [, zoneName] = raw.split(",").map((v) => v?.trim());
        if (!zoneName) return m.reply("Payload cachepurge tidak valid.");

        try {
            const zone = await requireZone(zoneName);
            await purgeZoneCache(zone.id, { purge_everything: true });
            return m.reply(`✅ Purge cache berhasil.\n\nZone : ${zone.name}\nMode : purge_everything`);
        } catch (error) {
            return m.reply(`❌ Gagal purge cache.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.cachepurge");
};

handler.command = ["cachepurge", "purgecache"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["cachepurge"];

export default handler;
