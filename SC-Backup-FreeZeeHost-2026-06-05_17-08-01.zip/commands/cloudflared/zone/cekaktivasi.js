import { listZones, requireZone, triggerActivationCheck } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const zoneName = text?.trim();
    if (!zoneName) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "🔄 *PILIH DOMAIN UNTUK ACTIVATION CHECK*\n\nPilih zone untuk memicu pengecekan ulang propagasi nameserver.",
            footer: "Cloudflare Activation Check",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Activation target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Trigger activation check`,
                            id: `.cekaktivasi ${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    try {
        const zone = await requireZone(zoneName);
        await triggerActivationCheck(zone.id);
        return m.reply(`✅ Activation check berhasil dipicu untuk zone *${zone.name}*.\nCloudflare akan cek ulang propagasi nameserver zone ini.`);
    } catch (error) {
        return m.reply(`❌ Gagal trigger activation check.\n${error.message}`);
    }
};

handler.command = ["cekaktivasi", "activationcheck", "recheckzone"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["cekaktivasi zone.com"];

export default handler;
