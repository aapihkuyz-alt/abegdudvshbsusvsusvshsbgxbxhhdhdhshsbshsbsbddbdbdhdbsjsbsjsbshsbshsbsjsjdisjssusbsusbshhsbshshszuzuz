import { listZones, requireZone, deleteZone } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        try {
            const zones = await listZones();
            if (!zones.length) {
                return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
            }

            return conn.sendMessage(m.chat, {
                text: "🗑️ *PILIH DOMAIN YANG MAU DIHAPUS*\n\nPilih zone/domain Cloudflare yang mau dihapus penuh dari akun.",
                footer: "Cloudflare Delete Domain",
                interactive: [{
                    name: "single_select",
                    buttonParamsJson: JSON.stringify({
                        title: "Pilih Domain",
                        sections: [{
                            title: "Zone List",
                            highlight_label: "Danger zone",
                            rows: zones.slice(0, 20).map((zone) => ({
                                header: "ZONE",
                                title: zone.name,
                                description: `Status: ${zone.status} | hapus zone penuh`,
                                id: `.deldomen --exec,${zone.name}`
                            }))
                        }]
                    })
                }]
            }, { quoted: m });
        } catch (error) {
            return m.reply(`❌ Gagal buka daftar domain.\n${error.message}`);
        }
    }

    if (raw.startsWith("--exec,")) {
        const [, zoneNameRaw] = raw.split(",").map((v) => v?.trim());
        if (!zoneNameRaw) {
            return m.reply("Payload deldomen tidak valid.");
        }

        try {
            const zone = await requireZone(zoneNameRaw);
            await deleteZone(zone.id);
            return m.reply(`✅ Zone berhasil dihapus dari akun Cloudflare.\n\nDomain : ${zone.name}\nZone ID : ${zone.id}`);
        } catch (error) {
            return m.reply(`❌ Gagal hapus zone/domain.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.deldomen");
};

handler.command = ["deldomen", "deldomain"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["deldomen"];

export default handler;
