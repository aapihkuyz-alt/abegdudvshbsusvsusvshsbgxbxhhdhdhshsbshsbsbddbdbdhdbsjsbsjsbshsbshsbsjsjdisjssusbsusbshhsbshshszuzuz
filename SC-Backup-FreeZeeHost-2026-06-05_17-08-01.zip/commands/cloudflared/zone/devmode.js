import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "🛠️ *DEVELOPMENT MODE*\n\nPilih zone untuk mengaktifkan development mode 3 jam.",
            footer: "Cloudflare Development Mode",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Dev mode target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Enable development mode",
                            id: `.devmode --exec,${zone.name},on`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const payload = raw.startsWith("--exec,") ? raw.slice(7) : raw;
    const [zoneName, state] = payload.split(",").map((v) => v?.trim());
    if (!zoneName || !state) {
        return m.reply("Format salah.\n.devmode zone.com,on/off");
    }

    try {
        const zone = await requireZone(zoneName);
        const value = /^on|true|1$/i.test(state) ? "on" : "off";
        await updateZoneSetting(zone.id, "development_mode", value);
        return m.reply(`✅ Development mode berhasil diubah.\n\nZone  : ${zone.name}\nValue : ${value}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah development mode.\n${error.message}`);
    }
};

handler.command = ["devmode", "developmentmode"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["devmode zone.com,on/off"];

export default handler;
