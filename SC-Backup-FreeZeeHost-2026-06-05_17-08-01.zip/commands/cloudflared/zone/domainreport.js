import { listZones, requireZone, getZoneDetails, getZoneSetting, listDnsRecords } from "../../../core/cloudflare.js";

async function buildZoneReport(zoneName) {
    const zone = await requireZone(zoneName);
    const detail = await getZoneDetails(zone.id);
    const records = await listDnsRecords(zone.id).catch(() => []);

    const settingIds = [
        "ssl",
        "always_use_https",
        "security_level",
        "development_mode",
        "cache_level",
        "browser_cache_ttl",
        "rocket_loader"
    ];

    const settings = {};
    await Promise.all(settingIds.map(async (id) => {
        try {
            const data = await getZoneSetting(zone.id, id);
            settings[id] = data?.value ?? "-";
        } catch {
            settings[id] = "-";
        }
    }));

    return {
        detail,
        dnsCount: records.length,
        settings
    };
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "📊 *PILIH DOMAIN UNTUK REPORT*\n\nPilih zone untuk melihat report ringkas status domain Cloudflare.",
            footer: "Cloudflare Domain Report",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Report target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Status: ${zone.status}`,
                            id: `.domainreport --exec,${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const zoneName = raw.startsWith("--exec,") ? raw.slice(7).trim() : raw;
    if (!zoneName) return m.reply("Format salah.\n.domainreport zone.com");

    try {
        const { detail, dnsCount, settings } = await buildZoneReport(zoneName);
        const nameservers = Array.isArray(detail.name_servers) && detail.name_servers.length
            ? detail.name_servers.join(", ")
            : "-";

        return conn.sendMessage(m.chat, {
            text:
                `📊 *DOMAIN REPORT*\n\n` +
                `Domain        : ${detail.name}\n` +
                `Status        : ${detail.status}\n` +
                `Plan          : ${detail.plan?.name || "-"}\n` +
                `Paused        : ${detail.paused ? "yes" : "no"}\n` +
                `DNS Count     : ${dnsCount}\n` +
                `Created       : ${detail.created_on || "-"}\n` +
                `Activated     : ${detail.activated_on || "-"}\n` +
                `NameServers   : ${nameservers}\n\n` +
                `SSL Mode      : ${settings.ssl}\n` +
                `Always HTTPS  : ${settings.always_use_https}\n` +
                `Security      : ${settings.security_level}\n` +
                `Dev Mode      : ${settings.development_mode}\n` +
                `Cache Level   : ${settings.cache_level}\n` +
                `Browser TTL   : ${settings.browser_cache_ttl}\n` +
                `RocketLoader  : ${settings.rocket_loader}`,
            footer: "Cloudflare Zone Report",
            interactive: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🛡️ DDoS Report",
                        id: `.domenddos ${detail.name}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🛡️ Set DDoS",
                        id: `.setddos ${detail.name},on`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📦 Zone Info",
                        id: `.zoneinfo ${detail.name}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📄 List Record",
                        id: `.listrecord ${detail.name}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🔒 Always HTTPS",
                        id: `.alwayshttps ${detail.name},on`
                    })
                }
            ]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil domain report.\n${error.message}`);
    }
};

handler.command = ["domainreport", "domenreport", "zonereport"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["domainreport zone.com"];

export default handler;
