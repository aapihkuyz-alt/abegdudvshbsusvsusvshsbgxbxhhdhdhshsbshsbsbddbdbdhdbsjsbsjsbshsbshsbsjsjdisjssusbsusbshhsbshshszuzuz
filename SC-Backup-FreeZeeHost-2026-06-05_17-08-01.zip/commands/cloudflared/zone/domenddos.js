import { listZones, requireZone, getZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "🛡️ *PILIH DOMAIN UNTUK CEK STATUS DDoS*\n\nPilih zone untuk melihat report proteksi DDoS / security status domain.",
            footer: "Cloudflare DDoS Report",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "DDoS report target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Status: ${zone.status}`,
                            id: `.domenddos --exec,${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const zoneName = raw.startsWith("--exec,") ? raw.slice(7).trim() : raw;
    if (!zoneName) return m.reply("Format salah.\n.domenddos zone.com");

    try {
        const zone = await requireZone(zoneName);

        const [security, https, ssl, devmode] = await Promise.all([
            getZoneSetting(zone.id, "security_level").catch(() => ({ value: "-" })),
            getZoneSetting(zone.id, "always_use_https").catch(() => ({ value: "-" })),
            getZoneSetting(zone.id, "ssl").catch(() => ({ value: "-" })),
            getZoneSetting(zone.id, "development_mode").catch(() => ({ value: "-" }))
        ]);

        const securityValue = security?.value ?? "-";
        const underAttack = securityValue === "under_attack";
        const levelLabel = underAttack
            ? "UNDER ATTACK"
            : securityValue === "high"
                ? "HIGH"
                : securityValue === "medium"
                    ? "MEDIUM"
                    : securityValue === "low"
                        ? "LOW"
                        : securityValue === "essentially_off" || securityValue === "off"
                            ? "LOWEST"
                            : securityValue;

        return conn.sendMessage(m.chat, {
            text:
                `🛡️ *DOMAIN DDoS REPORT*\n\n` +
                `Zone           : ${zone.name}\n` +
                `Cloudflare     : ${zone.status}\n` +
                `Security Level : ${levelLabel}\n` +
                `Under Attack   : ${underAttack ? "yes" : "no"}\n` +
                `Always HTTPS   : ${https?.value ?? "-"}\n` +
                `SSL Mode       : ${ssl?.value ?? "-"}\n` +
                `Dev Mode       : ${devmode?.value ?? "-"}\n\n` +
                `${underAttack ? "Status: proteksi DDoS agresif aktif." : "Status: mode Under Attack tidak aktif."}`,
            footer: "Cloudflare DDoS Status",
            interactive: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🛡️ Aktifkan UAM",
                        id: `.setddos ${zone.name},on`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🛡️ Matikan UAM",
                        id: `.setddos ${zone.name},off`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📊 Domain Report",
                        id: `.domainreport ${zone.name}`
                    })
                }
            ]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil report DDoS domain.\n${error.message}`);
    }
};

handler.command = ["domenddos", "domainddos"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["domenddos zone.com"];

export default handler;
