import handler from "./domainreport.js";

export default handler;
