import { listZones, requireZone, exportDnsRecords } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const zoneName = text?.trim();
    if (!zoneName) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "📤 *PILIH DOMAIN UNTUK EXPORT DNS*\n\nPilih zone untuk export record DNS ke file.",
            footer: "Cloudflare Export DNS",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Export target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Export DNS ${zone.name}`,
                            id: `.exportdomen ${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    try {
        const zone = await requireZone(zoneName);
        const bindConfig = await exportDnsRecords(zone.id);

        return conn.sendMessage(m.chat, {
            document: Buffer.from(bindConfig, "utf8"),
            mimetype: "text/plain",
            fileName: `${zone.name}-dns-export.txt`,
            caption: `✅ Export DNS berhasil untuk zone ${zone.name}`
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal export DNS.\n${error.message}`);
    }
};

handler.command = ["exportdomen", "exportdomain", "exportrecord"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["exportdomen zone.com"];

export default handler;
