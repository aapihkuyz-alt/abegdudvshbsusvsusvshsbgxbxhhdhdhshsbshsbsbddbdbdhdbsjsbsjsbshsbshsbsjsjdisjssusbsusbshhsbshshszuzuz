import { listZones } from "../../../core/cloudflare.js";

let handler = async (m, { conn }) => {
    try {
        const zones = await listZones();

        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: `🌐 *ZONE LIST CLOUDFLARE*\n\nTotal Zone: ${zones.length}\n\nPilih domain untuk melihat DNS record di zone tersebut.`,
            footer: "Cloudflare Zone List",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Zone",
                    sections: [{
                        title: `Zone Account (${Math.min(zones.length, 20)}/${zones.length})`,
                        highlight_label: "Zone selector",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Status: ${zone.status}`,
                            id: `.listrecord ${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil daftar zone.\n${error.message}`);
    }
};

handler.command = ["listdomen", "listdomain", "domains"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["listdomen"];

export default handler;
