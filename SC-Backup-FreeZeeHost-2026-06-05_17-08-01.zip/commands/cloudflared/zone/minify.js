import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "🗜️ *AUTO MINIFY*\n\nFormat manual:\n.minify zone.com,on/off\n\nMode ini akan set html/css/js sekaligus.",
            footer: "Cloudflare Auto Minify",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Minify target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Enable auto minify",
                            id: `.minify ${zone.name},on`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, state] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !state) {
        return m.reply("Format salah.\n.minify zone.com,on/off");
    }

    try {
        const zone = await requireZone(zoneName);
        const enabled = /^on|true|1$/i.test(state);
        await updateZoneSetting(zone.id, "minify", {
            css: enabled,
            html: enabled,
            js: enabled
        });
        return m.reply(`✅ Auto minify berhasil diubah.\n\nZone  : ${zone.name}\nCSS   : ${enabled ? "on" : "off"}\nHTML  : ${enabled ? "on" : "off"}\nJS    : ${enabled ? "on" : "off"}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah auto minify.\n${error.message}`);
    }
};

handler.command = ["minify", "autominify"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["minify zone.com,on/off"];

export default handler;
