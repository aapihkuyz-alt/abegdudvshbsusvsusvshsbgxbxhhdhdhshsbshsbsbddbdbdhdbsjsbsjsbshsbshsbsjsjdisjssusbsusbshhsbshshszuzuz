import axios from "axios";
import { listZones, requireZone, getZoneDetails } from "../../../core/cloudflare.js";

const DNS_API = "https://dns.google/resolve";

async function resolveNs(domain) {
    const { data } = await axios.get(DNS_API, {
        params: {
            name: domain,
            type: 2
        },
        timeout: 10000
    });

    return Array.isArray(data?.Answer)
        ? data.Answer.map((item) => String(item.data || "").replace(/\.$/, "").toLowerCase())
        : [];
}

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "🧭 *PILIH DOMAIN UNTUK CEK NAMESERVER*\n\nPilih zone untuk mengecek apakah NS registrar sudah mengarah ke Cloudflare.",
            footer: "Cloudflare NS Checker",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "NS check target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Cek nameserver aktif`,
                            id: `.nscheck ${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    try {
        const zone = await requireZone(raw);
        const detail = await getZoneDetails(zone.id);
        const expected = (detail.name_servers || []).map((v) => String(v || "").toLowerCase());
        const active = await resolveNs(zone.name);

        const matched = expected.length > 0 && expected.every((ns) => active.includes(ns));

        return conn.sendMessage(m.chat, {
            text:
                `🧭 *CLOUDFLARE NS CHECK*\n\n` +
                `Domain    : ${zone.name}\n` +
                `Status    : ${matched ? "MATCH" : "BELUM MATCH"}\n\n` +
                `Expected:\n${expected.map((v, i) => `${i + 1}. ${v}`).join("\n") || "-"}\n\n` +
                `Active:\n${active.map((v, i) => `${i + 1}. ${v}`).join("\n") || "-"}`,
            footer: "Cloudflare Nameserver Checker",
            interactive: [
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📦 Zone Info",
                        id: `.zoneinfo ${zone.name}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🔄 Activation Check",
                        id: `.cekaktivasi ${zone.name}`
                    })
                }
            ]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal cek nameserver domain.\n${error.message}`);
    }
};

handler.command = ["nscheck", "cekns", "ceknscloudflare"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["nscheck zone.com"];

export default handler;
