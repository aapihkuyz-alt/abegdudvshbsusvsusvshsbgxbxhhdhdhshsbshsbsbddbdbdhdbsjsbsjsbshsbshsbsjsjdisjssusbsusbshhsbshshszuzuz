import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "🚀 *ROCKET LOADER*\n\nFormat manual:\n.rocketloader zone.com,on/off",
            footer: "Cloudflare Rocket Loader",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Rocket Loader target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Enable Rocket Loader",
                            id: `.rocketloader ${zone.name},on`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, state] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !state) {
        return m.reply("Format salah.\n.rocketloader zone.com,on/off");
    }

    try {
        const zone = await requireZone(zoneName);
        const value = /^on|true|1$/i.test(state) ? "on" : "off";
        await updateZoneSetting(zone.id, "rocket_loader", value);
        return m.reply(`✅ Rocket Loader berhasil diubah.\n\nZone  : ${zone.name}\nValue : ${value}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah Rocket Loader.\n${error.message}`);
    }
};

handler.command = ["rocketloader", "rocket"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["rocketloader zone.com,on/off"];

export default handler;
