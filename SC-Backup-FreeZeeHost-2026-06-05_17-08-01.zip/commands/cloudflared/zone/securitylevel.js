import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "🛡️ *SECURITY LEVEL*\n\nFormat manual:\n.securitylevel zone.com,essentially_off|low|medium|high|under_attack\n\nAtau pilih zone untuk contoh cepat `medium`.",
            footer: "Cloudflare Security Level",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Security target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Set security level ke medium",
                            id: `.securitylevel ${zone.name},medium`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, valueRaw] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !valueRaw) {
        return m.reply("Format salah.\n.securitylevel zone.com,essentially_off|low|medium|high|under_attack");
    }

    try {
        const zone = await requireZone(zoneName);
        const value = valueRaw.toLowerCase();
        await updateZoneSetting(zone.id, "security_level", value);
        return m.reply(`✅ Security level berhasil diubah.\n\nZone  : ${zone.name}\nValue : ${value}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah security level.\n${error.message}`);
    }
};

handler.command = ["securitylevel", "setsecurity"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["securitylevel zone.com,medium"];

export default handler;
