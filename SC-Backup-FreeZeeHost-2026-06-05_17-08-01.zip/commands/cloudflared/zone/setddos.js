import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "🛡️ *PILIH DOMAIN UNTUK TOGGLE UNDER ATTACK MODE*\n\nPilih zone lalu tentukan ON/OFF.",
            footer: "Cloudflare Under Attack Mode",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Toggle UAM",
                        rows: zones.slice(0, 20).flatMap((zone) => ([
                            {
                                header: "UAM ON",
                                title: `${zone.name} -> ON`,
                                description: "Enable Under Attack mode",
                                id: `.setddos ${zone.name},on`
                            },
                            {
                                header: "UAM OFF",
                                title: `${zone.name} -> OFF`,
                                description: "Disable Under Attack mode",
                                id: `.setddos ${zone.name},off`
                            }
                        ]))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, stateRaw] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !stateRaw) {
        return m.reply("Format salah.\n.setddos zone.com,on/off");
    }

    try {
        const zone = await requireZone(zoneName);
        const value = /^on|true|1$/i.test(stateRaw) ? "under_attack" : "off";
        await updateZoneSetting(zone.id, "security_level", value);
        return m.reply(
            `✅ Mode anti-DDoS berhasil diubah.\n\n` +
            `Zone   : ${zone.name}\n` +
            `Mode   : ${value}\n\n` +
            `${value === "under_attack" ? "Cloudflare Under Attack mode aktif." : "Under Attack mode dimatikan."}`
        );
    } catch (error) {
        return m.reply(`❌ Gagal ubah mode anti-DDoS.\n${error.message}`);
    }
};

handler.command = ["setddos", "underattack"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["setddos zone.com,on/off"];

export default handler;
