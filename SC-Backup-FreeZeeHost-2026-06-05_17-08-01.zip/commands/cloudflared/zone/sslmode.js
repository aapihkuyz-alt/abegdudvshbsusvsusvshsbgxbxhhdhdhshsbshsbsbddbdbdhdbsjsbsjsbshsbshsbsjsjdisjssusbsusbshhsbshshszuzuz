import { listZones, requireZone, updateZoneSetting } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "🔐 *SET SSL MODE ZONE*\n\nFormat manual:\n.sslmode zone.com,off|flexible|full|strict|origin_pull",
            footer: "Cloudflare SSL Mode",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "SSL target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: "Contoh set strict mode",
                            id: `.sslmode ${zone.name},strict`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    const [zoneName, mode] = raw.split(",").map((v) => v?.trim());
    if (!zoneName || !mode) return m.reply("Format salah.\n.sslmode zone.com,off|flexible|full|strict|origin_pull");

    try {
        const zone = await requireZone(zoneName);
        const value = mode.toLowerCase();
        await updateZoneSetting(zone.id, "ssl", value);
        return m.reply(`✅ SSL mode berhasil diubah.\n\nZone : ${zone.name}\nMode : ${value}`);
    } catch (error) {
        return m.reply(`❌ Gagal ubah SSL mode.\n${error.message}`);
    }
};

handler.command = ["sslmode", "setssl"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["sslmode zone.com,strict"];

export default handler;
