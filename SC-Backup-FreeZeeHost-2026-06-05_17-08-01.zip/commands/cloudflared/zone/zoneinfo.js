import { listZones, requireZone, getZoneDetails } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const zoneName = text?.trim();
    if (!zoneName) {
        const zones = await listZones();
        if (!zones.length) {
            return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");
        }

        return conn.sendMessage(m.chat, {
            text: "📦 *PILIH DOMAIN UNTUK ZONE INFO*\n\nPilih zone untuk melihat detail domain Cloudflare.",
            footer: "Cloudflare Zone Info",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Zone info target",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Status: ${zone.status}`,
                            id: `.zoneinfo ${zone.name}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    try {
        const zone = await requireZone(zoneName);
        const detail = await getZoneDetails(zone.id);

        const nameservers = Array.isArray(detail.name_servers) ? detail.name_servers : [];
        const primaryNs = nameservers[0] || "-";
        const secondaryNs = nameservers[1] || "-";
        const nameserverText = nameservers.length ? nameservers.join(", ") : "-";

        return conn.sendMessage(m.chat, {
            text:
                `☁️ *ZONE INFO*\n\n` +
                `Name        : ${detail.name}\n` +
                `Zone ID     : ${detail.id}\n` +
                `Status      : ${detail.status}\n` +
                `Type        : ${detail.type}\n` +
                `Paused      : ${detail.paused ? "yes" : "no"}\n` +
                `Plan        : ${detail.plan?.name || "-"}\n` +
                `Created     : ${detail.created_on || "-"}\n` +
                `Modified    : ${detail.modified_on || "-"}\n` +
                `Activated   : ${detail.activated_on || "-"}\n` +
                `NameServer  : ${nameserverText}`,
            footer: "Cloudflare Zone Info",
            interactive: [
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Copy Zone ID",
                        copy_code: detail.id
                    })
                },
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Copy NS1",
                        copy_code: primaryNs
                    })
                },
                {
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Copy NS2",
                        copy_code: secondaryNs
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📄 List Record",
                        id: `.listrecord ${detail.name}`
                    })
                }
            ]
        }, { quoted: m });
    } catch (error) {
        return m.reply(`❌ Gagal ambil info zone.\n${error.message}`);
    }
};

handler.command = ["zoneinfo", "infodomain", "infodomen"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["zoneinfo zone.com"];

export default handler;
