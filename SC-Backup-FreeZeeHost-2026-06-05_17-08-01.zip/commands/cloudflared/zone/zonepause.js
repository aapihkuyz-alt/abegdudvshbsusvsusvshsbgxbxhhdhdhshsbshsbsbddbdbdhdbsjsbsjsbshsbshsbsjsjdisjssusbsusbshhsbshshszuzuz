import { listZones, requireZone, editZone } from "../../../core/cloudflare.js";

let handler = async (m, { conn, text }) => {
    const raw = String(text || "").trim();

    if (!raw) {
        const zones = await listZones();
        if (!zones.length) return m.reply("❌ Belum ada zone/domain di akun Cloudflare.");

        return conn.sendMessage(m.chat, {
            text: "⏸️ *PILIH DOMAIN UNTUK PAUSE/UNPAUSE*\n\nPilih zone untuk toggle mode paused.",
            footer: "Cloudflare Zone Pause",
            interactive: [{
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Pilih Domain",
                    sections: [{
                        title: "Zone List",
                        highlight_label: "Toggle paused",
                        rows: zones.slice(0, 20).map((zone) => ({
                            header: "ZONE",
                            title: zone.name,
                            description: `Status: ${zone.paused ? "paused" : "active"}`,
                            id: `.zonepause --exec,${zone.name},${zone.paused ? "off" : "on"}`
                        }))
                    }]
                })
            }]
        }, { quoted: m });
    }

    if (raw.startsWith("--exec,")) {
        const [, zoneName, state] = raw.split(",").map((v) => v?.trim());
        if (!zoneName || !state) return m.reply("Payload zonepause tidak valid.");

        try {
            const zone = await requireZone(zoneName);
            const paused = /^on|true|1$/i.test(state);
            const updated = await editZone(zone.id, { paused });
            return m.reply(`✅ Zone pause state berhasil diubah.\n\nZone   : ${updated.name}\nPaused : ${updated.paused ? "yes" : "no"}`);
        } catch (error) {
            return m.reply(`❌ Gagal ubah pause state zone.\n${error.message}`);
        }
    }

    return m.reply("Format salah.\n.zonepause");
};

handler.command = ["zonepause", "pausezone"];
handler.tags = ["cloudflared"];
handler.owner = true;
handler.help = ["zonepause"];

export default handler;
