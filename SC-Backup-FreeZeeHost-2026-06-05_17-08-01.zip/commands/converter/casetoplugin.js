/**
 * 🛠️ CASE TO ESM PLUGIN CONVERTER
 * Fitur: Mengubah potongan kode dari case.js menjadi struktur Plugin ESM (.js)
 */

const handler = async (m, {
    text,
    usedPrefix,
    command
}) => {
    // 1. Ambil teks (Teks samping command > Teks reply)
    let q = m.quoted ? m.quoted : m;
    let txt = text ? text : (q.text || q.caption || '');

    if (!txt) return m.reply(`*Format Salah!*\n\n*Contoh:* \n${usedPrefix + command} case "nama": ... break;\n\n*Atau:* Balas potongan case dengan ketik *${usedPrefix + command}*`);

    await m.react("⏳");

    // 2. REGEX CLEANER (Buang 'case ...:', 'break;', 'default:')
    let cleanCode = txt
        .replace(/case\s+['"].*?['"]\s*:/g, "") // Hapus 'case "xxx":'
        .replace(/break\s*;?\s*$/gm, "") // Hapus 'break;' di akhir
        .replace(/^\s*default\s*:/gm, "") // Hapus 'default:'
        .trim();

    // 3. DETEKSI COMMAND (Cari nama case-nya buat jadi help/command)
    let cmdName = txt.match(/case\s+['"](.*?)['"]\s*:/);
    cmdName = cmdName ? cmdName[1] : "newcommand";

    // 4. WRAPPING KE STRUKTUR ESM
    let esmPlugin = `
const handler = async (m, { conn, text, usedPrefix, command, args, isOwner, isAdmin, isBotAdmin, isGroup }) => {
    ${cleanCode}
};

handler.help = ["${cmdName}"];
handler.tags = ["tools"]; // Silakan ganti tag manual
handler.command = ["${cmdName}"];

export default handler;
`.trim();

    // 5. KIRIM HASILNYA
    await m.reply(`✅ *CONVERT CASE TO ESM SUCCESS*\n\n_Silakan simpan di folder plugins/_\n\n\`\`\`javascript\n${esmPlugin}\n\`\`\``);

    await m.react("✅");
};

handler.help = ["casetoplugin", "tocp"];
handler.command = ["casetoplugin", "tocp"];
handler.tags = ["converter"];
handler.owner = false;

export default handler;