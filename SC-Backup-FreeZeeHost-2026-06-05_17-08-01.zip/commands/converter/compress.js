import ffmpeg from "fluent-ffmpeg"
import fs from "fs"
import path from "path"
import {
    tmpdir
} from "os"

let handler = async (m, {
    conn
}) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""

    if (!/video/.test(mime)) return m.reply("Reply video")

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏳",
            key: m.key
        }
    })

    try {
        let media = await q.download()
        let input = path.join(tmpdir(), Date.now() + ".mp4")
        let output = path.join(tmpdir(), Date.now() + "_c.mp4")

        fs.writeFileSync(input, media)

        await new Promise((res, rej) => {
            ffmpeg(input)
                .outputOptions(["-crf 30", "-preset fast"])
                .save(output)
                .on("end", res)
                .on("error", rej)
        })

        await conn.sendMessage(m.chat, {
            video: fs.readFileSync(output),
            caption: "📦 Compressed"
        }, {
            quoted: m
        })

        fs.unlinkSync(input)
        fs.unlinkSync(output)

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal compress")
    }
}

handler.command = ["compress"]
handler.tags = ["converter"]
handler.help = ["compress (reply video)"]

export default handler