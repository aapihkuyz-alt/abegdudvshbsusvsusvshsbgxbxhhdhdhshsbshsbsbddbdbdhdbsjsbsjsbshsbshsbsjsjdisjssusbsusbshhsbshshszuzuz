/**
 * 🛠️ ADVANCED ESM <=> CJS CONVERTER
 * Fitur: Mengubah kodingan ESM (import/export) ke CJS (require/module.exports) & sebaliknya.
 * Support: Multi-line imports, destructuring, and wildcard (import * as).
 */

const handler = async (m, {
    text,
    usedPrefix,
    command
}) => {
    // 1. Ambil teks (Teks samping command > Teks reply > Caption)
    let q = m.quoted ? m.quoted : m;
    let txt = text ? text : (q.text || q.caption || '');

    if (!txt) return m.reply(`*Format Salah!*\n\n*Contoh:* \n${usedPrefix + command} import axios from 'axios'\n\n*Atau:* Balas kodingan dengan ketik *${usedPrefix + command}*`);

    await m.react("⏳");

    let result = "";

    // ==========================================
    // 1. CONVERT KE CJS (ESM -> CJS)
    // ==========================================
    if (command === 'tocjs') {
        result = txt
            // Support: import * as name from 'pkg' -> const name = require('pkg')
            .replace(/import\s+\*\s+as\s+(\w+)\s+from\s+['"](.+?)['"]/g, "const $1 = require('$2')")
            // Support: import { a, b } from 'c' (Multi-line) -> const { a, b } = require('c')
            .replace(/import\s+\{\s*([\s\S]+?)\s*\}\s+from\s+['"](.+?)['"]/g, "const { $1 } = require('$2')")
            // Support: import a from 'b' -> const a = require('b')
            .replace(/import\s+(\w+)\s+from\s+['"](.+?)['"]/g, "const $1 = require('$2')")
            // Support: export default -> module.exports = 
            .replace(/export\s+default\s+/g, "module.exports = ")
            // Support: export const/let/var name = -> exports.name = 
            .replace(/export\s+(const|let|var)\s+(\w+)\s*=\s*/g, "exports.$2 = ")
            // Support: export async function name -> exports.name = async function
            .replace(/export\s+async\s+function\s+(\w+)/g, "exports.$1 = async function")
            // Support: export function name -> exports.name = function
            .replace(/export\s+function\s+(\w+)/g, "exports.$1 = function");

        await m.reply(`✅ *CONVERT TO CJS SUCCESS*\n\n\`\`\`javascript\n${result}\n\`\`\``);
    }

    // ==========================================
    // 2. CONVERT KE ESM (CJS -> ESM)
    // ==========================================
    if (command === 'toesm') {
        result = txt
            // Support: const { a, b } = require('c') -> import { a, b } from 'c'
            .replace(/(const|let|var)\s+\{\s*([\s\S]+?)\s*\}\s+=\s+require\(['"](.+?)['"]\)/g, "import { $2 } from '$3'")
            // Support: const name = require('pkg') -> import name from 'pkg'
            .replace(/(const|let|var)\s+(\w+)\s+=\s+require\(['"](.+?)['"]\)/g, "import $2 from '$3'")
            // Support: module.exports = -> export default 
            .replace(/module\.exports\s*=\s*/g, "export default ")
            // Support: exports.name = -> export const name = 
            .replace(/exports\.(\w+)\s*=\s*/g, "export const $1 = ");

        await m.reply(`✅ *CONVERT TO ESM SUCCESS*\n\n\`\`\`javascript\n${result}\n\`\`\``);
    }

    await m.react("✅");
};

handler.help = ["toesm", "tocjs"];
handler.command = ["toesm", "tocjs"];
handler.tags = ["tools"];
handler.owner = true;

export default handler;