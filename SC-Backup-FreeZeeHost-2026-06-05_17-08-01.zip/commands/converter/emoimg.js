import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Format salah.\nContoh: #emoimg 😳 apple")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    const args = text.split(" ")
    const emoji = args[0]
    const style = args[1] || "apple"

    try {

        await conn.sendReact(m.chat, "🎭", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/emoimg", {
                params: {
                    q: emoji,
                    style,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal mengambil emoji image.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `🖼 Emoji Style: ${style}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("EMOIMG ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses emoji.")
    }
}

handler.command = ["emoimg"]
handler.tags = ["converter"]
handler.help = ["emoimg <emoji> <style>"]

export default handler