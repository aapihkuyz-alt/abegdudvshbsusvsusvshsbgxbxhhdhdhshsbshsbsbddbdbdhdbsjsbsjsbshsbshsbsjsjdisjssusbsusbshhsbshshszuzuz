import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan emoji.\nContoh: #emojito 😳")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🔄", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/emojito", {
                params: {
                    q: text,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal mengubah emoji.")

        await conn.sendMessage(m.chat, {
            sticker: {
                url: data.data.url
            }
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("EMOJITO ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses emoji.")
    }
}

handler.command = ["emojito"]
handler.tags = ["converter"]
handler.help = ["emojito <emoji>"]

export default handler