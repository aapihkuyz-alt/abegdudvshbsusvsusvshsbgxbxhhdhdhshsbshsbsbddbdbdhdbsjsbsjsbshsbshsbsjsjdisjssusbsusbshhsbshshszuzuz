/**
 * 🛠️ ULTIMATE ESM PLUGIN TO CASE CONVERTER (FINAL FIX)
 * Tags: converter | Owner: false
 */

const handler = async (m, {
    text,
    usedPrefix,
    command
}) => {
    let q = m.quoted ? m.quoted : m;
    let txt = text ? text : (q.text || q.caption || '');

    if (!txt) return m.reply(`Balas file plugin ESM dengan ketik *${usedPrefix + command}*`);

    await m.react("⏳");

    // 1. Ambil Nama Command dari handler.command
    let cmdMatch = txt.match(/handler\.command\s*=\s*\[?['"](.*?)['"]\]?/);
    let cmdName = cmdMatch ? cmdMatch[1].split(/['"],\s*['"]/)[0] : "newcommand";

    // 2. Buang Import & Export
    let lines = txt.split('\n').filter(line =>
        !line.trim().startsWith('import') &&
        !line.trim().startsWith('export default')
    ).join('\n');

    // 3. 💥 LOGIKA SCANNER AKURAT (Anti-Sisa 'let/const') 💥
    let handlerStartMatch = lines.match(/(let|const|var)\s+handler\s*=\s*async\s*\(m,\s*\{[\s\S]+?\}\)\s*=>\s*\{/);

    let finalBody = "";
    if (handlerStartMatch) {
        let startIndex = handlerStartMatch.index;
        let openingBraceIndex = lines.indexOf('{', startIndex + handlerStartMatch[0].indexOf('=>'));

        // Potongan A: Helper (Fungsi di atas handler)
        let helper = lines.substring(0, startIndex).trim();

        // Potongan B: Body (Isi di dalam handler)
        let restOfCode = lines.substring(openingBraceIndex + 1);

        // Buang Footer (handler.help dll)
        let footerIdx = restOfCode.search(/handler\.(help|tags|command|owner|limit|group|admin|register)/);
        let bodyOnly = footerIdx !== -1 ? restOfCode.substring(0, footerIdx).trim() : restOfCode.trim();

        // Buang kurung kurawal penutup terakhir (}) milik handler
        let lastBrace = bodyOnly.lastIndexOf('}');
        if (lastBrace !== -1) {
            bodyOnly = bodyOnly.substring(0, lastBrace) + bodyOnly.substring(lastBrace + 1);
        }

        finalBody = (helper + "\n\n" + bodyOnly).trim();
    } else {
        finalBody = lines.trim();
    }

    // 4. WRAPPING KE CASE
    let caseResult = `
case "${cmdName}": {
${finalBody}
}
break;
`.trim();

    await m.reply(`✅ *CONVERT PLUGIN TO CASE SUCCESS*\n\n\`\`\`javascript\n${caseResult}\n\`\`\``);
    await m.react("✅");
};

handler.help = ["tocase"];
handler.command = ["tocase", "plugintocase"];
handler.tags = ["converter"];
handler.owner = false; // Sekarang semua user bisa pakai

export default handler;