import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    try {

        let videoBuffer = null

        await conn.sendMessage(m.chat, {
            react: {
                text: "🎬",
                key: m.key
            }
        })

        /* ================= REPLY VIDEO ================= */
        if (m.quoted) {

            const quoted = m.quoted.message

            if (quoted?.videoMessage) {
                videoBuffer = await m.quoted.download()
            }
        }

        /* ================= VIDEO LANGSUNG ================= */
        if (!videoBuffer && m.message?.videoMessage) {
            videoBuffer = await m.download()
        }

        /* ================= LINK VIDEO ================= */
        if (!videoBuffer && text && text.startsWith("http")) {
            const res = await axios.get(text, {
                responseType: "arraybuffer",
                timeout: 60000
            })
            videoBuffer = res.data
        }

        /* ================= VALIDASI ================= */
        if (!videoBuffer) {
            return m.reply(
                "Reply video asli / kirim video langsung / masukkan link video mp4\n\nBukan reply preview link doang."
            )
        }

        /* ================= KIRIM PTV ================= */
        await conn.sendMessage(
            m.chat, {
                video: videoBuffer,
                ptv: true,
                mimetype: "video/mp4"
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (err) {

        console.error("PTV ERROR:", err)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal convert ke video note.")
    }
}

handler.command = ["videonote", "ptv", "vnvideo"]
handler.tags = ["converter"]
handler.help = ["ptv <reply video / link>"]

export default handler