import ffmpeg from "fluent-ffmpeg"
import fs from "fs"
import path from "path"
import {
    tmpdir
} from "os"

let handler = async (m, {
    conn
}) => {

    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""

    if (!/video/.test(mime)) return m.reply("Reply video")

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏳",
            key: m.key
        }
    })

    try {

        let media = await q.download()

        let input = path.join(tmpdir(), Date.now() + ".mp4")
        let output = path.join(tmpdir(), Date.now() + "_rev.mp4")

        fs.writeFileSync(input, media)

        await new Promise((res, rej) => {
            ffmpeg(input)
                .outputOptions([
                    "-filter_complex",
                    "[0:v]reverse[v];[0:a]areverse[a]",
                    "-map", "[v]",
                    "-map", "[a]"
                ])
                .save(output)
                .on("end", res)
                .on("error", rej)
        })

        await conn.sendMessage(m.chat, {
            video: fs.readFileSync(output),
            caption: "🔄 Reverse (video + audio)"
        }, {
            quoted: m
        })

        fs.unlinkSync(input)
        fs.unlinkSync(output)

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error(e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal reverse video")
    }
}

handler.command = ["reverse"]
handler.tags = ["converter"]
handler.help = ["reverse"]

export default handler