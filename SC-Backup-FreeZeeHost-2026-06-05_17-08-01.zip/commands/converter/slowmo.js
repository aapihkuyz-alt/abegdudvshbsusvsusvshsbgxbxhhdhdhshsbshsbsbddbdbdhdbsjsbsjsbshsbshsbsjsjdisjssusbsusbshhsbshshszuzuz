import ffmpeg from "fluent-ffmpeg"
import fs from "fs"
import path from "path"
import {
    tmpdir
} from "os"

let handler = async (m, {
    conn,
    text
}) => {

    let speed = parseFloat(text) || 0.5

    // 🔥 LIMIT BIAR GAK ERROR
    if (isNaN(speed)) speed = 0.5
    if (speed < 0.5) speed = 0.5
    if (speed > 2) speed = 2

    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""

    if (!/video/.test(mime)) return m.reply("Reply video")

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏳",
            key: m.key
        }
    })

    try {

        let media = await q.download()

        let input = path.join(tmpdir(), Date.now() + ".mp4")
        let output = path.join(tmpdir(), Date.now() + "_slow.mp4")

        fs.writeFileSync(input, media)

        await new Promise((res, rej) => {
            ffmpeg(input)
                .outputOptions([
                    "-filter_complex",
                    `[0:v]setpts=${1/speed}*PTS[v];[0:a]atempo=${speed}[a]`,
                    "-map", "[v]",
                    "-map", "[a]"
                ])
                .save(output)
                .on("end", res)
                .on("error", rej)
        })

        await conn.sendMessage(m.chat, {
            video: fs.readFileSync(output),
            caption: `🐢 Slow Motion (${speed}x)`
        }, {
            quoted: m
        })

        fs.unlinkSync(input)
        fs.unlinkSync(output)

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {
        console.error(e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal slowmo video")
    }
}

handler.command = ["slowmo"]
handler.tags = ["converter"]
handler.help = ["slowmo <0.5 - 2>"]

export default handler