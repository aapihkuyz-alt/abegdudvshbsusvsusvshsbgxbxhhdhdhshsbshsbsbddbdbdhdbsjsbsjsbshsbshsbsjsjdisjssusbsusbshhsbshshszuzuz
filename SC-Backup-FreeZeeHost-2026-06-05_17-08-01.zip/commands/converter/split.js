import ffmpeg from "fluent-ffmpeg"
import fs from "fs"
import path from "path"
import {
    tmpdir
} from "os"

let handler = async (m, {
    conn
}) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""

    if (!/video/.test(mime)) return m.reply("Reply video")

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏳",
            key: m.key
        }
    })

    try {
        let media = await q.download()

        let input = path.join(tmpdir(), Date.now() + ".mp4")
        fs.writeFileSync(input, media)

        for (let i = 0; i < 3; i++) {
            let output = path.join(tmpdir(), Date.now() + `_${i}.mp4`)

            await new Promise((res, rej) => {
                ffmpeg(input)
                    .setStartTime(i * 10)
                    .duration(10)
                    .save(output)
                    .on("end", res)
                    .on("error", rej)
            })

            await conn.sendMessage(m.chat, {
                video: fs.readFileSync(output),
                caption: `📂 Part ${i+1}`
            }, {
                quoted: m
            })

            fs.unlinkSync(output)
        }

        fs.unlinkSync(input)

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal split video")
    }
}

handler.command = ["split"]
handler.tags = ["converter"]
handler.help = ["split"]

export default handler