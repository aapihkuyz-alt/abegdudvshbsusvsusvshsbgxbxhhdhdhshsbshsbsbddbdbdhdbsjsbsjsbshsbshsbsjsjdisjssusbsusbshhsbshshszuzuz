import fs from "fs"
import ffmpeg from "fluent-ffmpeg"
import path from "path"
import {
    tmpdir
} from "os"

const handler = async (m, {
    conn
}) => {

    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""

    if (!/video|webp/.test(mime)) {
        return m.reply("Reply video / sticker")
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏳",
            key: m.key
        }
    })

    try {

        let media = await q.download()

        let input = path.join(tmpdir(), Date.now() + ".webm")
        let temp = path.join(tmpdir(), Date.now() + "_temp.mp4")
        let output = path.join(tmpdir(), Date.now() + "_final.mp4")

        fs.writeFileSync(input, media)

        // STEP 1: normalize
        await new Promise((resolve, reject) => {
            ffmpeg(input)
                .toFormat("mp4")
                .on("end", resolve)
                .on("error", reject)
                .save(temp)
        })

        // STEP 2: SMART CONVERT
        await new Promise((resolve, reject) => {
            ffmpeg(temp)
                .outputOptions([
                    "-vf", "fps=25,scale='min(512,iw)':-2:flags=lanczos",
                    "-t", "6", // auto cut max 6 detik
                    "-preset", "fast",
                    "-crf", "23",
                    "-pix_fmt", "yuv420p",
                    "-movflags", "+faststart"
                ])
                .toFormat("mp4")
                .on("end", resolve)
                .on("error", reject)
                .save(output)
        })

        let result = fs.readFileSync(output)

        await conn.sendMessage(
            m.chat, {
                video: result,
                gifPlayback: true,
                caption: "✨ GIF Smooth (Auto Optimize)"
            }, {
                quoted: m
            }
        )

        // cleanup
        fs.unlinkSync(input)
        fs.unlinkSync(temp)
        fs.unlinkSync(output)

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("TOGIF ERROR:", e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal convert video (kemungkinan video terlalu berat)")
    }

}

handler.command = ["togif", "gif", "stc"]
handler.tags = ["converter"]
handler.help = ["togif (reply video/sticker)"]

export default handler