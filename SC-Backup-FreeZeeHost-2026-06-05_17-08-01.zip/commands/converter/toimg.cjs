const { Worker } = require('worker_threads');
const fs = require('fs');
const path = require('path');

let handler = async (m, {
    conn,
    usedPrefix,
    command
}) => {
    let notMakerMessage = `Reply maker dengan command *${usedPrefix + command}*`;
    let q = m.quoted || m;

    const isMaker =
        q?.type === 'stickerMessage' ||
        q?.message?.stickerMessage;

    if (!isMaker) return m.reply(notMakerMessage);

    await global.loading(m, conn);

    const tmpDir = path.join(process.cwd(), 'tmp');
    if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir);

    const input = path.join(tmpDir, `worker_in_${Date.now()}.webp`);
    const output = path.join(tmpDir, `worker_out_${Date.now()}.jpg`);

    try {
        const media = await q.download();
        fs.writeFileSync(input, media);

        // Offload conversion ke Worker Thread
        const workerPath = path.join(process.cwd(), 'core/worker.js');
        const worker = new Worker(workerPath, {
            workerData: { 
                task: 'image_convert',
                data: { input, output, quality: 90 }
            }
        });

        worker.on('message', async (result) => {
            if (result.error) {
                console.error('Worker task error:', result.error);
                m.reply('Gagal convert image di background.');
            } else if (result.success) {
                const img = fs.readFileSync(result.output);
                await conn.sendFile(m.chat, img, 'toimg.jpg', '', m);
            }
            
            // Cleanup
            if (fs.existsSync(input)) fs.unlinkSync(input);
            if (fs.existsSync(output)) fs.unlinkSync(output);
            await global.loading(m, conn, true);
        });

        worker.on('error', (err) => {
            console.error('Worker Thread Error:', err);
            m.reply('Worker thread mengalami gangguan.');
        });

    } catch (e) {
        console.error('ERROR TOIMG:', e);
        m.reply('Terjadi kesalahan saat memproses sticker.');
        if (fs.existsSync(input)) fs.unlinkSync(input);
        await global.loading(m, conn, true);
    }
};

handler.help = ['toimg'];
handler.tags = ['converter'];
handler.command = ['toimg', 'toimage'];

module.exports = handler;