import ffmpeg from "fluent-ffmpeg"
import fs from "fs"
import path from "path"
import {
    tmpdir
} from "os"

let handler = async (m, {
    conn
}) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ""

    if (!/video|audio/.test(mime)) return m.reply("Reply media")

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏳",
            key: m.key
        }
    })

    try {
        let media = await q.download()

        let input = path.join(tmpdir(), Date.now() + ".mp4")
        let output = path.join(tmpdir(), Date.now() + ".mp3")

        fs.writeFileSync(input, media)

        await new Promise((res, rej) => {
            ffmpeg(input)
                .toFormat("mp3")
                .save(output)
                .on("end", res)
                .on("error", rej)
        })

        await conn.sendMessage(m.chat, {
            audio: fs.readFileSync(output),
            mimetype: "audio/mpeg"
        }, {
            quoted: m
        })

        fs.unlinkSync(input)
        fs.unlinkSync(output)

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal convert ke mp3")
    }
}

handler.command = ["tomp3"]
handler.tags = ["converter"]
handler.help = ["tomp3"]

export default handler