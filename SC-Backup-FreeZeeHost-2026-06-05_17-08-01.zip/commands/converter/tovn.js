import ffmpeg from "fluent-ffmpeg";
import ffmpegInstaller from "@ffmpeg-installer/ffmpeg";
import { PassThrough } from "stream";

ffmpeg.setFfmpegPath(ffmpegInstaller.path);

let handler = async (m, {
    conn
}) => {

    if (!m.quoted) return m.reply("Reply audio / video ya")

    const q = m.quoted
    const type = Object.keys(q.message || {})[0]
    const msg = q.message?.[type]

    if (!msg) return m.reply("Media tidak ditemukan")

    const mime = msg.mimetype || ""
    if (!/audio|video/.test(mime)) {
        return m.reply("Reply audio atau video")
    }

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🔄",
                key: m.key
            }
        })

        const buffer = await q.download();
        if (!buffer || !buffer.length) return m.reply("❌ Gagal download media");

        // --- CONVERSION VIA FFMPEG (Ensures WA compatibility) ---
        const inputStream = new PassThrough();
        inputStream.end(buffer);

        const outputStream = new PassThrough();
        const chunks = [];

        outputStream.on("data", chunk => chunks.push(chunk));

        await new Promise((resolve, reject) => {
            const ffmpegTimeout = setTimeout(() => {
                reject(new Error("Konversi audio terlalu lama (Timeout)"));
                inputStream.destroy();
                outputStream.destroy();
            }, 30000);

            ffmpeg(inputStream)
                .toFormat("ogg")
                .audioCodec("libopus")
                .on("error", (err) => {
                    clearTimeout(ffmpegTimeout);
                    reject(err);
                })
                .on("end", () => {
                    clearTimeout(ffmpegTimeout);
                    resolve();
                })
                .pipe(outputStream);
        });

        const finalAudio = Buffer.concat(chunks);

        await conn.sendMessage(
            m.chat, {
                audio: finalAudio,
                mimetype: 'audio/ogg; codecs=opus',
                ptt: true
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error(e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`Error: ${e.message}`)

    }

}

handler.command = ["tovn"]
handler.tags = ["converter"]
handler.help = ["tovn"]

export default handler