
const handler = async (m, {
    conn,
    text
}) => {
    if (!text)
        return m.reply(
            `Masukkan URL video Facebook!\n\nContoh:\nfb https://www.facebook.com/watch/?v=1393572814172251`
        )

    if (!/facebook\.com|fb\.watch/i.test(text))
        return m.reply('Link Facebook tidak valid.')

    await conn.sendMessage(m.chat, {
        react: {
            text: '⏳',
            key: m.key
        }
    })

    try {
        const api = `https://api.neoxr.eu/api/fb?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const res = await fetch(api)
        const json = await res.json()

        if (!json.status || !json.data?.length)
            throw 'Video tidak ditemukan'

        const hd = json.data.find(v => v.quality === 'HD')
        const sd = json.data.find(v => v.quality === 'SD')

        if (!hd && !sd)
            throw 'Tidak ada kualitas yang tersedia'

        // ⬇️ fungsi kirim video biar bisa fallback
        const sendVideo = async (video, label) => {
            await conn.sendMessage(
                m.chat, {
                    video: {
                        url: video.url
                    },
                    caption: `✅ Facebook Video\nKualitas: ${label}`,
                    mimetype: 'video/mp4'
                }, {
                    quoted: m
                }
            )
        }

        try {
            if (!hd) throw 'HD tidak tersedia'
            await sendVideo(hd, 'HD')
            await conn.sendMessage(m.chat, {
                react: {
                    text: '✅',
                    key: m.key
                }
            })
        } catch (e) {
            console.warn('HD gagal, fallback ke SD')
            if (!sd) throw 'SD tidak tersedia'
            await sendVideo(sd, 'SD')
            await conn.sendMessage(m.chat, {
                react: {
                    text: '⚠️',
                    key: m.key
                }
            })
        }

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, {
            react: {
                text: '❌',
                key: m.key
            }
        })
        m.reply('Gagal mengunduh video Facebook.')
    }
}

handler.help = ['fb <url>']
handler.tags = ['downloader']
handler.command = /^(fb|facebook)$/i

export default handler