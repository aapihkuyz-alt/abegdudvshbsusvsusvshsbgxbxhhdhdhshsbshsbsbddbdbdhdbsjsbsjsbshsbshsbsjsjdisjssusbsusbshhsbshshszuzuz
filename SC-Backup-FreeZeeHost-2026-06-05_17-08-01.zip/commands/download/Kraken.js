import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Kraken.\n\nContoh:\n#kraken https://krakenfiles.com/view/xxxx/file.html")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "⏳", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/kraken", {
                params: {
                    url: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data)
            return m.reply("❌ Gagal mengambil data dari Kraken.")

        const res = data.data

        const caption = `
╭━━━〔 📥 KRAKEN DOWNLOADER 〕━━━⬣
┃ 📄 Nama     : ${res.filename}
┃ 📦 Size     : ${res.size}
┃ 📂 Type     : ${res.type}
┃ 👁 Views    : ${res.views}
┃ ⬇ Downloads : ${res.downloads}
┃ 📅 Upload   : ${res.upload_at}
┃ 🕒 Last DL  : ${res.last_download}
╰━━━━━━━━━━━━━━━━━━━━⬣

📥 File sedang dikirim...
`.trim()

        await conn.sendMessage(m.chat, {
            text: caption
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "📤", m.key)

        // Kirim sebagai document biar stabil
        await conn.sendMessage(m.chat, {
            document: {
                url: res.url
            },
            fileName: res.filename,
            mimetype: "video/mp4"
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("KRAKEN ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses link Kraken.")
    }
}

handler.command = ["kraken"]
handler.tags = ["downloader"]
handler.help = ["kraken <link>"]

export default handler