import axios from "axios"
import * as cheerio from "cheerio"

const headers = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
    Accept: "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    Referer: "https://www.mediafire.com/",
}

/* ===== SCRAPER ===== */
async function mediafiredl(url) {
    const res = await axios.get(url, {
        headers,
        maxRedirects: 5
    })
    const $ = cheerio.load(res.data)

    const download = $("#download_link > a.input.popsok").attr("href")
    if (!download) throw "Download link tidak ditemukan"

    const filename =
        $(".dl-btn-label").first().text().trim() || "mediafire-file"

    const filesize =
        $("#download_link > a.input.popsok")
        .text()
        .match(/\(([^)]+)\)/)?.[1] || "-"

    const filetype = $(".dl-info .filetype span").first().text().trim()
    const uploaded =
        $(".details li").eq(1).find("span").text().trim()

    return {
        filename,
        filetype,
        filesize,
        uploaded,
        download
    }
}

/* ================= HANDLER ================= */
let handler = async (m, {
    text,
    conn
}) => {
    if (!text)
        return m.reply(
            "Contoh:\n#mf https://www.mediafire.com/file/xxxx/file"
        )

    if (!/mediafire\.com/i.test(text))
        return m.reply("❌ Link bukan MediaFire")

    try {
        await m.reply("⏳ Mengambil & mengunduh file MediaFire...")

        const data = await mediafiredl(text)

        // DOWNLOAD FILE BUFFER
        const fileRes = await axios.get(data.download, {
            responseType: "arraybuffer",
            headers,
            maxRedirects: 5,
        })

        const buffer = fileRes.data
        const sizeMB = buffer.length / (1024 * 1024)

        // LIMIT SAFETY
        if (sizeMB > 80) {
            return m.reply(
                `⚠️ File terlalu besar (${sizeMB.toFixed(
          2
        )} MB)\n\nDownload manual:\n${data.download}`
            )
        }

        await conn.sendMessage(
            m.chat, {
                document: buffer,
                fileName: data.filename + ".zip",
                mimetype: "application/zip",
                caption: `📁 *MEDIAFIRE DOWNLOADER*\n\n` +
                    `📄 Nama: ${data.filename}\n` +
                    `📦 Tipe: ${data.filetype}\n` +
                    `📏 Ukuran: ${data.filesize}\n` +
                    `📆 Upload: ${data.uploaded}`,
            }, {
                quoted: m
            }
        )
    } catch (e) {
        console.error(e)
        m.reply("❌ Gagal download file MediaFire")
    }
}

handler.command = ["mediafire", "mf"]
handler.tags = ["downloader"]
handler.help = ["mediafire <url>"]

export default handler