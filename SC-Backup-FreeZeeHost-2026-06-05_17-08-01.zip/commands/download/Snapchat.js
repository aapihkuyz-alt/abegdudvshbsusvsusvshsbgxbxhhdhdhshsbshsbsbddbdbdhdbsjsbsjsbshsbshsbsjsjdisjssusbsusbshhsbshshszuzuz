import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Snapchat.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "👻", m.key)

        const api = `https://api.neoxr.eu/api/snapchat?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const {
            data
        } = await axios.get(api, {
            timeout: 60000
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil video dari Snapchat.")

        const videoUrl = data.data.url
        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 👻 SNAPCHAT DOWNLOADER 〕━━━⬣
┃ 🌐 Source     : Snapchat Spotlight
┃ 📅 Download   : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Video berhasil diambil
🚫 Tanpa watermark
⚡ Direct stream (no buffer VPS)
🚀 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(m.chat, {
            video: {
                url: videoUrl
            },
            mimetype: "video/mp4",
            caption: caption
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("SNAPCHAT ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Snapchat.")
    }
}

handler.command = ["snapchat", "snapdl"]
handler.tags = ["downloader"]
handler.help = ["snapchat <link snapchat>"]

export default handler