import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Spotify.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎧", m.key)

        const api = `https://api.neoxr.eu/api/spotify?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const {
            data
        } = await axios.get(api, {
            timeout: 30000
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil lagu dari Spotify.")

        const res = data.data
        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🎧 SPOTIFY DOWNLOADER 〕━━━⬣
┃ 🎶 Title     : ${res.title || "-"}
┃ 👤 Artist    : ${res.artist?.name || "-"}
┃ ⏱ Duration  : ${res.duration || "-"}
┃ 📅 Download  : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Audio kualitas jernih
🔊 Playable langsung di WhatsApp
🚀 Powered by ${global.botname}
`.trim()

        // Kirim cover + caption
        await conn.sendMessage(m.chat, {
            image: {
                url: res.thumbnail
            },
            caption
        }, {
            quoted: m
        })

        // Kirim audio playable
        await conn.sendMessage(m.chat, {
            audio: {
                url: res.url
            },
            mimetype: "audio/mpeg",
            ptt: false
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("SPOTIFY ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Spotify.")
    }
}

handler.command = ["spotifydl", "spdl"]
handler.tags = ["downloader"]
handler.help = ["spotify <link spotify>"]

export default handler