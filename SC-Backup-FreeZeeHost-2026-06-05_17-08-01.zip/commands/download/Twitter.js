import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Twitter.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🐦", m.key)

        const api = `https://api.neoxr.eu/api/twitter?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 20000,
            validateStatus: s => s < 500
        })

        if (!data?.status || !Array.isArray(data.data) || !data.data.length)
            return m.reply("❌ Gagal mengambil media dari Twitter.")

        const now = moment()
            .tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🐦 TWITTER DOWNLOADER 〕━━━⬣
┃ 📦 Total Media : ${data.data.length}
┃ 📅 Download     : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Media berhasil diambil
🚀 Powered by ${global.botname}
`.trim()

        // =============================
        // SINGLE MEDIA
        // =============================
        if (data.data.length === 1) {

            const item = data.data[0]

            if (item.type === "mp4") {
                await conn.sendMessage(m.chat, {
                    video: {
                        url: item.url
                    },
                    mimetype: "video/mp4",
                    caption
                }, {
                    quoted: m
                })
            } else {
                await conn.sendMessage(m.chat, {
                    image: {
                        url: item.url
                    },
                    caption
                }, {
                    quoted: m
                })
            }

            await conn.sendReact(m.chat, "✅", m.key)
            return
        }

        // =============================
        // MULTIPLE MEDIA (ALBUM)
        // =============================

        let media = data.data.map((item, i) => {

            if (item.type === "mp4") {
                return {
                    video: {
                        url: item.url
                    },
                    mimetype: "video/mp4",
                    caption: i === 0 ? caption : undefined
                }
            } else {
                return {
                    image: {
                        url: item.url
                    },
                    caption: i === 0 ? caption : undefined
                }
            }
        })

        await conn.sendAlbumMessage(
            m.chat,
            media, {
                quoted: m
            }
        )

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {

        console.log("TWITTER ERROR:", err.response?.data || err.message)

        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Twitter.")
    }
}

handler.command = ["twitterdl", "twdl", "xdl"]
handler.tags = ["downloader"]
handler.help = ["twitter <link twitter>"]

export default handler