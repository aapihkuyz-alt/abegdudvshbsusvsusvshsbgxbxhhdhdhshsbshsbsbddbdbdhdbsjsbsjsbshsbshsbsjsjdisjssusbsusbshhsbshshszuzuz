let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link YouTube.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React loading
        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        const native_flow_button = [{
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
                title: '📥 Pilih Format Download',
                sections: [{
                    title: 'YouTube Downloader',
                    rows: [{
                            header: "Audio",
                            title: "🎵 MP3 (Best Quality)",
                            description: "Download sebagai audio 128kbps",
                            id: `.ytmp3 ${text}`
                        },
                        {
                            header: "Video",
                            title: "🎬 MP4 (Best Quality)",
                            description: "Download sebagai video 720p",
                            id: `.ytmp4 ${text}`
                        }
                    ]
                }]
            })
        }]

        const caption = `
╭━━━〔 🎥 YOUTUBE DOWNLOADER 〕━━━╮
┃ 🔗 Link :
┃ ➜ ${text}
┃
┃ ⚡ Pilih format download
┃ melalui tombol di bawah
╰━━━━━━━━━━━━━━━━━━━━━━╯
✨ Powered by ${global.ownername}
`.trim()

        await conn.sendMessage(m.chat, {
            text: caption,
            footer: "YouTube Download System",
            interactive: native_flow_button
        }, {
            quoted: m
        })

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.log("YTDL BUTTON ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Terjadi error saat memproses YouTube.")
    }
}

handler.command = ["youtube", "yt"]
handler.tags = ["downloader"]
handler.help = ["ytdl <link>"]

export default handler