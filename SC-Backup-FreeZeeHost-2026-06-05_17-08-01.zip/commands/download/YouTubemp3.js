import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text,
    Func
}) => {

    if (!text)
        return m.reply("❌ Masukkan link YouTube.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "⏳", m.key)

        const api = `https://api.neoxr.eu/api/youtube?url=${encodeURIComponent(text)}&type=audio&quality=128kbps&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 30000
        })

        if (!data?.status)
            return m.reply("❌ Gagal mengambil data.")

        const now = moment().tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
┏━━━━━━━━━━━━━❰ 🎵 YTMP3 DOWNLOADER ❱━━━━━━━━━━━━━━
┃ 🎙️ Title     : ${data.title}
┃ 👤 Channel   : ${data.channel}
┃ ⏱️ Duration  : ${data.fduration}
┃ 👁️ Views     : ${data.views}
┃ 🎚️ Quality   : ${data.data.quality}
┃ 💾 Size      : ${data.data.size}
┃ 📅 Download  : ${now}
┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

✨ Audio converted (playable)
🚀 Powered by ${global.botname}
`.trim()

        const thumbMsg = await conn.sendMessage(m.chat, {
            image: {
                url: data.thumbnail
            },
            caption
        }, {
            quoted: m
        })

        await Func.sendPlayableAudio(conn, m, data.data.url, {
            title: data.title
        }, { quoted: thumbMsg })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("YTMP3 ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Gagal memproses YTMP3.")
    }
}

handler.command = ["youtubemp3", "ytmp3"]
handler.tags = ["downloader"]
handler.help = ["ytmp3 <link youtube>"]

export default handler