import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("❌ Masukkan link YouTube.")
    if (!global.neoxr) return m.reply("❌ API key belum diset.")

    try {

        await conn.sendReact(m.chat, "⏳", m.key)

        const api = `https://api.neoxr.eu/api/youtube?url=${encodeURIComponent(text)}&type=video&quality=720p&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 30000
        })

        if (!data?.status) return m.reply("❌ Gagal mengambil video.")

        const now = moment().tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🎬 YTMP4 DOWNLOADER 〕━━━⬣
┃ 🎬 Title     : ${data.title}
┃ 👤 Channel   : ${data.channel}
┃ ⏱ Duration  : ${data.fduration}
┃ 👁 Views     : ${data.views}
┃ 📦 Quality   : ${data.data.quality}
┃ 📁 Size      : ${data.data.size}
┃ 📅 Download  : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ High quality video
🚀 Powered by ${global.botname}
`.trim()

        // Kirim video + caption jadi satu
        await conn.sendMessage(m.chat, {
            video: {
                url: data.data.url
            },
            mimetype: "video/mp4",
            caption
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("YTMP4 ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Gagal memproses YTMP4.")
    }
}

handler.command = ["youtubemp4", "ytmp4"]
handler.tags = ["downloader"]
export default handler