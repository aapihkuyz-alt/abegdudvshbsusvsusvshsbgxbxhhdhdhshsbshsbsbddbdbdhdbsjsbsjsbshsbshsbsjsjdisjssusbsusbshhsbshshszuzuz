import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link playlist YouTube.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "📂",
                key: m.key
            }
        })

        const api = `https://api.neoxr.eu/api/yt-playlist?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 20000
        })

        if (!data?.status || !data?.data?.length)
            return m.reply("❌ Gagal mengambil playlist atau playlist kosong.")

        const results = data.data

        const native_flow_button = [{
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: "📥 Pilih Video",
                sections: [{
                    title: `Total Video: ${results.length}`,
                    rows: results.map((v, i) => ({
                        header: `Video ${i + 1}`,
                        title: v.title.slice(0, 60),
                        description: "Klik untuk download",
                        id: `.ytdl ${v.url}`
                    }))
                }]
            })
        }]

        const caption = `
╭━━━〔 📂 YT PLAYLIST 〕━━━⬣
┃ 🔗 Playlist terdeteksi
┃ 📼 Total Video : ${results.length}
┃
┃ 🎬 Pilih video di bawah
┃ untuk download via YTDL
╰━━━━━━━━━━━━━━━━━━━━⬣

🚀 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(m.chat, {
            text: caption,
            footer: "YouTube Playlist System",
            interactive: native_flow_button
        }, {
            quoted: m
        })

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (err) {
        console.log("YT PLAYLIST ERROR:", err.response?.data || err.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Terjadi error saat memproses playlist.")
    }
}

handler.command = ["ytplaylistdl", "ytpldl"]
handler.tags = ["downloader"]
handler.help = ["ytplaylist <link playlist>"]

export default handler