import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link YouTube Post.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "📢", m.key)

        const api = `https://api.neoxr.eu/api/ytpost?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 20000,
            validateStatus: s => s < 500
        })

        if (!data?.status || !data?.data)
            return m.reply("❌ Gagal mengambil data YouTube Post.")

        const res = data.data
        const now = moment().tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 📢 YOUTUBE POST 〕━━━⬣
┃ 👤 Author    : ${res.author?.name || "-"}
┃ 🆔 Username  : ${res.author?.username || "-"}
┃ 📝 Caption   :
┃ ${res.caption || "-"}
┃ 📅 Published : ${res.published || "-"}
┃ 📦 Total     : ${res.medias?.length || 0} Media
┃ 📥 Retrieved : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Community post berhasil diambil
🚀 Powered by ${global.botname}
`.trim()

        // ===== MULTI MEDIA =====
        if (res.medias?.length > 1) {

            const media = res.medias.map((item, i) => ({
                image: {
                    url: item.url
                },
                caption: i === 0 ? caption : undefined
            }))

            await conn.sendAlbumMessage(
                m.chat,
                media, {
                    quoted: m
                }
            )
        }

        // ===== SINGLE MEDIA =====
        else if (res.medias?.length === 1) {

            await conn.sendMessage(m.chat, {
                image: {
                    url: res.medias[0].url
                },
                caption: caption
            }, {
                quoted: m
            })
        }

        // ===== NO MEDIA (TEXT ONLY POST) =====
        else {

            await conn.sendMessage(m.chat, {
                text: caption
            }, {
                quoted: m
            })
        }

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {

        console.log("YTPOST ERROR:", err.response?.data || err.message)

        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses YouTube Post.")
    }
}

handler.command = ["youtubepostdl", "ytpostdl"]
handler.tags = ["downloader"]
handler.help = ["ytpost <link youtube post>"]

export default handler