/**
  » Fitur     : AIO Downloader (Neoxr + Auto Backup Scrape)
  » Type      : Plugin ESM
**/

import axios from "axios"

/* ================= PRIMARY API (Neoxr) ================= */

async function aioPrimary(url) {
    const {
        data
    } = await axios.get(
        "https://api.neoxr.eu/api/aio", {
            params: {
                url: url,
                apikey: global.neoxr
            }
        }
    )

    if (!data.status || !data.data)
        throw new Error("Neoxr API Error")

    return data.data
}

/* ================= BACKUP SCRAPER (AUTO TOKEN) ================= */

async function aioBackup(url) {
    const baseURL = "https://allinonedownloader.com"

    // 1️⃣ Ambil homepage untuk ambil token
    const {
        data: html
    } = await axios.get(baseURL, {
        headers: {
            "user-agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        }
    })

    const tokenMatch = html.match(/token:\s*'(.+?)'/)
    const hashMatch = html.match(/urlhash:\s*'(.+?)'/)

    if (!tokenMatch || !hashMatch)
        throw new Error("Token atau urlhash tidak ditemukan")

    const token = tokenMatch[1]
    const urlhash = hashMatch[1]

    // 2️⃣ Request download
    const payload = new URLSearchParams({
        url,
        token,
        urlhash
    })

    const {
        data
    } = await axios.post(
        `${baseURL}/system/3c829fbbcf0387c.php`,
        payload.toString(), {
            headers: {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "origin": baseURL,
                "referer": baseURL + "/",
                "x-requested-with": "XMLHttpRequest",
                "user-agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
            }
        }
    )

    if (!data || !data.data)
        throw new Error("Backup response kosong")

    return data.data.map(v => ({
        type: v.type?.includes("audio") ? "mp3" : "mp4",
        url: v.url
    }))
}

/* ================= AUTO FALLBACK ================= */

async function aio(url) {
    try {
        console.log("Menggunakan Neoxr...")
        return await aioPrimary(url)
    } catch (err) {
        console.log("Neoxr gagal:", err.message)
        console.log("Switch ke Backup Scrape...")
        return await aioBackup(url)
    }
}

/* ================= HANDLER ================= */

let handler = async (m, {
    conn,
    text,
    command
}) => {
    try {

        /* ===== BUTTON CLICK ===== */
        if (command === "aiodl") {
            const media = JSON.parse(text)

            await conn.sendMessage(m.chat, {
                react: {
                    text: "⏳",
                    key: m.key
                }
            })

            if (media.type === "mp3") {
                await conn.sendMessage(
                    m.chat, {
                        audio: {
                            url: media.url
                        },
                        mimetype: "audio/mpeg"
                    }, {
                        quoted: m
                    }
                )
            } else {
                await conn.sendMessage(
                    m.chat, {
                        video: {
                            url: media.url
                        },
                        caption: "🎬 *AIO Downloader*\n\nAuto Backup System Aktif"
                    }, {
                        quoted: m
                    }
                )
            }

            await conn.sendMessage(m.chat, {
                react: {
                    text: "✔️",
                    key: m.key
                }
            })
            return
        }

        /* ===== MAIN COMMAND ===== */

        if (!text)
            return m.reply(
                "❌ Masukkan link!\n\nContoh:\n.aio https://x.com/xxxx"
            )

        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        const list = await aio(text)

        if (!list || list.length === 0)
            throw new Error("Media tidak ditemukan")

        const buttons = list.map((v, i) => ({
            buttonId: `.aiodl ${JSON.stringify(v)}`,
            buttonText: {
                displayText: v.type === "mp3" ?
                    "🎧 Audio MP3" :
                    `🎬 Video ${i + 1}`
            },
            type: 1
        }))

        await conn.sendMessage(
            m.chat, {
                text: "Pilih format download 👇",
                buttons,
                headerType: 1
            }, {
                quoted: m
            }
        )

    } catch (e) {
        console.error("ERROR DETAIL:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Terjadi kesalahan. Primary & Backup gagal.")
    }
}

handler.help = ["aio"]
handler.tags = ["downloader"]
handler.command = ["aio", "aiodl"]

export default handler