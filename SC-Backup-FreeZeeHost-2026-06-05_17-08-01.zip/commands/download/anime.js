let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Contoh: .animedl 1")

    const episodes = global.animeSession?.[m.sender]
    if (!episodes)
        return m.reply("❌ Session tidak ditemukan. Gunakan .animeget dulu.")

    const index = parseInt(text) - 1
    if (isNaN(index) || !episodes[index])
        return m.reply("❌ Nomor episode tidak valid.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        const ep = episodes[index]

        const quality720 = ep.link.find(q =>
            q.quality.toUpperCase() === "720P"
        )

        if (!quality720)
            return m.reply("❌ 720P tidak tersedia.")

        const gdrive = quality720.url.find(u =>
            u.server.toLowerCase().includes("gdrive")
        )

        if (!gdrive)
            return m.reply("❌ GDrive tidak tersedia.")

        await conn.reply(
            m.chat,
            `.gdrivedl ${gdrive.url}`,
            m
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch {
        m.reply("❌ Gagal memproses download.")
    }
}

handler.command = ["animedl"]
export default handler