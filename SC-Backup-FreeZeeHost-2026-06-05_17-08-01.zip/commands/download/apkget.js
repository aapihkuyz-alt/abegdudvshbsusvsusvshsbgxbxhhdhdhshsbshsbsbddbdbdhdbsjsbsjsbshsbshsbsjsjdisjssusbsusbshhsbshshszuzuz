import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text)
        return m.reply("Contoh:\n.apkget whatsapp|1")

    const [query, no] = text.split("|")

    if (!query || !no)
        return m.reply("Format salah!\nContoh:\n.apkget whatsapp|1")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "📥",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/apk", {
                params: {
                    q: query.trim(),
                    no: no.trim(),
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data || !data.file)
            throw new Error("Data tidak ditemukan")

        const info = data.data
        const file = data.file

        const caption =
            `📦 *${info.name}*

⭐ Rating : ${info.rating}
📥 Install : ${info.installs}
👨‍💻 Developer : ${info.developer}
📂 Kategori : ${info.category}
🔢 Versi : ${info.version}
📦 Size : ${file.size}

Mengirim file APK...`

        // kirim file APK langsung
        await conn.sendMessage(
            m.chat, {
                document: {
                    url: file.url
                },
                mimetype: "application/vnd.android.package-archive",
                fileName: file.filename,
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("APKGET ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengirim file APK.")
    }
}

handler.help = ["apkget <query>|<no>"]
handler.tags = ["downloader"]
handler.command = ["apkget"]

export default handler