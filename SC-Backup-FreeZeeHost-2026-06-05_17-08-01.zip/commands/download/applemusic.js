import fs from "fs"
import path from "path"
import axios from "axios"
import ffmpeg from "fluent-ffmpeg"
import ffmpegInstaller from "@ffmpeg-installer/ffmpeg"
import { fileURLToPath } from "url"

ffmpeg.setFfmpegPath(ffmpegInstaller.path)

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)

const tmpDir = path.join(__dirname, "tmp")
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

let handler = async (m, { conn, text }) => {

    if (!text)
        return m.reply("Contoh:\n.applemusic https://music.apple.com/...")

    if (!global.neoxr)
        return m.reply("API key belum di set di global.neoxr")

    try {

        await conn.sendMessage(m.chat, {
            react: { text: "🎵", key: m.key }
        })

        const { data } = await axios.get(
            "https://api.neoxr.eu/api/applemusic",
            {
                params: {
                    url: text.trim(),
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data)
            throw "API Error"

        const res = data.data

        const caption = `
╭━━━〔 🍎 APPLE MUSIC DOWNLOADER 〕━━━⬣
┃ 🎵 Title     : ${res.title}
┃ 💽 Album     : ${res.album}
┃ 📅 Released  : ${res.published}
┃
┃ 🔗 Source :
┃ ${res.source}
╰━━━━━━━━━━━━━━━━━━━━━━━━━━⬣
        `.trim()

        // ===== 1️⃣ Kirim Thumbnail =====
        await conn.sendMessage(
            m.chat,
            {
                image: { url: res.thumbnail },
                caption
            },
            { quoted: m }
        )

        // ===== 2️⃣ DOWNLOAD AUDIO =====
        const input = path.join(tmpDir, Date.now() + "_in")
        const output = path.join(tmpDir, Date.now() + "_out.mp3")

        const audioRes = await axios.get(res.audio.url, {
            responseType: "arraybuffer",
            timeout: 60000
        })

        fs.writeFileSync(input, Buffer.from(audioRes.data))

        // ===== 3️⃣ CONVERT =====
        await new Promise((resolve, reject) => {
            ffmpeg(input)
                .audioCodec("libmp3lame")
                .audioBitrate(128)
                .format("mp3")
                .on("end", resolve)
                .on("error", reject)
                .save(output)
        })

        const finalAudio = fs.readFileSync(output)

        // ===== 4️⃣ KIRIM AUDIO PLAYABLE =====
        await conn.sendMessage(
            m.chat,
            {
                audio: finalAudio,
                mimetype: "audio/mpeg",
                fileName: `${res.title}.mp3`,
                ptt: false
            },
            { quoted: m }
        )

        // ===== CLEANUP =====
        fs.unlinkSync(input)
        fs.unlinkSync(output)

        await conn.sendMessage(m.chat, {
            react: { text: "✔️", key: m.key }
        })

    } catch (e) {

        console.error("APPLE MUSIC ERROR:", e)

        await conn.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })

        m.reply("❌ Gagal convert atau API limit.")
    }
}

handler.help = ["applemusic <url>", "amd <url>"]
handler.tags = ["downloader"]
handler.command = ["applemusic", "amd"]

export default handler