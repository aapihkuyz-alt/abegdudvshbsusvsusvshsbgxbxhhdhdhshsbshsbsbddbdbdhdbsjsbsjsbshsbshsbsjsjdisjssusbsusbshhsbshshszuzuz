import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text)
        return m.reply("Contoh:\n.bilitv https://www.bilibili.tv/id/video/xxxx")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/bilibili", {
                params: {
                    url: text.trim(),
                    apikey: global.neoxr
                },
                timeout: 30000
            }
        )

        if (!data?.status || !data.data?.video?.length)
            throw new Error("Video tidak ditemukan")

        // Ambil kualitas pertama
        const stream = data.data.video[0]
        const video = stream.video_resource

        // Pakai backup_url kalau url utama bermasalah
        const videoUrl = video.url || video.backup_url?.[0]
        if (!videoUrl) throw new Error("URL video kosong")

        const duration = Math.floor(video.duration / 1000)
        const sizeMB = (video.size / 1024 / 1024).toFixed(2)

        const caption = `
╭━━━〔 📺 *BILIBILI DOWNLOADER* 〕━━━╮
┃ 🎞 Quality : ${stream.stream_info?.desc_words || "Unknown"}
┃ ⏳ Duration : ${duration}s
┃ 📦 Size : ${sizeMB} MB
╰━━━━━━━━━━━━━━━━━━━━━━╯
`.trim()

        await conn.sendMessage(
            m.chat, {
                video: {
                    url: videoUrl
                },
                mimetype: "video/mp4",
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("BILIBILI ERROR:", e.response?.data || e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil video atau link expired.")
    }
}

handler.help = ["bilitv <url>", "bilibili <url>"]
handler.tags = ["downloader"]
handler.command = ["bilitv", "bilibili"]

export default handler