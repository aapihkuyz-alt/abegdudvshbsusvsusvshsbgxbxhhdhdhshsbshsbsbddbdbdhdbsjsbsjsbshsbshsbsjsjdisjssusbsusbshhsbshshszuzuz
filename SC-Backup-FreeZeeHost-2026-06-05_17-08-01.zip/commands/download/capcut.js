import axios from 'axios'

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) {
        return m.reply(`📎 *Masukkan link CapCut ya*\n\nContoh:\n${usedPrefix + command} https://www.capcut.com/tv2/xxxx/`)
    }

    if (!global.neoxr) {
        return m.reply('⚠️ API key tidak ditemukan di global.neoxr')
    }

    try {
        // React 🎬
        await conn.sendMessage(m.chat, {
            react: {
                text: '🎬',
                key: m.key
            }
        })

        await m.reply(`
╭───〔 🎬 CAPCUT DOWNLOADER 〕───⬣
│  ⏳ Sedang mengambil video...
│  Mohon tunggu sebentar ya.
╰────────────────────────⬣
`.trim())

        const res = await axios.get('https://api.neoxr.eu/api/capcut', {
            params: {
                url: text,
                apikey: global.neoxr
            },
            timeout: 30000
        })

        if (!res.data?.status) {
            return m.reply('❌ API gagal merespon dengan benar.')
        }

        const videoUrl = res.data?.data?.url
        const tag = res.data?.caption || '-'

        if (!videoUrl) {
            return m.reply('❌ Gagal mendapatkan video dari API.')
        }

        await conn.sendMessage(m.chat, {
            video: {
                url: videoUrl
            },
            caption: `
╭───〔 ✅ DOWNLOAD SELESAI 〕───⬣
│  📌 Caption:
│  ${tag}
╰────────────────────────⬣
`.trim()
        }, {
            quoted: m
        })

    } catch (err) {
        console.error('[CAPCUT ERROR]', err)
        m.reply('❌ Terjadi kesalahan saat mengunduh video.')
    }
}

handler.help = ['capcutdl <url>']
handler.tags = ['downloader']
handler.command = /^(capcutdl|capcutdownload)$/i
handler.limit = true
handler.description = 'Download video dari CapCut tanpa watermark.'

export default handler