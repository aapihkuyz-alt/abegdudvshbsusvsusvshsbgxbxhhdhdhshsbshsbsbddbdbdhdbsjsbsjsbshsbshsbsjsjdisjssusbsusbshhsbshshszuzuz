import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Douyin.\n\nContoh:\n#douyin https://v.douyin.com/xxxx")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "⏳", m.key)

        const {
            data
        } = await axios.get("https://api.neoxr.eu/api/douyin", {
            params: {
                url: text,
                apikey: global.neoxr
            },
            timeout: 60000
        })

        if (!data?.status)
            return m.reply("❌ Gagal mengambil data dari API.")

        const res = data.data

        if (!res)
            return m.reply("❌ Data kosong.")

        // ================= PHOTO =================
        if (res.photo && Array.isArray(res.photo)) {
            for (let img of res.photo) {
                await conn.sendMessage(m.chat, {
                    image: {
                        url: img
                    }
                }, {
                    quoted: m
                })
            }

            await conn.sendReact(m.chat, "✅", m.key)
            return
        }

        // ================= VIDEO =================
        if (res.video) {

            await conn.sendMessage(m.chat, {
                video: {
                    url: res.video
                },
                caption: "🎬 Douyin Downloader\n\n✨ Video tanpa watermark"
            }, {
                quoted: m
            })

            await conn.sendReact(m.chat, "✅", m.key)
            return
        }

        // ================= FALLBACK WM =================
        if (res.videoWM) {

            await conn.sendMessage(m.chat, {
                video: {
                    url: res.videoWM
                },
                caption: "🎬 Douyin Downloader\n\n⚠️ Video dengan watermark"
            }, {
                quoted: m
            })

            await conn.sendReact(m.chat, "✅", m.key)
            return
        }

        // ================= AUDIO =================
        if (res.audio) {

            await conn.sendMessage(m.chat, {
                audio: {
                    url: res.audio
                },
                mimetype: "audio/mpeg"
            }, {
                quoted: m
            })

            await conn.sendReact(m.chat, "✅", m.key)
            return
        }

        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Tidak ada media yang bisa dikirim.")

    } catch (err) {
        console.log("DOUYIN ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses.")
    }
}

handler.command = ["douyin"]
handler.tags = ["downloader"]
handler.help = ["douyin <link>"]

export default handler