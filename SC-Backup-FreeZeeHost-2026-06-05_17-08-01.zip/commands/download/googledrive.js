import axios from 'axios'

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) {
        return m.reply(
            `📁 *Google Drive Downloader*

Kirim link file Google Drive ya.

Contoh:
${usedPrefix + command} https://drive.google.com/file/d/xxxx/view`
        )
    }

    if (!global.neoxr) {
        return m.reply('⚠️ API key tidak ditemukan di global.neoxr')
    }

    try {
        // React 📁
        await conn.sendMessage(m.chat, {
            react: {
                text: '📁',
                key: m.key
            }
        })

        await m.reply('🔄 Mengambil file dari Google Drive...')

        const res = await axios.get('https://api.neoxr.eu/api/gdrive', {
            params: {
                url: text,
                apikey: global.neoxr
            },
            timeout: 30000
        })

        if (!res.data?.status) {
            return m.reply('❌ Gagal mengambil data dari API.')
        }

        const fileUrl = res.data?.data?.url
        if (!fileUrl) {
            return m.reply('❌ Link file tidak ditemukan.')
        }

        await conn.sendMessage(m.chat, {
            document: {
                url: fileUrl
            },
            fileName: 'GoogleDrive_File',
            mimetype: 'application/octet-stream',
            caption: `✅ File berhasil diunduh dari Google Drive.`
        }, {
            quoted: m
        })

    } catch (err) {
        console.error('[GDRIVE ERROR]', err)
        m.reply('❌ Terjadi kesalahan saat mengunduh file.')
    }
}

handler.help = ['gdrivedl <url>']
handler.tags = ['downloader']
handler.command = /^(gdrivedl|googledrive|googledrivedownload)$/i
handler.limit = true
handler.description = 'Download file dari Google Drive.'

export default handler