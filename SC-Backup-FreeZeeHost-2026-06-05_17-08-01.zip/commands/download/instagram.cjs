const axios = require("axios");

const handler = async (m, {
    conn,
    args,
    usedPrefix,
    command
}) => {
    if (!args[0]) {
        return conn.sendMessage(
            m.chat, {
                text: `Masukkan URL Instagram!\n\nContoh:\n${usedPrefix}${command} https://www.instagram.com/p/xxxxxx/`
            }, {
                quoted: m
            }
        );
    }

    const url = args[0];

    if (!/https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)\//i.test(url)) {
        return conn.sendMessage(
            m.chat, {
                text: "❌ URL Instagram tidak valid."
            }, {
                quoted: m
            }
        );
    }

    if (!global.neoxr) {
        return conn.sendMessage(
            m.chat, {
                text: "❌ API key Neoxr belum diisi."
            }, {
                quoted: m
            }
        );
    }

    await conn.sendMessage(
        m.chat, {
            text: "⏳ Mengambil media Instagram..."
        }, {
            quoted: m
        }
    );

    try {
        // ===== API NEOXR =====
        const api = `https://api.neoxr.eu/api/ig?url=${encodeURIComponent(
            url
        )}&apikey=${global.neoxr}`;

        const {
            data
        } = await axios.get(api, {
            timeout: 30000
        });

        if (!data.status || !data.data || !data.data.length) {
            throw "Gagal mengambil media Instagram.";
        }

        // ===== KIRIM MEDIA =====
        for (let i = 0; i < data.data.length; i++) {
            const media = data.data[i];

            if (media.type === "mp4") {
                await conn.sendMessage(
                    m.chat, {
                        video: {
                            url: media.url
                        }
                    }, {
                        quoted: m
                    }
                );
            } else {
                await conn.sendMessage(
                    m.chat, {
                        image: {
                            url: media.url
                        }
                    }, {
                        quoted: m
                    }
                );
            }
        }
    } catch (e) {
        console.error(e);
        conn.sendMessage(
            m.chat, {
                text: "❌ Terjadi kesalahan saat mengambil media Instagram."
            }, {
                quoted: m
            }
        );
    }
};

handler.command = ["ig", "igdl", "instagram"];
handler.help = ["ig <url>"];
handler.tags = ["downloader"];
handler.description = "Download media Instagram (image & video) via Neoxr API";

module.exports = handler;