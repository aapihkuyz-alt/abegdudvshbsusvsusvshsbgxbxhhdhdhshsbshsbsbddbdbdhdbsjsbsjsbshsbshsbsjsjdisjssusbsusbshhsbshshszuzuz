import axios from 'axios';

async function getNpmPackageInfo(packageName) {
    const encodedName = packageName.trim()
        .replace(/^\/+|\/+$/g, '') // Hapus slash di awal/akhir
        .split('/')
        .map(v => encodeURIComponent(v))
        .join('%2f')
        .replace(/^%40/, '@'); // NPM Registry butuh @ literal di awal untuk scoped package

    const { data } = await axios.get(
        `https://registry.npmjs.com/${encodedName}`,
        { 
            timeout: 15000,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            }
        }
    );

    if (!data?.versions) {
        throw new Error('Package tidak ditemukan di NPM');
    }

    const version =
        data['dist-tags']?.latest || Object.keys(data.versions).pop();
    const v = data.versions[version];

    return {
        name: data.name,
        version,
        description: data.description || 'Tidak ada deskripsi',
        license: v.license || 'Unknown',
        author: data.author?.name || v.author?.name || 'Unknown',
        homepage: data.homepage || `https://www.npmjs.com/package/${data.name}`,
        repository: data.repository?.url || 'Tidak ada repository',
        size: v.dist.unpackedSize || v.dist.size || 0,
        tarball: v.dist.tarball,
        deps: Object.keys(v.dependencies || {}).length,
        devDeps: Object.keys(v.devDependencies || {}).length
    };
}

async function download(url) {
    const { data } = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 30000,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        }
    });
    return Buffer.from(data);
}

let handler = async (m, { conn, text, usedPrefix, command }) => {

    // ✅ VALIDASI USER (BUKAN ERROR)
    if (!text) {
        return conn.reply(
            m.chat,
            `⚠️ Masukkan nama package NPM\n\nContoh:\n${usedPrefix + command} axios`,
            m
        );
    }

    const loading = await conn.reply(
        m.chat,
        '🔎 Mencari package di NPM Registry...',
        m
    );

    try {
        let pkgName = text.trim();
        const urlMatch = pkgName.match(/npmjs\.com\/package\/([^\?#\s]+)/i);
        if (urlMatch) pkgName = urlMatch[1];

        const pkg = await getNpmPackageInfo(pkgName);

        const sizeMB = pkg.size
            ? (pkg.size / 1024 / 1024).toFixed(2) + ' MB'
            : 'N/A';

        const info = `📦 *NPM Package Info*

∘ *Name:* ${pkg.name}
∘ *Version:* ${pkg.version}
∘ *License:* ${pkg.license}
∘ *Author:* ${pkg.author}
∘ *Size:* ${sizeMB}
∘ *Dependencies:* ${pkg.deps}
∘ *Dev Dependencies:* ${pkg.devDeps}

∘ *Homepage:* ${pkg.homepage}
∘ *Repository:* ${pkg.repository}

⏳ Mendownload package...`;

        // ✅ KIRIM INFO (BUKAN EDIT)
        await conn.reply(m.chat, info, m);

        // hapus pesan loading
        await conn.sendMessage(m.chat, { delete: loading.key }).catch(() => {});

        const buffer = await download(pkg.tarball);

        await conn.sendMessage(
            m.chat,
            {
                document: buffer,
                mimetype: 'application/gzip',
                fileName: `${pkg.name}-${pkg.version}.tgz`
            },
            { quoted: m }
        );

    } catch (err) {
        await conn.sendMessage(m.chat, { delete: loading.key }).catch(() => {});
        throw err; // ⬅️ ERROR BENERAN BARU DILEMPAR
    }
};

handler.command = ['npm', 'npmjs', 'npmdl'];
handler.tags = ['downloader'];
handler.help = ['npm <package>'];
handler.limit = true;

export default handler;