import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Pinterest.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "📌", m.key)

        const api = `https://api.neoxr.eu/api/pin?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 30000,
            headers: {
                "User-Agent": "Mozilla/5.0"
            }
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil media dari Pinterest.")

        const res = data.data
        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 📌 PINTEREST DOWNLOADER 〕━━━⬣
┃ 🗂 Format   : ${res.type?.toUpperCase() || "-"}
┃ 📦 Size     : ${res.size || "-"}
┃ 🕒 Waktu    : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Media berhasil diambil
🚀 Powered by ${global.botname}
`.trim()

        if (res.type === "mp4") {

            await conn.sendMessage(m.chat, {
                video: {
                    url: res.url
                },
                mimetype: "video/mp4",
                caption: caption
            }, {
                quoted: m
            })

        } else {

            await conn.sendMessage(m.chat, {
                image: {
                    url: res.url
                },
                caption: caption
            }, {
                quoted: m
            })

        }

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {

        console.log("PINDL ERROR:", err.response?.data || err.message)

        await conn.sendReact(m.chat, "❌", m.key)

        if (err.code === "ECONNABORTED")
            return m.reply("❌ Server terlalu lama merespon.")

        m.reply("❌ Terjadi error saat memproses Pinterest.")
    }
}

handler.command = ["pindl", "pinterestdownload"]
handler.tags = ["downloader"]
handler.help = ["pindl <link pinterest>"]

export default handler