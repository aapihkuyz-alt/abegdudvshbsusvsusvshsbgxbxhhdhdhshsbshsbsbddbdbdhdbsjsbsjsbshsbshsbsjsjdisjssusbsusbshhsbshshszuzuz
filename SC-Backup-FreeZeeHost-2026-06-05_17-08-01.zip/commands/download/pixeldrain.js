import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Pixeldrain.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "💾", m.key)

        const api = `https://api.neoxr.eu/api/pixeldrain?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 20000
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil data Pixeldrain.")

        const res = data.data
        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 💾 PIXELDRAIN DOWNLOADER 〕━━━⬣
┃ 📄 Nama     : ${res.filename}
┃ 📂 Type     : ${res.type}
┃ 📦 Size     : ${res.size}
┃ 👁 Views    : ${res.views}
┃ ⬇ Downloads : ${res.downloads}
┃ 📅 Upload   : ${new Date(res.upload_at).toLocaleDateString()}
┃ 🕒 Last DL  : ${new Date(res.last_download).toLocaleDateString()}
╰━━━━━━━━━━━━━━━━━━━━⬣

🚀 Powered by ${global.botname}
`.trim()

        const sizeMB = parseFloat(res.size)

        // Kalau <= 100MB kirim playable
        if (sizeMB <= 100 && res.type === "mp4") {
            await conn.sendMessage(m.chat, {
                video: {
                    url: res.url
                },
                mimetype: "video/mp4",
                caption: caption
            }, {
                quoted: m
            })
        }
        // Kalau besar kirim dokumen biar gak crash
        else {
            await conn.sendMessage(m.chat, {
                document: {
                    url: res.url
                },
                fileName: res.filename,
                mimetype: "video/mp4",
                caption: caption
            }, {
                quoted: m
            })
        }

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("PIXELDRAIN ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Pixeldrain.")
    }
}

handler.command = ["pixeldl", "pixeldrain"]
handler.tags = ["downloader"]
handler.help = ["pixeldl <link pixeldrain>"]

export default handler