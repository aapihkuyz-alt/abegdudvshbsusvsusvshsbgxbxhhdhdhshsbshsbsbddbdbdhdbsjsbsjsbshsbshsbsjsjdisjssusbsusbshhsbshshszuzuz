import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Pixiv.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const api = `https://api.neoxr.eu/api/pixiv?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 20000
        })

        if (!data?.status || !data?.data?.images?.length)
            return m.reply("❌ Gagal mengambil data Pixiv.")

        const res = data.data

        const tags = res.tags.tags
            .map(t => t.translation?.en || t.tag)
            .slice(0, 6)
            .join(", ")

        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🎨 PIXIV DOWNLOADER 〕━━━⬣
┃ 🆔 ID        : ${res.id}
┃ 🖼 Title     : ${res.title}
┃ 👤 Author    : ${res.author.name}
┃ 🏷 Tags      : ${tags}
┃ 📚 Total     : ${res.images.length} Image
┃ 📅 Download  : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ High quality image
🚀 Powered by ${global.botname}
`.trim()

        let media = []

        for (let i = 0; i < res.images.length; i++) {

            const img = await axios.get(res.images[i], {
                responseType: "arraybuffer",
                timeout: 25000,
                headers: {
                    "User-Agent": "Mozilla/5.0",
                    "Referer": "https://www.pixiv.net/"
                },
                validateStatus: s => s < 500
            })

            const type = img.headers["content-type"] || ""

            if (!type.includes("image"))
                throw new Error("Invalid image response (HTML detected)")

            media.push({
                image: Buffer.from(img.data),
                caption: i === 0 ? caption : undefined
            })
        }

        // Kirim album
        await conn.sendAlbumMessage(
            m.chat,
            media, {
                quoted: m
            }
        )

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("PIXIV ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Pixiv.")
    }
}

handler.command = ["pixiv"]
handler.tags = ["downloader"]
handler.help = ["pixiv <link pixiv>"]

export default handler