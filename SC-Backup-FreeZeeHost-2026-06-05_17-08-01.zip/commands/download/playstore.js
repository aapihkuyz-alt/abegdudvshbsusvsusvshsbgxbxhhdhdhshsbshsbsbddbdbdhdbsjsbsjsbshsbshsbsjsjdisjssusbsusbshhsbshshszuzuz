
let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text)
        return m.reply(
            `📲 *Play Store Downloader*\n\nContoh:\n${usedPrefix + command} https://play.google.com/store/apps/details?id=com.ss.android.ugc.trill`
        )

    if (!/play\.google\.com\/store\/apps\/details\?id=/i.test(text))
        return m.reply("❌ Itu bukan link Play Store yang valid.")

    await m.react("⏳")

    try {
        const apiUrl =
            `https://api.neoxr.eu/api/playstore?url=${encodeURIComponent(text)}` +
            `&apikey=${global.neoxr}`

        const res = await fetch(apiUrl)
        const json = await res.json()

        if (!json?.status || !json?.data || !json?.files?.length) {
            await m.react("❌")
            return m.reply("⚠️ Aplikasi nggak ketemu atau API lagi ngambek.")
        }

        const {
            icon,
            name,
            version,
            publish
        } = json.data

        const apk = json.files[0]

        const caption = `
📦 *PLAY STORE APP*

📛 Nama     : ${name}
🔖 Versi    : ${version}
📅 Update   : ${publish}
📦 Size     : ${apk.size}

⚡ APK siap dikirim
`.trim()

        // kirim info + icon
        await conn.sendMessage(
            m.chat, {
                image: {
                    url: icon
                },
                caption
            }, {
                quoted: m
            }
        )

        // kirim APK
        await conn.sendMessage(
            m.chat, {
                document: {
                    url: apk.url
                },
                fileName: `${name}.apk`,
                mimetype: "application/vnd.android.package-archive"
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (e) {
        console.error("PLAYSTORE ERROR:", e)
        await m.react("❌")
        m.reply("⚠️ Gagal ambil APK. Coba lagi nanti.")
    }
}

handler.command = ["playstore", "ps"]
handler.tags = ["downloader"]
handler.help = ["playstore <link>"]
handler.limit = true

export default handler