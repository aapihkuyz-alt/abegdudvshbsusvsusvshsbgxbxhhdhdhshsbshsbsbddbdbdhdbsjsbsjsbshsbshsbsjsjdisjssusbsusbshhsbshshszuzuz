import fs from "fs"
import path from "path"
import {
    pipeline
} from "stream/promises"
import {
    fileURLToPath
} from "url"

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const tmpDir = path.resolve(__dirname, "../../data/sampah/tmp")
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, {
    recursive: true
})

const handler = async (m, {
    conn,
    text,
    usedPrefix
}) => {
    if (!text || !/^https?:\/\//i.test(text))
        return m.reply(
            `⚠️ *Format salah!*\n\nContoh:\n${usedPrefix}sfileget https://sfile.co/xxxx`
        )

    try {
        // ⏳ react loading
        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        const api = `https://api.neoxr.eu/api/sfile?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const res = await fetch(api)
        const json = await res.json()

        if (!json.status || !json.data?.url) {
            await conn.sendMessage(m.chat, {
                react: {
                    text: "❌",
                    key: m.key
                }
            })
            return m.reply("❌ Gagal mengambil file dari SFile")
        }

        const file = json.data

        const info = `
╭━━━〔 📥 *SFILE DOWNLOADER* 〕━━━╮
┃
┃ 📄 Nama :
┃ ➜ ${file.filename}
┃
┃ 📦 Ukuran :
┃ ➜ ${file.size}
┃
┃ 🧑‍💻 Uploader :
┃ ➜ ${file.author}
┃
┃ 📊 Download :
┃ ➜ ${file.downloads}x
┃
┃ 📆 Upload :
┃ ➜ ${file.upload_at}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯
⏳ Mengunduh file...
⚡ Powered by ${global.ownername}
`.trim()

        await m.reply(info)

        const filePath = path.join(tmpDir, file.filename)
        const dl = await fetch(file.url)
        if (!dl.ok) throw new Error("Gagal download file")

        await pipeline(dl.body, fs.createWriteStream(filePath))

        await conn.sendMessage(
            m.chat, {
                document: fs.readFileSync(filePath),
                fileName: file.filename,
                mimetype: file.mime || "application/octet-stream",
                caption: `
✅ *DOWNLOAD SELESAI*

📄 ${file.filename}
📦 ${file.size}

🤖 ${global.ownername}
`.trim()
            }, {
                quoted: m
            }
        )

        fs.unlinkSync(filePath)

        // ✅ react sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {
        console.error("[SFILE GET ERROR]", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Terjadi kesalahan saat mengunduh file")
    }
}

handler.command = ["sfileget"]
handler.tags = ["downloader"]
handler.help = ["sfileget <url>"]

export default handler
