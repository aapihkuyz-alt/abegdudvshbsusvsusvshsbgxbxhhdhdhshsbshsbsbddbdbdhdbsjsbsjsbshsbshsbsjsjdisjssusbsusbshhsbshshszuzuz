import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link SlideShare.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "📊", m.key)

        const api = `https://api.neoxr.eu/api/slideshare?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        // Timeout lebih panjang karena API lambat
        const {
            data
        } = await axios.get(api, {
            timeout: 60000
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil file SlideShare.")

        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 📊 SLIDESHARE DOWNLOADER 〕━━━⬣
┃ 🔗 Source   : SlideShare
┃ 📅 Download : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ File berhasil diambil
🚀 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(m.chat, {
            document: {
                url: data.data.url
            },
            mimetype: "application/pdf",
            fileName: `slideshare_${Date.now()}.pdf`,
            caption: caption
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("SLIDESHARE ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Server sedang lambat atau file tidak tersedia.")
    }
}

handler.command = ["slideshare", "ssdl"]
handler.tags = ["downloader"]
handler.help = ["slideshare <link slideshare>"]

export default handler