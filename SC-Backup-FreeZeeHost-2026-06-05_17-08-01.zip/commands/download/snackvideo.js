import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link SnackVideo.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🍿", m.key)

        const api = `https://api.neoxr.eu/api/snackvid?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const {
            data
        } = await axios.get(api, {
            timeout: 60000
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil video SnackVideo.")

        const res = data.data
        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🍿 SNACKVIDEO DOWNLOADER 〕━━━⬣
┃ 👤 Author     : ${res.author || "-"}
┃ 💬 Comments   : ${res.comments || 0}
┃ 📅 Posted     : ${res.posted_at ? moment(res.posted_at).tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm") : "-"}
┃ 🕒 Download   : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

📝 Caption:
${res.caption || "-"}

🎵 Audio:
${res.audio?.name || "-"} — ${res.audio?.author || "-"}

✨ No watermark
🚀 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(m.chat, {
            video: {
                url: res.url
            },
            mimetype: "video/mp4",
            caption: caption
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("SNACKVID ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses SnackVideo.")
    }
}

handler.command = ["snackvid", "snackdl"]
handler.tags = ["downloader"]
handler.help = ["snackvid <link snackvideo>"]

export default handler