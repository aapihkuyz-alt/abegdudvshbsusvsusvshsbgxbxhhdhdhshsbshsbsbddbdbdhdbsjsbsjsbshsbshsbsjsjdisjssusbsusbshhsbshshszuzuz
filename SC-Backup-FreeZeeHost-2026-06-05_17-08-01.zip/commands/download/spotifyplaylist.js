import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link playlist Spotify.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎧", m.key)

        const api = `https://api.neoxr.eu/api/spotify?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const {
            data
        } = await axios.get(api, {
            timeout: 60000
        })

        if (!data?.status || !data?.tracks)
            return m.reply("❌ Gagal mengambil playlist.")

        const playlist = data.data
        const tracks = data.tracks

        const now = moment().tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const rows = tracks.map((t, i) => ({
            title: `${i + 1}. ${t.title}`,
            description: `${t.artists} • ${t.duration}`,
            id: `.spdl ${t.url}`
        }))

        const caption = `
╭━━━〔 🎧 SPOTIFY PLAYLIST 〕━━━⬣
┃ 📀 Title      : ${playlist.title}
┃ 🎵 Total Lagu : ${tracks.length}
┃ 📅 Checked    : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

Pilih lagu untuk download 🎶
Powered by ${global.botname}
`.trim()

        const native_flow = [{
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: "🎵 LIST LAGU",
                sections: [{
                    title: `Semua Track (${tracks.length})`,
                    rows
                }]
            })
        }]

        await conn.sendMessage(m.chat, {
            image: {
                url: playlist.cover
            },
            caption,
            footer: "Spotify Downloader",
            viewOnce: true,
            interactive: native_flow
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("SPOTIFY PLAYLIST ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses playlist.")
    }
}

handler.command = ["spotifyplaylist", "sppl"]
handler.tags = ["downloader"]
handler.help = ["spotifyplaylist <link playlist>"]

export default handler