
let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text)
        return m.reply(
            `📦 *Terabox Downloader*\n\nContoh:\n${usedPrefix + command} https://terabox.com/s/xxxx`
        )

    if (!/terabox\.com/i.test(text))
        return m.reply("❌ Itu bukan link Terabox bre.")

    await m.react("⏳")

    try {
        const apiUrl =
            `https://api.neoxr.eu/api/terabox?url=${encodeURIComponent(text)}` +
            `&apikey=${global.neoxr}`

        const res = await fetch(apiUrl)
        const json = await res.json()

        if (!json?.status || !json?.data?.url) {
            await m.react("❌")
            return m.reply("⚠️ Gagal ambil data Terabox. Link mati / limit API.")
        }

        const fileUrl = json.data.url
        const url = new URL(fileUrl)

        const fileName =
            url.searchParams.get("fin") ||
            json.data.filename ||
            "terabox-file"

        const fileSize =
            url.searchParams.get("size") ?
            formatBytes(Number(url.searchParams.get("size"))) :
            "Unknown"

        const ext =
            (url.searchParams.get("sta_ft") || "")
            .toLowerCase()

        let mimetype = "application/octet-stream"
        if (ext.includes("mp4")) mimetype = "video/mp4"
        else if (ext.includes("mp3")) mimetype = "audio/mpeg"
        else if (ext.includes("zip")) mimetype = "application/zip"
        else if (ext.includes("pdf")) mimetype = "application/pdf"

        const caption = `
📥 *TERABOX DOWNLOAD*

📄 Nama : ${fileName}
📦 Size : ${fileSize}
📁 Type : ${ext || "unknown"}

⚡ File siap dikirim...
`.trim()

        await conn.sendMessage(
            m.chat, {
                document: {
                    url: fileUrl
                },
                fileName,
                mimetype,
                caption
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (e) {
        console.error("TERABOX ERROR:", e)
        await m.react("❌")
        m.reply("⚠️ Terjadi error pas ambil file Terabox.")
    }
}

handler.command = ["terabox", "tb"]
handler.tags = ["downloader"]
handler.help = ["terabox <link>"]
handler.limit = true

export default handler

function formatBytes(bytes) {
    if (!bytes || isNaN(bytes)) return "0 B"
    const units = ["B", "KB", "MB", "GB", "TB"]
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return `${(bytes / 1024 ** i).toFixed(2)} ${units[i]}`
}