import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Threads.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🧵", m.key)

        const api = `https://api.neoxr.eu/api/threads?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 30000
        })

        if (!data?.status || !Array.isArray(data.data) || !data.data.length)
            return m.reply("❌ Gagal mengambil data Threads.")

        const res = data.data
        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🧵 THREADS DOWNLOADER 〕━━━⬣
┃ 📦 Total Media : ${res.length}
┃ 📅 Download     : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Media berhasil diambil
🚀 Powered by ${global.botname}
`.trim()

        let media = []

        for (let i = 0; i < res.length; i++) {

            const file = await axios.get(res[i].url, {
                responseType: "arraybuffer",
                timeout: 30000,
                headers: {
                    "User-Agent": "Mozilla/5.0",
                    "Referer": "https://www.threads.net/"
                },
                validateStatus: s => s < 500
            })

            const type = file.headers["content-type"] || ""

            if (type.includes("image")) {
                media.push({
                    image: Buffer.from(file.data),
                    caption: i === 0 ? caption : undefined
                })
            } else if (type.includes("video")) {
                media.push({
                    video: Buffer.from(file.data),
                    mimetype: "video/mp4",
                    caption: i === 0 ? caption : undefined
                })
            } else {
                throw new Error("Invalid media type dari Threads")
            }
        }

        await conn.sendAlbumMessage(
            m.chat,
            media, {
                quoted: m
            }
        )

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {

        console.log("THREADS ERROR REAL:", err.response?.data || err.message)

        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Threads.")
    }
}

handler.command = ["threadsdl", "threads"]
handler.tags = ["downloader"]
handler.help = ["threads <link threads>"]

export default handler