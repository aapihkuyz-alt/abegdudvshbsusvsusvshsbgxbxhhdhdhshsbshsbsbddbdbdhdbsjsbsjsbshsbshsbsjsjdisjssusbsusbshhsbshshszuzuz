import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link TikTok.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "⏳", m.key)

        const api = `https://api.neoxr.eu/api/tiktok?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const {
            data
        } = await axios.get(api, {
            timeout: 15000
        })

        if (!data?.status)
            return m.reply("❌ Gagal mengambil data dari API.")

        const res = data.data
        const now = moment().tz("Asia/Jakarta").format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🎬 TIKTOK DOWNLOADER 〕━━━⬣
┃ 👤 Creator    : ${res.author.nickname}
┃ 🆔 Username   : @${res.author.uniqueId}
┃ 📝 Caption    : 
┃ ${res.caption || "-"}
┃
┃ 📊 Statistik
┃ ❤️ Likes      : ${res.statistic.likes.toLocaleString()}
┃ 💬 Comments   : ${res.statistic.comments.toLocaleString()}
┃ 🔁 Shares     : ${res.statistic.shares.toLocaleString()}
┃ 👁 Views      : ${res.statistic.views.toLocaleString()}
┃
┃ 🎵 Music      : ${res.music.title}
┃ ⏱ Duration    : ${res.music.duration}s
┃ 📅 Downloaded  : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Video tanpa watermark
🔊 Audio playable tersedia di bawah
`.trim()

        // ========= VIDEO =========
        await conn.sendMessage(m.chat, {
            video: {
                url: res.video
            },
            mimetype: "video/mp4",
            caption: caption
        }, {
            quoted: m
        })

        // ========= AUDIO =========
        await conn.sendMessage(m.chat, {
            audio: {
                url: res.video
            },
            mimetype: "audio/mpeg",
            ptt: false
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("TIKTOK ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Gagal memproses TikTok.")
    }
}

handler.command = ["tiktok", "tt"]
handler.tags = ["downloader"]
handler.help = ["tiktok <link>"]

export default handler