import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Videy.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎥", m.key)

        const api = `https://api.neoxr.eu/api/videy?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 20000,
            validateStatus: s => s < 500
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil video dari Videy.")

        const now = moment()
            .tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🎥 VIDEY DOWNLOADER 〕━━━⬣
┃ 🔗 Source     : Videy
┃ 📅 Download   : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Video berhasil diambil
🚀 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(m.chat, {
            video: {
                url: data.data.url
            },
            mimetype: "video/mp4",
            caption
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {

        console.log("VIDEY ERROR:", err.response?.data || err.message)

        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Videy.")
    }
}

handler.command = ["videydl"]
handler.tags = ["downloader"]
handler.help = ["videy <link videy>"]

export default handler