import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan link Xiaohongshu.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "📕", m.key)

        const api = `https://api.neoxr.eu/api/xiaohongshu?url=${encodeURIComponent(text)}&apikey=${global.neoxr}`

        const {
            data
        } = await axios.get(api, {
            timeout: 20000,
            validateStatus: s => s < 500
        })

        if (!data?.status || !data?.data?.length)
            return m.reply("❌ Gagal mengambil media dari Xiaohongshu.")

        const mediaData = data.data

        const now = moment()
            .tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 📕 XIAOHONGSHU DOWNLOADER 〕━━━⬣
┃ 📦 Total Media : ${mediaData.length}
┃ 📅 Download    : ${now}
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Media berhasil diambil
🚀 Powered by ${global.botname}
`.trim()

        let media = []

        for (let i = 0; i < mediaData.length; i++) {

            const item = mediaData[i]

            if (item.type === "mp4") {
                media.push({
                    video: {
                        url: item.url
                    },
                    mimetype: "video/mp4",
                    caption: i === 0 ? caption : undefined
                })
            } else {
                media.push({
                    image: {
                        url: item.url
                    },
                    caption: i === 0 ? caption : undefined
                })
            }
        }

        // Kalau cuma 1 media → kirim normal
        if (media.length === 1) {
            await conn.sendMessage(m.chat, media[0], {
                quoted: m
            })
        }
        // Kalau lebih dari 1 → kirim album
        else {
            await conn.sendAlbumMessage(
                m.chat,
                media, {
                    quoted: m
                }
            )
        }

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {

        console.log("XIAOHONGSHU ERROR:", err.response?.data || err.message)

        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses Xiaohongshu.")
    }
}

handler.command = ["xiaohongshudl", "xhdl"]
handler.tags = ["downloader"]
handler.help = ["xiaohongshu <link>"]

export default handler