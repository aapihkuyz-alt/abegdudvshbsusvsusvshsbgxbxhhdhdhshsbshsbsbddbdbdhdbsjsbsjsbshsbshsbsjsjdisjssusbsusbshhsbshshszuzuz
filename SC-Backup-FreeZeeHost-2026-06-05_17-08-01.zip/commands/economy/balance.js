let handler = async (m, { db }) => {
    let user = db.get("user", m.sender);
    if (!user) return m.reply("❌ Data user tidak ditemukan.");

    let report = `👛 *[ USER BALANCE ]* 👛\n\n` +
                 `👤 *User:* @${m.sender.split("@")[0]}\n` +
                 `💰 *Saldo:* Rp${(user.saldo || 0).toLocaleString()}\n` +
                 `📈 *Level:* ${user.level || 1}\n` +
                 `✨ *XP:* ${user.xp || 0}\n` +
                 `🎫 *Limit:* ${user.limit || 0}\n\n` +
                 `_Ayo kerja buat dapet saldo lebih banyak!_`;

    await conn.sendMessage(m.chat, { 
        text: report, 
        contextInfo: { mentionedJid: [m.sender] } 
    }, { quoted: m });
};

handler.help = ["balance", "saldo", "me"];
handler.tags = ["economy"];
handler.command = /^(balance|saldo|me)$/i;

export default handler;