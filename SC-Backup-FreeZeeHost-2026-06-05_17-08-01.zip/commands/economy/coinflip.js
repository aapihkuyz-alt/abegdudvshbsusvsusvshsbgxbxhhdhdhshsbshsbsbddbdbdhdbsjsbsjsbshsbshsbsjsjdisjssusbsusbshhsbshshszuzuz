let handler = async (m, { db, text, usedPrefix, command }) => {
    let user = db.get("user", m.sender);
    if (!user) return;

    let [amount, choice] = text.split(" ");
    if (!amount || !choice) return m.reply(`📌 Contoh: *${usedPrefix + command} 5000 heads* (atau tails)`);

    amount = parseInt(amount);
    choice = choice.toLowerCase().trim();

    if (isNaN(amount) || amount < 100) return m.reply("❌ Minimal taruhan Rp100.");
    if (user.saldo < amount) return m.reply("❌ Saldo tidak cukup.");
    if (choice !== "heads" && choice !== "tails") return m.reply("❌ Pilih antara 'heads' atau 'tails'.");

    await m.react("🪙");

    const result = Math.random() > 0.5 ? "heads" : "tails";
    const win = choice === result;

    let report = `╭─❍ *COIN FLIP* ❍─\n` +
                 `│\n` +
                 `│ 🪙 *Result:* ${result.toUpperCase()}\n` +
                 `│ 👤 *Your Bet:* ${choice.toUpperCase()}\n` +
                 `│\n` +
                 `├─────────────────────\n`;

    if (win) {
        user.saldo += amount;
        report += `│ 🎉 *MENANG!* \n│ Kamu dapet: *Rp${amount.toLocaleString()}*\n`;
        await m.react("💰");
    } else {
        user.saldo -= amount;
        report += `│ 💸 *KALAH* \n│ Kamu rugi: *Rp${amount.toLocaleString()}*\n`;
        await m.react("💀");
    }

    report += `│ 💰 *Saldo Sekarang:* Rp${user.saldo.toLocaleString()}\n╰─────────────────────❍`;

    await m.reply(report);
    await db.save();
};

handler.help = ["coinflip <amount> <heads/tails>"];
handler.tags = ["economy"];
handler.command = /^(coinflip|cf)$/i;

export default handler;