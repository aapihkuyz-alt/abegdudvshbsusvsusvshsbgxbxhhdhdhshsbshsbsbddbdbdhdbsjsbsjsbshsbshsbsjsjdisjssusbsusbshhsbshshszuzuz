let handler = async (m, { conn, db, Func }) => {
    let user = db.get("user", m.sender)
    const timeClaim = 24 * 60 * 60 * 1000 // 24 jam
    const now = Date.now()

    if (!user.lastClaim) user.lastClaim = 0

    if (now - user.lastClaim < timeClaim) {
        let remaining = timeClaim - (now - user.lastClaim)
        let time = Func.readTime(remaining)
        return m.reply(`🎁 *DAILY REWARD* 🎁\n\nKamu sudah mengambil hadiah hari ini.\nTunggu *${time.hours}j ${time.minutes}m ${time.seconds}d* lagi untuk mengambil kembali.`)
    }

    const rewardLimit = 25
    const rewardXP = 500
    const rewardSaldo = 5000

    user.limit += rewardLimit
    user.xp += rewardXP
    user.saldo += rewardSaldo
    user.lastClaim = now
    await db.save()

    let text = `
🎁 *DAILY REWARD CLAIMED* 🎁

Selamat! Kamu mendapatkan:
◦ *Limit:* +${rewardLimit}
◦ *XP:* +${rewardXP}
◦ *Saldo:* Rp ${Func.formatter(rewardSaldo)}

_Gunakan perintah *.my* untuk cek status terbaru._`.trim()

    m.reply(text)
}

handler.help = ["daily", "claim"]
handler.tags = ["xp"]
handler.command = ["daily", "claim"]
handler.register = true

export default handler
