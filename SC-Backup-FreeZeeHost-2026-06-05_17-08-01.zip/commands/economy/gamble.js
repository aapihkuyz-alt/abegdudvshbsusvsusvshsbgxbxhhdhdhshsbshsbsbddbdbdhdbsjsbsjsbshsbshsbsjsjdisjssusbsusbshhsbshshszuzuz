let handler = async (m, { db, text, usedPrefix }) => {
    let user = db.get("user", m.sender);
    if (!user) return;

    if (!text) return m.reply(`📌 Contoh: *${usedPrefix}gamble 5000*`);
    let amount = parseInt(text);
    if (isNaN(amount) || amount < 100) return m.reply("❌ Minimal taruhan adalah Rp100.");
    if (user.saldo < amount) return m.reply("❌ Saldo kamu tidak cukup.");

    await m.react("🎲");

    const botDice = Math.floor(Math.random() * 6) + 1;
    const userDice = Math.floor(Math.random() * 6) + 1;

    let report = `╭─❍ *DICE GAMBLE* ❍─\n` +
                 `│\n` +
                 `│ 🤖 *Bot Dice:* ${botDice}\n` +
                 `│ 👤 *Your Dice:* ${userDice}\n` +
                 `│\n` +
                 `├─────────────────────\n`;

    if (userDice > botDice) {
        user.saldo += amount;
        report += `│ 🎉 *MENANG!* \n│ Kamu dapet: *Rp${amount.toLocaleString()}*\n`;
        await m.react("💰");
    } else if (userDice < botDice) {
        user.saldo -= amount;
        report += `│ 💸 *KALAH* \n│ Kamu rugi: *Rp${amount.toLocaleString()}*\n`;
        await m.react("💀");
    } else {
        report += `│ 🤝 *SERI* \n│ Saldo kamu aman.\n`;
        await m.react("🧘");
    }

    report += `│ 💰 *Saldo Sekarang:* Rp${user.saldo.toLocaleString()}\n╰─────────────────────❍`;

    await m.reply(report);
    await db.save();
};

handler.help = ["gamble <amount>"];
handler.tags = ["economy"];
handler.command = /^(gamble|judi)$/i;

export default handler;