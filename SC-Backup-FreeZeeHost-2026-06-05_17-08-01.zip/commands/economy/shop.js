let handler = async (m, { conn, text, usedPrefix, command, db }) => {
    const user = db.get("user", m.sender);
    
    const items = {
        limit: { price: 500, stock: 1, name: "1 Limit" },
        premium: { price: 50000, stock: 3, name: "3 Hari Premium" }
    };

    if (!text) {
        let menu = `🛒 *[ FREEZEEHOST SHOP ]* 🛒\n\n` +
                   `💰 *Saldo Kamu:* Rp${(user.saldo || 0).toLocaleString()}\n` +
                   `─────────────────────\n`;
        
        Object.entries(items).forEach(([id, item]) => {
            menu += `🛍️ *${item.name}*\n│ 💸 Harga: Rp${item.price.toLocaleString()}\n│ 📌 Ketik: *${usedPrefix + command} buy ${id}*\n╰───────────────────\n`;
        });
        
        return m.reply(menu);
    }

    const [action, itemKey] = text.split(" ").map(v => v.toLowerCase().trim());

    if (action === "buy") {
        if (!items[itemKey]) return m.reply("❌ Barang tidak tersedia di toko.");
        const item = items[itemKey];

        if ((user.saldo || 0) < item.price) return m.reply(`❌ Saldo kamu tidak cukup. Butuh Rp${item.price.toLocaleString()} lagi.`);

        user.saldo -= item.price;

        if (itemKey === "limit") {
            user.limit = (user.limit || 0) + 1;
            await m.reply(`✅ Berhasil membeli *${item.name}*! \nSisa saldo: Rp${user.saldo.toLocaleString()}`);
        } 
        
        else if (itemKey === "premium") {
            if (!user.premium) user.premium = { status: false, expired: 0 };
            const now = Date.now();
            const currentExpired = user.premium.expired > now ? user.premium.expired : now;
            
            user.premium.status = true;
            user.premium.expired = currentExpired + (3 * 24 * 60 * 60 * 1000);
            await m.reply(`🎉 *PEMBELIAN BERHASIL!* \nKamu sekarang Premium selama 3 hari. \nExpired: ${new Date(user.premium.expired).toLocaleString()}`);
        }

        await db.save();
    }
};

handler.help = ["shop", "buy"];
handler.tags = ["economy"];
handler.command = /^(shop|toko|buy|beli)$/i;

export default handler;