
let handler = async (m, { conn, text, usedPrefix, db }) => {
    let user = db.get("user", m.sender);
    if (!user) return;

    if (!text) return m.reply(`📌 Contoh: *${usedPrefix}slot 5000*`);
    let amount = parseInt(text);
    if (isNaN(amount) || amount < 100) return m.reply("❌ Minimal taruhan adalah Rp100.");
    if (user.saldo < amount) return m.reply("❌ Saldo kamu tidak cukup untuk taruhan ini.");

    const emojis = ["🍎", "🍐", "🍇", "🍒", "💎", "🎰"];
    
    // Kurangi saldo dulu (Anti-Cheat)
    user.saldo -= amount;
    await db.save();

    const { key } = await m.reply(`🎰 *SLOT MACHINE* 🎰\n\n[ 🎰 | 🎰 | 🎰 ]\n\n🔄 *Spinning...* `);

    // --- ANIMASI MUTAR (3 Tahap) ---
    for (let i = 0; i < 3; i++) {
        await new Promise(resolve => setTimeout(resolve, 800));
        const r1 = emojis[Math.floor(Math.random() * emojis.length)];
        const r2 = emojis[Math.floor(Math.random() * emojis.length)];
        const r3 = emojis[Math.floor(Math.random() * emojis.length)];
        await conn.sendMessage(m.chat, { text: `🎰 *SLOT MACHINE* 🎰\n\n[ ${r1} | ${r2} | ${r3} ]\n\n🔄 *Spinning... (${i + 1}/3)*`, edit: key });
    }

    // --- HASIL FINAL ---
    const a = emojis[Math.floor(Math.random() * emojis.length)];
    const b = emojis[Math.floor(Math.random() * emojis.length)];
    const c = emojis[Math.floor(Math.random() * emojis.length)];

    let win = false;
    let multiplier = 0;

    if (a === b && b === c) {
        win = true;
        multiplier = 10;
    } else if (a === b || b === c || a === c) {
        win = true;
        multiplier = 2;
    }

    let resultText = `🎰 *SLOT MACHINE* 🎰\n\n[ ${a} | ${b} | ${c} ]\n\n`;
    if (win) {
        const prize = amount * multiplier;
        user.saldo += prize;
        resultText += `🎉 *JACKPOT!* \n│ Kamu menang: *Rp${prize.toLocaleString()}*\n│ Multiplier: x${multiplier}\n`;
        await m.react("💰");
    } else {
        resultText += `💸 *KALAH* \n│ Kamu kehilangan: *Rp${amount.toLocaleString()}*\n│ Coba lagi lain kali!\n`;
        await m.react("💀");
    }

    resultText += `💰 *Sisa Saldo:* Rp${user.saldo.toLocaleString()}`;

    await conn.sendMessage(m.chat, { text: resultText, edit: key });
    await db.save();
};

handler.help = ["slot <amount>"];
handler.tags = ["economy"];
handler.command = /^(slot)$/i;

export default handler;
