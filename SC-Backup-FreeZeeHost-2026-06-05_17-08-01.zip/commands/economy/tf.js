let handler = async (m, { conn, text, db, usedPrefix, command }) => {
    let [amount, ...target] = text.split(" ");
    let targetJid = m.quoted ? m.quoted.sender : (m.mentionedJid?.[0] || (target.join(" ").replace(/[^0-9]/g, "") + "@s.whatsapp.net"));

    if (!targetJid || !amount) return m.reply(`📌 Contoh: *${usedPrefix + command} 5000 @tag* atau reply pesan user.`);
    if (isNaN(amount) || parseInt(amount) <= 0) return m.reply("❌ Jumlah transfer harus berupa angka valid.");

    let user = db.get("user", m.sender);
    let targetUser = db.get("user", targetJid);

    if (!targetUser) return m.reply("❌ Target transfer tidak ditemukan di database.");
    if ((user.saldo || 0) < parseInt(amount)) return m.reply(`❌ Saldo kamu tidak cukup. Sisa saldo: Rp${(user.saldo || 0).toLocaleString()}`);

    // Proses Transfer
    user.saldo -= parseInt(amount);
    targetUser.saldo = (targetUser.saldo || 0) + parseInt(amount);
    
    await db.save();

    let report = `💸 *[ TRANSFER BERHASIL ]* 💸\n\n` +
                 `📤 *Dari:* @${m.sender.split("@")[0]}\n` +
                 `📥 *Ke:* @${targetJid.split("@")[0]}\n` +
                 `💰 *Jumlah:* Rp${parseInt(amount).toLocaleString()}\n\n` +
                 `_Sisa saldo kamu: Rp${user.saldo.toLocaleString()}_`;

    await conn.sendMessage(m.chat, { 
        text: report, 
        contextInfo: { mentionedJid: [m.sender, targetJid] } 
    }, { quoted: m });
};

handler.help = ["transfer", "tf"];
handler.tags = ["economy"];
handler.command = /^(transfer|tf)$/i;

export default handler;