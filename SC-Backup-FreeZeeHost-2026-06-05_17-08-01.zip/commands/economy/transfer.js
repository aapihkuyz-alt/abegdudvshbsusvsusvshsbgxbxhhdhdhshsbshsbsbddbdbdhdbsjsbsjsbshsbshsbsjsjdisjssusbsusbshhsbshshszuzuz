let handler = async (m, { conn, db, text, Func, usedPrefix, command }) => {
    let user = db.get("user", m.sender)
    
    // Validasi input: Format harus @user jumlah
    if (!text || !text.includes(' ')) return m.reply(`*Format salah!*\n\nContoh penggunaan:\n${usedPrefix}${command} @tag 5000\n${usedPrefix}${command} 628xxx 5000`)
    
    let target = m.mentions[0] ? m.mentions[0] : (text.split(' ')[0].replace(/[^0-9]/g, '') + '@s.whatsapp.net')
    let amountStr = text.split(' ')[1]
    
    if (m.quoted && !m.mentions[0]) {
        target = m.quoted.sender
        amountStr = text.split(' ')[0]
    }

    if (!target) return m.reply("❌ Tag target atau reply pesan orang yang mau ditransfer.")
    if (target === m.sender) return m.reply("❌ Tidak bisa transfer ke diri sendiri!")
    
    let amount = parseInt(amountStr.replace(/[^0-9]/g, ''))
    if (!amount || isNaN(amount) || amount <= 0) return m.reply("❌ Jumlah yang ditransfer harus berupa angka lebih dari 0.")
    
    // Cek user tujuan di DB
    let targetUser = db.get("user", target)
    if (!targetUser) return m.reply("❌ User tujuan belum terdaftar di database bot.")

    let isTransferLimit = command.includes("limit")
    
    if (isTransferLimit) {
        if (user.limit < amount) return m.reply(`❌ Limit kamu tidak cukup untuk transfer.\nLimit kamu: ${user.limit}`)
        user.limit -= amount
        targetUser.limit += amount
        await db.save()
        m.reply(`✅ Berhasil transfer *${amount}* Limit ke *@${target.split('@')[0]}*.\nSisa Limit kamu: ${user.limit}`, { mentions: [target] })
    } else {
        if (user.saldo < amount) return m.reply(`❌ Saldo kamu tidak cukup.\nSaldo kamu: Rp ${Func.formatter(user.saldo)}`)
        // Pajak transfer 2%
        let tax = Math.floor(amount * 0.02)
        let totalDeduct = amount + tax
        
        if (user.saldo < totalDeduct) return m.reply(`❌ Saldo tidak cukup untuk biaya admin (2% pajak).\nTotal butuh: Rp ${Func.formatter(totalDeduct)}`)
        
        user.saldo -= totalDeduct
        targetUser.saldo += amount
        await db.save()
        m.reply(`✅ Berhasil transfer *Rp ${Func.formatter(amount)}* ke *@${target.split('@')[0]}*.\nBiaya admin: Rp ${Func.formatter(tax)}\nSisa saldo: Rp ${Func.formatter(user.saldo)}`, { mentions: [target] })
    }
}

handler.help = ["transfer", "tflimit", "tfsaldo"]
handler.tags = ["xp"]
handler.command = ["transfer", "tflimit", "tfsaldo"]
handler.register = true
handler.group = true // Biasanya tf saldo/limit lebih aman di grup biar ga bisa exploit bot

export default handler