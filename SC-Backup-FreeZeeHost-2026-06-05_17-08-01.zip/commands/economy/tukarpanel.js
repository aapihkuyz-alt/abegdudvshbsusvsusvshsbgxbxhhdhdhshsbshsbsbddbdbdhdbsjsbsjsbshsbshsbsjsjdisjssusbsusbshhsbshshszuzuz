import {
    generateWAMessageFromContent,
    proto
} from "baileys"

/* ================= CONFIG PANEL PRICES ================= */
const PACKAGES = {
    "1gb": { ram: 1000, disk: 1000, cpu: 40, price: 5000 },
    "2gb": { ram: 2000, disk: 2000, cpu: 60, price: 10000 },
    "3gb": { ram: 3000, disk: 3000, cpu: 80, price: 15000 },
    "4gb": { ram: 4000, disk: 4000, cpu: 100, price: 20000 },
    "5gb": { ram: 5000, disk: 5000, cpu: 120, price: 25000 },
    "6gb": { ram: 6000, disk: 6000, cpu: 140, price: 30000 },
    "7gb": { ram: 7000, disk: 7000, cpu: 160, price: 35000 },
    "8gb": { ram: 8000, disk: 8000, cpu: 180, price: 40000 },
    "unli": { ram: 0, disk: 0, cpu: 0, price: 100000 }
}

let handler = async (m, {
    conn,
    command,
    text,
    db,
    usedPrefix
}) => {
    let user = db.get("user", m.sender);
    if (!user) return m.reply("❌ Data Anda tidak ditemukan.");

    const choice = text.trim().toLowerCase();

    /* ================= 1. MENU PEMBELIAN ================= */
    if (!choice || !PACKAGES[choice]) {
        let menu = `🛒 *PANEL MARKETPLACE* 🛒\n\n` +
                   `Saldo Anda: *Rp${(user.saldo || 0).toLocaleString()}*\n\n` +
                   `Silakan pilih paket panel di bawah ini:\n\n`;

        Object.keys(PACKAGES).forEach(pkg => {
            const p = PACKAGES[pkg];
            menu += `📦 *Paket ${pkg.toUpperCase()}*\n`;
            menu += ` ◦ RAM  : ${p.ram === 0 ? "Unli" : (p.ram/1000) + "GB"}\n`;
            menu += ` ◦ Harga: *Rp${p.price.toLocaleString()}*\n`;
            menu += ` ◦ Ketik: *${usedPrefix + command} ${pkg}*\n\n`;
        });

        menu += `_Pastikan saldo Anda cukup sebelum membeli._`;
        
        return m.reply(menu);
    }

    /* ================= 2. PROSES PEMBELIAN ================= */
    const pkg = PACKAGES[choice];
    const userSaldo = user.saldo || 0;

    if (userSaldo < pkg.price) {
        return m.reply(`❌ *SALDO TIDAK CUKUP!*\n\nHarga paket *${choice.toUpperCase()}* adalah Rp${pkg.price.toLocaleString()}, sedangkan saldo Anda hanya Rp${userSaldo.toLocaleString()}.`);
    }

    await m.react("⏳");
    m.reply(`⏳ Sedang memproses pembelian *Paket ${choice.toUpperCase()}*...`);

    // Potong Saldo
    user.saldo -= pkg.price;
    await db.save();

    // Data Panel
    let username = `user${m.sender.split('@')[0]}${Math.floor(Math.random() * 100)}`.toLowerCase();
    let email = username + "@host.id";
    let password = Math.random().toString(36).slice(-8);
    let serverName = `${username} Server`;

    try {
        // --- CREATE USER ---
        let createUser = await fetch(`${global.domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${global.apikey}`
            },
            body: JSON.stringify({
                email,
                username,
                first_name: username,
                last_name: "Host",
                language: "en",
                password
            })
        });

        let userData = await createUser.json();
        if (userData.errors) {
            // Refund saldo jika gagal
            user.saldo += pkg.price;
            await db.save();
            await m.react("❌");
            return m.reply(`❌ *GAGAL MEMBUAT USER:* ${userData.errors[0].detail}\n_Saldo telah dikembalikan._`);
        }

        let panelUser = userData.attributes;

        // --- GET STARTUP EGG ---
        let eggData = await fetch(`${global.domain}/api/application/nests/${global.nestid}/eggs/${global.egg}`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${global.apikey}`
            }
        });
        let eggJson = await eggData.json();
        let startup = eggJson.attributes.startup;

        // --- CREATE SERVER ---
        let createServer = await fetch(`${global.domain}/api/application/servers`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${global.apikey}`
            },
            body: JSON.stringify({
                name: serverName,
                description: `Purchased by @${m.sender.split('@')[0]} via ${global.botname}`,
                user: panelUser.id,
                egg: parseInt(global.egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
                startup,
                environment: { INST: "npm", USER_UPLOAD: "0", AUTO_UPDATE: "0", CMD_RUN: "npm start" },
                limits: { memory: pkg.ram, swap: 0, disk: pkg.disk, io: 500, cpu: pkg.cpu },
                feature_limits: { databases: 5, backups: 5, allocations: 5 },
                deploy: { locations: [parseInt(global.loc)], dedicated_ip: false, port_range: [] }
            })
        });

        let serverData = await createServer.json();
        if (serverData.errors) {
             // Refund saldo jika gagal
             user.saldo += pkg.price;
             await db.save();
             await m.react("❌");
             return m.reply(`❌ *GAGAL MEMBUAT SERVER:* ${serverData.errors[0].detail}\n_Saldo telah dikembalikan._`);
        }

        let server = serverData.attributes;

        // --- SUCCESS RESPONSE ---
        let report = `
✅ *PEMBELIAN BERHASIL!*

📦 Paket: *${choice.toUpperCase()}*
💰 Harga: Rp${pkg.price.toLocaleString()}
👤 Sisa Saldo: Rp${user.saldo.toLocaleString()}

────────────────────
👤 *LOGIN DETAILS:*
Username: \`${username}\`
Password: \`${password}\`
URL: ${global.domain}
────────────────────
_Data login telah dikirim ke chat pribadi Anda._`.trim();

        // Kirim ke PC (Target)
        const privateMsg = `
╭───〔 📦 YOUR PANEL ACCOUNT 〕───╮

👤 Username  : ${username}
🔐 Password  : ${password}
🌐 Login     : ${global.domain}

────────────────────
⚙️ Spesifikasi:
💾 RAM  : ${pkg.ram === 0 ? "Unli" : (pkg.ram/1000) + "GB"}
📀 Disk : ${pkg.disk === 0 ? "Unli" : (pkg.disk/1000) + "GB"}
⚡ CPU  : ${pkg.cpu === 0 ? "Unli" : pkg.cpu + "%"}
────────────────────
╰────────────────────╯`.trim();

        await conn.sendMessage(m.sender, { 
            text: privateMsg,
            contextInfo: {
                externalAdReply: {
                    title: "PANEL HOSTING SUCCESS",
                    body: "Enjoy your server!",
                    thumbnailUrl: global.thumb,
                    sourceUrl: global.website,
                    mediaType: 1
                }
            }
        });

        await m.reply(report);
        await m.react("✅");

    } catch (e) {
        console.error(e);
        // Refund saldo jika crash
        user.saldo += pkg.price;
        await db.save();
        m.reply("❌ Terjadi kesalahan sistem. Saldo Anda telah dikembalikan.");
    }
}

handler.help = ["tukarpanel <paket>"];
handler.tags = ["economy", "panel"];
handler.command = /^(tukarpanel|buypanel)$/i;

export default handler;