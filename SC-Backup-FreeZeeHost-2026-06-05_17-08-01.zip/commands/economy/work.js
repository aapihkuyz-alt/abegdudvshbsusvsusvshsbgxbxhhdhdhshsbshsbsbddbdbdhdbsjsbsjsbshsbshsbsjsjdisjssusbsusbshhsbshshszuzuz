let handler = async (m, { db, usedPrefix, command }) => {
    let user = db.get("user", m.sender);
    if (!user) return m.reply("❌ Data user tidak ditemukan.");

    const cooldown = 60 * 60 * 1000; // 1 Jam
    const lastWork = user.lastWork || 0;
    
    if (Date.now() - lastWork < cooldown) {
        const remaining = cooldown - (Date.now() - lastWork);
        const minutes = Math.floor(remaining / 60000);
        return m.reply(`🕒 Bang, baru aja kerja. Istirahat dulu ya! \nSisa waktu: *${minutes} menit* lagi.`);
    }

    const rewards = [
        { job: "Jadi Admin Slot", salary: 5000, xp: 50 },
        { job: "Narik Ojol", salary: 2000, xp: 20 },
        { job: "Jualan Panel", salary: 8000, xp: 80 },
        { job: "Kuli Panggul", salary: 3000, xp: 30 },
        { job: "Scraping API", salary: 10000, xp: 100 },
        { job: "Begal Member", salary: 15000, xp: 150 }
    ];

    const result = rewards[Math.floor(Math.random() * rewards.length)];
    
    user.saldo = (user.saldo || 0) + result.salary;
    user.xp = (user.xp || 0) + result.xp;
    user.lastWork = Date.now();
    await db.save();

    let report = `👷 *[ WORK REPORT ]* 👷\n\n` +
                 `Bang baru aja selesai kerja sebagai:\n` +
                 `💼 *Pekerjaan:* ${result.job}\n` +
                 `💰 *Gaji:* Rp${result.salary.toLocaleString()}\n` +
                 `✨ *Bonus XP:* +${result.xp}\n\n` +
                 `_Saldo sekarang: Rp${user.saldo.toLocaleString()}_`;

    await m.reply(report);
};

handler.help = ["work"];
handler.tags = ["economy"];
handler.command = /^(work|kerja)$/i;

export default handler;