let handler = async (m, { conn, text, usedPrefix, command, db }) => {
    const anonymous = db.list().anonymous || {};
    
    // Pastikan data anonymous ada
    if (!db.list().anonymous) db.list().anonymous = {};

    switch (command) {
        case 'anonymous':
        case 'cariteman':
        case 'start': {
            if (Object.values(anonymous).find(room => room.a === m.sender || room.b === m.sender)) {
                return m.reply("❌ Kamu masih berada dalam sesi chat! Ketik `.stop` untuk menyudahi.");
            }
            
            // Cari orang yang lagi nunggu
            const partnerJid = Object.keys(anonymous).find(jid => anonymous[jid].status === "waiting" && jid !== m.sender);

            if (partnerJid) {
                // Pasangkan!
                anonymous[partnerJid].status = "chatting";
                anonymous[partnerJid].b = m.sender;
                anonymous[m.sender] = {
                    status: "chatting",
                    a: m.sender,
                    b: partnerJid
                };
                
                await m.reply("✅ *Partner ditemukan!* \nSelamat mengobrol secara anonim. \n\n_Ketik .skip untuk cari baru atau .stop untuk berhenti._");
                await conn.sendMessage(partnerJid, { text: "✅ *Partner ditemukan!* \nSelamat mengobrol secara anonim." });
            } else {
                // Masuk antrean
                anonymous[m.sender] = {
                    status: "waiting",
                    a: m.sender,
                    b: null
                };
                await m.reply("⏳ *Mencari partner...* \nMohon tunggu sampai ada orang lain yang bergabung.");
            }
            break;
        }

        case 'stop': {
            const room = anonymous[m.sender];
            if (!room) return m.reply("❌ Kamu tidak sedang berada dalam sesi anonymous.");
            
            const partner = room.b || room.a === m.sender ? room.b : room.a;
            
            if (partner) {
                await conn.sendMessage(partner, { text: "🏁 *Partner telah menghentikan chat.* \nKetik .start untuk mencari baru." });
                delete anonymous[partner];
            }
            
            delete anonymous[m.sender];
            await m.reply("🏁 *Sesi anonymous dihentikan.*");
            break;
        }

        case 'skip': {
            const room = anonymous[m.sender];
            if (!room) return m.reply("❌ Kamu tidak sedang berada dalam sesi anonymous.");
            
            const partner = room.b;
            if (partner) {
                await conn.sendMessage(partner, { text: "🏁 *Partner telah me-skip chat ini.* \nKetik .start untuk mencari baru." });
                delete anonymous[partner];
            }
            
            delete anonymous[m.sender];
            // Otomatis start lagi
            return handler(m, { conn, text: 'start', usedPrefix, command: 'start', db });
        }
    }
    
    await db.save();
};

handler.onMessage = async (m, { conn, sock, db }) => {
  if (!sock) sock = conn;
    if (m.isGroup || m.fromMe || m.isBaileys) return;
    
    const anonymous = db.list().anonymous;
    if (!anonymous || !anonymous[m.sender] || anonymous[m.sender].status !== "chatting") return;
    
    const room = anonymous[m.sender];
    const partner = room.b;
    
    if (partner && m.text && !m.text.startsWith(".") && !m.text.startsWith("#")) {
        // Teruskan pesan ke partner
        await conn.sendMessage(partner, { 
            text: `💬 *Anonymous:* \n\n${m.text}` 
        });
    }
};

handler.help = ["anonymous", "start", "stop", "skip"];
handler.tags = ["fun"];
handler.command = /^(anonymous|cariteman|start|stop|skip)$/i;
handler.private = true;

export default handler;