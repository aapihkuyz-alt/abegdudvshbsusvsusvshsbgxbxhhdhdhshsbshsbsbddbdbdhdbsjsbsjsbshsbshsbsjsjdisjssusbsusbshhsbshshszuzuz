import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "💘",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/bucin", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        const teks =
            `💌 *KATA BUCIN HARI INI*

"${data.data.text}"

Kirim ke doi sebelum keduluan orang lain 😌`

        await conn.sendMessage(
            m.chat, {
                text: teks
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("BUCIN ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil kata bucin.")
    }
}

handler.help = ["bucin"]
handler.tags = ["fun"]
handler.command = ["bucin"]

export default handler