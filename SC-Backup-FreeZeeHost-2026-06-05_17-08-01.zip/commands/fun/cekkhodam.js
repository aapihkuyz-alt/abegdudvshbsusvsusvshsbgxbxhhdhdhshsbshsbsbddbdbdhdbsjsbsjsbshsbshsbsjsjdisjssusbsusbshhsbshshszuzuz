import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔮",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/khodam", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        const {
            name,
            meaning
        } = data.data

        const teks =
            `🔮 *CEK KHODAM*

🪬 Nama : ${name}
📖 Arti : ${meaning}

Jangan terlalu serius. Ini cuma hiburan.`

        await conn.sendMessage(
            m.chat, {
                text: teks
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("KHODAM ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil data khodam.")
    }
}

handler.help = ["khodam"]
handler.tags = ["fun"]
handler.command = ["khodam", "cekkodam", "cekkhodam"]

export default handler