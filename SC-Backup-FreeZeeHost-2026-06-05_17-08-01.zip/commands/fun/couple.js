import { proto, generateWAMessageFromContent } from "baileys";

let handler = async (m, { conn, participants, usedPrefix, command }) => {
    if (!m.isGroup) return m.reply("Khusus di dalam grup!")

    let member = participants.map(u => u.id)
    let pick = member[Math.floor(Math.random() * member.length)]
    let pick2 = member[Math.floor(Math.random() * member.length)]

    while (pick === pick2) {
        pick2 = member[Math.floor(Math.random() * member.length)]
    }

    let caption = `
💘 *GROUP SOULMATE* 💘

Kira-kira siapa ya pasangan yang paling cocok di grup ini?
Bot sudah menghitung probabilitasnya...

@${pick.split('@')[0]}  ❤️  @${pick2.split('@')[0]}

*Kecocokan:* ${Math.floor(Math.random() * 50) + 50}%
_Semoga langgeng ya!_`.trim()

    const msg = generateWAMessageFromContent(m.chat, {
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Is it destiny?" }),
            header: proto.Message.InteractiveMessage.Header.fromObject({ title: "💠 SOULMATE FINDER", hasMediaAttachment: false }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "🔄 CARI LAGI",
                            id: `${usedPrefix}${command}`
                        })
                    }
                ]
            }),
            contextInfo: {
                mentionedJid: [pick, pick2]
            }
        })
    }, { quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ["couple", "jodoh"]
handler.tags = ["fun"]
handler.command = ["couple", "jodoh"]
handler.group = true

export default handler
