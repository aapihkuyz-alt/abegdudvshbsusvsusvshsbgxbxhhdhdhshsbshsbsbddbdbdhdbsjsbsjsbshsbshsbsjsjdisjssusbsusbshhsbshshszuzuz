import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "📚",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/fakta", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        const teks =
            `🧠 *FAKTA UNIK HARI INI*

${data.data.text}

Sekarang kamu sedikit lebih pintar dari 10 detik yang lalu.`

        await conn.sendMessage(
            m.chat, {
                text: teks
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("FAKTA ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil fakta unik.")
    }
}

handler.help = ["fakta"]
handler.tags = ["fun"]
handler.command = ["fakta", "faktaunik"]

export default handler