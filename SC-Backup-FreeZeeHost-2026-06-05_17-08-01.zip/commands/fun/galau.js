import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🥀",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/galau", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        const teks =
            `🥀 *KATA GALAU HARI INI*

"${data.data.text}"

Tidak apa-apa merasa sedih. Asal jangan lupa bangkit.`

        await conn.sendMessage(
            m.chat, {
                text: teks
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("GALAU ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil kata galau.")
    }
}

handler.help = ["galau"]
handler.tags = ["fun"]
handler.command = ["galau"]

export default handler