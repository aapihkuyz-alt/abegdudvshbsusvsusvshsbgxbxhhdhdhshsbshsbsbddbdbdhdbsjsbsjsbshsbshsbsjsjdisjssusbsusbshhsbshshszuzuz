import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "📖",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/dilan", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        const teks =
            `🎬 *KATA-KATA DILAN*

"${data.data.text}"

Jangan baper. Ini cuma dialog, bukan janji hidup.`

        await conn.sendMessage(
            m.chat, {
                text: teks
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("DILAN ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil kata Dilan.")
    }
}

handler.help = ["dilan", "katadilan"]
handler.tags = ["fun"]
handler.command = ["dilan", "katadilan"]

export default handler