import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🗿",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/meme", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        const meme = data.data

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: meme.url
                },
                caption: `🖼 *MEME HARI INI*\n\n📌 ${meme.title}`
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("MEME ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil meme.")
    }
}

handler.help = ["meme"]
handler.tags = ["fun"]
handler.command = ["meme"]

export default handler