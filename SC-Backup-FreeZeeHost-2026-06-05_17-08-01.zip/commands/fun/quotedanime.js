import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🎌",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/quotesnime", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        const q = data.data

        const caption =
            `🎬 *QUOTES ANIME*

📺 Anime : ${q.anime}
👤 Karakter : ${q.character}

🗯️ "${q.quotes}"`

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: q.image
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("QANIME ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil quotes anime.")
    }
}

handler.help = ["qanime", "quotedanime"]
handler.tags = ["fun"]
handler.command = ["qanime", "quotedanime"]

export default handler