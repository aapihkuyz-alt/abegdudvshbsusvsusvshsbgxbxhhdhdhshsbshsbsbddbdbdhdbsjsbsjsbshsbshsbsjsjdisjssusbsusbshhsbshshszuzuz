import axios from "axios"

let handler = async (m, {
    conn
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🖼️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/quotesimage", {
                params: {
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data)
            throw new Error("API Error")

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption: "✨ *Quotes Image Hari Ini*"
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("QIMAGE ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil quotes image.")
    }
}

handler.help = ["qimg", "qimage", "qgambar", "quotedimage"]
handler.tags = ["fun"]
handler.command = ["qimg", "qimage", "qgambar", "quotedimage"]

export default handler