import axios from "axios"

async function getTOD(type) {
    const endpoint =
        type === "dare" ?
        "https://api.neoxr.eu/api/dare" :
        "https://api.neoxr.eu/api/truth"

    const {
        data
    } = await axios.get(endpoint, {
        params: {
            apikey: global.neoxr
        }
    })

    if (!data.status || !data.data)
        throw new Error("API Error")

    return data.data.text
}

let handler = async (m, {
    conn,
    command,
    args
}) => {
    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🎲",
                key: m.key
            }
        })

        let type

        if (command === "truth") type = "truth"
        else if (command === "dare") type = "dare"
        else if (command === "tod") {
            if (!args[0])
                return m.reply("Gunakan: .tod truth / .tod dare")

            type = args[0].toLowerCase()
            if (!["truth", "dare"].includes(type))
                return m.reply("Pilih: truth atau dare")
        }

        const result = await getTOD(type)

        const teks =
            `🎮 *TRUTH OR DARE*

Mode : ${type.toUpperCase()}

"${result}"

Siap terima konsekuensi? 😏`

        await conn.sendMessage(
            m.chat, {
                text: teks
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("TOD ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal mengambil Truth or Dare.")
    }
}

handler.help = ["truth", "dare", "tod truth", "tod dare"]
handler.tags = ["fun"]
handler.command = ["truth", "dare", "tod"]

export default handler