import axios from "axios"

let handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.asahOtak = global.asahOtak || {}

    // Cegah double game
    if (global.asahOtak[m.chat])
        return m.reply("⚠️ Masih ada game yang belum selesai di chat ini.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧠",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/asahotak", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status)
            throw new Error("API error")

        const soal = data.data.pertanyaan
        const jawaban = data.data.jawaban.toLowerCase().trim()

        const caption = `
╔════════════════════════════╗
        🧠  ASAH OTAK
╚════════════════════════════╝

📜 Pertanyaan:
${soal}

━━━━━━━━━━━━━━━━━━━━━━
🎯 Cara Menjawab:
• Reply pesan ini
• Maksimal 3 kesalahan
• Waktu 60 detik

❤️ Nyawa : ❤️❤️❤️
━━━━━━━━━━━━━━━━━━━━━━
`.trim()

        const sent = await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        // Simpan session game
        global.asahOtak[m.chat] = {
            answer: jawaban,
            attempts: 0,
            maxAttempts: 3,
            msgId: sent.key.id,
            start: Date.now(),
            timeout: setTimeout(() => {

                conn.sendMessage(m.chat, {
                    text: `
╔══════════════════════╗
        ⏰  WAKTU HABIS
╚══════════════════════╝

Jawaban yang benar:
➜ *${jawaban}*

Otaknya lagi loading kayak VPS 1 core.
`.trim()
                })

                delete global.asahOtak[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal.")
    }
}

handler.command = ["asahotak"]
handler.tags = ["game"]
handler.help = ["asahotak"]

export default handler


/* ================= BEFORE HANDLER ================= */

handler.before = async (m) => {

    const game = global.asahOtak?.[m.chat]
    if (!game) return

    // WAJIB REPLY KE PESAN SOAL
    if (!m.quoted) return
    if (m.quoted.id !== game.msgId) return
    if (!m.text) return

    const input = m.text.toLowerCase().trim()

    // ===== BENAR =====
    if (input === game.answer) {

        clearTimeout(game.timeout)
        delete global.asahOtak[m.chat]

        const waktuMain = ((Date.now() - game.start) / 1000).toFixed(1)
        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        return m.reply(`
╔══════════════════════╗
        🎉  BENAR!
╚══════════════════════╝

🏆 Jawaban kamu tepat!
⏱ Waktu : ${waktuMain} detik
💰 Gaji : Rp${rewardSaldo.toLocaleString()}
✨ XP : +${rewardXp}

🧠 Otak kamu masih berfungsi normal.
`.trim())
    }

    // ===== SALAH =====
    game.attempts++

    const sisa = game.maxAttempts - game.attempts
    const nyawa = "❤️".repeat(sisa)

    if (sisa > 0) {
        return m.reply(`
╔══════════════════════╗
        ❌  SALAH!
╚══════════════════════╝

❤️ Sisa nyawa : ${nyawa}

Balas ulang pesan soal dengan jawaban baru.
`.trim())
    }

    // ===== GAME OVER =====
    clearTimeout(game.timeout)
    delete global.asahOtak[m.chat]

    return m.reply(`
╔══════════════════════╗
        💀  GAME OVER
╚══════════════════════╝

Jawaban yang benar:
➜ *${game.answer}*

Istirahat dulu. Minum air.
`.trim())
}