import axios from "axios"

let handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.fiboGame = global.fiboGame || {}

    if (global.fiboGame[m.chat])
        return m.reply("⚠️ Masih ada game yang belum selesai.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧠",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/fibonacci", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status)
            throw "Gagal mengambil soal"

        const soal = data.data.question.join(" , ")
        const jawaban = Number(data.data.answer)

        const caption = `
╔══════════════════════╗
        🧠 FIBONACCI QUIZ
╚══════════════════════╝

Lengkapi pola angka berikut:

${soal} , ?

Balas dengan REPLY pesan ini.

❤️ Kesempatan : 3 kali
⏳ Waktu : 2 menit
`.trim()

        const msg = await conn.sendMessage(m.chat, {
            text: caption
        }, {
            quoted: m
        })

        global.fiboGame[m.chat] = {
            answer: jawaban,
            attempts: 0,
            maxAttempts: 3,
            msgId: msg.key.id,
            start: Date.now(),
            timeout: setTimeout(() => {
                delete global.fiboGame[m.chat]
                conn.sendMessage(m.chat, {
                    text: `
⏳ Waktu habis!

Jawaban yang benar:
➜ *${jawaban}*
`.trim()
                })
            }, 120000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal Fibonacci.")
    }
}

handler.command = ["fibonacci"]
handler.tags = ["game"]
handler.help = ["fibonacci"]

export default handler

handler.before = async (m) => {

    const game = global.fiboGame?.[m.chat]
    if (!game) return

    if (!m.quoted) return
    if (m.quoted.id !== game.msgId) return
    if (!m.text) return

    const cleaned = m.text.replace(/[^\d\-]/g, "")
    if (!cleaned || isNaN(cleaned))
        return m.reply("❌ Jawaban harus berupa angka.")

    const userAnswer = Number(cleaned)
    const correctAnswer = Number(game.answer)

    // ===== BENAR =====
    if (userAnswer === correctAnswer) {

        clearTimeout(game.timeout)
        delete global.fiboGame[m.chat]

        const waktuMain = ((Date.now() - game.start) / 1000).toFixed(1)
        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        return m.reply(`
╔══════════════════════╗
        🎉 BENAR TOTAL
╚══════════════════════╝

Jawaban tepat!
⏱ Waktu : ${waktuMain} detik
💰 Gaji : Rp${rewardSaldo.toLocaleString()}
✨ XP : +${rewardXp}
`.trim())
    }

    const selisih = Math.abs(userAnswer - correctAnswer)

    game.attempts++
    const sisa = game.maxAttempts - game.attempts

    const arah = userAnswer < correctAnswer ?
        "📈 Jawaban kamu masih kurang." :
        "📉 Jawaban kamu kebanyakan."

    let feedback = ""

    if (selisih === 1) {
        feedback = "🔥 HAMPIR BANGET! Beda 1!"
    } else if (selisih === 2) {
        feedback = "⚡ Sangat dekat."
    } else if (selisih <= 5) {
        feedback = "👀 Sudah dekat."
    }

    if (feedback && sisa > 0) {
        return m.reply(`
${feedback}

${arah}

❤️ Sisa nyawa : ${"❤️".repeat(sisa)}
`.trim())
    }

    if (sisa > 0) {
        return m.reply(`
❌ Salah.

${arah}

❤️ Sisa nyawa : ${"❤️".repeat(sisa)}
`.trim())
    }

    clearTimeout(game.timeout)
    delete global.fiboGame[m.chat]

    return m.reply(`
💀 GAME OVER

Jawaban yang benar:
➜ *${correctAnswer}*
`.trim())
}