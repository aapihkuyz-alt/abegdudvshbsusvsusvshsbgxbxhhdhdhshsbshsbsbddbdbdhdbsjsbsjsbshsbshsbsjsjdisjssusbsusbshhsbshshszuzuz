import axios from "axios"

let handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.mtkGame = global.mtkGame || {}

    if (global.mtkGame[m.chat])
        return m.reply("⚠️ Masih ada game MTK yang belum selesai di chat ini.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "📐",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/cryptarithm", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status)
            throw new Error("API error")

        const soal = data.data.question
        const jawaban = data.data.answer.toString().trim()

        const caption = `
╔══════════════════════════╗
        📐  MATH CHALLENGE
╚══════════════════════════╝

🧮 Soal:
${soal}

━━━━━━━━━━━━━━━━━━━━━━
📌 Aturan:
• Reply pesan ini untuk menjawab
• Jawaban angka saja
• Maksimal 3 kesalahan
• Waktu 90 detik

❤️ Nyawa : ❤️❤️❤️
━━━━━━━━━━━━━━━━━━━━━━
`.trim()

        const sent = await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        global.mtkGame[m.chat] = {
            answer: jawaban,
            attempts: 0,
            maxAttempts: 3,
            msgId: sent.key.id,
            start: Date.now(),
            timeout: setTimeout(() => {

                conn.sendMessage(m.chat, {
                    text: `
╔══════════════════════╗
        ⏰  WAKTU HABIS
╚══════════════════════╝

Jawaban yang benar:
➜ *${jawaban}*

Matematika tidak pernah salah.
Yang salah biasanya manusianya.
`.trim()
                })

                delete global.mtkGame[m.chat]

            }, 90000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal MTK.")
    }
}

handler.command = ["mtk", "math"]
handler.tags = ["game"]
handler.help = ["mtk"]

export default handler


/* ================= BEFORE HANDLER ================= */

handler.before = async (m) => {

    const game = global.mtkGame?.[m.chat]
    if (!game) return

    if (!m.quoted) return
    if (m.quoted.id !== game.msgId) return
    if (!m.text) return

    // Ambil angka saja (antisipasi typo atau minus nyasar)
    const cleaned = m.text.replace(/[^\d\-]/g, "")
    if (!cleaned || isNaN(cleaned))
        return m.reply("❌ Jawaban harus berupa angka.")

    const userAnswer = Number(cleaned)
    const correctAnswer = Number(game.answer)

    // ===== BENAR =====
    if (userAnswer === correctAnswer) {

        clearTimeout(game.timeout)
        delete global.mtkGame[m.chat]

        const waktuMain = ((Date.now() - game.start) / 1000).toFixed(1)
        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        return m.reply(`
╔══════════════════════╗
        🎉  BENAR TOTAL
╚══════════════════════╝

🏆 Jawaban tepat!
⏱ Waktu : ${waktuMain} detik
💰 Gaji : Rp${rewardSaldo.toLocaleString()}
✨ XP : +${rewardXp}

Otak kamu masih tajam ternyata.
`.trim())
    }

    const selisih = Math.abs(userAnswer - correctAnswer)

    game.attempts++
    const sisa = game.maxAttempts - game.attempts

    const arah = userAnswer < correctAnswer ?
        "📈 Jawaban kamu masih kurang." :
        "📉 Jawaban kamu kebanyakan."

    // ===== LEVEL HAMPIR =====
    let feedback = ""

    if (selisih === 1) {
        feedback = "🔥 HAMPIR BANGET! Cuma beda 1!"
    } else if (selisih === 2) {
        feedback = "⚡ Sangat dekat. Tinggal dikit lagi."
    } else if (selisih <= 5) {
        feedback = "👀 Sudah dekat. Fokus sedikit lagi."
    }

    if (feedback && sisa > 0) {
        return m.reply(`
╔══════════════════════╗
        ${feedback}
╚══════════════════════╝

${arah}

Selisih : ${selisih}

❤️ Sisa nyawa : ${"❤️".repeat(sisa)}
`.trim())
    }

    // ===== SALAH BIASA =====
    if (sisa > 0) {
        return m.reply(`
╔══════════════════════╗
        ❌  SALAH
╚══════════════════════╝

${arah}

❤️ Sisa nyawa : ${"❤️".repeat(sisa)}
`.trim())
    }

    // ===== GAME OVER =====
    clearTimeout(game.timeout)
    delete global.mtkGame[m.chat]

    return m.reply(`
╔══════════════════════╗
        💀  GAME OVER
╚══════════════════════╝

Jawaban yang benar:
➜ *${correctAnswer}*

Matematika masih lebih kuat hari ini.
`.trim())
}