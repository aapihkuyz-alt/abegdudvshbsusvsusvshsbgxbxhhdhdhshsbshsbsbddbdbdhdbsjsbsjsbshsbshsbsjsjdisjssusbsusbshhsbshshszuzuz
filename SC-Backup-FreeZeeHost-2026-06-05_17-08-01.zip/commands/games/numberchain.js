import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.numberchain = global.numberchain || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧮",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/numberchain", {
                params: {
                    start: 150,
                    show: 10,
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data?.length)
            throw new Error("Soal tidak tersedia")

        const soal = data.data[0] // ambil 1 soal dulu

        const caption = `
╭━━━〔 🧮 NUMBER CHAIN 〕━━━⬣
┃ 🎯 Mode       : ${soal.mode.toUpperCase()}
┃ 📘 Soal       :
┃ ➜ ${soal.question}
┃
┃ ⏳ Waktu      : 60 Detik
┃ ❤️ Kesempatan : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ agar jawaban dihitung
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

Ketik jawaban angka saja.
`.trim()

        const msg = await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        global.numberchain[m.chat] = {
            answer: Number(soal.answer),
            attempts: 3,
            messageId: msg.key.id,
            timeout: setTimeout(async () => {

                if (!global.numberchain[m.chat]) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ Jawaban yang benar:
┃ ➜ *${soal.answer}*
┃
┃ 💡 Jangan panik.
┃ Hitung pelan-pelan.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                })

                delete global.numberchain[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal Number Chain.")
    }
}

handler.before = async (m, {
    conn
}) => {

    if (!global.numberchain?.[m.chat]) return
    if (!m.quoted) return
    if (m.quoted.id !== global.numberchain[m.chat].messageId) return
    if (isNaN(m.text)) return

    const session = global.numberchain[m.chat]
    const userAnswer = Number(m.text)
    const correct = session.answer

    if (userAnswer === correct) {

        clearTimeout(session.timeout)

        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        await conn.sendMessage(m.chat, {
            text: `
╭━━━〔 🎉 BENAR! 〕━━━⬣
┃ Jawaban kamu : ${userAnswer}
┃ Status       : AKURAT 💯
┃ 💰 Gaji       : Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP         : +${rewardXp}
┃
┃ 🧠 Otak kamu lagi tajam.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        })

        delete global.numberchain[m.chat]
        return
    }

    session.attempts--

    const selisih = Math.abs(correct - userAnswer)

    if (selisih <= 2) {
        return m.reply(`
🤏 Hampir benar!

Selisih cuma ${selisih}.
Cek lagi perhitungan terakhir kamu.
Sisa kesempatan: ${session.attempts}
`)
    }

    if (session.attempts > 0) {
        return m.reply(`
❌ Salah!

Jawaban kamu: ${userAnswer}
Sisa kesempatan: ${session.attempts}

Tenang. Hitung ulang pelan-pelan.
`)
    }

    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu : ${userAnswer}
┃ Jawaban benar: ${correct}
┃
┃ 🔁 Kesempatan habis.
┃ Coba lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    })

    delete global.numberchain[m.chat]
}

handler.command = ["numberchain"]
handler.tags = ["game"]
handler.help = ["numberchain"]

export default handler