import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.pilgan = global.pilgan || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "📚",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/pilgan", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Soal tidak tersedia")

        const soal = data.data

        const pilihan = soal.selection
            .map((v, i) => `${String.fromCharCode(65 + i)}. ${v}`)
            .join("\n")

        const caption = `
╭━━━〔 📚 PILIHAN GANDA 〕━━━⬣
┃ 📝 Pertanyaan :
┃
┃ ${soal.question}
┃
┃ 📌 Pilihan :
┃ ${pilihan}
┃
┃ ⏳ Waktu      : 60 Detik
┃ ❤️ Kesempatan : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ Jawab dengan huruf saja
┃ (A / B / C / D)
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

        const soalMsg = await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        global.pilgan[m.chat] = {
            answer: soal.answer.toUpperCase(),
            explanation: soal.explanation,
            attempts: 3,
            messageId: soalMsg.key.id,
            soalKey: soalMsg,
            timeout: setTimeout(async () => {

                const session = global.pilgan[m.chat]
                if (!session) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ 📌 Jawaban yang benar :
┃ ➜ *${session.answer}*
┃
┃ 📖 Penjelasan :
┃ ${session.explanation}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                }, {
                    quoted: session.soalKey
                })

                delete global.pilgan[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal pilihan ganda.")
    }
}

/* ================= CEK JAWABAN ================= */

handler.before = async (m, {
    conn
}) => {

    const session = global.pilgan?.[m.chat]
    if (!session) return
    if (!m.quoted) return
    if (m.quoted.id !== session.messageId) return
    if (!m.text) return

    const userAnswer = m.text.trim().toUpperCase()

    if (!["A", "B", "C", "D"].includes(userAnswer)) return

    /* ===== BENAR ===== */
    if (userAnswer === session.answer) {

        clearTimeout(session.timeout)

        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        await conn.sendMessage(m.chat, {
            text: `
╭━━━〔 🎉 BENAR! 〕━━━⬣
┃ Jawaban kamu : ${userAnswer}
┃ Status       : AKURAT 💯
┃ 💰 Gaji       : Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP         : +${rewardXp}
┃
┃ 📖 Penjelasan :
┃ ${session.explanation}
┃
┃ 🔥 Nice. Fokus kamu solid.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        }, {
            quoted: m
        })

        delete global.pilgan[m.chat]
        return
    }

    session.attempts--

    /* ===== MASIH ADA KESEMPATAN ===== */
    if (session.attempts > 0) {
        return conn.sendMessage(m.chat, {
            text: `
╭━━━〔 ❌ SALAH 〕━━━⬣
┃ Jawaban kamu : ${userAnswer}
┃ ❤️ Sisa kesempatan : ${session.attempts}
┃
┃ 🔎 Baca lagi pertanyaannya.
┃ Jangan asal tembak.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        }, {
            quoted: m
        })
    }

    /* ===== GAME OVER ===== */
    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu : ${userAnswer}
┃ Jawaban benar: ${session.answer}
┃
┃ 📖 Penjelasan :
┃ ${session.explanation}
┃
┃ 🔁 Kesempatan habis.
┃ Coba lagi biar makin tajam.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    }, {
        quoted: m
    })

    delete global.pilgan[m.chat]
}

handler.command = ["pilgan"]
handler.tags = ["game"]
handler.help = ["pilgan"]

export default handler