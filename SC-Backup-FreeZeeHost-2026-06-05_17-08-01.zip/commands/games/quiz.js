import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.quiz = global.quiz || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧠",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/quiz", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Quiz tidak tersedia")

        const soal = data.data
        const totalJawaban = soal.jawaban.length

        const caption = `
╭━━━〔 🧠 QUIZ TEBAK KATA 〕━━━⬣
┃ 📌 Pertanyaan :
┃ ➜ ${soal.pertanyaan}
┃
┃ 🎯 Total Jawaban : ${totalJawaban}
┃ ⏳ Waktu          : 60 Detik
┃ ❤️ Kesalahan Maks : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ Ketik 1 jawaban setiap kirim
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

        const soalMsg = await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        global.quiz[m.chat] = {
            answers: soal.jawaban.map(v => v.toLowerCase()),
            found: [],
            attempts: 3,
            messageId: soalMsg.key.id,
            soalKey: soalMsg,
            timeout: setTimeout(async () => {

                const session = global.quiz[m.chat]
                if (!session) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ 📝 Jawaban yang belum ditemukan :
┃
${session.answers
  .filter(v => !session.found.includes(v))
  .map(v => `┃ • ${v}`)
  .join("\n")}
┃
┃ 🔁 Coba lagi biar makin tajam.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                }, {
                    quoted: session.soalKey
                })

                delete global.quiz[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal quiz.")
    }
}

/* ================= CEK JAWABAN ================= */

handler.before = async (m, {
    conn
}) => {

    const session = global.quiz?.[m.chat]
    if (!session) return
    if (!m.quoted) return
    if (m.quoted.id !== session.messageId) return
    if (!m.text) return

    const userAnswer = m.text.trim().toLowerCase()

    /* ===== SUDAH PERNAH DIJAWAB ===== */
    if (session.found.includes(userAnswer)) {
        return conn.sendMessage(m.chat, {
            text: `
⚠️ Jawaban *${userAnswer}* sudah ditemukan.

Coba yang lain.
`.trim()
        }, {
            quoted: m
        })
    }

    /* ===== JAWABAN BENAR ===== */
    if (session.answers.includes(userAnswer)) {

        session.found.push(userAnswer)

        /* Semua ketemu */
        if (session.found.length === session.answers.length) {

            clearTimeout(session.timeout)

            const user = global.db.get("user", m.sender)
            const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
            const rewardXp = Math.floor(Math.random() * 50) + 20
            user.saldo = (user.saldo || 0) + rewardSaldo
            user.xp = (user.xp || 0) + rewardXp
            await global.db.save()

            return conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 🎉 SEMUA BENAR! 〕━━━⬣
┃ 🏆 Kamu berhasil menemukan
┃ ${session.answers.length} jawaban!
┃ 💰 Gaji       : Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP         : +${rewardXp}
┃
┃ 📌 Daftar Jawaban :
${session.answers.map(v => `┃ • ${v}`).join("\n")}
┃
┃ 🔥 Otak kamu aktif banget.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                }, {
                    quoted: m
                })
                .then(() => delete global.quiz[m.chat])
        }

        return conn.sendMessage(m.chat, {
            text: `
╭━━━〔 ✅ BENAR 〕━━━⬣
┃ Jawaban : ${userAnswer}
┃
┃ 📊 Progress :
┃ ${session.found.length} / ${session.answers.length}
┃
┃ 🔎 Masih ada yang belum ketemu.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        }, {
            quoted: m
        })
    }

    /* ===== SALAH ===== */
    session.attempts--

    if (session.attempts > 0) {
        return conn.sendMessage(m.chat, {
            text: `
╭━━━〔 ❌ SALAH 〕━━━⬣
┃ Jawaban : ${userAnswer}
┃ ❤️ Sisa Kesalahan : ${session.attempts}
┃
┃ 💡 Fokus lagi ke kata kunci.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        }, {
            quoted: m
        })
    }

    /* ===== GAME OVER ===== */
    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu : ${userAnswer}
┃
┃ 📌 Jawaban yang benar :
${session.answers.map(v => `┃ • ${v}`).join("\n")}
┃
┃ 🔁 Kesempatan habis.
┃ Coba lagi biar makin jago.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    }, {
        quoted: m
    })

    delete global.quiz[m.chat]
}

handler.command = ["quiz"]
handler.tags = ["game"]
handler.help = ["quiz"]

export default handler