import { proto, generateWAMessageFromContent } from "baileys";

let handler = async (m, { conn, db, text, Func, usedPrefix, command }) => {
    let user = db.get("user", m.sender)
    
    // Jika tidak ada text (pembukaan game)
    if (!text) {
        let caption = `
╔══  「 🎰 *LUCKY ROULETTE* 」
║ ◦ *Saldo:* Rp ${Func.formatter(user.saldo)}
╠══════════════════
║  *CARA BERMAIN:*
║ 1. Pilih jumlah taruhan di bawah.
║ 2. Bot akan memutar mesin.
║ 3. Jika menang, saldo bertambah 2x!
║ 4. Jika kalah, taruhan hangus.
╚══════════════════

_Gunakan saldo dengan bijak, jangan sampai bangkrut!_`.trim()

        const msg = generateWAMessageFromContent(m.chat, {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Luck is on your side?" }),
                header: proto.Message.InteractiveMessage.Header.fromObject({ title: "💠 CASINO ENGINE", hasMediaAttachment: false }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Bet 500", id: `${usedPrefix}${command} 500` }) },
                        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Bet 1.000", id: `${usedPrefix}${command} 1000` }) },
                        { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "Bet 5.000", id: `${usedPrefix}${command} 5000` }) }
                    ]
                })
            })
        }, { quoted: m })

        return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
    }

    // Proses taruhan
    let bet = parseInt(text.replace(/[^0-9]/g, ''))
    if (!bet || isNaN(bet) || bet <= 0) return m.reply("❌ Masukkan jumlah taruhan yang valid.")
    if (user.saldo < bet) return m.reply(`❌ Saldo tidak cukup! Saldo kamu: *Rp ${Func.formatter(user.saldo)}*`)

    // Animasi putar (Fake delay)
    await m.reply("🎰 *Mesin sedang berputar...*")
    await new Promise(r => setTimeout(r, 2000))

    let win = Math.random() < 0.45 // Peluang menang 45% (Casino house edge)
    
    if (win) {
        let profit = bet * 1 // Menang dapat 2x (taruhan balik + profit 1x)
        user.saldo += profit
        await db.save()
        m.reply(`🎊 *CONGRATULATIONS* 🎊\n\nKamu menang! Mesin berhenti di angka keberuntungan.\n◦ *Profit:* +Rp ${Func.formatter(profit)}\n◦ *Saldo Sekarang:* Rp ${Func.formatter(user.saldo)}`)
    } else {
        user.saldo -= bet
        await db.save()
        m.reply(`💀 *YOU LOST* 💀\n\nSayang sekali, keberuntungan belum berpihak padamu.\n◦ *Loss:* -Rp ${Func.formatter(bet)}\n◦ *Saldo Sekarang:* Rp ${Func.formatter(user.saldo)}`)
    }
}

handler.help = ["roulette", "judi"]
handler.tags = ["xp"]
handler.command = ["roulette", "judi", "bet"]
handler.register = true

export default handler
