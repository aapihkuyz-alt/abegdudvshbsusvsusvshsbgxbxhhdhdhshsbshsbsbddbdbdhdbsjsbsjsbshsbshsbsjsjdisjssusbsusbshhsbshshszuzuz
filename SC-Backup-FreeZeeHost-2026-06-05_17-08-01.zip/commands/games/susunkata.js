import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.whatword = global.whatword || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🔤",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/whatword", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Soal tidak tersedia")

        const soal = data.data

        const caption = `
╭━━━〔 🔤 WHAT WORD 〕━━━⬣
┃ 🧩 Tebak kata dari huruf acak
┃
┃ 📂 Tipe :
┃ ➜ ${soal.tipe}
┃
┃ 🔀 Huruf :
┃ ➜ ${soal.pertanyaan}
┃
┃ ⏳ Waktu      : 60 Detik
┃ ❤️ Kesempatan : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ Ketik jawaban tanpa spasi tambahan
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

        const soalMsg = await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        global.whatword[m.chat] = {
            answer: soal.jawaban.toLowerCase(),
            attempts: 3,
            messageId: soalMsg.key.id,
            soalKey: soalMsg,
            timeout: setTimeout(async () => {

                const session = global.whatword[m.chat]
                if (!session) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ Jawaban yang benar:
┃ ➜ *${soal.jawaban}*
┃
┃ 🔎 Hurufnya sebenarnya jelas,
┃ cuma otaknya lagi loading.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                }, {
                    quoted: session.soalKey
                })

                delete global.whatword[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal WhatWord.")
    }
}

/* ================= CEK JAWABAN ================= */

handler.before = async (m, {
    conn
}) => {

    const session = global.whatword?.[m.chat]
    if (!session) return
    if (!m.quoted) return
    if (m.quoted.id !== session.messageId) return
    if (!m.text) return

    const userAnswer = m.text.trim().toLowerCase()
    const correct = session.answer

    /* ===== BENAR ===== */
    if (userAnswer === correct) {

        clearTimeout(session.timeout)

        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        await conn.sendMessage(m.chat, {
            text: `
╭━━━〔 🎉 BENAR! 〕━━━⬣
┃ Jawaban kamu :
┃ ➜ *${m.text}*
┃
┃ 🎯 Status : VALID ✅
┃ 💰 Gaji   : Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP     : +${rewardXp}
┃
┃ 🧠 Huruf acak berhasil
┃ kamu susun dengan benar.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        }, {
            quoted: m
        })

        delete global.whatword[m.chat]
        return
    }

    /* ===== SALAH ===== */
    session.attempts--

    if (session.attempts > 0) {

        return conn.sendMessage(m.chat, {
            text: `
╭━━━〔 ❌ SALAH 〕━━━⬣
┃ Jawaban kamu :
┃ ➜ *${m.text}*
┃
┃ ❤️ Sisa Kesempatan :
┃ ➜ ${session.attempts}
┃
┃ 🔄 Coba susun ulang hurufnya.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        }, {
            quoted: m
        })
    }

    /* ===== GAME OVER ===== */
    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu :
┃ ➜ *${m.text}*
┃
┃ ✅ Jawaban benar :
┃ ➜ *${correct}*
┃
┃ 🔁 Latihan lagi biar
┃ nggak ketuker huruf terus.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    }, {
        quoted: m
    })

    delete global.whatword[m.chat]
}

handler.command = ["susunkata", "whatword"]
handler.tags = ["game"]
handler.help = ["whatword"]

export default handler