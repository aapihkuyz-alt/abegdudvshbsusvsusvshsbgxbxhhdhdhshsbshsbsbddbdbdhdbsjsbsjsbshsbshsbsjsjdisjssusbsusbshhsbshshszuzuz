import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.tebakbendera = global.tebakbendera || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🏳️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/whatflag", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Soal tidak tersedia")

        const soal = data.data
        const jawaban = soal.name.toLowerCase()

        const caption = `
╭━━━〔 🌍 TEBAK BENDERA 〕━━━⬣
┃ 🧠 Tebak nama negara dari bendera ini!
┃
┃ ⏳ Waktu       : 60 Detik
┃ ❤️ Kesempatan  : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ agar jawaban dihitung
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

Ketik nama negaranya saja.
Contoh: indonesia
`.trim()

        const msg = await conn.sendMessage(
            m.chat, {
                image: {
                    url: soal.img
                },
                caption
            }, {
                quoted: m
            }
        )

        global.tebakbendera[m.chat] = {
            answer: jawaban,
            attempts: 3,
            messageId: msg.key.id,
            timeout: setTimeout(async () => {

                if (!global.tebakbendera[m.chat]) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ Jawaban yang benar:
┃ ➜ *${soal.name}*
┃
┃ 🌍 Itu tadi bendera ${soal.name}.
┃ Coba lagi biar hafal semua negara.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                })

                delete global.tebakbendera[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal Tebak Bendera.")
    }
}

handler.before = async (m, {
    conn
}) => {

    if (!global.tebakbendera?.[m.chat]) return
    if (!m.quoted) return
    if (m.quoted.id !== global.tebakbendera[m.chat].messageId) return
    if (!m.text) return

    const session = global.tebakbendera[m.chat]
    const userAnswer = m.text.toLowerCase().trim()
    const correct = session.answer

    if (userAnswer === correct) {

        clearTimeout(session.timeout)

        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        await conn.sendMessage(m.chat, {
            text: `
╭━━━〔 🎉 BENAR! 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Status       : AKURAT 💯
┃ 💰 Gaji       : Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP         : +${rewardXp}
┃
┃ 🌎 Mantap.
┃ Kamu lumayan paham geografi.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        })

        delete global.tebakbendera[m.chat]
        return
    }

    session.attempts--

    const mirip = correct.includes(userAnswer) || userAnswer.includes(correct)

    if (mirip) {
        return m.reply(`
🤏 Hampir benar!

Periksa ejaan lagi.
Sisa kesempatan: ${session.attempts}
`)
    }

    if (session.attempts > 0) {
        return m.reply(`
❌ Salah!

Jawaban kamu: ${m.text}
Sisa kesempatan: ${session.attempts}

Coba lagi. Fokus lihat detail warna & simbol.
`)
    }

    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Jawaban benar: ${correct}
┃
┃ 📚 Geografi memang kejam.
┃ Coba lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    })

    delete global.tebakbendera[m.chat]
}

handler.command = ["tebakbendera"]
handler.tags = ["game"]
handler.help = ["tebakbendera"]

export default handler