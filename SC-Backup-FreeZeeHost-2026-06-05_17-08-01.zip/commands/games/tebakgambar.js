import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.tebakgambar = global.tebakgambar || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🖼️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/whatimg", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Soal tidak tersedia")

        const soal = data.data
        const jawaban = soal.jawaban.toLowerCase().trim()

        const caption = `
╭━━━〔 🧠 TEBAK GAMBAR 〕━━━⬣
┃ 🎯 Perhatikan gambar berikut!
┃
┃ ⏳ Waktu       : 60 Detik
┃ ❤️ Kesempatan  : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ agar jawaban dihitung
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

Ketik jawabannya saja.
Gunakan huruf biasa tanpa simbol.
`.trim()

        const msg = await conn.sendMessage(
            m.chat, {
                image: {
                    url: soal.img
                },
                caption
            }, {
                quoted: m
            }
        )

        global.tebakgambar[m.chat] = {
            answer: jawaban,
            desc: soal.deskripsi,
            attempts: 3,
            messageId: msg.key.id,
            timeout: setTimeout(async () => {

                if (!global.tebakgambar[m.chat]) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ Jawaban yang benar:
┃ ➜ *${soal.jawaban}*
┃
┃ 📝 Penjelasan:
┃ ${soal.deskripsi}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                })

                delete global.tebakgambar[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal Tebak Gambar.")
    }
}

handler.before = async (m, {
    conn
}) => {

    if (!global.tebakgambar?.[m.chat]) return
    if (!m.quoted) return
    if (m.quoted.id !== global.tebakgambar[m.chat].messageId) return
    if (!m.text) return

    const session = global.tebakgambar[m.chat]
    const userAnswer = m.text.toLowerCase().trim()
    const correct = session.answer

    const normalize = str => str.replace(/\s+/g, "")

    if (normalize(userAnswer) === normalize(correct)) {

        clearTimeout(session.timeout)

        const user = global.db.get("user", m.sender)
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000
        const rewardXp = Math.floor(Math.random() * 50) + 20
        user.saldo = (user.saldo || 0) + rewardSaldo
        user.xp = (user.xp || 0) + rewardXp
        await global.db.save()

        await conn.sendMessage(m.chat, {
            text: `
╭━━━〔 🎉 BENAR! 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Status       : AKURAT 💯
┃ 💰 Gaji       : Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP         : +${rewardXp}
┃
┃ 📝 Penjelasan:
┃ ${session.desc}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        })

        delete global.tebakgambar[m.chat]
        return
    }

    session.attempts--

    const mirip =
        normalize(correct).includes(normalize(userAnswer)) ||
        normalize(userAnswer).includes(normalize(correct))

    if (mirip && session.attempts > 0) {
        return m.reply(`
🤏 Hampir benar!

Periksa lagi kata yang kurang atau salah eja.
Sisa kesempatan: ${session.attempts}
`)
    }

    if (session.attempts > 0) {
        return m.reply(`
❌ Salah!

Jawaban kamu: ${m.text}
Sisa kesempatan: ${session.attempts}

Coba pikirkan hubungan gambar satu dengan lainnya.
`)
    }

    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Jawaban benar: ${correct}
┃
┃ 📝 Penjelasan:
┃ ${session.desc}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    })

    delete global.tebakgambar[m.chat]
}

handler.command = ["tebakgambar"]
handler.tags = ["game"]
handler.help = ["tebakgambar"]

export default handler