import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.tebaklagu = global.tebaklagu || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🎵",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/whatsong", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Soal tidak tersedia")

        const soal = data.data
        const jawaban = soal.title.toLowerCase().trim()

        // 1️⃣ Kirim audio
        const audioMsg = await conn.sendMessage(
            m.chat, {
                audio: {
                    url: soal.path
                },
                mimetype: "audio/mpeg",
                ptt: false
            }, {
                quoted: m
            }
        )

        // 2️⃣ Kirim teks soal (JANGAN reply audio)
        const textMsg = await conn.sendMessage(
            m.chat, {
                text: `
╭━━━〔 🎧 TEBAK LAGU 〕━━━⬣
┃ 🎶 Dengarkan audio di atas
┃
┃ ⏳ Waktu       : 60 Detik
┃ ❤️ Kesempatan  : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ agar jawaban dihitung
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

Tebak judul lagunya.
`.trim()
            }
        )

        // Simpan session pakai ID teks, bukan audio
        global.tebaklagu[m.chat] = {
            answer: jawaban,
            attempts: 3,
            messageId: textMsg.key.id,
            timeout: setTimeout(async () => {

                if (!global.tebaklagu[m.chat]) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ Jawaban yang benar:
┃ ➜ *${soal.title}*
┃
┃ 🎵 Fokus lagi lain kali.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                })

                delete global.tebaklagu[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal Tebak Lagu.")
    }
}

handler.before = async (m, {
    conn
}) => {

    if (!global.tebaklagu?.[m.chat]) return
    if (!m.quoted) return
    if (m.quoted.id !== global.tebaklagu[m.chat].messageId) return
    if (!m.text) return

    const session = global.tebaklagu[m.chat]
    const userAnswer = m.text.toLowerCase().trim()
    const correct = session.answer

    const normalize = str => str.replace(/\s+/g, "")

    if (normalize(userAnswer) === normalize(correct)) {

        clearTimeout(session.timeout)
        
        const user = global.db.get("user", m.sender);
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000;
        const rewardXp = Math.floor(Math.random() * 50) + 20;
        user.saldo = (user.saldo || 0) + rewardSaldo;
        user.xp = (user.xp || 0) + rewardXp;
        await global.db.save();

        await conn.sendMessage(m.chat, {
            text: `
╭━━━〔 🎉 BENAR! 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Status       : AKURAT 💯
┃
┃ 💰 Saldo     : +Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP        : +${rewardXp}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        })

        delete global.tebaklagu[m.chat]
        return
    }

    session.attempts--

    if (session.attempts > 0) {
        return m.reply(`
❌ Salah!
Sisa kesempatan: ${session.attempts}
`)
    }

    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Jawaban benar: ${correct}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    })

    delete global.tebaklagu[m.chat]
}

handler.command = ["tebaklagu"]
handler.tags = ["game"]
handler.help = ["tebaklagu"]

export default handler