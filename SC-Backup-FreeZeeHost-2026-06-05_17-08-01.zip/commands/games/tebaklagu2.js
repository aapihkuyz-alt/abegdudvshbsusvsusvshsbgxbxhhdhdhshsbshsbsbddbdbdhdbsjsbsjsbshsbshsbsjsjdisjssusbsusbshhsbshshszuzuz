import axios from "axios";

const handler = async (m, { conn, db }) => {
    if (!global.neoxr) return m.reply("❌ API key neoxr belum diset.");

    global.tebaklagu = global.tebaklagu || {};

    try {
        await m.react("🎵");

        const { data } = await axios.get("https://api.neoxr.eu/api/whatsong", {
            params: { apikey: global.neoxr },
            timeout: 20000
        });

        if (!data?.status || !data?.data) throw new Error("Soal tidak tersedia");

        const soal = data.data;
        const jawaban = soal.title.toLowerCase().trim();

        // 1️⃣ Kirim Audio (Voice Note)
        const audioMsg = await conn.sendMessage(m.chat, {
            audio: { url: soal.path },
            mimetype: "audio/mpeg",
            ptt: true // Dikirim sebagai VN
        }, { quoted: m });

        // 2️⃣ Kirim Instruksi
        const caption = `╭━━━〔 🎧 TEBAK LAGU V2 〕━━━⬣
┃ 🎶 Dengarkan Voice Note di atas!
┃
┃ ⏳ Waktu       : 60 Detik
┃ ❤️ Kesempatan  : 3 Kali
┃ 💰 Hadiah      : Rp1.000 - 3.000
┃
┃ ⚠️ WAJIB reply Voice Note tersebut
┃ agar jawaban dihitung.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣`.trim();

        const textMsg = await conn.sendMessage(m.chat, { text: caption }, { quoted: audioMsg });

        global.tebaklagu[m.chat] = {
            answer: jawaban,
            attempts: 3,
            messageId: audioMsg.key.id, // User harus reply VN
            timeout: setTimeout(async () => {
                if (!global.tebaklagu[m.chat]) return;
                await m.reply(`╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣\n┃ Jawaban: *${soal.title}*\n╰━━━━━━━━━━━━━━━━━━━━━━⬣`);
                delete global.tebaklagu[m.chat];
            }, 60000)
        };

    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal mengambil soal Tebak Lagu.");
    }
};

handler.before = async (m, { conn, db }) => {
    const session = global.tebaklagu?.[m.chat];
    if (!session || !m.quoted || m.quoted.id !== session.messageId || !m.text) return;

    const userAnswer = m.text.toLowerCase().trim();
    if (userAnswer === session.answer) {
        clearTimeout(session.timeout);
        
        const user = db.get("user", m.sender);
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000;
        const rewardXp = Math.floor(Math.random() * 50) + 20;
        user.saldo = (user.saldo || 0) + rewardSaldo;
        user.xp = (user.xp || 0) + rewardXp;
        await db.save();

        await m.reply(`╭━━━〔 🎉 BENAR! 〕━━━⬣\n┃ Jawaban: ${m.text}\n┃ 💰 Saldo: +Rp${rewardSaldo.toLocaleString()}\n┃ ✨ XP: +${rewardXp}\n╰━━━━━━━━━━━━━━━━━━━━━━⬣`);
        delete global.tebaklagu[m.chat];
    } else {
        session.attempts--;
        if (session.attempts > 0) {
            m.reply(`❌ Salah! Sisa kesempatan: ${session.attempts}`);
        } else {
            clearTimeout(session.timeout);
            await m.reply(`╭━━━〔 💀 GAME OVER 〕━━━⬣\n┃ Jawaban: ${session.answer}\n╰━━━━━━━━━━━━━━━━━━━━━━⬣`);
            delete global.tebaklagu[m.chat];
        }
    }
};

handler.help = ["tebaklagu2"];
handler.tags = ["game"];
handler.command = /^(tebaklagu2|ts2)$/i;

export default handler;