import axios from "axios"

const handler = async (m, {
    conn
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    global.tekateki = global.tekateki || {}

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧩",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/tekateki", {
                params: {
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Soal tidak tersedia")

        const soal = data.data
        const jawaban = soal.jawaban.toLowerCase().trim()

        const caption = `
╭━━━〔 🧩 TEKA TEKI 〕━━━⬣
┃ 🤔 Pertanyaan :
┃ ➜ ${soal.pertanyaan}
┃
┃ ⏳ Waktu       : 60 Detik
┃ ❤️ Kesempatan  : 3 Kali
┃
┃ ⚠️ WAJIB reply pesan ini
┃ agar jawaban dihitung
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

Gunakan logika… atau insting random kamu.
`.trim()

        const msg = await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        global.tekateki[m.chat] = {
            answer: jawaban,
            attempts: 3,
            messageId: msg.key.id,
            timeout: setTimeout(async () => {

                if (!global.tekateki[m.chat]) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⏳ WAKTU HABIS 〕━━━⬣
┃ Jawaban yang benar:
┃ ➜ *${soal.jawaban}*
┃
┃ 😌 Santai aja.
┃ Otak kadang perlu istirahat.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                })

                delete global.tekateki[m.chat]

            }, 60000)
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil soal Teka-Teki.")
    }
}

handler.before = async (m, {
    conn
}) => {

    if (!global.tekateki?.[m.chat]) return
    if (!m.quoted) return
    if (m.quoted.id !== global.tekateki[m.chat].messageId) return
    if (!m.text) return

    const session = global.tekateki[m.chat]
    const userAnswer = m.text.toLowerCase().trim()
    const correct = session.answer

    const normalize = str => str.replace(/\s+/g, "")

    if (normalize(userAnswer) === normalize(correct)) {

        clearTimeout(session.timeout)
        
        const user = global.db.get("user", m.sender);
        const rewardSaldo = Math.floor(Math.random() * 2000) + 1000;
        const rewardXp = Math.floor(Math.random() * 50) + 20;
        user.saldo = (user.saldo || 0) + rewardSaldo;
        user.xp = (user.xp || 0) + rewardXp;
        await global.db.save();

        await conn.sendMessage(m.chat, {
            text: `
╭━━━〔 🎉 BENAR! 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Status       : Tepat sekali 💯
┃
┃ 💰 Saldo     : +Rp${rewardSaldo.toLocaleString()}
┃ ✨ XP        : +${rewardXp}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
        })

        delete global.tekateki[m.chat]
        return
    }

    session.attempts--

    // Hampir benar (kalau beda 1 huruf)
    const similarity =
        Math.abs(normalize(userAnswer).length - normalize(correct).length)

    if (similarity <= 1) {
        return m.reply(`
🤏 Hampir benar!

Perhatikan ejaan atau tanda hubungnya.
Sisa kesempatan: ${session.attempts}
`)
    }

    if (session.attempts > 0) {
        return m.reply(`
❌ Salah!

Sisa kesempatan: ${session.attempts}
Coba pikir lagi pelan-pelan.
`)
    }

    clearTimeout(session.timeout)

    await conn.sendMessage(m.chat, {
        text: `
╭━━━〔 💀 GAME OVER 〕━━━⬣
┃ Jawaban kamu : ${m.text}
┃ Jawaban benar: ${correct}
┃
┃ 🔁 Kesempatan habis.
┃ Teka-teki memang suka menjebak.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
    })

    delete global.tekateki[m.chat]
}

handler.command = ["tekateki"]
handler.tags = ["game"]
handler.help = ["tekateki"]

export default handler