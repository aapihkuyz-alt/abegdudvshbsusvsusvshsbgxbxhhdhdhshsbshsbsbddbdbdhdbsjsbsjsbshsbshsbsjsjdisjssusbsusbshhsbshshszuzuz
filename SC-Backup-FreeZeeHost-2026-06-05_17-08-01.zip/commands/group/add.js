let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply("❌ Masukkan nomor.")

    let number = text.replace(/[^0-9]/g, "")
    if (!number) return m.reply("❌ Nomor tidak valid.")

    try {
        await conn.groupParticipantsUpdate(m.chat, [number + "@s.whatsapp.net"], "add")
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })
    } catch (e) {
        console.log(e)
        m.reply("❌ Gagal menambahkan.")
    }
}

handler.command = ["add"]
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler