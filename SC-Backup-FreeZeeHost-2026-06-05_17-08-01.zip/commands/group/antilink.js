let handler = async (m, { db, isAdmin, isOwner }) => {
  if (!m.isGroup) return

  let opt = (m.text || "").toLowerCase()
  if (!["--on", "--off"].includes(opt))
    return m.reply("⚠️ Gunakan:\n--on\n--off")

  let chat = db.get("group", m.chat) || {}

  if (opt === "--on") {
    chat.antilink = true
    db.set("group", m.chat, chat)
    return m.reply("✅ Anti Link diaktifkan")
  }

  if (opt === "--off") {
    chat.antilink = false
    db.set("group", m.chat, chat)
    return m.reply("❌ Anti Link dimatikan")
  }
}

handler.before = async (m, { conn, db, isAdmin, isOwner }) => {
  if (!m.isGroup) return
  if (isAdmin || isOwner) return
  if (!m.text) return

  let chat = db.get("group", m.chat)
  if (!chat?.antilink) return

  const linkRegex = /(https?:\/\/|www\.|chat\.whatsapp\.com)/i
  if (!linkRegex.test(m.text)) return

  await conn.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: false,
      id: m.key.id,
      participant: m.sender
    }
  })

  await conn.sendMessage(m.chat, {
    text: "🚫 *Anti Link Aktif*\nPesan berisi link telah dihapus."
  })
}

handler.command = ["antilink"]
handler.group = true
handler.admin = true

export default handler
