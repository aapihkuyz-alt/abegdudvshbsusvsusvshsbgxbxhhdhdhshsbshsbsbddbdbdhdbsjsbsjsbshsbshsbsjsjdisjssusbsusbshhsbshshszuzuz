let handler = async (m, { db, isAdmin, isOwner }) => {
  if (!m.isGroup) return

  let opt = (m.text || "").toLowerCase()
  if (!["--on", "--off"].includes(opt))
    return m.reply("⚠️ Gunakan:\n--on\n--off")

  let chat = db.get("group", m.chat) || {}

  if (opt === "--on") {
    chat.antitoxic = true
    db.set("group", m.chat, chat)
    return m.reply("✅ Anti Toxic diaktifkan")
  }

  if (opt === "--off") {
    chat.antitoxic = false
    db.set("group", m.chat, chat)
    return m.reply("❌ Anti Toxic dimatikan")
  }
}

handler.before = async (m, { conn, db, isAdmin, isOwner }) => {
  if (!m.isGroup) return
  if (isAdmin || isOwner) return
  if (!m.text) return

  let chat = db.get("group", m.chat)
  if (!chat?.antitoxic) return

  const toxicRegex = /(babi|anjing|bangsat|kontol|ngentot|memek|jembut|asu)/i
  if (!toxicRegex.test(m.text)) return

  await conn.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      fromMe: false,
      id: m.key.id,
      participant: m.sender
    }
  })

  await conn.sendMessage(m.chat, {
    text: "🚫 *Anti Toxic Aktif*\nTolong jaga ketikanmu di grup ini!",
    mentions: [m.sender]
  })
}

handler.command = ["antitoxic"]
handler.group = true
handler.admin = true

export default handler
