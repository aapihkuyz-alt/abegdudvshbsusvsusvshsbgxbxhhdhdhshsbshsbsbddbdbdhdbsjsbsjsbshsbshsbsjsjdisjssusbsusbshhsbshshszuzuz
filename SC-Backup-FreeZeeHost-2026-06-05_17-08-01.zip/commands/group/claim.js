/**
 * CLAIM AIRDROP
 * Fitur untuk mengambil kotak harta karun yang jatuh di grup.
 */
let handler = async (m, { conn, db }) => {
    global.activeAirdrops = global.activeAirdrops || new Map();
    const prize = global.activeAirdrops.get(m.chat);

    if (!prize) return m.reply("❌ Tidak ada airdrop aktif di grup ini, Bang. Tunggu kotak jatuh ya!");

    let user = db.get("user", m.sender);
    
    // Berikan Hadiah
    if (prize.type === 'saldo') {
        user.saldo = (user.saldo || 0) + prize.val;
        m.reply(`🎉 *HOREEE!*\n\n@${m.sender.split('@')[0]} berhasil mengklaim airdrop!\n🎁 Hadiah: *${prize.name}*\n\nSaldo Bang sekarang: Rp ${user.saldo.toLocaleString()}`, null, { mentions: [m.sender] });
    } else if (prize.type === 'xp') {
        user.xp = (user.xp || 0) + prize.val;
        m.reply(`🎉 *HOREEE!*\n\n@${m.sender.split('@')[0]} berhasil mengklaim airdrop!\n🎁 Hadiah: *${prize.name}*\n\nTerus kumpulkan XP untuk naik level!`, null, { mentions: [m.sender] });
    }

    // Hapus Airdrop setelah di-claim
    global.activeAirdrops.delete(m.chat);
    await db.save();
    await m.react("🎁");
};

handler.help = ["claim"];
handler.tags = ["group"];
handler.command = /^(claim)$/i;
handler.group = true;

export default handler;
