let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("Masukkan link invite.")

    try {
        const code = text.split("https://chat.whatsapp.com/")[1]
        if (!code) return m.reply("❌ Link tidak valid.")

        const info = await conn.groupGetInviteInfo(code)

        m.reply(`📋 Group Info:

Nama: ${info.subject}
ID: ${info.id}
Member: ${info.size}

Deskripsi:
${info.desc || "-"}`)

    } catch {
        m.reply("❌ Gagal mengambil metadata.")
    }
}

handler.command = ["ginfo", "detailgc"]
handler.tags = ["group"]
export default handler