import { proto, generateWAMessageFromContent } from "baileys";

let handler = async (m, { conn, isAdmin, isOwner, usedPrefix, command, text }) => {
    if (!m.isGroup) return m.reply("Fitur ini hanya untuk grup.")
    
    // Logic untuk memproses aksi dari tombol
    if (text) {
        if (!isAdmin && !isOwner) return m.reply("Khusus Admin!")
        
        if (text === 'open') {
            await conn.groupSettingUpdate(m.chat, 'not_announcement')
            return m.reply("✅ Grup berhasil **DIBUKA**. Sekarang member bisa mengirim pesan.")
        }
        if (text === 'close') {
            await conn.groupSettingUpdate(m.chat, 'announcement')
            return m.reply("✅ Grup berhasil **DITUTUP**. Sekarang hanya admin yang bisa mengirim pesan.")
        }
        if (text === 'link') {
            let link = await conn.groupInviteCode(m.chat)
            return m.reply(`https://chat.whatsapp.com/${link}`)
        }
    }

    let metadata = await conn.groupMetadata(m.chat)
    let caption = `
╔══  「 📢 *GROUP CONTROL* 」
║ ◦ *Nama:* ${metadata.subject}
║ ◦ *Member:* ${metadata.participants.length}
║ ◦ *Status:* ${metadata.announce ? '🔒 Tertutup' : '🔓 Terbuka'}
╚══════════════════

Gunakan tombol di bawah untuk mengontrol akses grup dengan cepat.`.trim()

    const msg = generateWAMessageFromContent(m.chat, {
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Admin Quick Tools" }),
            header: proto.Message.InteractiveMessage.Header.fromObject({ title: "💠 CONTROL PANEL", hasMediaAttachment: false }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔓 BUKA GRUP", id: `${usedPrefix}${command} open` }) },
                    { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔒 TUTUP GRUP", id: `${usedPrefix}${command} close` }) },
                    { name: "quick_reply", buttonParamsJson: JSON.stringify({ display_text: "🔗 LINK GRUP", id: `${usedPrefix}${command} link` }) }
                ]
            })
        })
    }, { quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ["gc", "groupinfo"]
handler.tags = ["group"]
handler.command = ["gc", "groupinfo", "control"]
handler.group = true
handler.admin = true

export default handler
