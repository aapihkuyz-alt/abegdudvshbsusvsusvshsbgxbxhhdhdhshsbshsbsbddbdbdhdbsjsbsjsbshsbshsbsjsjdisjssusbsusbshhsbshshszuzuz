import { generateWAMessageFromContent, proto } from "baileys";

let handler = async (m, { conn, text, usedPrefix, command, db, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Khusus grup, Bang.");
    if (!isAdmin && !isOwner) return m.reply("❌ Hanya admin yang bisa akses Panel Kontrol.");

    const group = db.get("group", m.chat);
    if (!group) return m.reply("❌ Data grup tidak ditemukan.");

    // --- LOGIKA UPDATE SETTING (TRIGGER DARI BUTTON) ---
    if (text) {
        const [setting, value] = text.split('|');
        if (typeof group[setting] !== 'undefined') {
            group[setting] = value === 'true';
            await db.save();
            await m.react("✅");
            // Lanjut tampilkan menu yang sudah diupdate
        }
    }

    const status = (bool) => bool ? "✅ ON" : "❌ OFF";

    let menuText = `╭─❍ *GROUP ADMIN PANEL* ❍─
│
│ 📝 *Grup:* ${m.groupMetadata?.subject || "Grup"}
│ 🛡️ *Status Keamanan:*
│
├─────────────────────
│ 🔗 *Antilink:* ${status(group.antilink)}
│ 🕵️ *AI Warden:* ${status(group.antitoxic)}
│ 🚫 *Anti-Scam:* ${status(group.antiscam)}
│ 🌍 *Anti-VN:* ${status(group.antivn_number)}
│ 👋 *Welcome:* ${status(group.welcome)}
│ 🤖 *Auto-AI:* ${status(group.autoAi)}
├─────────────────────
│ 📌 *Klik tombol di bawah*
│ untuk menyalakan/mematikan fitur.
╰─────────────────────❍`;

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({ text: menuText }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: global.botname }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: group.antilink ? "OFF Antilink" : "ON Antilink",
                                    id: `${usedPrefix + command} antilink|${!group.antilink}`
                                })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: group.antitoxic ? "OFF Warden" : "ON Warden",
                                    id: `${usedPrefix + command} antitoxic|${!group.antitoxic}`
                                })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: group.welcome ? "OFF Welcome" : "ON Welcome",
                                    id: `${usedPrefix + command} welcome|${!group.welcome}`
                                })
                            }
                        ]
                    })
                })
            }
        }
    }, { quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.help = ["gcset", "adminpanel"];
handler.tags = ["group", "admin"];
handler.command = /^(gcset|adminpanel|settings)$/i;
handler.group = true;

export default handler;