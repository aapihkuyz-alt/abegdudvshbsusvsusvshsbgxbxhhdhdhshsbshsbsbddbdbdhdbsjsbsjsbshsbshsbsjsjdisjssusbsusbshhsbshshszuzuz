let handler = async (m, {
    conn,
    text
}) => {
    let groupMetadata = await conn.groupMetadata(m.chat)
    let participants = groupMetadata.participants.map(v => v.id)

    if (!text) return m.reply('Teksnya mana?')

    conn.sendMessage(m.chat, {
        text,
        mentions: participants
    }, {
        quoted: m
    })
}

handler.help = ['hidetag']
handler.tags = ['group']
handler.command = /^(hidetag|ht)$/i
handler.group = true
handler.admin = true

export default handler