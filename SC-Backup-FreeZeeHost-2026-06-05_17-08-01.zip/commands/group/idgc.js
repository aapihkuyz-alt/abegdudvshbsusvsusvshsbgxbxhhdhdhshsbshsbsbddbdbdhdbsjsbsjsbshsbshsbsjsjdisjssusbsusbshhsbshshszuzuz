let handler = async (m, {
    conn,
    command
}) => {
    if (!m.isGroup)
        return m.reply("❌ Fitur ini cuma bisa dipakai di dalam grup.")

    try {
        const groupId = m.chat

        const buttons = [{
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
                display_text: "📋 Salin ID Grup",
                copy_code: groupId
            })
        }]

        const text = `
🆔 *GROUP ID CHECK*

Ini ID unik buat grup ini 👇

\`\`\`
${groupId}
\`\`\`

Pencet tombol di bawah kalau mau langsung nyalin.
`.trim()

        await conn.sendMessage(
            m.chat, {
                text,
                footer: "Simple • Cepat • Anti Ribet",
                interactiveButtons: buttons
            }, {
                quoted: m
            }
        )

    } catch (e) {
        console.error("IDGC ERROR:", e)
        m.reply("⚠️ Gagal ambil ID grup. Coba lagi bentar.")
    }
}

handler.command = ["idgc", "cekidgc"]
handler.tags = ["group"]
handler.help = ["idgc"]
handler.group = true

export default handler