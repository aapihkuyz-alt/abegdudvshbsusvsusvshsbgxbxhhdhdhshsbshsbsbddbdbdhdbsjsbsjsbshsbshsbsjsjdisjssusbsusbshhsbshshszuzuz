import axios from "axios";

let handler = async (m, { conn, db, store }) => {
    if (!m.isGroup) return m.reply("❌ Khusus grup, Bang.");
    
    await m.react("👁️");
    await m.reply("🕵️ *The Oracle sedang melihat sejarah and jiwa grup ini...* \n_Menganalisa pola perilaku and energi member._");

    try {
        // 1. Ambil riwayat chat yang lebih banyak (100 pesan)
        const messages = store.messages[m.chat].array.slice(-100);
        
        let chatData = "";
        messages.forEach(msg => {
            const sender = msg.pushName || msg.key.participant?.split("@")[0] || "User";
            const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || "";
            if (text && !text.startsWith(".") && !text.startsWith("#")) {
                chatData += `${sender}: ${text}\n`;
            }
        });

        if (!chatData) return m.reply("❌ Sejarah chat tidak cukup untuk di-analisa.");

        // 2. Tanya AI untuk analisa psikologis grup
        const query = `Analisa kepribadian grup WhatsApp ini berdasarkan sejarah chat berikut. 
Tentukan:
1. Nama Vibe (Misal: Warung Kopi Santai, Markas Pro koding, dll).
2. Siapa "Leader" (yang paling dominan/bijak).
3. Siapa "Clown" (yang paling lucu/random).
4. Siapa "Toxic" (jika ada).
5. Topik utama yang sering dibahas.
Jawab dalam bahasa Indonesia yang sangat gaul, santai, and berikan sedikit ramalan untuk masa depan grup ini. (Panggil "Bang").

Chat Data:
${chatData}`;
        
        const { data } = await axios.get("https://api.neoxr.eu/api/gpt4-session", {
            params: {
                q: query,
                session: "oracle_" + m.chat.split("@")[0],
                apikey: global.neoxr
            },
            timeout: 60000
        });

        if (!data?.status || !data.data?.message) throw new Error("The Oracle sedang bermeditasi.");

        let result = `🔮 *[ THE ORACLE INSIGHT ]* 🔮\n\n` +
                     `${data.data.message}\n\n` +
                     `_The Oracle has spoken._`;

        await m.reply(result);
        await m.react("✨");

    } catch (e) {
        console.error("Oracle Error:", e.message);
        m.reply("❌ *[ ERROR ]* The Oracle gagal melihat masa depan. Mungkin energi grup terlalu kacau.");
        await m.react("❌");
    }
};

handler.help = ["oracle", "insight"];
handler.tags = ["group", "ai"];
handler.command = /^(oracle|insight|cekjiwa)$/i;
handler.group = true;
handler.premium = true;

export default handler;