let handler = async (m, {
    conn,
    args,
    isAdmin,
    isBotAdmin
}) => {

    if (!m.isGroup)
        return m.reply("❌ Fitur ini hanya untuk grup.")

    if (!isAdmin)
        return m.reply("❌ Hanya admin yang bisa pin pesan.")

    if (!isBotAdmin)
        return m.reply("❌ Bot harus jadi admin dulu.")

    if (!m.message?.extendedTextMessage?.contextInfo?.quotedMessage)
        return m.reply("❌ Reply pesan yang ingin dipin.")

    const context = m.message.extendedTextMessage.contextInfo

    const key = {
        remoteJid: m.chat,
        fromMe: context.participant === conn.user.id,
        id: context.stanzaId,
        participant: context.participant
    }

    // ===== UNPIN =====
    if (args[0]?.toLowerCase() === "off") {
        await conn.sendMessage(m.chat, {
            pin: {
                type: 2,
                key
            }
        })
        return m.reply("📌 Pesan berhasil di-unpin.")
    }

    // ===== PARSE TIME =====
    let time = 86400 // default 24 jam

    if (args[0]) {
        let input = args[0].toLowerCase()

        if (input.endsWith("d")) {
            let day = parseInt(input)
            if (!isNaN(day)) time = day * 86400
        } else {
            let num = parseInt(input)
            if (!isNaN(num)) {
                if (num <= 7) {
                    time = num * 86400
                } else {
                    time = num * 3600
                }
            }
        }
    }

    try {

        await conn.sendMessage(m.chat, {
            pin: {
                type: 1,
                time: time,
                key
            }
        })

        await conn.sendReact(m.chat, "📌", m.key)

    } catch (err) {
        console.log("PIN ERROR:", err)
        m.reply("❌ Gagal pin pesan.")
    }
}

handler.command = ["pin", "pinmsg"]
handler.tags = ["group"]
handler.help = ["pin", "pin 7", "pin 30d", "pin off"]

export default handler