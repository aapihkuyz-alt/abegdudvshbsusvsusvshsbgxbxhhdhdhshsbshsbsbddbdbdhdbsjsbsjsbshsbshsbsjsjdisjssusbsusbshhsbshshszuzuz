let handler = async (m, {
    conn,
    text
}) => {

    let users = []

    if (m.quoted) users.push(m.quoted.sender)
    if (m.mentionedJid?.length) users = users.concat(m.mentionedJid)

    if (text) {
        let number = text.replace(/[^0-9]/g, "")
        if (number) users.push(number + "@s.whatsapp.net")
    }

    users = [...new Set(users)]
    if (!users.length) return m.reply("❌ Target tidak ditemukan.")

    try {
        await conn.groupParticipantsUpdate(m.chat, users, "promote")
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })
    } catch (e) {
        console.log(e)
        m.reply("❌ Gagal promote.")
    }
}

handler.command = ["promote"]
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler