import croner from "croner";
import moment from "moment-timezone";

let handler = async (m, { conn, text, usedPrefix, command, db, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Khusus grup, Bang.");
    if (!isAdmin && !isOwner) return m.reply("❌ Hanya admin yang bisa set pengingat.");

    const group = db.get("group", m.chat);
    if (!group.reminders) group.reminders = [];

    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} 20:00 | Mabar ML* \n(Format: HH:mm | Pesan)`);

    let [time, ...msgArr] = text.split("|");
    let msg = msgArr.join("|").trim();
    time = time.trim();

    if (!time || !msg) return m.reply(`📌 Contoh: *${usedPrefix + command} 20:00 | Mabar ML*`);

    // Validasi format waktu
    if (!/^([01]\d|2[0-3]):([0-5]\d)$/.test(time)) return m.reply("❌ Format waktu salah! Gunakan HH:mm (24 jam). Contoh: 20:30");

    const [hour, minute] = time.split(":").map(Number);
    
    // Set reminder di database
    const reminderId = Date.now().toString(36);
    group.reminders.push({
        id: reminderId,
        time,
        message: msg,
        creator: m.sender
    });

    await db.save();

    // Jalankan Cron Job
    croner(`${minute} ${hour} * * *`, { timezone: "Asia/Jakarta" }, async () => {
        // Cek apakah grup masih ada dan reminder belum dihapus
        const currentGroup = db.get("group", m.chat);
        if (currentGroup && currentGroup.reminders?.find(r => r.id === reminderId)) {
            const metadata = await conn.groupMetadata(m.chat);
            const participants = metadata.participants.map(v => v.id);
            
            const announce = `🔔 *GROUP REMINDER* 🔔\n\n📢 *Pesan:* ${msg}\n⏰ *Waktu:* ${time} WIB\n\nCc: @all`;
            
            await conn.sendMessage(m.chat, { 
                text: announce,
                contextInfo: { 
                    mentionedJid: participants,
                    forwardingScore: 999,
                    isForwarded: true
                }
            });
        }
    });

    await m.reply(`✅ *Reminder Berhasil Diset!* \nSetiap hari jam *${time}* bot akan nge-tag se-grup untuk: \n\n> ${msg}`);
};

handler.help = ["remind", "ingatkan"];
handler.tags = ["group"];
handler.command = /^(remind|ingatkan|setalarm)$/i;
handler.group = true;

export default handler;