let handler = async (m, {
    conn,
    text
}) => {

    if (!text) {
        return m.reply("❌ Masukkan deskripsi baru.\n\nContoh:\n#setdesc Grup paling santai se-WhatsApp")
    }

    try {

        await conn.groupUpdateDescription(m.chat, text)

        m.reply("✅ Deskripsi grup berhasil diperbarui.")

    } catch (err) {
        console.error(err)
        m.reply("❌ Gagal mengubah deskripsi grup.")
    }
}

handler.command = ["setdescgc", "setdeskgc", "sdgc"]
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler