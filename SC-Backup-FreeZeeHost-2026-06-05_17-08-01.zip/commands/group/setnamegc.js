let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("❌ Masukkan judul baru.")

    try {
        await conn.groupUpdateSubject(m.chat, text)
        m.reply("✅ Judul grup diperbarui.")
    } catch {
        m.reply("❌ Gagal.")
    }
}

handler.command = ["setsubject", "setnamegc"]
handler.admin = true
handler.botAdmin = true
handler.tags = ["group"]
export default handler