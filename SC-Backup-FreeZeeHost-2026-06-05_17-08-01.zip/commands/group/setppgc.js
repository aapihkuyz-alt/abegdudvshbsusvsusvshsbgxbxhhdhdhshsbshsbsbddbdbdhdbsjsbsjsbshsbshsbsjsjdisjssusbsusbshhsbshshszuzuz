import axios from "axios"
import sharp from "sharp"

let handler = async (m, {
    conn,
    args
}) => {

    try {

        if (args[0] === "remove") {
            await conn.removeProfilePicture(m.chat)
            return m.reply("✅ Foto grup berhasil dihapus.")
        }

        let media

        if (args[0] && args[0].startsWith("http")) {
            const res = await axios.get(args[0], {
                responseType: "arraybuffer"
            })
            media = res.data
        } else if (m.quoted) {
            const type = Object.keys(m.quoted.message || {})[0]

            if (type !== "imageMessage")
                return m.reply("❌ Reply foto asli.")

            media = await m.quoted.download()
        } else {
            return m.reply("Reply foto atau kirim URL.\n#setppgc remove untuk hapus.")
        }

        const optimized = await sharp(media)
            .resize(720, 720, {
                fit: "cover"
            })
            .jpeg({
                quality: 100
            })
            .toBuffer()

        await conn.updateProfilePicture(m.chat, optimized)

        m.reply("✅ Foto grup berhasil diperbarui.")

    } catch (err) {
        console.error(err)
        m.reply("❌ Gagal mengganti foto grup.")
    }
}

handler.command = ["setppgc"]
handler.group = true
handler.admin = true
handler.botAdmin = true

export default handler