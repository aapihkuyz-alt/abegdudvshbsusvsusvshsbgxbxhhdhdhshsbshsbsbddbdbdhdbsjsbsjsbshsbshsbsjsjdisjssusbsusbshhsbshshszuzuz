import { proto, generateWAMessageFromContent } from "baileys";

let handler = async (m, { conn, db, isAdmin, isOwner, usedPrefix, command, text }) => {
    if (!m.isGroup) return m.reply("Fitur ini hanya dapat digunakan di dalam grup.")
    
    let chat = db.get("group", m.chat)
    if (!chat) return m.reply("Data grup tidak ditemukan.")

    // Jika ada input (berasal dari klik button)
    if (text) {
        if (!isAdmin && !isOwner) return m.reply("Khusus Admin Grup!")
        
        let [feature, status] = text.split('|')
        if (feature && status) {
            chat[feature] = status === 'on'
            await db.save()
            return m.reply(`✅ Fitur *${feature.toUpperCase()}* berhasil di *${status === 'on' ? 'AKTIFKAN' : 'MATIKAN'}* untuk grup ini.`)
        }
    }

    // Tampilan Dashboard Utama (Pake Button sesuai prinsip)
    const status = (feat) => chat[feat] ? "✅ ON" : "❌ OFF"

    let caption = `
╔══  「 ⚙️ *GROUP SETTINGS* 」
║ ◦ *Group:* ${m.metadata?.subject || 'Grup'}
╠══════════════════
║ 🛠️ *Fitur Aktif:*
║ ◦ Anti Link: ${status('antilink')}
║ ◦ Anti Toxic: ${status('antitoxic')}
║ ◦ Welcome: ${status('welcome')}
║ ◦ Detect: ${status('detect')}
║ ◦ Auto AI: ${status('autoAi')}
║ ◦ Anti Spam: ${status('antispam')}
╚══════════════════

_Silakan klik tombol di bawah untuk mengubah pengaturan._`.trim()

    const msg = generateWAMessageFromContent(m.chat, {
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: caption
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: "Power by " + global.botname
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: "💠 DASHBOARD ADMIN",
                hasMediaAttachment: false
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "🔧 KONTROL FITUR",
                            sections: [{
                                title: "PENGATURAN GRUP",
                                rows: [
                                    { header: "Anti Link", title: "Toggle Anti Link", description: "Hapus otomatis link yang dikirim member", id: `${usedPrefix}${command} antilink|${chat.antilink ? 'off' : 'on'}` },
                                    { header: "Anti Toxic", title: "Toggle Anti Toxic", description: "Hapus otomatis kata kasar", id: `${usedPrefix}${command} antitoxic|${chat.antitoxic ? 'off' : 'on'}` },
                                    { header: "Welcome", title: "Toggle Welcome Message", description: "Pesan sambutan member baru", id: `${usedPrefix}${command} welcome|${chat.welcome ? 'off' : 'on'}` },
                                    { header: "Detect", title: "Toggle Detect", description: "Notifikasi perubahan admin/grup", id: `${usedPrefix}${command} detect|${chat.detect ? 'off' : 'on'}` },
                                    { header: "Auto AI", title: "Toggle Auto AI", description: "Respon otomatis AI di grup", id: `${usedPrefix}${command} autoAi|${chat.autoAi ? 'off' : 'on'}` },
                                    { header: "Anti Spam", title: "Toggle Anti Spam", description: "Batasi member yang spam perintah", id: `${usedPrefix}${command} antispam|${chat.antispam ? 'off' : 'on'}` }
                                ]
                            }]
                        })
                    }
                ]
            }),
            contextInfo: {
                mentionedJid: [m.sender]
            }
        })
    }, { quoted: m })

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })
}

handler.help = ["setting", "groupmode"]
handler.tags = ["group"]
handler.command = ["setting", "groupmode", "set"]
handler.group = true
handler.admin = true // Default hanya admin yang bisa buka menu setting

export default handler
