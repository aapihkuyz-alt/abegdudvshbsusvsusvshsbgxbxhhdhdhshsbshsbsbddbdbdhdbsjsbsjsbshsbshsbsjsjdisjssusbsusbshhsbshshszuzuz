import axios from "axios";

let handler = async (m, { conn, db, usedPrefix, command, store }) => {
    if (!m.isGroup) return m.reply("❌ Khusus grup, Bang.");
    
    await m.react("⏳");
    await m.reply("🧠 *Sedang membaca and merangkum obrolan grup...* \n_Mohon tunggu sebentar._");

    try {
        // 1. Ambil riwayat chat terakhir (50-100 pesan)
        const messages = store.messages[m.chat].array.slice(-50);
        
        if (messages.length < 5) return m.reply("❌ Belum cukup banyak obrolan untuk dirangkum.");

        let chatHistory = "";
        messages.forEach(msg => {
            const sender = msg.pushName || msg.key.participant?.split("@")[0] || "User";
            const text = msg.message?.conversation || msg.message?.extendedTextMessage?.text || "";
            if (text && !text.startsWith(".") && !text.startsWith("#")) {
                chatHistory += `${sender}: ${text}\n`;
            }
        });

        if (!chatHistory) return m.reply("❌ Tidak ditemukan obrolan teks yang bisa dirangkum.");

        // 2. Kirim ke AI GPT-4 Session (Neoxr)
        const query = `Rangkum obrolan grup berikut dalam bahasa Indonesia yang santai and gaul (panggil "Bang"). Sebutkan poin-poin penting and siapa saja yang sedang dibahas. \n\nObrolan:\n${chatHistory}`;
        
        const { data } = await axios.get("https://api.neoxr.eu/api/gpt4-session", {
            params: {
                q: query,
                session: "sum_" + m.chat.split("@")[0],
                apikey: global.neoxr
            },
            timeout: 60000
        });

        if (!data?.status || !data.data?.message) throw new Error("AI Gagal merespon.");

        let result = `╭─❍ *GROUP CHAT SUMMARY* ❍─\n│\n` +
                     `📝 *Poin Penting:* \n${data.data.message}\n` +
                     `│\n` +
                     `╰─────────────────────❍`;

        await m.reply(result);
        await m.react("✅");

    } catch (e) {
        console.error("Summarizer Error:", e.message);
        m.reply("❌ *[ ERROR ]* Gagal merangkum obrolan. Mungkin chat terlalu panjang atau server AI sibuk.");
        await m.react("❌");
    }
};

handler.help = ["rangkum", "summary"];
handler.tags = ["group", "ai"];
handler.command = /^(rangkum|summary|sum)$/i;
handler.group = true;
handler.limit = true;

export default handler;