let handler = async (m, {
    conn,
    text
}) => {
    if (!m.isGroup) return

    let metadata
    try {
        metadata = await conn.groupMetadata(m.chat)
    } catch (e) {
        return m.reply('❌ Gagal mengambil data grup')
    }

    let participants = metadata.participants || []
    if (!participants.length) return m.reply('❌ Tidak ada participant')

    let teks = `◇───── Tag All ─────◇
乂 *Pesan : ${text || 'kosong'}*\n\n`

    let mentions = []

    for (let p of participants) {
        if (!p?.jid) continue
        teks += `• @${p.jid.split('@')[0]}\n`
        mentions.push(p.jid)
    }

    await conn.sendMessage(
        m.chat, {
            text: teks,
            mentions
        }, {
            quoted: m
        }
    )
}

handler.help = ['tagall']
handler.tags = ['group']
handler.command = ['tagall']
handler.admin = true
handler.group = true

export default handler