let handler = async (m, { conn, db, usedPrefix }) => {
    if (!m.isGroup) return m.reply("❌ Perintah ini hanya bisa digunakan di dalam grup.");
    
    const group = db.get("group", m.chat);
    if (!group || !group.memberStats) return m.reply("📊 Data statistik grup belum tersedia.");

    // Ambil data dan urutkan
    const sorted = Object.entries(group.memberStats)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 10); // Ambil 10 teratas

    if (sorted.length === 0) return m.reply("📊 Belum ada data aktivitas di grup ini.");

    let report = `╭─❍ *TOP 10 ACTIVE MEMBERS* ❍─
│
│ Grup: ${m.groupMetadata?.subject || "Grup"}
│ Total Data: ${Object.keys(group.memberStats).length} User
│
├─────────────────────\n`;

    sorted.forEach(([jid, count], i) => {
        const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "👤";
        report += `│ ${medal} *${i + 1}.* @${jid.split("@")[0]}\n│    ┗ 💬 *${count}* pesan\n`;
    });

    report += `\n╰─────────────────────❍`;

    await conn.sendMessage(m.chat, { 
        text: report, 
        contextInfo: { 
            mentionedJid: sorted.map(v => v[0]),
            forwardingScore: 999,
            isForwarded: true
        } 
    }, { quoted: m });
};

handler.help = ["topactive", "top"];
handler.tags = ["group"];
handler.command = /^(topactive|top)$/i;
handler.group = true;

export default handler;