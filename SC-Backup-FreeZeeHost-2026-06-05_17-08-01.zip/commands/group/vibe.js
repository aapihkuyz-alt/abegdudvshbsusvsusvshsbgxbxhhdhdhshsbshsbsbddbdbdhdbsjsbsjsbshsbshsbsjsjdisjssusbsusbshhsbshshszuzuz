let handler = async (m, { db }) => {
    if (!m.isGroup) return m.reply("❌ Khusus grup, Bang.");
    
    const group = db.get("group", m.chat);
    if (!group || !group.sentiment) return m.reply("📊 Data vibe belum tersedia.");

    const vibe = group.sentiment.vibe;
    const score = group.sentiment.score;
    
    let emoji = "🧘";
    if (vibe.includes("Happy")) emoji = "🥳";
    if (vibe.includes("Toxic")) emoji = "💀";

    let report = `╭─❍ *GROUP VIBE CHECK* ❍─
│
│ 🎭 *Status:* ${vibe}
│ 📊 *Mood Score:* ${score}
│ 💡 *Condition:* ${score > 20 ? "Grup sangat kondusif and asik!" : score < -20 ? "Hati-hati, tensi grup lagi tinggi." : "Grup dalam keadaan stabil."}
│
╰─────────────────────❍`;

    await m.reply(report);
};

handler.help = ["vibe", "mood"];
handler.tags = ["group"];
handler.command = /^(vibe|mood|cekgroup)$/i;
handler.group = true;

export default handler;