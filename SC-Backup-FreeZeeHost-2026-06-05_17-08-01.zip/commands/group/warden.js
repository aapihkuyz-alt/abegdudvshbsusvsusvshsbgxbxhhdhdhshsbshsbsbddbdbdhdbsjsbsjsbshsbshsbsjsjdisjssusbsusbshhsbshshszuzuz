let handler = async (m, { db, text, isAdmin, isOwner }) => {
    if (!m.isGroup) return m.reply("❌ Khusus grup, Bang.");
    if (!isAdmin && !isOwner) return m.reply("❌ Hanya admin yang bisa mengaktifkan Warden.");

    let group = db.get("group", m.chat);
    if (!text) return m.reply(`📌 Contoh: *.warden on* atau *off*`);

    if (text === "on") {
        group.antitoxic = true;
        await db.save();
        m.reply("🛡️ *[ WARDEN ACTIVE ]* \nAI Smart Moderator telah diaktifkan. Bot akan memantau konteks chat dan menindak user toxic secara otomatis.");
    } else if (text === "off") {
        group.antitoxic = false;
        await db.save();
        m.reply("🔓 *[ WARDEN INACTIVE ]* \nAI Smart Moderator telah dimatikan.");
    } else {
        m.reply(`📌 Contoh: *.warden on* atau *off*`);
    }
};

handler.help = ["warden on/off"];
handler.tags = ["group", "admin"];
handler.command = /^(warden|antitoxic)$/i;
handler.group = true;

export default handler;