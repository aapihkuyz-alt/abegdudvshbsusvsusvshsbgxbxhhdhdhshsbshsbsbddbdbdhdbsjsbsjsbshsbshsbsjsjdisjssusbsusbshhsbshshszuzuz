let handler = async (m, { conn }) => {
    try {

        if (!global.noowner) {
            return m.reply("Nomor owner belum diset di global.noowner")
        }

        // React proses
        await conn.sendMessage(m.chat, {
            react: { text: "📞", key: m.key }
        })

        // Bersihin nomor (hapus +, spasi, dll)
        const cleanNumber = global.noowner.replace(/[^0-9]/g, "")

        const native_flow_button = [{
            name: 'cta_call',
            buttonParamsJson: JSON.stringify({
                display_text: '📞 Telepon Owner',
                phone_number: cleanNumber
            })
        }]

        await conn.sendMessage(m.chat, {
            text: "Butuh bantuan?\nKlik tombol di bawah untuk langsung menghubungi owner.",
            footer: global.ownername || "Bot System",
            nativeFlowMessage: {
                buttons: native_flow_button
            }
        }, { quoted: m })

        // React sukses
        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (err) {
        console.error("CALL OWNER ERROR:", err)

        await conn.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })

        m.reply("❌ Gagal membuat tombol telepon.")
    }
}

handler.command = ["callowner", "telponowner"]
handler.tags = ["tools"]
handler.help = ["callowner"]

export default handler