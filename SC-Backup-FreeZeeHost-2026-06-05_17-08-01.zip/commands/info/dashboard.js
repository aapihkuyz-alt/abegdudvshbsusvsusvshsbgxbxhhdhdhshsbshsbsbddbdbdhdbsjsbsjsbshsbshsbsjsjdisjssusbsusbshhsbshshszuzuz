import os from 'os';
import moment from 'moment-timezone';
import TaskQueue from '../../core/queue.js';

const handler = async (m, { conn, Func, db }) => {
    const ramUsed = (process.memoryUsage().rss / 1024 / 1024).toFixed(2);
    const totalRam = (os.totalmem() / 1024 / 1024).toFixed(2);
    const cpuLoad = os.loadavg()[0].toFixed(2);
    const uptime = Func.toTime(process.uptime() * 1000);
    const speed = ((Date.now() - m.timestamps) / 1000).toFixed(3);
    const queueStats = (TaskQueue && typeof TaskQueue.getStats === 'function') ? TaskQueue.getStats() : { pending: 0, active: 0 };
    
    // Process Stats
    const settings = db.list().settings || {};
    const stats = settings.stats || {};
    const topCommands = Object.entries(stats)
        .sort((a, b) => b[1].count - a[1].count)
        .slice(0, 5)
        .map(([name, data], i) => `┃ ${i+1}. ${name.padEnd(12)} : ${data.count}x`)
        .join('\n');

    const dashboard = `
╭━━━〔 📊 *PRO DASHBOARD* 〕━━━⬣
┃ 🤖 *Bot Name:* ${global.botname}
┃ 🛰 *Status:* Online & Armed
┃ ⏱ *Uptime:* ${uptime}
┃ ⚡ *Response:* ${speed}s
┣━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 💻 *SYSTEM STATS*
┃ 🧠 *RAM:* ${ramUsed} / ${totalRam} MB
┃ 🧬 *CPU:* ${cpuLoad}%
┃ 📦 *Node:* ${process.version}
┃ 📍 *OS:* ${os.platform()}
┣━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 🛠 *TASK QUEUE*
┃ 📥 *Pending:* ${queueStats.pending}
┃ ⚙️ *Active:* ${queueStats.active}
┣━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 🏆 *TOP 5 COMMANDS*
${topCommands || '┃ Belum ada data statistik.'}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim();

    await conn.sendMessage(m.chat, {
        text: dashboard
    }, { quoted: m });
};

handler.help = ['dashboard', 'stats'];
handler.tags = ['info'];
handler.command = ['dashboard', 'stats', 'statusbot'];

export default handler;
