import os from "os";
import {
    exec
} from "child_process";
import {
    promisify
} from "util";
import performance from "performance-now";
import {
    createCanvas
} from "canvas";

const execAsync = promisify(exec);

/* ===================== UTIL ===================== */
const formatSize = b => {
    if (!b) return "0 B";
    const u = ["B", "KB", "MB", "GB", "TB"];
    const i = Math.floor(Math.log(b) / Math.log(1024));
    return (b / 1024 ** i).toFixed(2) + " " + u[i];
};
const formatDuration = s => {
    s = Number(s);
    const d = Math.floor(s / 86400);
    const h = Math.floor(s % 86400 / 3600);
    const m = Math.floor(s % 3600 / 60);
    const sc = Math.floor(s % 60);
    return d ? `${d}d ${h}h ${m}m` : h ? `${h}h ${m}m` : `${m}m ${sc}s`;
};

/* ===================== SHAPE ===================== */
function roundedRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

/* ===================== DATA ===================== */
const getOSRelease = async () => {
    try {
        const {
            stdout
        } = await execAsync("cat /etc/os-release | grep PRETTY_NAME");
        return stdout.split("=")[1].replace(/"/g, "").trim();
    } catch {
        return `${os.type()} ${os.release()}`;
    }
};

const getDiskDetails = async () => {
    try {
        const {
            stdout
        } = await execAsync("df -h --output=source,size,used,avail,pcent,target");
        return stdout.trim().split("\n").slice(1)
            .filter(l => (l.includes("/dev/loop") || l.endsWith(" /")) && !l.includes("tmpfs"))
            .map(l => {
                const p = l.trim().split(/\s+/);
                return {
                    source: p[0],
                    total: p[1],
                    used: p[2],
                    avail: p[3],
                    percent: parseFloat(p[4]),
                    mount: p[5]
                };
            });
    } catch {
        return [];
    }
};

const getMemoryDetails = async () => {
    const total = os.totalmem(),
        free = os.freemem(),
        used = total - free;
    let swap = {
            total: 0,
            used: 0
        },
        extra = "";
    try {
        const {
            stdout
        } = await execAsync("free -h");
        const l = stdout.split("\n").find(v => v.startsWith("Mem:"));
        if (l) {
            const p = l.split(/\s+/);
            extra = `Buffers ${p[5]}  Cache ${p[6]}`;
        }
    } catch {}
    try {
        const {
            stdout
        } = await execAsync("free -b");
        const l = stdout.split("\n").find(v => v.includes("Swap:"));
        if (l) {
            const p = l.trim().split(/\s+/);
            swap = {
                total: +p[1],
                used: +p[2]
            };
        }
    } catch {}
    return {
        ram: {
            total: formatSize(total),
            used: formatSize(used),
            free: formatSize(free),
            percent: ((used / total) * 100).toFixed(1),
            extra
        },
        swap: {
            total: formatSize(swap.total),
            used: formatSize(swap.used),
            percent: swap.total ? ((swap.used / swap.total) * 100).toFixed(1) : "0.0"
        }
    };
};

const getNetworkInfo = () =>
    Object.entries(os.networkInterfaces())
    .filter(([n]) => n !== "lo")
    .map(([n, a]) => {
        const v = a.find(i => i.family === "IPv4" && !i.internal);
        return v ? {
            name: n,
            address: v.address
        } : null;
    }).filter(Boolean);

const getExtraStats = async () => {
    let processCount = "N/A",
        inode = null,
        netStat = "N/A";
    try {
        const {
            stdout
        } = await execAsync("ps -e --no-headers | wc -l");
        processCount = stdout.trim();
    } catch {}
    try {
        const {
            stdout
        } = await execAsync("df -i / | tail -1");
        const p = stdout.trim().split(/\s+/);
        inode = {
            used: p[2],
            total: p[1],
            percent: parseFloat(p[4])
        };
    } catch {}
    try {
        const {
            stdout
        } = await execAsync("cat /proc/net/dev | grep eth0");
        const p = stdout.trim().split(/\s+/);
        netStat = `RX ${formatSize(p[1])}  TX ${formatSize(p[9])}`;
    } catch {}
    return {
        processCount,
        inode,
        netStat
    };
};

/* ===================== STATE ===================== */
global.cpuHist = global.cpuHist || [];
global.last = global.last || {};

/* ===================== RENDER ===================== */
function renderSystemImage(d) {
    const W = 1200,
        H = 860;
    const c = createCanvas(W, H);
    const ctx = c.getContext("2d");

    const T = {
        bg1: "#0b1020",
        bg2: "#111827",
        card: "#1f2937",
        border: "#2d3748",
        text: "#f9fafb",
        sub: "#9ca3af",
        green: "#22c55e",
        yellow: "#facc15",
        red: "#ef4444",
        blue: "#3b82f6",
        purple: "#a855f7"
    };
    const auto = p => p >= 85 ? T.red : p >= 60 ? T.yellow : T.green;
    const trend = (k, v) => {
        const t = global.last[k] != null ? (v > global.last[k] ? "▲" : v < global.last[k] ? "▼" : "•") : "•";
        global.last[k] = v;
        return t;
    };

    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, T.bg1);
    g.addColorStop(1, T.bg2);
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);

    ctx.globalAlpha = 0.04;
    ctx.strokeStyle = "#94a3b8";
    for (let i = 0; i < W; i += 60) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, H);
        ctx.stroke();
    }
    for (let i = 0; i < H; i += 60) {
        ctx.beginPath();
        ctx.moveTo(0, i);
        ctx.lineTo(W, i);
        ctx.stroke();
    }
    ctx.globalAlpha = 1;

    const card = (x, y, w, h) => {
        ctx.fillStyle = T.card;
        ctx.strokeStyle = T.border;
        roundedRect(ctx, x, y, w, h, 16);
        ctx.fill();
        ctx.stroke();
    };
    const title = (t, x, y) => {
        ctx.fillStyle = T.text;
        ctx.font = "bold 17px Arial";
        ctx.fillText(t, x, y);
    };
    const txt = (t, x, y) => {
        ctx.fillStyle = T.sub;
        ctx.font = "13px Arial";
        ctx.fillText(t, x, y);
    };
    const bar = (x, y, w, p) => {
        const c = auto(p);
        ctx.fillStyle = "#0f172a";
        ctx.fillRect(x, y, w, 12);
        ctx.fillStyle = c + "33";
        ctx.fillRect(x, y, w, 12);
        ctx.fillStyle = c;
        ctx.fillRect(x, y, w * (p / 100), 12);
    };
    const section = (x, y, w, col) => {
        const g = ctx.createLinearGradient(x, y, x + w, y);
        g.addColorStop(0, col);
        g.addColorStop(1, "transparent");
        ctx.strokeStyle = g;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(x, y);
        ctx.lineTo(x + w, y);
        ctx.stroke();
    };

    ctx.font = "bold 30px Arial";
    ctx.fillStyle = T.text;
    ctx.fillText("SYSTEM OVERVIEW", 50, 55);
    txt(`Server Time: ${d.time}`, 50, 80);

    ctx.textAlign = "right";
    ctx.font = "bold 24px Arial";
    ctx.fillStyle = auto(d.latency > 300 ? 90 : d.latency > 100 ? 65 : 30);
    ctx.fillText(`${d.latency} ms`, W - 50, 55);
    ctx.font = "11px Arial";
    ctx.fillText("LATENCY", W - 50, 75);
    ctx.textAlign = "left";

    section(50, 115, 1100, T.blue);

    card(50, 130, 520, 210);
    title("OS & ENGINE", 70, 160);
    txt(`System: ${d.os}`, 70, 190);
    txt(`Kernel: ${d.kernel}`, 70, 210);
    txt(`NodeJS: ${d.node}`, 70, 230);
    txt(`Manager: ${d.pm2}`, 70, 250);
    txt(`Hostname: ${os.hostname()}`, 70, 270);
    txt(`Platform: ${os.platform()}  Arch: ${os.arch()}`, 70, 290);

    card(610, 130, 540, 210);
    title("CPU INFO", 630, 160);
    txt(d.cpu.model, 630, 190);
    txt(`Cores: ${d.cpu.cores}  Threads: ${d.cpu.cores}`, 630, 210);
    txt(`Speed: ${d.cpu.speed}`, 630, 230);
    txt(`Load: ${d.cpu.load}`, 630, 250);
    txt(`Load/Core: ${d.loadPerCore}%`, 630, 270);

    global.cpuHist.push(d.cpuLoad);
    if (global.cpuHist.length > 40) global.cpuHist.shift();
    ctx.beginPath();
    global.cpuHist.forEach((v, i) => {
        const px = 630 + (i / (global.cpuHist.length - 1)) * 420;
        const py = 310 - (v / 100) * 35;
        i ? ctx.lineTo(px, py) : ctx.moveTo(px, py);
    });
    ctx.lineTo(1050, 310);
    ctx.lineTo(630, 310);
    ctx.closePath();
    ctx.fillStyle = "rgba(59,130,246,.18)";
    ctx.fill();

    card(50, 360, 520, 220);
    title(`MEMORY ${trend("ram",d.ramPercent)}`, 70, 390);
    txt(`Total: ${d.mem.total}`, 70, 420);
    bar(70, 440, 380, d.ramPercent);
    txt(`${d.mem.used} / ${d.mem.total}`, 70, 465);
    txt(d.mem.extra, 70, 485);

    title("SWAP", 70, 515);
    bar(70, 535, 380, parseFloat(d.swap.percent));
    txt(`${d.swap.used} / ${d.swap.total}`, 70, 560);

    card(610, 360, 540, 220);
    title(`DISK ${trend("disk",d.diskPercent)}`, 630, 390);
    d.disks.forEach((v, i) => {
        const y = 420 + i * 60;
        txt(`${v.mount} (${v.source})`, 630, y);
        bar(630, y + 15, 420, v.percent);
        txt(`${v.used} / ${v.total} (Avail ${v.avail})`, 630, y + 40);
    });
    if (d.inode) txt(`Inodes: ${d.inode.used}/${d.inode.total} (${d.inode.percent}%)`, 630, 560);

    card(50, 600, 520, 180);
    title("NETWORK", 70, 630);
    d.net.forEach((n, i) => txt(`${n.name}: ${n.address}`, 70, 660 + i * 22));
    txt(d.netStat, 70, 705);

    card(610, 600, 540, 180);
    title("SYSTEM STATS", 630, 630);
    txt(`Processes: ${d.processCount}`, 630, 660);
    txt(`Disk Used: ${d.diskPercent}%`, 630, 680);
    txt(`RAM Used: ${d.ramPercent}%`, 630, 700);
    txt(`Bot Uptime: ${d.botUptime}`, 630, 720);

    ctx.fillStyle = "rgba(255,255,255,.05)";
    ctx.fillRect(0, H - 30, W, 30);
    ctx.font = "11px Arial";
    ctx.fillStyle = "rgba(255,255,255,.5)";
    ctx.fillText("System stable • Monitoring active", 20, H - 12);
    ctx.textAlign = "right";
    ctx.fillText(`Node ${process.version}`, W - 20, H - 12);

    return c.toBuffer("image/png");
}

/* ===================== COMMAND ===================== */
const handler = async (m, {
    conn
}) => {
    const start = performance();
    const loading = await conn.sendMessage(m.chat, {
        text: "Gathering system telemetry..."
    }, {
        quoted: m
    });
    try {
        const [osName, disks, mem, net, extra] = await Promise.all([
            getOSRelease(), getDiskDetails(), getMemoryDetails(), getNetworkInfo(), getExtraStats()
        ]);
        const cpu = os.cpus()[0];
        const loadArr = os.loadavg();
        const load = loadArr.map(v => v.toFixed(2)).join(" | ");
        const cpuLoad = Math.min(100, (loadArr[0] * 100) / os.cpus().length);

        const image = renderSystemImage({
            time: new Date().toLocaleTimeString("id-ID"),
            latency: (performance() - start).toFixed(2),
            os: osName,
            kernel: os.release(),
            node: process.version,
            pm2: process.env.PM2_HOME ? "Yes (PM2)" : "No (Native)",
            cpu: {
                model: cpu.model,
                cores: os.cpus().length,
                speed: `${cpu.speed} MHz`,
                load
            },
            cpuLoad,
            loadPerCore: ((loadArr[0] / os.cpus().length) * 100).toFixed(1),
            mem: mem.ram,
            swap: mem.swap,
            ramPercent: parseFloat(mem.ram.percent),
            disks,
            diskPercent: disks[0]?.percent || 0,
            inode: extra.inode,
            net,
            netStat: extra.netStat,
            processCount: extra.processCount,
            procRam: formatSize(process.memoryUsage().rss),
            botUptime: formatDuration(process.uptime())
        });

        await conn.sendMessage(m.chat, {
            image,
            caption: "SYSTEM OVERVIEW"
        }, {
            quoted: m
        });
        await conn.sendMessage(m.chat, {
            delete: loading.key
        });
    } catch (e) {
        console.error(e);
        await conn.sendMessage(m.chat, {
            text: `Error: ${e.message}`
        }, {
            quoted: m
        });
    }
};

handler.command = ["os", "system", "stus"];
handler.category = "info";
handler.help = ["os"];
export default handler;