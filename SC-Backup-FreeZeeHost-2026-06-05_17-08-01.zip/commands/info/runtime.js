import os from "os"

/* ================= STATE ================= */

// hitung command selama bot hidup
global.__cmdCount ??= 0

/* ================= HANDLER ================= */

const handler = async (m) => {
    global.__cmdCount++

    const uptimeMs = process.uptime() * 1000
    const uptime = formatDuration(uptimeMs)

    const memUsed = process.memoryUsage().rss
    const memTotal = os.totalmem()

    const cpuCount = os.cpus().length
    const cpuModel = os.cpus()[0]?.model || "Unknown CPU"
    const load = os.loadavg()[0].toFixed(2)

    const startTime = new Date(
        Date.now() - uptimeMs
    ).toLocaleString("id-ID")

    const text = `
🤖 *Status Bot*

⏱️ *Uptime*
${uptime}

🧠 *Resource*
• RAM : ${formatBytes(memUsed)} / ${formatBytes(memTotal)}
• CPU : ${cpuCount} core
• Load: ${load}

💻 *System*
• OS   : ${os.platform()} (${os.arch()})
• Node : ${process.version}

📊 *Session*
• Command dipakai : ${global.__cmdCount}
• Bot start       : ${startTime}

Masih hidup, belum tumbang.
`.trim()

    await m.reply(text)
}

handler.command = ["runtime", "uptime", "statusbot", "rt"]
handler.tags = ["info"]
handler.help = ["runtime"]
handler.limit = false

export default handler

/* ================= UTIL ================= */

function formatDuration(ms) {
    const sec = Math.floor(ms / 1000)
    const d = Math.floor(sec / 86400)
    const h = Math.floor((sec % 86400) / 3600)
    const m = Math.floor((sec % 3600) / 60)
    const s = sec % 60

    const out = []
    if (d) out.push(`${d} hari`)
    if (h) out.push(`${h} jam`)
    if (m) out.push(`${m} menit`)
    out.push(`${s} detik`)
    return out.join(" • ")
}

function formatBytes(bytes) {
    const u = ["B", "KB", "MB", "GB"]
    const i = Math.floor(Math.log(bytes) / Math.log(1024))
    return `${(bytes / 1024 ** i).toFixed(2)} ${u[i]}`
}