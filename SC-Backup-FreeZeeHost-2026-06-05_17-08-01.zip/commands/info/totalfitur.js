import {
    createCanvas
} from "canvas"
import fs from "fs"
import path from "path"

let handler = async (m, {
    conn
}) => {

    const pluginFolder = "./commands"

    let total = 0
    let category = {}

    const scan = (dir, parent = null) => {
        const items = fs.readdirSync(dir, {
            withFileTypes: true
        })

        for (let item of items) {
            const full = path.join(dir, item.name)

            if (item.isDirectory()) {
                scan(full, item.name)
            } else if (item.name.endsWith(".js")) {
                total++
                let cat = parent ? parent.toUpperCase() : "OTHER"
                if (!category[cat]) category[cat] = 0
                category[cat]++
            }
        }
    }

    scan(pluginFolder)

    const sorted = Object.entries(category).sort((a, b) => b[1] - a[1])
    const totalCat = sorted.length
    const topData = sorted.slice(0, 12)

    const width = 1400
    const height = 750
    const canvas = createCanvas(width, height)
    const ctx = canvas.getContext("2d")

    // =========================
    // 🌌 BACKGROUND + GRID
    // =========================
    let bg = ctx.createLinearGradient(0, 0, width, height)
    bg.addColorStop(0, "#020617")
    bg.addColorStop(1, "#0f172a")
    ctx.fillStyle = bg
    ctx.fillRect(0, 0, width, height)

    ctx.strokeStyle = "rgba(255,255,255,0.03)"
    for (let i = 0; i < width; i += 40) {
        ctx.beginPath()
        ctx.moveTo(i, 0)
        ctx.lineTo(i, height)
        ctx.stroke()
    }
    for (let i = 0; i < height; i += 40) {
        ctx.beginPath()
        ctx.moveTo(0, i)
        ctx.lineTo(width, i)
        ctx.stroke()
    }

    // vignette
    let vignette = ctx.createRadialGradient(
        width / 2, height / 2, 200,
        width / 2, height / 2, 800
    )
    vignette.addColorStop(0, "rgba(0,0,0,0)")
    vignette.addColorStop(1, "rgba(0,0,0,0.6)")
    ctx.fillStyle = vignette
    ctx.fillRect(0, 0, width, height)

    // =========================
    // 🔥 HEADER
    // =========================
    ctx.shadowColor = "#22d3ee"
    ctx.shadowBlur = 40
    ctx.fillStyle = "#22d3ee"
    ctx.font = "bold 42px Sans"
    ctx.fillText("DISTRIBUSI FITUR BOT", 40, 60)

    ctx.shadowBlur = 0
    ctx.fillStyle = "#94a3b8"
    ctx.font = "18px Sans"
    ctx.fillText("Command Distribution Dashboard", 40, 90)

    // =========================
    // 🔲 PANEL
    // =========================
    const drawBox = (x, y, w, h, color) => {
        ctx.strokeStyle = color
        ctx.lineWidth = 2

        ctx.shadowColor = color
        ctx.shadowBlur = 30
        ctx.strokeRect(x, y, w, h)

        ctx.shadowBlur = 0
        ctx.strokeStyle = "#ffffff22"
        ctx.strokeRect(x + 2, y + 2, w - 4, h - 4)
    }

    drawBox(20, 120, 400, 550, "#22d3ee")
    drawBox(440, 120, 560, 550, "#a855f7")
    drawBox(1020, 120, 350, 550, "#ec4899")

    const colors = [
        ["#22d3ee", "#0ea5e9"],
        ["#a855f7", "#9333ea"],
        ["#ec4899", "#db2777"],
        ["#4ade80", "#22c55e"],
        ["#facc15", "#eab308"],
        ["#fb7185", "#f43f5e"],
        ["#60a5fa", "#3b82f6"],
        ["#fb923c", "#f97316"]
    ]

    // =========================
    // 🥧 PIE
    // =========================
    let start = 0
    const gap = 0.02
    const cx = 220
    const cy = 380
    const r = 150

    topData.forEach(([_, val], i) => {
        let slice = (val / total) * Math.PI * 2

        let grad = ctx.createRadialGradient(cx, cy, 20, cx, cy, r)
        grad.addColorStop(0, colors[i % colors.length][0])
        grad.addColorStop(1, colors[i % colors.length][1])

        ctx.beginPath()
        ctx.moveTo(cx, cy)
        ctx.fillStyle = grad
        ctx.arc(cx, cy, r, start, start + slice - gap)
        ctx.fill()

        ctx.lineWidth = 2
        ctx.strokeStyle = "#ffffff22"
        ctx.stroke()

        start += slice
    })

    ctx.fillStyle = "#020617"
    ctx.beginPath()
    ctx.arc(cx, cy, 70, 0, Math.PI * 2)
    ctx.fill()

    ctx.fillStyle = "#fff"
    ctx.font = "bold 30px Sans"
    ctx.fillText(total, cx - 25, cy + 10)

    // =========================
    // 📊 BAR
    // =========================
    let y = 150
    let max = topData[0]?.[1] || 1

    topData.forEach(([name, val], i) => {
        let percent = ((val / total) * 100).toFixed(1)
        let w = (val / max) * 450

        let grad = ctx.createLinearGradient(460, y, 460 + w, y)
        grad.addColorStop(0, colors[i % colors.length][0])
        grad.addColorStop(1, colors[i % colors.length][1])

        ctx.shadowColor = colors[i % colors.length][0]
        ctx.shadowBlur = 35

        ctx.fillStyle = grad
        ctx.fillRect(460, y, w, 24)

        ctx.shadowBlur = 0
        ctx.strokeStyle = "#ffffff22"
        ctx.strokeRect(460, y, w, 24)

        ctx.globalAlpha = 0.25
        ctx.fillStyle = "#fff"
        ctx.fillRect(460, y, w, 8)
        ctx.globalAlpha = 1

        ctx.fillStyle = "#fff"
        ctx.font = "bold 16px Sans"
        ctx.fillText(`${name} (${val} | ${percent}%)`, 460, y - 8)

        y += 45
    })

    // =========================
    // 📜 LIST
    // =========================
    let listY = 150

    topData.forEach(([name, val], i) => {
        let percent = ((val / total) * 100).toFixed(1)

        ctx.fillStyle = colors[i % colors.length][0]
        ctx.fillRect(1040, listY, 12, 12)

        ctx.fillStyle = "#fff"
        ctx.font = "bold 14px Sans"
        ctx.fillText(`${name} (${val}) ${percent}%`, 1060, listY + 10)

        listY += 25
        if (listY > 620) return
    })

    const buffer = canvas.toBuffer("image/png")

    // =========================
    // 📜 CAPTION FULL
    // =========================
    let teks = `╭╌╌⬡「 📈 *STATISTIK* 」
┃ ◦ Total Commands : *${total}*
┃ ◦ Categories     : *${totalCat}*
╰╌╌⬡

╭╌╌⬡「 📋 *KATEGORI (FULL)* 」\n`

    sorted.forEach(([name, val]) => {
        let percent = ((val / total) * 100).toFixed(1)
        teks += `┃ ◦ \`${name}\`: *${val}* _(${percent}%)_\n`
    })

    teks += `╰╌╌⬡

> ⚡ *${total}* fitur tersedia — ${global.botname}`

    await conn.sendMessage(m.chat, {
        image: buffer,
        caption: teks
    }, {
        quoted: m
    })
}

handler.command = ["fitur", "totalfitur", "ft"]
handler.tags = ["info"]

export default handler