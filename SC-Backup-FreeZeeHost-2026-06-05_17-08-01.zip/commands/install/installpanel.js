import {
    Client
} from 'ssh2';

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    if (!isOwner) return m.reply("❌ Akses ditolak. Khusus Owner!");

    const usage = `*CARA PAKAI AUTO-INSTALLER:*\n\n${usedPrefix + command} ipvps, pwvps, domainpanel, domainnode, ramserver\n\n*Contoh:*\n${usedPrefix + command} 192.168.1.1, SandiKuat123, panel.web.com, node.web.com, 100000`;

    if (!text) return m.reply(usage);

    let vii = text.split(",");
    if (vii.length < 5) return m.reply(usage);

    await m.react("🔥");
    m.reply("⏳ *PROSES AUTO-INSTALL DIMULAI!*\n\nBot sedang login ke VPS via SSH dan akan menginstal Panel & Node. Proses ini memakan waktu 10-20 menit. Mohon bersabar dan jangan spam bot.");

    const hostIp = vii[0].trim();
    const hostPw = vii[1].trim();
    const domainpanel = vii[2].trim();
    const domainnode = vii[3].trim();
    const ramserver = vii[4].trim();

    // ==============================================
    // GENERATOR ACAK (Biar gak bentrok sama installan lama)
    // ==============================================
    const randStr = () => Math.random().toString(36).substring(2, 6);
    const dbName = "panel_" + randStr();
    const dbUser = "ptero_" + randStr();
    const dbHostUser = "dbadm_" + randStr();
    const dbHostPw = "DbPw" + Math.floor(Math.random() * 100000) + "!";
    const sslEmail = "ssl_" + randStr() + "@gmail.com";

    // Akun Login Panel
    const passwordPanel = "admin" + Math.floor(Math.random() * 10000);
    const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;

    const ress = new Client();
    const connSettings = {
        host: hostIp,
        port: 22,
        username: 'root',
        password: hostPw,
        readyTimeout: 20000
    };

    // ==============================================
    // FUNGSI 2: INSTALL WINGS & AUTO-CREATE NODE
    // ==============================================
    async function instalWings() {
        ress.exec(commandPanel, (err, stream) => {
            if (err) throw err;

            stream.on('close', async () => {
                ress.exec('bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/createnode.sh)', (err, stream2) => {
                    if (err) throw err;

                    stream2.on('close', async () => {
                        let teks = `🎉 *INSTALASI PTERODACTYL & NODE SELESAI!* 🎉\n\n` +
                            `*📦 Detail Akun Panel:*\n` +
                            `* 🌐 *Domain:* https://${domainpanel}\n` +
                            `* 👤 *Username:* admin\n` +
                            `* 🔑 *Password:* ${passwordPanel}\n\n` +
                            `*⚙️ Detail Node:*\n` +
                            `* 🌐 *Domain Node:* ${domainnode}\n` +
                            `* 💾 *RAM:* ${ramserver} MB\n\n` +
                            `*Langkah Terakhir:* Silakan login ke panel, masuk ke menu Node, buat Allocation, dan ambil Token Wings. Lalu ketik:\n\n` +
                            `*.startwings* ${hostIp}, ${hostPw}, tokenwings`;

                        await m.reply(teks);
                        await m.react("✅");
                        ress.end();
                    }).on('data', (data) => {
                        const out = data.toString();
                        console.log('Wings/Node Output:', out);

                        const botNameLabel = global.botname ? global.botname : 'Bot';

                        if (out.includes("Masukkan nama lokasi: ")) stream2.write('Singapore\n');
                        if (out.includes("Masukkan deskripsi lokasi: ")) stream2.write(`Node By ${botNameLabel}\n`);
                        if (out.includes("Masukkan domain: ")) stream2.write(`${domainnode}\n`);
                        if (out.includes("Masukkan nama node: ")) stream2.write(`Node By ${botNameLabel}\n`);
                        if (out.includes("Masukkan RAM (dalam MB): ")) stream2.write(`${ramserver}\n`);
                        if (out.includes("Masukkan jumlah maksimum disk space (dalam MB): ")) stream2.write(`${ramserver}\n`);
                        if (out.includes("Masukkan Locid: ")) stream2.write('1\n');
                    }).stderr.on('data', (data) => console.log('Node Stderr: ' + data));
                });

            }).on('data', (data) => {
                const out = data.toString();
                console.log('Wings Output:', out);

                if (out.includes('Are you sure you want to proceed?')) stream.write('y\n');
                else if (out.includes('Input 0-6:')) stream.write('1\n');
                else if (out.includes('(y/N)')) stream.write('y\n');
                else if (out.includes('Enter the panel address')) stream.write(`${domainpanel}\n`);
                else if (out.includes('Database host username')) stream.write(`${dbHostUser}\n`);
                else if (out.includes('Database host password')) stream.write(`${dbHostPw}\n`);
                else if (out.includes("Set the FQDN to use for Let's Encrypt")) stream.write(`${domainnode}\n`);
                else if (out.includes("Enter email address for Let's Encrypt")) stream.write(`${sslEmail}\n`);
                else if (out.includes('Proceed anyways')) stream.write('y\n');
                else if (out.includes('Select the appropriate number [1-2]')) stream.write('1\n');
            }).stderr.on('data', (data) => console.log('Wings Stderr: ' + data));
        });
    }

    // ==============================================
    // FUNGSI 1: INSTALL PANEL
    // ==============================================
    async function instalPanel() {
        ress.exec(commandPanel, (err, stream) => {
            if (err) throw err;

            stream.on('close', async () => {
                await instalWings();
            }).on('data', (data) => {
                const out = data.toString();
                console.log('Panel Output:', out);

                if (out.includes('Are you sure you want to proceed?')) stream.write('y\n');
                else if (out.includes('Input 0-6:')) stream.write('0\n');
                else if (out.includes('Database name (panel):')) stream.write(`${dbName}\n`);
                else if (out.includes('Database username (pterodactyl):')) stream.write(`${dbUser}\n`);
                else if (out.includes('Password (press enter to use randomly generated password):')) stream.write('\n');
                else if (out.includes('Select timezone')) stream.write('Asia/Jakarta\n');
                else if (out.includes("Provide the email address that will be used to configure Let's Encrypt")) stream.write(`${sslEmail}\n`);
                else if (out.includes('Email address for the initial admin account:')) stream.write('admin@gmail.com\n');
                else if (out.includes('Username for the initial admin account:')) stream.write('admin\n');
                else if (out.includes('First name for the initial admin account:')) stream.write('admin\n');
                else if (out.includes('Last name for the initial admin account:')) stream.write('admin\n');
                else if (out.includes('Password for the initial admin account:')) stream.write(`${passwordPanel}\n`);
                else if (out.includes('Set the FQDN of this panel')) stream.write(`${domainpanel}\n`);
                else if (out.includes('Do you want to automatically configure UFW')) stream.write('y\n');
                else if (out.includes("Do you want to automatically configure HTTPS")) stream.write('y\n');
                else if (out.includes('I agree that this HTTPS request is performed')) stream.write('y\n');
                else if (out.includes('Continue with installation? (y/N):')) stream.write('y\n');
                else if (out.includes('Enable sending anonymous telemetry data?')) stream.write('yes\n');
                else if (out.includes('Please read the Terms of Service') || out.includes('(Y)es/(N)o:')) stream.write('y\n');
                else if (out.includes('Select the appropriate number [1-2]')) stream.write('1\n');

            }).stderr.on('data', (data) => console.log('Panel Stderr: ' + data));
        });
    }

    ress.on('ready', () => {
        console.log('SSH Connection Ready!');
        instalPanel();
    }).on('error', (err) => {
        m.reply(`❌ *KONEKSI SSH GAGAL!*\nPastikan IP dan Password VPS benar.\n\nDetail: ${err.message}`);
    }).connect(connSettings);
};

handler.command = ['installpanel', 'autoinstall'];
handler.tags = ['install'];
handler.help = ['installpanel <ipvps, pwvps, domainpanel, domainnode, ram>'];
handler.owner = true;

export default handler;