import {
    Client
} from 'ssh2';

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    if (!isOwner) return m.reply("Khusus Owner, Bang! 🗿");
    if (!text || !text.includes("|")) return m.reply(`*Contoh:* \n${usedPrefix + command} ipvps|pwvps`);

    let [ipvps, passwd] = text.split("|");
    await m.react("⏳");

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd
    };
    const sshClient = new Client();

    sshClient.on('ready', () => {
        m.reply("🚀 *Koneksi Berhasil!*\nMemproses install *Tema Enigma*...");
        sshClient.exec(`bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`, (err, stream) => {
            if (err) return m.reply(`❌ Error: ${err.message}`);
            stream.on('close', () => {
                    m.reply("✅ *Berhasil* install Tema Enigma!");
                    sshClient.end();
                })
                .on('data', (data) => {
                    console.log(data.toString());
                    stream.write(`skyzodev\n`); // Token
                    stream.write(`1\n`); // Install
                    stream.write(`3\n`); // Enigma
                    stream.write(`https://wa.me/6285624297893\n`);
                    stream.write(`https://whatsapp.com/channel/0029VaYoztA47XeAhs447Y1s\n`);
                    stream.write(`https://chat.whatsapp.com/IP1KjO4OyM97ay2iEsSAFy\n`);
                    stream.write(`yes\n`);
                    stream.write(`x\n`);
                });
        });
    }).on('error', (err) => m.reply(`❌ Gagal: ${err.message}`)).connect(connSettings);
};

handler.help = ['installtemaenigma'];
handler.tags = ['install'];
handler.command = /^(installtemaenigma|instaltemaenigma)$/i;
handler.owner = true;

export default handler;