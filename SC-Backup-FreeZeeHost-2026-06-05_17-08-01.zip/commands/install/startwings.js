import {
    Client
} from 'ssh2';

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    if (!isOwner) return m.reply("❌ Akses ditolak. Khusus Owner!");

    const usage = `*CARA PAKAI START WINGS:*\n\n${usedPrefix + command} ipvps, pwvps, token_wings\n\n*Contoh:*\n${usedPrefix + command} 192.168.1.1, SandiKuat123, cd /etc/pterodactyl && sudo wings configure ...`;

    if (!text) return m.reply(usage);

    // Split pakai koma
    let t = text.split(',');
    if (t.length < 3) return m.reply(usage);

    await m.react("⏳");
    m.reply("Menghubungkan ke VPS dan mengonfigurasi Wings... 🚀");

    let ipvps = t[0].trim();
    let passwd = t[1].trim();

    // Pakai slice + join biar aman kalau kebetulan di dalam token wings ada koma-nya
    let token = t.slice(2).join(',').trim();

    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd,
        readyTimeout: 15000 // Timeout dinaikin dikit biar aman
    };

    // Gabung command configure dari panel sama perintah nyalain wings
    const executeCmd = `${token} && systemctl start wings`;
    const ress = new Client();

    ress.on('ready', () => {
        ress.exec(executeCmd, (err, stream) => {
            if (err) throw err;

            stream.on('close', async (code, signal) => {
                await m.reply("✅ *Berhasil Menjalankan Wings!*\n\n*Status:* Aktif & Terhubung ke Panel 🟢\n_Silakan cek status Node di web panel Abang (Ikon Hati Hijau)._");
                await m.react("✅");
                ress.end();
            }).on('data', (data) => {
                console.log('Wings Stdout:', data.toString());
            }).stderr.on('data', (data) => {
                const out = data.toString();
                console.log('Wings Stderr:', out);

                // Bot otomatis jawab yes kalau ditanya di terminal
                if (out.toLowerCase().includes('y/n') || out.toLowerCase().includes('proceed')) {
                    stream.write("y\n");
                }
            });
        });
    }).on('error', (err) => {
        console.log('Connection Error:', err);
        m.reply(`❌ *KONEKSI GAGAL!*\nKatasandi atau IP tidak valid.\n\nDetail: ${err.message}`);
        m.react("❌");
    }).connect(connSettings);
};

handler.command = ['startwings', 'configurewings'];
handler.tags = ['panel'];
handler.help = ['startwings <ipvps, pwvps, token>'];
handler.owner = true;

export default handler;