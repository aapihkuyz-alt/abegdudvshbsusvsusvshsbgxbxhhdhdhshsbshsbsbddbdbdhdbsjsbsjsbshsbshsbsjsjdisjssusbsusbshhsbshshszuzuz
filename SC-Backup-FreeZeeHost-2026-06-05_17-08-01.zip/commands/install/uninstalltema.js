import {
    Client
} from 'ssh2';

/**
 * 🛠️ PTERODACTYL THEME UNINSTALLER
 * Format: .uninstalltema ipvps|pwvps
 */

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    // 1. Proteksi Owner
    if (!isOwner) return m.reply("Khusus Owner, Bang! Fitur sistem ini. 🗿");

    // 2. Validasi Input
    if (!text || !text.includes("|")) {
        return m.reply(`*Format Salah!*\n\n*Contoh:* \n${usedPrefix + command} 103.xxx.xxx.xxx|passwordvps`);
    }

    let [ipvps, passwd] = text.split("|");
    if (!ipvps || !passwd) return m.reply("IP VPS atau Password tidak ditemukan!");

    await m.react("⏳");
    await m.reply("⏳ Memproses *Uninstall* tema Pterodactyl...\nMohon tunggu 1-10 menit hingga proses selesai.");

    // 3. Konfigurasi SSH
    const connSettings = {
        host: ipvps,
        port: 22,
        username: 'root',
        password: passwd
    };

    const sshCommand = `bash <(curl -s https://raw.githubusercontent.com/SkyzoOffc/Pterodactyl-Theme-Autoinstaller/main/install.sh)`;
    const sshClient = new Client();

    sshClient.on('ready', () => {
        sshClient.exec(sshCommand, (err, stream) => {
            if (err) {
                sshClient.end();
                return m.reply(`❌ *SSH Exec Error:* ${err.message}`);
            }

            stream.on('close', async (code, signal) => {
                await m.reply("✅ *BERHASIL!*\nTema Pterodactyl telah di-uninstall (kembali ke default).");
                sshClient.end();
            }).on('data', (data) => {
                let output = data.toString();
                console.log('SSH Output:', output);

                // Automasi Input Uninstall
                stream.write(`skyzodev\n`); // Token Key
                stream.write(`2\n`); // Option 2 (Uninstall)
                stream.write(`y\n`); // Confirm Yes
                stream.write(`x\n`); // Exit
            }).stderr.on('data', (data) => {
                console.log('SSH STDERR:', data.toString());
            });
        });

    }).on('error', (err) => {
        console.error('Connection Error:', err);
        m.reply(`❌ *Koneksi Gagal!*\nIP atau Password VPS salah.`);
    }).connect(connSettings);
};

handler.help = ['uninstalltema'];
handler.tags = ['install'];
handler.command = /^(uninstalltema|uninstaltema)$/i;
handler.owner = true;

export default handler;