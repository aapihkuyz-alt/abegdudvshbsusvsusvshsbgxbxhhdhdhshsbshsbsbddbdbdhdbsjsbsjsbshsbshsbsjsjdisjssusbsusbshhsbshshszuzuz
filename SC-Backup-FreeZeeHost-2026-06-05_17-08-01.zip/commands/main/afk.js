let handler = async (m, { text, db }) => {
    let user = db.get("user", m.sender);
    if (!user) return;

    user.afk = Date.now();
    user.afkReason = text || "Tanpa alasan (Sibuk)";
    
    await db.save();
    
    let report = `💤 *[ AFK MODE ]* 💤\n\n` +
                 `👤 *User:* @${m.sender.split("@")[0]}\n` +
                 `📝 *Alasan:* ${user.afkReason}\n\n` +
                 `_Jangan tag dia ya, lagi istirahat!_`;

    await conn.sendMessage(m.chat, { 
        text: report, 
        contextInfo: { mentionedJid: [m.sender] } 
    }, { quoted: m });
};

handler.help = ["afk <alasan>"];
handler.tags = ["main"];
handler.command = /^afk$/i;

export default handler;