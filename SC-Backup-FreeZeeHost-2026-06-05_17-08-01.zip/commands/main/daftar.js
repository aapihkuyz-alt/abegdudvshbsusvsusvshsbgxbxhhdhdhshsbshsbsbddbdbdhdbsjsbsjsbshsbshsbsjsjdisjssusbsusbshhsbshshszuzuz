import { createHash } from 'crypto';

const handler = async (m, {
    text,
    command,
    usedPrefix,
    user,
    db
}) => {
    // 1. Pastikan database terdefinisi
    const database = db || global.db;
    if (!database) return m.reply('⚠️ Database tidak ditemukan. Pastikan global.db sudah diinisialisasi.');

    // 2. Ambil data user dari argumen 'user' atau tembak ke database
    let userData = user || database.get('user', m.sender);
    
    // Inisialisasi data jika benar-benar baru
    if (!userData) {
        userData = {
            id: m.sender,
            name: '',
            age: 0,
            register: false,
            regTime: 0,
            sn: '',
            limit: 20,
            premium: {
                status: false,
                expired: 0
            }
        };
        await database.add('user', m.sender, userData);
    }

    // 3. Cegah pendaftaran ganda
    if (userData.register) {
        return m.reply(`_Anda sudah terdaftar dengan nama ${userData.name}!_`);
    }

    // 4. Validasi Input (Nama.Umur atau Nama Umur)
    if (!text) return m.reply(`_Format salah!_\nContoh: *${usedPrefix + command} Baka 16*`);

    // Memisahkan teks menjadi bagian-bagian
    let parts = text.trim().split(/[ .]+/);
    
    // Cek apakah ada umur yang dimasukkan
    if (parts.length < 2) return m.reply(`_Masukkan Nama dan Umur!_\nContoh: *${usedPrefix + command} ${text.trim()} 16*`);

    let age = parts[parts.length - 1]; // Bagian terakhir adalah umur
    let name = parts.slice(0, -1).join(" "); // Sisanya adalah nama

    // Validasi Umur
    if (isNaN(age)) return m.reply(`_Umur harus berupa angka!_\nContoh: *${usedPrefix + command} ${name} 16*`);
    
    age = parseInt(age);
    if (age > 70 || age < 5) return m.reply('_Umur tidak valid (rentang 5 - 70 tahun)._');
    if (name.length > 20) return m.reply('_Nama terlalu panjang, maksimal 20 karakter._');

    // 5. Update data pendaftaran
    const serialNumber = createHash('md5').update(m.sender).digest('hex').slice(0, 8).toUpperCase();

    userData.name = name.trim();
    userData.age = age;
    userData.register = true;
    userData.regTime = Date.now();
    userData.sn = serialNumber;
    userData.limit = (userData.limit || 0) + 50; // Bonus limit

    // 6. Simpan ke database
    // Jika bot kamu menggunakan database.save()
    if (typeof database.save === 'function') {
        await database.save();
    }

    // 7. Pesan konfirmasi
    const msg = `
🎉 *Pendaftaran Berhasil!*

👤 *Nama:* ${name}
🎂 *Umur:* ${age} tahun
🧾 *Serial Number:* ${serialNumber}

🎁 Anda mendapatkan bonus *50 Limit*.
Ketik *.menu* untuk melihat daftar perintah.
  `.trim();

    await m.reply(msg);
};

handler.help = ['daftar <nama> <umur>'];
handler.command = ['daftar', 'register', 'reg'];
handler.tags = ['main'];

export default handler;
