let handler = async (m, { conn, text, usedPrefix, command, db }) => {
    let user = db.get("user", m.sender);
    if (!user.privateDrive) user.privateDrive = {};

    const [action, ...args] = (text || "").split(" ");
    const fileName = args.join(" ").trim();

    switch (command) {
        case 'drive':
        case 'cloud': {
            if (!text) {
                const files = Object.keys(user.privateDrive);
                if (files.length === 0) return m.reply(`📂 *[ PRIVATE DRIVE ]* 📂\n\nDrive kamu masih kosong.\n📌 *Cara simpan:* Reply media dengan *${usedPrefix}save nama_file*\n📌 *Cara ambil:* *${usedPrefix}get nama_file*`);
                
                let report = `📂 *[ PRIVATE DRIVE ]* 📂\n\n📍 *Daftar File Kamu:* \n`;
                files.forEach((f, i) => {
                    const file = user.privateDrive[f];
                    report += `${i + 1}. *${f}* (${file.type})\n`;
                });
                report += `\n📌 Ketik *${usedPrefix}get <nama>* untuk mengambil.`;
                return m.reply(report);
            }
            break;
        }

        case 'save': {
            if (!m.quoted) return m.reply("📌 Reply media (Gambar/Video/Audio/Stiker) yang mau disimpan!");
            if (!text) return m.reply("📌 Kasih nama filenya, Bang!");
            
            await m.react("📥");
            const buffer = await m.quoted.download();
            const type = m.quoted.mtype;
            
            user.privateDrive[text.trim()] = {
                data: buffer.toString('base64'),
                type: type,
                mime: m.quoted.msg?.mimetype || 'image/jpeg',
                timestamp: Date.now()
            };
            
            await db.save();
            return m.reply(`✅ *FILE SAVED!* \n\nFile *${text.trim()}* berhasil disimpan di Cloud Drive pribadimu.`);
        }

        case 'get': {
            if (!text) return m.reply("📌 Tulis nama file yang mau diambil!");
            const file = user.privateDrive[text.trim()];
            if (!file) return m.reply("❌ File tidak ditemukan.");

            await m.react("📤");
            const buffer = Buffer.from(file.data, 'base64');
            
            let message = {};
            const type = file.type;
            
            if (/image/i.test(type)) message = { image: buffer };
            else if (/video/i.test(type)) message = { video: buffer };
            else if (/audio/i.test(type)) message = { audio: buffer, ptt: true };
            else if (/sticker/i.test(type)) message = { sticker: buffer };
            else message = { document: buffer, mimetype: file.mime, fileName: text.trim() };

            return await conn.sendMessage(m.chat, message, { quoted: m });
        }

        case 'delcloud': {
            if (!text) return m.reply("📌 Tulis nama file yang mau dihapus!");
            if (!user.privateDrive[text.trim()]) return m.reply("❌ File tidak ditemukan.");
            
            delete user.privateDrive[text.trim()];
            await db.save();
            return m.reply(`🗑️ *FILE DELETED!* \nFile *${text.trim()}* telah dihapus dari Cloud Drive.`);
        }
    }
};

handler.help = ["drive", "save <nama>", "get <nama>", "delcloud <nama>"];
handler.tags = ["main", "premium"];
handler.command = /^(drive|cloud|save|get|delcloud)$/i;

export default handler;