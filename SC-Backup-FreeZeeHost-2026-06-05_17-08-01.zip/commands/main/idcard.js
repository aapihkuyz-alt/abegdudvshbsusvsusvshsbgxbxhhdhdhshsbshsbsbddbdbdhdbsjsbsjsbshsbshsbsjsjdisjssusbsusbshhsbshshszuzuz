import { createCanvas, loadImage, registerFont } from 'canvas';
import path from 'path';

let handler = async (m, { conn, db }) => {
    let user = db.get("user", m.sender);
    if (!user) return;

    await m.react("💳");
    await m.reply("🎫 *Sedang mencetak Passport Digital Bang...*");

    try {
        const W = 800;
        const H = 450;
        const canvas = createCanvas(W, H);
        const ctx = canvas.getContext('2d');

        // 1. Background Design
        const grad = ctx.createLinearGradient(0, 0, W, H);
        grad.addColorStop(0, '#0f172a');
        grad.addColorStop(0.5, '#1e293b');
        grad.addColorStop(1, '#0f172a');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, W, H);

        // Pattern Overlay
        ctx.strokeStyle = "rgba(59, 130, 246, 0.1)";
        ctx.lineWidth = 1;
        for (let i = 0; i < W; i += 40) {
            ctx.beginPath();
            ctx.moveTo(i, 0);
            ctx.lineTo(i, H);
            ctx.stroke();
        }

        // 2. Header
        ctx.fillStyle = "#3b82f6";
        ctx.font = "bold 35px Arial";
        ctx.fillText("FREEZEEHOST", 50, 60);
        ctx.fillStyle = "#ffffff";
        ctx.font = "20px Arial";
        ctx.fillText("OFFICIAL DIGITAL PASSPORT", 50, 90);

        // 3. User Avatar
        const ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch(() => "https://files.catbox.moe/7e4y9f.jpg");
        const avatar = await loadImage(ppUrl);
        
        // Shadow Avatar
        ctx.shadowColor = 'rgba(0, 0, 0, 0.5)';
        ctx.shadowBlur = 10;
        ctx.fillStyle = "#1e293b";
        ctx.fillRect(50, 130, 200, 250); // Frame foto
        ctx.drawImage(avatar, 60, 140, 180, 230);
        ctx.shadowBlur = 0;

        // 4. Identity Details
        const drawField = (label, value, x, y) => {
            ctx.fillStyle = "#94a3b8";
            ctx.font = "14px Arial";
            ctx.fillText(label, x, y);
            ctx.fillStyle = "#ffffff";
            ctx.font = "bold 22px Arial";
            ctx.fillText(value, x, y + 25);
        };

        drawField("NAME / IDENTITAS", (m.pushName || "Unknown").toUpperCase(), 300, 160);
        drawField("PASSPORT ID", m.sender.split("@")[0], 300, 230);
        drawField("LEVEL", (user.level || 1).toString(), 300, 300);
        drawField("TRUST SCORE", `${user.trustScore || 50}/100`, 500, 300);
        drawField("MEMBERSHIP", user.premium?.status ? "ELITE PREMIUM" : "STANDARD CITIZEN", 300, 370);

        // 5. Verified Badge
        if (user.trustScore > 80 || user.owner) {
            ctx.fillStyle = "#10b981";
            ctx.beginPath();
            ctx.arc(700, 80, 40, 0, Math.PI * 2);
            ctx.fill();
            ctx.fillStyle = "#ffffff";
            ctx.textAlign = "center";
            ctx.font = "bold 12px Arial";
            ctx.fillText("VERIFIED", 700, 85);
            ctx.textAlign = "left";
        }

        // QR Code Placeholder (Aesthetic)
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(650, 320, 100, 100);
        ctx.fillStyle = "#000000";
        ctx.font = "bold 10px Arial";
        ctx.fillText("SECURITY", 670, 370);
        ctx.fillText("ENCRYPTED", 670, 385);

        const buffer = canvas.toBuffer('image/png');
        await conn.sendMessage(m.chat, { 
            image: buffer, 
            caption: `✅ *PASSPORT ISSUED!* \n\nIni adalah kartu identitas resmi Bang di ekosistem *${global.botname}*.\n🛡️ Status: ${user.premium?.status ? "Elite Member" : "Active Citizen"}`
        }, { quoted: m });
        await m.react("✨");

    } catch (e) {
        console.error(e);
        m.reply("❌ Gagal mencetak Passport.");
    }
};

handler.help = ["passport", "id"];
handler.tags = ["main", "info"];
handler.command = /^(passport|id|idcard)$/i;

export default handler;