import axios from "axios";
import moment from "moment-timezone";
import {
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    proto
} from "baileys";

const handler = async (m, {
    conn,
    cmd,
    Func,
    text,
    usedPrefix
}) => {
    const username = m.pushName || "User";
    const prefix = usedPrefix;
    const menu = {};

    /* ================= 1. REACTION & PREPARE DATA ================= */
    await m.react("📂");

    Object.values(cmd.plugins).forEach(plugin => {
        if (!plugin.command || !plugin.tags) return;
        const tags = Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags];
        let name = Array.isArray(plugin.command) ? plugin.command[0] : plugin.command;
        if (name && typeof name === "string") {
            tags.forEach(tag => {
                const t = tag.toLowerCase().trim();
                if (!menu[t]) menu[t] = [];
                menu[t].push(name.toLowerCase());
            });
        }
    });

    const sortedTags = Object.keys(menu).sort();
    let menuBody = "";

    // If user requests specific category or "all"
    if (text === "all") {
        sortedTags.forEach(t => {
            menuBody += `\n┏━━  「 *${t.toUpperCase()}* 」  ━━┓\n`;
            menu[t].forEach(c => (menuBody += `┃ ◦ ${prefix}${c}\n`));
            menuBody += "┗━━━━━━━━━━━━━━━━━━━━┛\n";
        });
    } else if (text && menu[text.toLowerCase()]) {
        const t = text.toLowerCase();
        menuBody += `┏━━  「 *${t.toUpperCase()}* 」  ━━┓\n`;
        menu[t].forEach(c => (menuBody += `┃ ◦ ${prefix}${c}\n`));
        menuBody += "┗━━━━━━━━━━━━━━━━━━━━┛";
    }

    /* ================= 2. GENERATE AI GREETING (NEOXR) ================= */
    let aiGreeting = "";
    try {
        const { data } = await axios.get("https://api.neoxr.eu/api/gemini-chat", {
            params: { 
                q: `Sapa user ${username} yang buka menu bot ${global.botname} dengan gaya sangat keren, techy, and singkat.`,
                apikey: global.neoxr 
            }
        });
        aiGreeting = data?.status ? data.data.message : `System Ignited. Welcome back, ${username}.`;
    } catch (e) {
        aiGreeting = `Access Granted. Hello ${username}, how can I assist you today?`;
    }

    /* ================= 3. CONSTRUCT CAPTION ================= */
    const isOwner = global.owner.map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
    const role = isOwner ? '👑 ELITE OWNER' : '👤 ACTIVE USER';
    
    const finalCaption = `
*${global.botname?.toUpperCase() || 'BOT'} MULTI-DEVICE*
“ ${aiGreeting} ”

╭━━━〔 👤 *USER PROFILE* 〕━━━⬣
┃ ◦ *Name:* ${username}
┃ ◦ *Role:* ${role}
┃ ◦ *ID:* @${m.sender.split('@')[0]}
╰━━━━━━━━━━━━━━━━━━━━━━⬣

╭━━━〔 📊 *SYSTEM STATUS* 〕━━━⬣
┃ 📈 *Uptime:* ${Func.toTime(process.uptime() * 1000)}
┃ 🛠️ *Prefix:* [  ${prefix}  ]
┃ 💾 *Engine:* Hybrid Node.js
┃ 📡 *Network:* Stable Encryption
╰━━━━━━━━━━━━━━━━━━━━━━⬣

${menuBody ? menuBody : "_Select a category from the buttons below to view commands._"}

*FreeZeeHost Project* • _v${process.env.npm_package_version || "1.0.0"}_
_© 2026 Secured By Phoenix Guard_`.trim();

    /* ================= 4. BUILD INTERACTIVE MESSAGE ================= */
    
    // Prepare thumbnail media
    let mediaHeader = {};
    try {
        const media = await prepareWAMessageMedia({ image: { url: global.thumb } }, { upload: conn.waUploadToServer });
        mediaHeader = {
            hasMediaAttachment: true,
            imageMessage: media.imageMessage
        };
    } catch (e) {
        console.error("Menu Media Header Error:", e);
        mediaHeader = { hasMediaAttachment: false };
    }

    const interactiveMessage = {
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `💠 *${global.botname?.toUpperCase() || 'BOT'} DASHBOARD*`,
                ...mediaHeader
            }),
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: finalCaption
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: "Click buttons below to explore system"
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "📂 EXPLORE COMMANDS",
                            sections: [{
                                title: "SISTEM KATEGORI",
                                rows: [
                                    {
                                        header: "ALL-IN-ONE",
                                        title: "ALL COMMANDS",
                                        description: "Tampilkan semua perintah bot",
                                        id: `${prefix}menu all`
                                    },
                                    ...sortedTags.map(tag => ({
                                        header: "KATEGORI",
                                        title: tag.toUpperCase(),
                                        description: `Buka fitur dalam kategori ${tag}`,
                                        id: `${prefix}menu ${tag}`
                                    }))
                                ]
                            }]
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "🚀 SPEEDTEST / PING",
                            id: `${prefix}ping`
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "👤 OWNER BOT",
                            id: `${prefix}owner`
                        })
                    },
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "🌐 REST API",
                            url: global.website || "https://theresapis.vercel.app"
                        })
                    },
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📢 JOIN CHANNEL",
                            url: global.linkch || "https://whatsapp.com/channel/0029VbBV0VzAe5VoWlBKNN0p"
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📜 SCRIPT INFO",
                            id: `${prefix}sc`
                        })
                    }
                ]
            }),
            contextInfo: {
                mentionedJid: [m.sender],
                forwardingScore: 999,
                isForwarded: true,
                forwardedNewsletterMessageInfo: {
                    newsletterJid: global.idch || "120363233804868012@newsletter",
                    newsletterName: global.namech || "FreeZeeHost Botz",
                    serverMessageId: -1
                }
            }
        })
    };

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: interactiveMessage
        }
    }, { userJid: conn.user.id, quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
}

handler.command = ["menu", "help"];
handler.tags = ["main"];
handler.help = ["menu"];
handler.register = true;

export default handler;