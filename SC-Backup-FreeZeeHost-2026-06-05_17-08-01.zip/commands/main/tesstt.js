import {
    GoogleGenerativeAI
} from "@google/generative-ai";

const {
    proto,
    generateWAMessageFromContent,
    generateWAMessageContent
} = await import('baileys');

/* ================= FAKE STATUS QUOTED ================= */
const fakeStatusQuoted = (botname) => ({
    key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
    },
    message: {
        conversation: `✨ *${botname}* ✨`
    }
});

const genAI = new GoogleGenerativeAI("AIzaSyBKfA9zi8E43yhX8CasqoKfvd4CBw3P-IA");
const model = genAI.getGenerativeModel({
    model: "gemini-3.1-pro",
    systemInstruction: `Namamu ${global.botname}. Kamu asisten AI cerdas milik FreeZeeHost. Sapa user dengan gaya sangat singkat dan keren.`
});

const handler = async (m, {
    conn,
    cmd,
    Func,
    usedPrefix
}) => {
    const username = m.pushName || "User";
    const prefix = usedPrefix;
    const menu = {};

    // 1. Send Reaction tanda bot mulai memproses data
    await conn.sendMessage(m.chat, {
        react: {
            text: "📂",
            key: m.key
        }
    });

    /* ================= 2. GENERATE AI GREETING ================= */
    let aiGreeting = "";
    try {
        const result = await model.generateContent(`Sapa user ${username} yang buka menu bot ${global.botname}`);
        aiGreeting = result.response.text().trim();
    } catch (e) {
        aiGreeting = `Halo ${username}, selamat datang di ${global.botname}!`;
    }

    /* ================= 3. BUILD ALL MENU DATA ================= */
    Object.values(cmd.plugins).forEach(plugin => {
        if (!plugin.command || !plugin.tags) return;
        const tags = Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags];
        let name = Array.isArray(plugin.command) ? plugin.command[0] : plugin.command;
        if (name && typeof name === "string") {
            tags.forEach(tag => {
                const t = tag.toLowerCase().trim();
                if (!menu[t]) menu[t] = [];
                menu[t].push(name.toLowerCase());
            });
        }
    });

    const sortedTags = Object.keys(menu).sort();

    // Body untuk pesan awal (Intro) - Gaya Kategori Menu (seperti menu.js)
    let categoryList = "乂 *KATEGORI MENU*\n\n";
    sortedTags.forEach(t => {
        categoryList += `• ${t.toUpperCase()}\n`;
    });
    categoryList += `\nGeser slide untuk melihat detail perintah setiap kategori.`;

    /* ================= 4. FETCH BANNER GIF ================= */
    const videoUrl = global.mp4;
    const videoBuffer = await Func.fetchBuffer(videoUrl, {
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
        }
    });

    async function createVideo(buffer) {
        const {
            videoMessage
        } = await generateWAMessageContent({
            video: buffer,
            gifPlayback: true
        }, {
            upload: conn.waUploadToServer
        });
        return videoMessage;
    }

    const videoMsg = await createVideo(videoBuffer);

    /* ================= 5. CREATE CAROUSEL CARDS (SATU PER KATEGORI) ================= */
    const carouselCards = sortedTags.map((t) => {
        let cardBody = "";
        menu[t].forEach(c => {
            cardBody += `│ ◦ ${prefix}${c}\n`;
        });
        cardBody += "└──";

        return {
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: cardBody
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({
                text: "© " + global.botname
            }),
            header: proto.Message.InteractiveMessage.Header.fromObject({
                title: `乂 KATEGORI: ${t.toUpperCase()}`,
                hasMediaAttachment: true,
                videoMessage: videoMsg
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [{
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "📂 ALL MENU",
                            id: `${prefix}menu all`
                        })
                    },
                    {
                        name: "cta_url",
                        buttonParamsJson: JSON.stringify({
                            display_text: "👤 OWNER WA",
                            url: `https://wa.me/${global.owner[0]}`
                        })
                    }
                ]
            })
        };
    });

    /* ================= 6. EKSEKUSI SEND VIA RELAY MESSAGE ================= */
    const message = generateWAMessageFromContent(
        m.chat, {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.create({
                    text: `🌙 *${aiGreeting}*\n\n${categoryList}`,
                }),
                footer: proto.Message.InteractiveMessage.Footer.create({
                    text: "FreeZee Baileys Status Tracker",
                }),
                header: proto.Message.InteractiveMessage.Header.create({
                    title: `💠 ${global.botname} MENU`,
                    hasMediaAttachment: false,
                }),
                carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                    cards: carouselCards,
                }),
            }),
        }, {
            quoted: m
        }
    );

    await conn.relayMessage(m.chat, message.message, {
        messageId: message.key.id
    });
};

handler.command = ["menutest", "testcarousel"];
handler.tags = ["tools"];
handler.help = ["menutest"];

export default handler;