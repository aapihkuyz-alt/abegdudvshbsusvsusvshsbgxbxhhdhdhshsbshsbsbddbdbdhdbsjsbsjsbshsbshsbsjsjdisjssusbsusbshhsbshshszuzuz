import chalk from 'chalk';

let handler = async (m, { conn, db, text, usedPrefix, command }) => {
    const user = db.get("user", m.sender);
    const group = m.isGroup ? db.get("group", m.chat) : null;

    // --- SUB-COMMAND: LEADERBOARD ---
    if (text === 'top' || text === 'leaderboard') {
        if (!m.isGroup) return m.reply("❌ Fitur leaderboard hanya tersedia di dalam grup.");
        
        const stats = group.memberStats || {};
        const sorted = Object.entries(stats)
            .sort((a, b) => b[1] - a[1])
            .slice(0, 10);

        if (sorted.length === 0) return m.reply(" belum ada statistik pesan di grup ini.");

        let list = `📊 *TOP ACTIVE MEMBERS* 📊\n\n`;
        list += `Grup: ${m.metadata?.subject || "Group"}\n\n`;
        
        sorted.forEach(([jid, count], i) => {
            list += `${i + 1}. @${jid.split('@')[0]} : *${count.toLocaleString()}* pesan\n`;
        });

        list += `\n_Terus aktif untuk naik ke puncak!_`;
        
        return await conn.sendMessage(m.chat, { 
            text: list, 
            mentions: sorted.map(v => v[0]) 
        }, { quoted: m });
    }

    // --- MAIN LOGIC: PERSONAL STATS ---
    const globalCount = user.totalMessages || 0;
    const groupCount = (m.isGroup && group.memberStats) ? (group.memberStats[m.sender] || 0) : 0;
    const trustEmoji = user.trustScore > 80 ? "🛡️" : (user.trustScore > 40 ? "👤" : "⚠️");

    let report = `╭─❍ *PESAN ANALYTICS* ❍─\n`;
    report += `│\n`;
    report += `│ 👤 *User:* @${m.sender.split('@')[0]}\n`;
    report += `│ ${trustEmoji} *Reputasi:* ${user.trustScore}/100\n`;
    report += `│\n`;
    report += `│ 🌎 *Global Messages:* ${globalCount.toLocaleString()}\n`;
    
    if (m.isGroup) {
        report += `│ 👥 *Group Messages:* ${groupCount.toLocaleString()}\n`;
    }

    report += `│ 📈 *Bot Level:* ${user.level}\n`;
    report += `│\n`;
    report += `├─────────────────────\n`;
    report += `│ 💡 *Tips:* Ketik *${usedPrefix + command} top*\n`;
    report += `│ untuk melihat leaderboard grup.\n`;
    report += `╰─────────────────────❍`;

    await conn.sendMessage(m.chat, { 
        text: report, 
        mentions: [m.sender] 
    }, { quoted: m });
};

handler.help = ["totalpesan", "top"];
handler.tags = ["main", "group"];
handler.command = /^(totalpesan|totalmsg|stats|top)$/i;

export default handler;
