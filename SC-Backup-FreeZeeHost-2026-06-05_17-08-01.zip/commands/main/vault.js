import crypto from 'crypto';

/**
 * THE VAULT: Encrypted Private Storage
 */
let handler = async (m, { conn, text, usedPrefix, command, db }) => {
    let user = db.get("user", m.sender);
    if (!user.vault) user.vault = { notes: [], pin: null, locked: true };

    const [cmd, ...args] = text.split(' ');
    const input = args.join(' ');

    // 1. SET PIN (Hanya jika belum punya)
    if (cmd === 'setpin') {
        if (user.vault.pin) return m.reply(`❌ Bang sudah punya PIN. Gunakan *${usedPrefix}vault resetpin* jika lupa (hanya owner).`);
        if (!input || input.length !== 4 || isNaN(input)) return m.reply(`📌 Contoh: *${usedPrefix}vault setpin 1234* (4 digit angka)`);
        
        user.vault.pin = input;
        await db.save();
        return m.reply("✅ *PIN BERHASIL DISET!*\nJangan sampai lupa ya Bang.");
    }

    // 2. UNLOCK VAULT
    if (cmd === 'open') {
        if (!user.vault.pin) return m.reply(`❌ Bang belum set PIN. Ketik *${usedPrefix}vault setpin <4digit>*`);
        if (input !== user.vault.pin) return m.reply("❌ PIN Salah, Bang.");
        
        user.vault.locked = false;
        return m.reply("🔓 *VAULT TERBUKA!*\nBang bisa menambah atau melihat catatan sekarang.");
    }

    // 3. LOCK VAULT
    if (cmd === 'lock') {
        user.vault.locked = true;
        return m.reply("🔒 *VAULT TERKUNCI!*");
    }

    // --- PROTEKSI ---
    if (user.vault.locked && command !== 'vault') {
        if (['add', 'list', 'del'].includes(cmd)) {
            return m.reply(`🔒 *VAULT TERKUNCI!*\nBuka dulu dengan: *${usedPrefix}vault open <pin>*`);
        }
    }

    // 4. ADD NOTE
    if (cmd === 'add') {
        if (!input) return m.reply(`📌 Contoh: *${usedPrefix}vault add Password Akun: xxxxx*`);
        user.vault.notes.push({
            content: input,
            timestamp: Date.now()
        });
        await db.save();
        return m.reply("✅ Catatan berhasil disimpan di Vault.");
    }

    // 5. LIST NOTES
    if (cmd === 'list') {
        if (user.vault.notes.length === 0) return m.reply("ℹ️ Vault Bang masih kosong.");
        
        let list = `╭─❍ *SECURE VAULT* 🔒 ❍─\n│\n`;
        user.vault.notes.forEach((note, i) => {
            list += `│ *${i + 1}.* ${note.content}\n│ 📅 ${new Date(note.timestamp).toLocaleString()}\n│\n`;
        });
        list += `╰─────────────────────❍\n\n💡 Ketik *${usedPrefix}vault del <nomor>* untuk hapus.`;
        return m.reply(list);
    }

    // 6. DELETE NOTE
    if (cmd === 'del') {
        const index = parseInt(input) - 1;
        if (isNaN(index) || !user.vault.notes[index]) return m.reply("❌ Nomor catatan tidak valid.");
        
        user.vault.notes.splice(index, 1);
        await db.save();
        return m.reply("✅ Catatan berhasil dihapus.");
    }

    // DEFAULT MENU
    const help = `
╭─❍ *THE VAULT SYSTEM* 🔐
│
│ 🔓 *vault open <pin>*
│ 🔒 *vault lock*
│ ➕ *vault add <teks>*
│ 📜 *vault list*
│ 🗑️ *vault del <no>*
│ 🔑 *vault setpin <pin>*
│
├─────────────────────
│ ⚠️ *Status:* ${user.vault.locked ? '❌ TERKUNCI' : '✅ TERBUKA'}
╰─────────────────────❍
`.trim();
    m.reply(help);
};

handler.help = ["vault"];
handler.tags = ["main"];
handler.command = /^(vault|brankas)$/i;
handler.register = true;

export default handler;
