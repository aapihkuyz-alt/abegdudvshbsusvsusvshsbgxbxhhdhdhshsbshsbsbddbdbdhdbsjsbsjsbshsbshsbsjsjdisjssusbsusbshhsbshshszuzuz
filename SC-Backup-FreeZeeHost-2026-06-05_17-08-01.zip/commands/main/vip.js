import { generateWAMessageFromContent, proto } from "baileys";

let handler = async (m, { conn, usedPrefix, command, isPremium, isOwner }) => {
    if (!isPremium && !isOwner) return m.reply("❌ Fitur ini khusus member *Premium* atau *Owner*, Bang.");

    await m.react("💎");

    let menu = `╭─❍ *💎 VIP USER LOUNGE 💎* ❍─
│
│ ✨ *Status:* Premium Active
│ 🌟 *Benefits:* High-Priority Queue, 
│    No Limits, Exclusive Features.
│
├─────────────────────
│ 🛠️ *VIP EXCLUSIVE TOOLS:*
│
│ 📂 *Private Drive:*
│ ◦ ${usedPrefix}drive (Cek Cloud Storage)
│ ◦ ${usedPrefix}save (Simpan Media)
│ ◦ ${usedPrefix}get (Ambil Media)
│
│ 🕵️ *Stealth Tools:*
│ ◦ ${usedPrefix}ghost (Ghost/Stealth Mode)
│
│ 🎭 *Advanced AI:*
│ ◦ ${usedPrefix}ts2 (Tebak Lagu VN)
│ ◦ ${usedPrefix}remini (HD Upscaler)
│
╰─────────────────────❍`;

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: { deviceListMetadata: {}, deviceListMetadataVersion: 2 },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.fromObject({ text: menu }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "FreeZeeHost Exclusive" }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "📂 My Drive",
                                    id: `${usedPrefix}drive`
                                })
                            },
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "👤 My Profile",
                                    id: `${usedPrefix}profile`
                                })
                            }
                        ]
                    })
                })
            }
        }
    }, { quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.help = ["vip", "viplounge"];
handler.tags = ["main", "premium"];
handler.command = /^(vip|viplounge)$/i;

export default handler;