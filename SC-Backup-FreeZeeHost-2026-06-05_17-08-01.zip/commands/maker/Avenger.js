import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text || !text.includes("|"))
        return m.reply("Contoh:\n.avenger neoxr|api")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🦸",
                key: m.key
            }
        })

        const [text1, text2] = text.split("|").map(v => v.trim())

        if (!text1 || !text2)
            return m.reply("Format salah!\nContoh:\n.avenger neoxr|api")

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/avenger", {
                params: {
                    text1,
                    text2,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.url)
            throw new Error("API Error")

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption: `🦸 *Avengers Maker*\n\n${text1} x ${text2}`
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("AVENGER ERROR:", e.response?.data || e.message)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal membuat poster Avengers.")
    }
}

handler.help = ["avenger <text1>|<text2>", "avengers <text1>|<text2>"]
handler.tags = ["maker"]
handler.command = ["avenger", "avengers"]

export default handler