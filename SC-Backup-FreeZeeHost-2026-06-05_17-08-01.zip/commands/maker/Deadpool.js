import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text || !text.includes("|"))
        return m.reply(`
╭━━━〔 🔴 DEADPOOL TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .deadpool teks1|teks2
┃
┃ Contoh:
┃ ➜ .deadpool neoxr|api
┃
┃ Gunakan tanda "|" untuk
┃ memisahkan dua teks.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    const [text1, text2] = text.split("|").map(v => v.trim())

    if (!text1 || !text2)
        return m.reply("❌ Kedua teks harus diisi.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔴",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/deadpool", {
                params: {
                    text1,
                    text2,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 🔴 DEADPOOL RESULT 〕━━━⬣
┃ 📝 Teks 1 :
┃ ➜ ${text1}
┃
┃ 📝 Teks 2 :
┃ ➜ ${text2}
┃
┃ 🎭 Style  : Deadpool Comic
┃ 🔥 Theme  : Superhero Meme
┃
┃ Cocok buat:
┃ • Status brutal
┃ • Bio sok savage
┃ • Caption toxic tapi lucu
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("DEADPOOL ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat Deadpool image.
┃
┃ Coba teks lebih pendek
┃ atau ulangi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["deadpool"]
handler.tags = ["maker"]
handler.help = ["deadpool <teks1>|<teks2>"]

export default handler