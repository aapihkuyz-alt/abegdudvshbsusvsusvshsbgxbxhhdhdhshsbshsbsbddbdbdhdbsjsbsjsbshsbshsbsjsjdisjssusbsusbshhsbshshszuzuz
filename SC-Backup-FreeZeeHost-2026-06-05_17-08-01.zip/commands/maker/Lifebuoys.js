import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text || !text.includes("|"))
        return m.reply(`
╭━━━〔 🛟 LIFE BUOYS MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .lifebuoys teks1|teks2
┃
┃ Contoh:
┃ ➜ .lifebuoys neoxr|api
┃
┃ Gunakan tanda | untuk memisahkan
┃ dua teks yang ingin ditampilkan.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    const [text1, text2] = text.split("|").map(v => v.trim())

    if (!text1 || !text2)
        return m.reply("❌ Kedua teks harus diisi.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🛟",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/lifebuoys", {
                params: {
                    text1,
                    text2,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat lifebuoys image")

        const caption = `
╭━━━〔 🛟 LIFE BUOYS RESULT 〕━━━⬣
┃ 📝 Teks 1 :
┃ ➜ ${text1}
┃
┃ 📝 Teks 2 :
┃ ➜ ${text2}
┃
┃ 🌊 Theme  : Rescue Style
┃ 🎨 Output : HD Image
┃
┃ Cocok buat:
┃ • Meme dramatis
┃ • Quotes penyelamat
┃ • Konten unik
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("LIFEBUOYS ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat gambar lifebuoys.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["lifebuoys"]
handler.tags = ["maker"]
handler.help = ["lifebuoys <teks1|teks2>"]

export default handler