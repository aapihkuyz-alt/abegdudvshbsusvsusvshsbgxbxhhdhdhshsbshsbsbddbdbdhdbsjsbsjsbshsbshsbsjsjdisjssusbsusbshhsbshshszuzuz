import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text || !text.includes("|"))
        return m.reply(`
╭━━━〔 🦸 MARVEL TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .marvel teks1|teks2
┃
┃ Contoh:
┃ ➜ .marvel neoxr|api
┃
┃ Gunakan tanda "|" untuk
┃ memisahkan 2 teks.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    const [text1, text2] = text.split("|").map(v => v.trim())

    if (!text1 || !text2)
        return m.reply("❌ Kedua teks harus diisi.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🦸",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/marvel", {
                params: {
                    text1,
                    text2,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🦸 MARVEL EFFECT 〕━━━⬣
┃ 📝 Teks 1 : ${text1}
┃ 📝 Teks 2 : ${text2}
┃
┃ 🎬 Style  : Marvel Cinematic
┃ 📦 Size   : ${data.data.size || "-"}
┃ 🖼 Format : ${data.data.mime || "image/jpeg"}
┃
┃ Sekarang kamu terasa
┃ seperti karakter utama.
┃ Padahal cuma ganti teks.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("MARVEL ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Marvel.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["marvel"]
handler.tags = ["maker"]
handler.help = ["marvel <teks1|teks2>"]

export default handler