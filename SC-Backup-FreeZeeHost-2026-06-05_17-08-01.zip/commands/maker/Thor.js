import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text || !text.includes("|"))
        return m.reply(`
╭━━━〔 ⚡ THOR TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .thor teks1|teks2
┃
┃ Contoh:
┃ ➜ .thor neoxr|api
┃
┃ Gunakan tanda | untuk
┃ memisahkan dua teks.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    const [text1, text2] = text.split("|").map(v => v.trim())

    if (!text1 || !text2)
        return m.reply("❌ Kedua teks wajib diisi.")

    try {

        // React mulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "⚡",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/thor", {
                params: {
                    text1,
                    text2,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate thor image")

        const caption = `
╭━━━〔 ⚡ THOR EFFECT 〕━━━⬣
┃ 📝 Text 1 : ${text1}
┃ 📝 Text 2 : ${text2}
┃ 🎨 Style  : Thunder Power
┃
┃ Efek petir khas Asgard.
┃ Aura kuat. Energi brutal.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

⚡ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("THOR MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Thor.
┃ Coba lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["thor"]
handler.tags = ["maker"]
handler.help = ["thor <teks1|teks2>"]

export default handler