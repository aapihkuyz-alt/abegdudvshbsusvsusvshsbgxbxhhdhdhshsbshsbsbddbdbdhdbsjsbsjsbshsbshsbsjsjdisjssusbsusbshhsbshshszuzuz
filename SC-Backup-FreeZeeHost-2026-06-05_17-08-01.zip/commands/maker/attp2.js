import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan teks.\nContoh:\n#attp2 ayo scroll fesnuk!")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/attp2", {
                params: {
                    text,
                    color: JSON.stringify(["#FF0000", "#00FF00", "#0000FF"]),
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal membuat sticker.")

        await conn.sendMessage(m.chat, {
            sticker: {
                url: data.data.url
            }
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("ATTP2 ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat membuat sticker.")
    }
}

handler.command = ["attp2"]
handler.tags = ["maker"]
handler.help = ["attp2 <teks>"]

export default handler