import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan teks.\nContoh:\n#attp3 forget about where we are and let go?")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "✨", m.key)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/attp3", {
                params: {
                    text,
                    color: "2B1D0E", // default warna, bisa kamu ubah nanti
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal membuat sticker.")

        await conn.sendMessage(m.chat, {
            sticker: {
                url: data.data.url
            }
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("ATTP3 ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat membuat sticker.")
    }
}

handler.command = ["attp3"]
handler.tags = ["maker"]
handler.help = ["attp3 <teks>"]

export default handler