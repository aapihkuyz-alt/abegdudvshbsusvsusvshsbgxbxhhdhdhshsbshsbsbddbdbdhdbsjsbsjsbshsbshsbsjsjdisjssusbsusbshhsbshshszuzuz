import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🖤 BLACKPINK MAKER 〕━━━⬣
┃
┃ ➜ Contoh:
┃ ➜ .blackpink neoxr
┃
┃ Tulis teks yang ingin
┃ dijadikan style BLACKPINK.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🖤",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/blackpink", {
                params: {
                    text: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat logo")

        const caption = `
╭━━━〔 🖤 BLACKPINK RESULT 〕━━━⬣
┃ 💬 Teks :
┃ ➜ ${text}
┃
┃ 🎀 Style  : BLACKPINK Official
┃ 🌸 Mode   : K-Pop Aesthetic
┃
┃ ✨ Siap dipamerin ke grup.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("BLACKPINK ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat logo BLACKPINK.
┃
┃ Kemungkinan:
┃ • Teks terlalu panjang
┃ • API sibuk
┃ • Atau kamu typo
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["blackpink"]
handler.tags = ["maker"]
handler.help = ["blackpink <teks>"]

export default handler