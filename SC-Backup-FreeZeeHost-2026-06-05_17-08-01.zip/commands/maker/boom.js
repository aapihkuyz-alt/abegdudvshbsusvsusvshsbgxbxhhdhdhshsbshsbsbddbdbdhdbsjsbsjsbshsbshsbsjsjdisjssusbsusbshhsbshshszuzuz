import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 💥 BOOM TEXT MAKER 〕━━━⬣
┃
┃ ➜ Contoh:
┃ ➜ .boom neoxr
┃
┃ Masukkan teks yang ingin
┃ dibuat efek ledakan.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "💥",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/boom", {
                params: {
                    text: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 💥 BOOM EFFECT RESULT 〕━━━⬣
┃ 💬 Teks :
┃ ➜ ${text}
┃
┃ 🔥 Style  : Explosion Effect
┃ 🎇 Theme  : Fire / Impact
┃ 📦 Size   : ${data.data.size}
┃
┃ ⚠️ Cocok untuk:
┃ • Poster dramatis
┃ • Banner gaming
┃ • Thumbnail chaos
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("BOOM ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek ledakan.
┃
┃ Kemungkinan:
┃ • Teks terlalu panjang
┃ • API sedang sibuk
┃ • Server lagi ngambek
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["boom"]
handler.tags = ["maker"]
handler.help = ["boom <teks>"]

export default handler