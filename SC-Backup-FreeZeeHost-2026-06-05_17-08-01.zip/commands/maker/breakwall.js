import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🧱 BREAK WALL MAKER 〕━━━⬣
┃
┃ ➜ Contoh:
┃ ➜ .breakwall neoxr
┃
┃ Masukkan teks untuk
┃ efek tembok pecah.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🧱",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/breakwall", {
                params: {
                    text: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 🧱 BREAK WALL RESULT 〕━━━⬣
┃ 💬 Teks :
┃ ➜ ${text}
┃
┃ 💥 Effect  : Wall Break
┃ 🎨 Style   : Concrete Impact
┃
┃ Cocok untuk:
┃ • Banner keren
┃ • Logo clan
┃ • Tulisan savage
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("BREAKWALL ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek breakwall.
┃
┃ Coba lagi dengan teks
┃ yang lebih pendek.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["breakwall"]
handler.tags = ["maker"]
handler.help = ["breakwall <teks>"]

export default handler