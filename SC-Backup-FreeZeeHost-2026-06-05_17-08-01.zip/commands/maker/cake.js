import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🎂 CAKE TEXT MAKER 〕━━━⬣
┃
┃ ➜ Contoh:
┃ ➜ .cake neoxr
┃
┃ Masukkan teks untuk
┃ ditaruh di atas kue.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🎂",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/cake", {
                params: {
                    text: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 🎂 CAKE RESULT 〕━━━⬣
┃ 💬 Teks :
┃ ➜ ${text}
┃
┃ 🍰 Effect  : Birthday Cake
┃ 🎉 Style   : Celebration Theme
┃
┃ Cocok untuk:
┃ • Ucapan ulang tahun
┃ • Surprise virtual
┃ • Spam manis ke teman
╰━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("CAKE ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat cake image.
┃
┃ Coba lagi dengan teks
┃ yang lebih pendek ya.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["cake"]
handler.tags = ["maker"]
handler.help = ["cake <teks>"]

export default handler