import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 ☁️ CLOUDS TEXT MAKER 〕━━━⬣
┃
┃ ➜ Contoh:
┃ ➜ .clouds neoxr
┃
┃ Masukkan teks yang ingin
┃ dibuat efek awan.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "☁️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/clouds", {
                params: {
                    text: text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 ☁️ CLOUDS RESULT 〕━━━⬣
┃ 💬 Teks :
┃ ➜ ${text}
┃
┃ 🌥 Effect  : Sky Clouds
┃ 🎨 Style   : Soft & Dreamy
┃
┃ Cocok untuk:
┃ • Kata-kata galau
┃ • Quotes aesthetic
┃ • Bio yang sok tenang
╰━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("CLOUDS ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat clouds image.
┃
┃ Coba teks lebih pendek
┃ atau ulangi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["clouds"]
handler.tags = ["maker"]
handler.help = ["clouds <teks>"]

export default handler