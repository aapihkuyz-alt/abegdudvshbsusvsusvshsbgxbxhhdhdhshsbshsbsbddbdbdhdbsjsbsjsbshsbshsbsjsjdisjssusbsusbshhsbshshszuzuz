import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 😈 DEVIL TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .devil teks
┃
┃ Contoh:
┃ ➜ .devil neoxr
┃
┃ Gunakan teks pendek
┃ agar hasil lebih rapi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "😈",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/devil", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 😈 DEVIL RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🔥 Style  : Dark Devil
┃ 🎭 Theme  : Evil Aura
┃ 💀 Mood   : Brutal & Sinister
┃
┃ Cocok untuk:
┃ • Foto profil gelap
┃ • Status misterius
┃ • Bio anti terang
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔥",
                key: m.key
            }
        })

    } catch (e) {

        console.error("DEVIL ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat Devil image.
┃
┃ Coba teks lebih pendek
┃ atau ulangi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["devil"]
handler.tags = ["maker"]
handler.help = ["devil <teks>"]

export default handler