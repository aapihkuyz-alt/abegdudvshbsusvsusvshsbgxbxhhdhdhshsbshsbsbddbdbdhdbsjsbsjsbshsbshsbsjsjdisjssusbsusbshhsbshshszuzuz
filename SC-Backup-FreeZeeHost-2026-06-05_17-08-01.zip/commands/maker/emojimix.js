/**
 ╔══════════════════════
      ⧉  [emojimix] — [fun]
 ╚══════════════════════

  ✺ Type     : Plugin ESM
  ✺ API      : https://api.neoxr.eu
*/

import sharp from "sharp"

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    try {
        if (!text)
            return m.reply(
                `*Contoh:*\n` +
                `${usedPrefix + command} 😄🔥\n` +
                `${usedPrefix + command} 😄 🔥\n` +
                `${usedPrefix + command} 😄|🔥`
            )

        let emoji1, emoji2

        // support emoji1|emoji2
        if (text.includes("|")) {
            [emoji1, emoji2] = text.split("|").map(v => v.trim())
        } else {
            // support 😄🔥 atau 😄 🔥
            const emojis = [...text.matchAll(/\p{Extended_Pictographic}/gu)].map(v => v[0])
            if (emojis.length >= 2) {
                emoji1 = emojis[0]
                emoji2 = emojis[1]
            }
        }

        if (!emoji1 || !emoji2)
            return m.reply("🍂 *Masukkan 2 emoji yang valid.*")

        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        // 🔹 request API Neoxr
        const apiUrl =
            `https://api.neoxr.eu/api/emoji?q=${encodeURIComponent(emoji1)}_${encodeURIComponent(emoji2)}&apikey=${global.neoxr}`

        const res = await fetch(apiUrl)
        const json = await res.json()

        if (!json.status || !json.data?.url)
            return m.reply("🍂 *Emoji ini tidak bisa digabung.*")

        // 🔹 download PNG dari gstatic
        const imgRes = await fetch(json.data.url)
        const imgBuffer = Buffer.from(await imgRes.arrayBuffer())

        // 🔑 SAMA PERSIS KAYAK SMEME:
        // PNG → WEBP → STICKER
        const sticker = await sharp(imgBuffer)
            .resize(512, 512, {
                fit: "inside",
                background: {
                    r: 0,
                    g: 0,
                    b: 0,
                    alpha: 0
                }
            })
            .webp({
                quality: 90
            })
            .toBuffer()

        await conn.sendMessage(
            m.chat, {
                sticker
            }, {
                quoted: m
            }
        )

    } catch (e) {
        console.error(e)
        m.reply("🍂 *Emoji mix gagal diproses.*")
    } finally {
        await conn.sendMessage(m.chat, {
            react: {
                text: "",
                key: m.key
            }
        })
    }
}

handler.help = ["emojimix 😄🔥"]
handler.tags = ["fun"]
handler.command = ["emojimix"]
handler.limit = true
handler.register = false

export default handler