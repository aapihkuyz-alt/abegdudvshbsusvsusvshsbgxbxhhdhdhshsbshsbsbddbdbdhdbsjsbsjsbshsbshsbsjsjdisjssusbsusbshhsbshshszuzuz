import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🧽 ERASER TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .eraser teks
┃
┃ Contoh:
┃ ➜ .eraser neoxr
┃
┃ Gunakan teks singkat
┃ agar hasil lebih rapi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🧽",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/eraser", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 🧽 ERASER RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🎨 Style  : Eraser Effect
┃ ✏️ Tema   : Clean & Soft
┃ 🖼️ Output : High Quality
┃
┃ Cocok untuk:
┃ • Foto profil minimalis
┃ • Status aesthetic
┃ • Branding clean look
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✨",
                key: m.key
            }
        })

    } catch (e) {

        console.error("ERASER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat Eraser image.
┃
┃ Coba teks lebih pendek
┃ atau ulangi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["eraser"]
handler.tags = ["maker"]
handler.help = ["eraser <teks>"]

export default handler