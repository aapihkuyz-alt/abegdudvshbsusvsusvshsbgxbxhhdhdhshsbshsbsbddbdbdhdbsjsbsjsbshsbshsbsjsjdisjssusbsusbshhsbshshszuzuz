import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🔥 FLAMES TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .flames teks
┃
┃ Contoh:
┃ ➜ .flames neoxr
┃
┃ Gunakan teks singkat
┃ agar efek api terlihat jelas.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔥",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/flames", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 🔥 FLAMES RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🎨 Style  : Fire Effect
┃ 🌡️ Tema   : Burning Text
┃ 🖼️ Output : High Quality
┃
┃ Cocok untuk:
┃ • Nama clan
┃ • Logo gaming
┃ • Bio yang dramatis
┃ • Status penuh amarah 🔥
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔥",
                key: m.key
            }
        })

    } catch (e) {

        console.error("FLAMES ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat Flames image.
┃
┃ Coba teks lebih pendek
┃ atau ulangi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["flames"]
handler.tags = ["maker"]
handler.help = ["flames <teks>"]

export default handler