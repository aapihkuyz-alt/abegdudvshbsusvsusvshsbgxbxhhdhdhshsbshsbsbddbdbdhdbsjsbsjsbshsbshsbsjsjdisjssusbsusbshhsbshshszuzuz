import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 💕 GIRL TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .girl teks
┃
┃ Contoh:
┃ ➜ .girl neoxr
┃
┃ Gunakan teks singkat
┃ agar hasil lebih rapi ✨
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "💗",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/girl", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 💕 GIRL RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🎨 Style  : Girl Aesthetic
┃ 🌸 Tema   : Soft & Cute
┃ 🖼️ Output : High Quality
┃
┃ Cocok untuk:
┃ • Nama pasangan
┃ • Status bucin
┃ • PP aesthetic
┃ • Branding lucu ✨
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

💖 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✨",
                key: m.key
            }
        })

    } catch (e) {

        console.error("GIRL ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat Girl image.
┃
┃ Coba teks lebih pendek
┃ atau ulangi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["girl"]
handler.tags = ["maker"]
handler.help = ["girl <teks>"]

export default handler