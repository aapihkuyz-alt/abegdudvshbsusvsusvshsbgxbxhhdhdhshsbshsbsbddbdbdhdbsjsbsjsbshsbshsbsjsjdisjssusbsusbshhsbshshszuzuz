import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🕶️ GLASSES TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .glasses teks
┃
┃ Contoh:
┃ ➜ .glasses neoxr
┃
┃ Gunakan teks singkat
┃ agar hasil lebih jelas 👀
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🕶️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/glasses", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gambar")

        const caption = `
╭━━━〔 🕶️ GLASSES RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🎨 Style  : Glasses Effect
┃ 😎 Vibes  : Cool & Clean
┃ 🖼️ Output : HD Image
┃
┃ Cocok untuk:
┃ • Nama aesthetic
┃ • Branding santai
┃ • PP keren
┃ • Story WhatsApp
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔥",
                key: m.key
            }
        })

    } catch (e) {

        console.error("GLASSES ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat Glasses image.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["glasses"]
handler.tags = ["maker"]
handler.help = ["glasses <teks>"]

export default handler