import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 ⚡ GLITCH TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .glitchtext teks
┃
┃ Contoh:
┃ ➜ .glitchtext neoxr
┃
┃ Gunakan teks singkat
┃ agar efek glitch maksimal 🔥
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "⚡",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/glitchtext", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat glitch text")

        const caption = `
╭━━━〔 ⚡ GLITCH RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🎨 Style  : Digital Glitch
┃ 💥 Effect : Distorted RGB
┃ 🖼️ Output : HD Image
┃
┃ Cocok untuk:
┃ • Logo hacker vibe
┃ • PP gelap aesthetic
┃ • Story cyber style
┃ • Banner edgy
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔥",
                key: m.key
            }
        })

    } catch (e) {

        console.error("GLITCHTEXT ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat glitch text.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["glitchtext"]
handler.tags = ["maker"]
handler.help = ["glitchtext <teks>"]

export default handler