import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 ✨ GLOW TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .glow teks
┃
┃ Contoh:
┃ ➜ .glow neoxr
┃
┃ Gunakan teks singkat
┃ agar efek glow terlihat jelas 🔥
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✨",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/glow", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat glow text")

        const caption = `
╭━━━〔 ✨ GLOW RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🎨 Style  : Neon Glow
┃ 💡 Effect : Bright Light
┃ 🖼️ Output : HD Image
┃
┃ Cocok untuk:
┃ • Banner aesthetic
┃ • PP neon vibe
┃ • Story Instagram
┃ • Logo digital
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔥",
                key: m.key
            }
        })

    } catch (e) {

        console.error("GLOW ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat glow text.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["glow"]
handler.tags = ["maker"]
handler.help = ["glow <teks>"]

export default handler