import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🎨 GRADIENT TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .gradient teks
┃
┃ Contoh:
┃ ➜ .gradient neoxr
┃
┃ Gunakan teks singkat
┃ agar warna gradasi terlihat jelas.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🎨",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/gradient", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat gradient text")

        const caption = `
╭━━━〔 🎨 GRADIENT RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🌈 Style  : Color Gradient
┃ 🎭 Effect : Smooth Blend
┃ 🖼️ Output : HD Image
┃
┃ Cocok untuk:
┃ • Banner modern
┃ • Logo aesthetic
┃ • Story / feed
┃ • Branding digital
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("GRADIENT ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat gradient text.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["gradient"]
handler.tags = ["maker"]
handler.help = ["gradient <teks>"]

export default handler