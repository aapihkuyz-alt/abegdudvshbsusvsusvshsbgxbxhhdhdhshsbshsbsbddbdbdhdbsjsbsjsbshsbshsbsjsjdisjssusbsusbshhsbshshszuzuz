import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🌿 GRASS TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .grass teks
┃
┃ Contoh:
┃ ➜ .grass neoxr
┃
┃ Gunakan teks singkat
┃ agar efek rumput terlihat jelas.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "🌿",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/grass", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal membuat grass text")

        const caption = `
╭━━━〔 🌿 GRASS TEXT RESULT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🌱 Style  : Natural Grass
┃ 🌿 Effect : Fresh Outdoor
┃ 🖼️ Output : HD Image
┃
┃ Cocok untuk:
┃ • Poster tema alam
┃ • Logo eco style
┃ • Story aesthetic
┃ • Branding natural
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React sukses
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("GRASS ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat grass text.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["grass"]
handler.tags = ["maker"]
handler.help = ["grass <teks>"]

export default handler