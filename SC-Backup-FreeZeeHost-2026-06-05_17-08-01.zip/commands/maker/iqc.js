import axios from "axios"

function getTime() {
    const now = new Date()
    return now.toTimeString().slice(0, 5)
}

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply("Contoh:\n.iqc ayo scroll fesnuk 😜")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🖼️",
                key: m.key
            }
        })

        const timeNow = getTime()

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/iqc", {
                params: {
                    text,
                    time: timeNow,
                    chat_time: timeNow,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.url)
            throw new Error("API Error")

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption: "🗨️ Fake Chat Generated"
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("IQC ERROR:", e.response?.data || e.message)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Gagal generate IQC image.")
    }
}

handler.help = ["iqc <text>"]
handler.tags = ["maker"]
handler.command = ["iqc"]

export default handler