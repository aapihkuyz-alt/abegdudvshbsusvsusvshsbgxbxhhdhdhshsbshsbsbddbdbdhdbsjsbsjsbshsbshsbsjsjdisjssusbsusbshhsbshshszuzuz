import axios from "axios"
import FormData from "form-data"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text.includes("|"))
        return m.reply("❌ Format:\n#leveling rank|level|currentXp|requiredXp|name\n\nReply gambar.")

    if (!m.quoted)
        return m.reply("❌ Reply gambar untuk leveling card.")

    const mime =
        m.quoted.mimetype ||
        m.quoted.msg?.mimetype ||
        ""

    if (!/image/.test(mime))
        return m.reply("❌ File harus berupa gambar.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const [rank, level, currentXp, requiredXp, name] =
        text.split("|").map(v => v.trim())

        if (!rank || !level || !currentXp || !requiredXp || !name)
            return m.reply("❌ Format tidak lengkap.\n#leveling 2|10|7560|250|Jokowi")

        // ===== Download gambar =====
        const media = await m.quoted.download()
        if (!media)
            return m.reply("❌ Gagal download gambar.")

        // ===== Upload ke tmpfiles =====
        const form = new FormData()
        form.append("file", media, "image.jpg")

        const upload = await axios.post(
            "https://tmpfiles.org/api/v1/upload",
            form, {
                headers: form.getHeaders()
            }
        )

        if (!upload.data?.data?.url)
            return m.reply("❌ Gagal upload gambar.")

        // Ubah ke direct link
        const rawUrl = upload.data.data.url
        const imageUrl = rawUrl.replace("tmpfiles.org/", "tmpfiles.org/dl/")

        // ===== Request API =====
        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/leveling", {
                params: {
                    rank,
                    level,
                    picture: imageUrl,
                    currentXp,
                    requiredXp,
                    name,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal membuat leveling card.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `🎖 Leveling Card\n\n👤 ${name}\n⭐ Level ${level}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("LEVELING ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat membuat leveling card.")
    }
}

handler.command = ["leveling", "rankcard"]
handler.tags = ["maker"]
handler.help = ["leveling rank|level|currentXp|requiredXp|name (reply image)"]

export default handler