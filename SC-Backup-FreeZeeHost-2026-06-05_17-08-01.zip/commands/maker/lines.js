import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🧵 LINES TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .lines teks
┃
┃ Contoh:
┃ ➜ .lines neoxr
┃
┃ Buat teks kamu tampil
┃ dengan efek garis estetik.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧵",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/lines", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🧵 LINES EFFECT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🎨 Style   : Line Art Text
┃ 📦 Size    : ${data.data.size || "-"}
┃ 🖼 Format  : ${data.data.mime || "image/jpeg"}
┃
┃ Efek minimalis,
┃ tapi tetap nyolot.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("LINES ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek lines.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["lines"]
handler.tags = ["maker"]
handler.help = ["lines <teks>"]

export default handler