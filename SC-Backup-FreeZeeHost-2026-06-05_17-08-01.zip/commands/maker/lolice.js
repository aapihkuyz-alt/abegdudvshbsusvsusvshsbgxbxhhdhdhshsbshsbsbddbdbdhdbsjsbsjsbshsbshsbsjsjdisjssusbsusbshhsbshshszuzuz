import axios from 'axios'
import FormData from 'form-data'
import {
    fileTypeFromBuffer
} from 'file-type'

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    let inputUrl

    // --- LOGIC INPUT: Support Gambar (Reply/Direct) atau Link (Text) ---
    if (/image\/(jpe?g|png)/.test(mime)) {
        await conn.sendMessage(m.chat, {
            react: {
                text: '🕒',
                key: m.key
            }
        })
        let img = await q.download()
        let {
            ext
        } = await fileTypeFromBuffer(img) || {
            ext: 'jpg'
        }
        let outForm = new FormData()
        outForm.append('fileToUpload', img, `image.${ext}`)
        outForm.append('reqtype', 'fileupload')

        const catboxInput = await axios.post('https://catbox.moe/user/api.php', outForm, {
            headers: {
                ...outForm.getHeaders()
            }
        })
        inputUrl = catboxInput.data
    } else if (text && /https?:\/\/[^\s]+/.test(text)) {
        await conn.sendMessage(m.chat, {
            react: {
                text: '🕒',
                key: m.key
            }
        })
        inputUrl = text.trim()
    } else {
        return m.reply(`Balas gambar atau masukkan link gambar dengan perintah *${usedPrefix + command}*`)
    }

    try {
        // 1. Hit API AlyaChan (Canvas Lolice)
        const {
            data
        } = await axios.get('https://api.alyachan.dev/api/canvas/lolice', {
            params: {
                image_url: inputUrl
            },
            headers: {
                'Authorization': `Bearer ${global.alyachan}`,
                'Content-Type': 'application/json'
            }
        })

        if (!data.status) return m.reply('Gagal memproses Lolice card.')
        let resultUrl = data.data.url

        // 2. Upload Hasil ke Catbox
        let resBuffer = await axios.get(resultUrl, {
            responseType: 'arraybuffer'
        }).then(res => res.data)
        let finalForm = new FormData()
        finalForm.append('fileToUpload', Buffer.from(resBuffer), `lolice.png`)
        finalForm.append('reqtype', 'fileupload')

        const catboxResult = await axios.post('https://catbox.moe/user/api.php', finalForm, {
            headers: {
                ...finalForm.getHeaders()
            }
        })
        let finalCatboxUrl = catboxResult.data

        // 3. Kirim Hasil & React Sukses
        await conn.sendFile(m.chat, finalCatboxUrl, 'lolice.png', `*Result:* ${finalCatboxUrl}`, m)
        await conn.sendMessage(m.chat, {
            react: {
                text: '✅',
                key: m.key
            }
        })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, {
            react: {
                text: '❌',
                key: m.key
            }
        })
        m.reply(`Error: ${e.message || 'Terjadi kesalahan internal.'}`)
    }
}

handler.help = ['lolice <link/reply>']
handler.tags = ['maker']
handler.command = /^(lolice)$/i
handler.limit = true

export default handler