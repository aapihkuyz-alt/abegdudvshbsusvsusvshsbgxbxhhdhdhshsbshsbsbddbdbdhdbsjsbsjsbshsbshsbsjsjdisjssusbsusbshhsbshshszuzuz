import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🌋 MAGMA TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .magma teks
┃
┃ Contoh:
┃ ➜ .magma neoxr
┃
┃ Efek lava panas membara
┃ siap melelehkan teks kamu.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🌋",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/magma", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🌋 MAGMA EFFECT 〕━━━⬣
┃ 📝 Teks :
┃ ➜ ${text}
┃
┃ 🔥 Style   : Magma / Lava
┃ 📦 Size    : ${data.data.size || "-"}
┃ 🖼 Format  : ${data.data.mime || "image/jpeg"}
┃
┃ Efek panas membara,
┃ cocok buat yang emosinya
┃ sering naik turun.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("MAGMA ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek magma.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["magma"]
handler.tags = ["maker"]
handler.help = ["magma <teks>"]

export default handler