import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🟢 MATRIX TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .matrix teks
┃
┃ Contoh:
┃ ➜ .matrix neoxr
┃
┃ Gunakan teks pendek
┃ agar hasil lebih rapi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🟢",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/matrix", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🟢 MATRIX EFFECT 〕━━━⬣
┃ 📝 Teks     : ${text}
┃ 🎨 Style    : Digital Rain
┃
┃ Kamu sekarang terlihat
┃ seperti hacker profesional.
┃
┃ Padahal cuma ganti font.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("MATRIX ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Matrix.
┃
┃ Coba teks lebih pendek
┃ atau ulangi lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["matrix"]
handler.tags = ["maker"]
handler.help = ["matrix <teks>"]

export default handler