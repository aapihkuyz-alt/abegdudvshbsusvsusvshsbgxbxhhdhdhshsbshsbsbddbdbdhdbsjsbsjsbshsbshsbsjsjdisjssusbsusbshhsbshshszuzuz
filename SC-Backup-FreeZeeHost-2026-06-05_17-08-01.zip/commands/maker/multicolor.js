import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🌈 MULTICOLOR TEXT 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .multicolor teks
┃
┃ Contoh:
┃ ➜ .multicolor neoxr
┃
┃ Gunakan teks singkat
┃ agar hasil lebih jelas.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🌈",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/multicolor", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🌈 MULTICOLOR EFFECT 〕━━━⬣
┃ 📝 Teks     : ${text}
┃ 🎨 Style    : Rainbow Gradient
┃
┃ Warna-warni begini
┃ cocok buat flex tipis-tipis.
┃
┃ Minimal kelihatan niat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("MULTICOLOR ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Multicolor.
┃
┃ Coba lagi atau gunakan teks
┃ yang lebih pendek.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["multicolor"]
handler.tags = ["maker"]
handler.help = ["multicolor <teks>"]

export default handler