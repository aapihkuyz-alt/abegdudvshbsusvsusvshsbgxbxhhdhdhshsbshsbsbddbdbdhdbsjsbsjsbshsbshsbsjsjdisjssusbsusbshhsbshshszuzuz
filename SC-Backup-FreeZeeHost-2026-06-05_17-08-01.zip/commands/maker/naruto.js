import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🍥 NARUTO TEXT 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .naruto teks
┃
┃ Contoh:
┃ ➜ .naruto neoxr
┃
┃ Gunakan teks singkat
┃ agar hasil lebih jelas.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🍥",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/naruto", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🍥 NARUTO EFFECT 〕━━━⬣
┃ 📝 Teks     : ${text}
┃ 🌀 Style    : Shinobi Theme
┃
┃ Siap jadi Hokage
┃ atau cuma ninja keyboard?
┃
┃ Rasakan chakra dalam teksmu.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

🔥 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("NARUTO ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Naruto.
┃
┃ Coba lagi atau gunakan teks
┃ yang lebih pendek.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["naruto"]
handler.tags = ["maker"]
handler.help = ["naruto <teks>"]

export default handler