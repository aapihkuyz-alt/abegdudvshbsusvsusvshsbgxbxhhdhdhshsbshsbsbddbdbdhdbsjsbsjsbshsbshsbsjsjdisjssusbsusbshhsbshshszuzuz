import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 💡 NEON TEXT 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .neon teks
┃
┃ Contoh:
┃ ➜ .neon neoxr
┃
┃ Gunakan teks singkat
┃ agar efek lebih maksimal.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "💡",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/neon", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 💡 NEON EFFECT 〕━━━⬣
┃ 📝 Teks     : ${text}
┃ 🌈 Style    : Neon Glow
┃
┃ Lampu nyala,
┃ aura langsung beda.
┃
┃ Siap jadi papan nama
┃ paling terang di timeline.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("NEON ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Neon.
┃
┃ Coba lagi atau gunakan
┃ teks yang lebih pendek.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["neon"]
handler.tags = ["maker"]
handler.help = ["neon <teks>"]

export default handler