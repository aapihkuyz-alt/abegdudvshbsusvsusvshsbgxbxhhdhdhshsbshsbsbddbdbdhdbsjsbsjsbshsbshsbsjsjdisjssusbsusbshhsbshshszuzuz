import axios from 'axios'
import FormData from 'form-data'

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    // Validasi input teks menggunakan m.reply
    if (!text) return m.reply(`Masukkan teks bijaknya!\nContoh: *${usedPrefix + command} Masa depan adalah misteri*`)

    // --- REACT: Processing ---
    await conn.sendMessage(m.chat, {
        react: {
            text: '🕒',
            key: m.key
        }
    })

    try {
        // 1. Hit API AlyaChan (Canvas Oogway)
        const {
            data
        } = await axios.get('https://api.alyachan.dev/api/canvas/oogway', {
            params: {
                text: text
            },
            headers: {
                'Authorization': `Bearer ${global.alyachan}`,
                'Content-Type': 'application/json'
            }
        })

        if (!data.status) return m.reply('Gagal memproses gambar Oogway.')
        let resultUrl = data.data.url

        // 2. Upload Hasil ke Catbox (Setiap ada gini upload ke catbox)
        let resBuffer = await axios.get(resultUrl, {
            responseType: 'arraybuffer'
        }).then(res => res.data)
        let finalForm = new FormData()
        finalForm.append('fileToUpload', Buffer.from(resBuffer), `oogway.png`)
        finalForm.append('reqtype', 'fileupload')

        const catboxResult = await axios.post('https://catbox.moe/user/api.php', finalForm, {
            headers: {
                ...finalForm.getHeaders()
            }
        })
        let finalCatboxUrl = catboxResult.data

        // 3. Kirim Hasil & React Sukses
        await conn.sendFile(m.chat, finalCatboxUrl, 'oogway.png', `*Quote:* ${text}\n*Source:* ${finalCatboxUrl}`, m)
        await conn.sendMessage(m.chat, {
            react: {
                text: '✅',
                key: m.key
            }
        })

    } catch (e) {
        console.error(e)
        // React Gagal
        await conn.sendMessage(m.chat, {
            react: {
                text: '❌',
                key: m.key
            }
        })
        m.reply(`Error: ${e.message || 'Terjadi kesalahan internal.'}`)
    }
}

handler.help = ['oogway <teks>']
handler.tags = ['maker']
handler.command = /^(oogway)$/i
handler.limit = true

export default handler