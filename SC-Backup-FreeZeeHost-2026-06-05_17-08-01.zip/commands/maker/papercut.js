import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 ✂️ PAPERCUT TEXT 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .papercut teks
┃
┃ Contoh:
┃ ➜ .papercut neoxr
┃
┃ Gunakan teks singkat
┃ agar hasil lebih rapi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "✂️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/papercut", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 ✂️ PAPERCUT EFFECT 〕━━━⬣
┃ 📝 Teks     : ${text}
┃ 🎨 Style    : Paper Cut Art
┃
┃ Efek potongan kertas
┃ dengan bayangan realistis.
┃
┃ Minimalis tapi tetap estetik.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("PAPERCUT ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Papercut.
┃
┃ Coba lagi dengan teks lebih pendek.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["papercut"]
handler.tags = ["maker"]
handler.help = ["papercut <teks>"]

export default handler