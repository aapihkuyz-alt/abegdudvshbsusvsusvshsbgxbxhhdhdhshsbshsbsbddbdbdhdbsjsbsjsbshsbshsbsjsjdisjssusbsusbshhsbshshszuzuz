import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🐷 PIG TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .pig teks
┃
┃ Contoh:
┃ ➜ .pig neoxr
┃
┃ Gunakan teks singkat
┃ agar hasil tidak kepanjangan.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🐷",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/pig", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🐷 PIG EFFECT 〕━━━⬣
┃ 📝 Teks     : ${text}
┃ 🎨 Style    : Pig Art
┃
┃ Teks kamu sekarang
┃ resmi jadi bagian peternakan digital.
┃
┃ Unik. Aneh. Tapi estetik.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("PIG ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Pig.
┃
┃ Coba ulangi beberapa saat lagi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["pig"]
handler.tags = ["maker"]
handler.help = ["pig <teks>"]

export default handler