import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text || !text.includes("|"))
        return m.reply(`
╭━━━〔 🎬 HUB LOGO MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .pornhub teks1|teks2
┃
┃ Contoh:
┃ ➜ .pornhub neoxr|api
┃
┃ Gunakan tanda | untuk
┃ memisahkan dua teks.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    const [text1, text2] = text.split("|").map(v => v.trim())

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🎬",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/pornhub", {
                params: {
                    text1,
                    text2,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate image")

        const caption = `
╭━━━〔 🎬 HUB STYLE LOGO 〕━━━⬣
┃ 📝 Text 1 : ${text1}
┃ 📝 Text 2 : ${text2}
┃ 🎨 Style  : Black & Orange
┃
┃ Logo parody berhasil dibuat.
┃ Gunakan dengan bijak ya.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("PORN HUB MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat logo.
┃ Coba ulangi beberapa saat lagi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["pornhub"]
handler.tags = ["maker"]
handler.help = ["pornhub <teks1|teks2>"]

export default handler