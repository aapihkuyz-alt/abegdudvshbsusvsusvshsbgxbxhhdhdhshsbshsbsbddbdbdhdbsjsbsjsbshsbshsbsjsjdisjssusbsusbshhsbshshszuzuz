import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🐶 PUPPY GIF MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .puppy teks
┃
┃ Contoh:
┃ ➜ .puppy neoxr
┃
┃ Teks akan dimasukkan
┃ ke dalam animasi puppy.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🐶",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/puppy", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate GIF")

        const caption = `
╭━━━〔 🐾 PUPPY ANIMATION 〕━━━⬣
┃ 📝 Text   : ${text}
┃ 🎬 Format : GIF Animation
┃
┃ Puppy lucu berhasil dibuat.
┃ Siap dikirim ke grup biar rame.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                video: {
                    url: data.data.url
                }, // kirim sebagai gif video
                gifPlayback: true,
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("PUPPY MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat puppy GIF.
┃ Coba ulangi beberapa saat lagi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["puppy"]
handler.tags = ["maker"]
handler.help = ["puppy <teks>"]

export default handler