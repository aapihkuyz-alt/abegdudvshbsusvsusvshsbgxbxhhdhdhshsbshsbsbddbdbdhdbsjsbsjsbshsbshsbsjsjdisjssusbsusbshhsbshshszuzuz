import axios from 'axios'
import {
    Sticker
} from 'wa-sticker-formatter'
import uploadImage from '../../core/uploadImage.js'

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''
    let txt = text ? text : typeof q.text == 'string' ? q.text : ''

    if (!txt) throw `Example: ${usedPrefix + command} halo`

    // ambil avatar
    let avatar = await conn.profilePictureUrl(q.sender, 'image')
        .catch(_ => 'https://i.ibb.co/2WzLyGk/profile.jpg')

    avatar = /telegra|catbox/.test(avatar) ?
        avatar :
        await uploadImage((await conn.getFile(avatar)).data)

    let buffer

    if (!/image\/(jpe?g|png)/.test(mime)) {
        buffer = await fakechat(txt, q.name, avatar)
    } else {
        let img = await q.download()
        let url = await uploadImage(img)
        buffer = await fakechatImg(url, txt, q.name, avatar)
    }

    // BUAT STIKER (PAKAI GLOBAL FIX)
    let sticker = new Sticker(buffer, {
        pack: global.namebot, // ✅ namebot
        author: global.ownername, // ✅ ownername
        type: 'FULL',
        quality: 100
    })

    await conn.sendMessage(
        m.chat, {
            sticker: await sticker.toBuffer()
        }, {
            quoted: m
        }
    )
}

handler.help = ['qc']
handler.tags = ['sticker']
handler.command = /^(fc|fakechat|qc)$/i
handler.limit = true
handler.onlyprem = true

export default handler

/* ================= FUNCTIONS ================= */

async function fakechat(text, name, url) {
    let body = {
        type: 'quote',
        format: 'webp',
        backgroundColor: '#FFFFFF',
        width: 512,
        height: 512,
        scale: 2,
        messages: [{
            avatar: true,
            from: {
                name,
                photo: {
                    url
                }
            },
            text,
            replyMessage: {}
        }]
    }

    let res = await axios.post(
        'https://bot.lyo.su/quote/generate',
        body
    )

    return Buffer.from(res.data.result.image, 'base64')
}

async function fakechatImg(url, text, name, avatar) {
    let body = {
        type: 'quote',
        format: 'png',
        backgroundColor: '#FFFFFF',
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
            media: {
                url
            },
            avatar: true,
            from: {
                name,
                photo: {
                    url: avatar
                }
            },
            text,
            replyMessage: {}
        }]
    }

    let res = await axios.post(
        'https://bot.lyo.su/quote/generate',
        body
    )

    return Buffer.from(res.data.result.image, 'base64')
}