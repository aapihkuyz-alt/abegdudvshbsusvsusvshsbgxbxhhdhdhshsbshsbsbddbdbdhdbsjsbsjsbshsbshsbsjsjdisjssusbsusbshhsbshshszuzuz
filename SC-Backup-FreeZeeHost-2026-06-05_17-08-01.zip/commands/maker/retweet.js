import axios from 'axios'
import FormData from 'form-data'
import {
    fileTypeFromBuffer
} from 'file-type'

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    let q = m.quoted ? m.quoted : m
    let mime = (q.msg || q).mimetype || ''

    // Validasi 1: Harus reply gambar
    if (!/image\/(jpe?g|png)/.test(mime)) {
        return m.reply(`Kirim atau balas gambar dengan format:\n*${usedPrefix + command} username | Nama | Isi tweet*`)
    }

    // Validasi 2: Pisahkan teks dengan karakter "|"
    let [username, displayName, comment] = text.split('|').map(v => v?.trim())

    // Validasi 3: Pastikan ketiga parameter diisi
    if (!username || !displayName || !comment) {
        return m.reply(`Format salah atau kurang lengkap!\n\n*Contoh Penggunaan:*\n${usedPrefix + command} alyachan | Alya Chan | Info mabar dong ges\n\n*(Jangan lupa balas/kirim gambarnya)*`)
    }

    if (typeof conn.sendReact === 'function') {
        await conn.sendReact(m.chat, '🕒', m.key).catch(() => {})
    } else {
        await conn.sendMessage(m.chat, {
            react: {
                text: '🕒',
                key: m.key
            }
        }).catch(() => {})
    }

    try {
        // 1. Download gambar yang di-reply & Upload ke Catbox sebagai Avatar
        let img = await q.download()
        let {
            ext
        } = await fileTypeFromBuffer(img) || {
            ext: 'jpg'
        }
        let ppForm = new FormData()
        ppForm.append('fileToUpload', img, `avatar.${ext}`)
        ppForm.append('reqtype', 'fileupload')

        let catboxInput = await axios.post('https://catbox.moe/user/api.php', ppForm, {
            headers: {
                ...ppForm.getHeaders()
            }
        })
        let pp = catboxInput.data.trim()

        // 2. Hit API AlyaChan (Canvas Retweet) dengan data MANUAL
        const {
            data
        } = await axios.get('https://api.alyachan.dev/api/canvas/retweet', {
            params: {
                avatar_url: pp,
                comment: comment, // Dari input manual
                display_name: displayName, // Dari input manual
                username: username, // Dari input manual
                theme: 'dark'
            },
            headers: {
                'Authorization': `Bearer ${global.alyachan}`,
                'Content-Type': 'application/json'
            }
        })

        if (!data.status) {
            return m.reply(`Gagal memproses gambar Retweet dari API.\nDetail: ${data.message || 'Unknown Error'}`)
        }

        let resultUrl = data.data.url

        // 3. Upload Hasil Akhir ke Catbox (Wajib)
        let resBuffer = await axios.get(resultUrl, {
            responseType: 'arraybuffer'
        }).then(res => res.data)
        let finalForm = new FormData()
        finalForm.append('fileToUpload', Buffer.from(resBuffer), `retweet.png`)
        finalForm.append('reqtype', 'fileupload')

        const catboxResult = await axios.post('https://catbox.moe/user/api.php', finalForm, {
            headers: {
                ...finalForm.getHeaders()
            }
        })
        let finalCatboxUrl = catboxResult.data.trim()

        // 4. Kirim Hasil ke User
        await conn.sendFile(m.chat, finalCatboxUrl, 'retweet.png', `*Result:* ${finalCatboxUrl}`, m)
        if (typeof conn.sendReact === 'function') await conn.sendReact(m.chat, '✅', m.key).catch(() => {})

    } catch (e) {
        console.error(e)
        if (typeof conn.sendReact === 'function') {
            await conn.sendReact(m.chat, '❌', m.key).catch(() => {})
        } else {
            await conn.sendMessage(m.chat, {
                react: {
                    text: '❌',
                    key: m.key
                }
            }).catch(() => {})
        }

        let errMsg = e.response ? JSON.stringify(e.response.data) : e.message
        m.reply(`Error Sistem:\n\`\`\`${errMsg}\`\`\``)
    }
}

handler.help = ['retweet <username|nama|teks>']
handler.tags = ['maker']
handler.command = /^(retweet|rt)$/i
handler.limit = true

export default handler