import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🏖️ SAND TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format penggunaan:
┃ ➜ .sand teks
┃
┃ Contoh:
┃ ➜ .sand neoxr
┃
┃ Teks kamu akan dibuat
┃ dengan efek tulisan pasir.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🏖️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/sand", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate sand image")

        const caption = `
╭━━━〔 🏝️ SAND EFFECT 〕━━━⬣
┃ 📝 Text    : ${text}
┃ 🎨 Style   : Sand Writing
┃
┃ Tulisan kamu sekarang
┃ terlihat seperti dibuat
┃ di atas pasir pantai.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("SAND MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek sand.
┃ Coba lagi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["sand"]
handler.tags = ["maker"]
handler.help = ["sand <teks>"]

export default handler