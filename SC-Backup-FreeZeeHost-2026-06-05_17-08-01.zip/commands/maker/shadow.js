import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🌑 SHADOW TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format penggunaan:
┃ ➜ .shadow teks
┃
┃ Contoh:
┃ ➜ .shadow neoxr
┃
┃ Teks kamu akan dibuat
┃ dengan efek bayangan gelap
┃ yang elegan dan tegas.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React mulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "🌑",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/shadow", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate shadow image")

        const caption = `
╭━━━〔 🌘 SHADOW EFFECT 〕━━━⬣
┃ 📝 Text    : ${text}
┃ 🎨 Style   : Dark Shadow
┃ 📦 Size    : ${data.data.size || "-"}
┃
┃ Efek ini memberi kesan
┃ misterius, tegas, dan
┃ sedikit edgy.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("SHADOW MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek shadow.
┃ Coba lagi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["shadow"]
handler.tags = ["maker"]
handler.help = ["shadow <teks>"]

export default handler