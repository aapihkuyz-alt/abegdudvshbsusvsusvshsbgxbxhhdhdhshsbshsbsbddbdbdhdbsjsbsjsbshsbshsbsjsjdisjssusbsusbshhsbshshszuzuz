import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🔪 SLICE TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format penggunaan:
┃ ➜ .slice teks
┃
┃ Contoh:
┃ ➜ .slice neoxr
┃
┃ Teks kamu akan dibuat
┃ dengan efek terpotong
┃ dramatis dan tajam.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React mulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔪",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/slice", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate slice image")

        const caption = `
╭━━━〔 ⚔️ SLICE EFFECT 〕━━━⬣
┃ 📝 Text    : ${text}
┃ 🎨 Style   : Slice / Cut
┃
┃ Efek ini memberi kesan
┃ terbelah, tajam, dan
┃ penuh tekanan visual.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("SLICE MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek slice.
┃ Coba lagi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["slice"]
handler.tags = ["maker"]
handler.help = ["slice <teks>"]

export default handler