import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🔥 SLICED TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format penggunaan:
┃ ➜ .sliced teks
┃
┃ Contoh:
┃ ➜ .sliced neoxr
┃
┃ Efek teks terpotong dengan
┃ gaya lebih agresif & tajam.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React mulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "⚡",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/sliced", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate sliced image")

        const caption = `
╭━━━〔 ⚔️ SLICED EFFECT 〕━━━⬣
┃ 📝 Text    : ${text}
┃ 🎨 Style   : Sliced Extreme
┃ 📦 Size    : ${data.data.size || "-"}
┃
┃ Versi ini lebih brutal.
┃ Terlihat seperti dibelah
┃ dengan tekanan keras.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("SLICED MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek sliced.
┃ Coba lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["sliced"]
handler.tags = ["maker"]
handler.help = ["sliced <teks>"]

export default handler