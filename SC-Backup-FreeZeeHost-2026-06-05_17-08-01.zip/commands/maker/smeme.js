/**
 ╔══════════════════════
      ⧉  [smeme] — [maker]
 ╚══════════════════════

  ✺ Type     : Plugin ESM
  ✺ Source   : https://whatsapp.com/channel/0029VbAXhS26WaKugBLx4E05
  ✺ Creator  : SXZnightmare
  ✺ API      : [ https://api.nekolabs.web.id ]
  ✺ Req      : Dneo [ 6283851×××××× ]
*/

import { Buffer } from "buffer";
import sharp from "sharp";
import { fileTypeFromBuffer } from "file-type";

const UPLOAD_TIMEOUT = 20000;

async function uploader(buffer) {
    if (!buffer || buffer.length === 0) {
        throw new Error("Empty buffer");
    }

    const type = await fileTypeFromBuffer(buffer);
    if (!type) {
        throw new Error("Unknown file type");
    }

    const form = new FormData();
    const blob = new Blob([buffer], { type: type.mime });
    form.append("files[]", blob, `upload.${type.ext}`);

    const res = await fetch("https://uguu.se/upload.php", {
        method: "POST",
        headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            Accept: "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br",
            "Cache-Control": "no-cache",
            Pragma: "no-cache"
        },
        body: form,
        signal: AbortSignal.timeout(UPLOAD_TIMEOUT)
    });

    if (!res.ok) {
        throw new Error(`Upload failed (${res.status})`);
    }

    const json = await res.json();
    if (!json?.files?.[0]?.url) {
        throw new Error("Invalid upload response");
    }

    return json.files[0].url.trim();
}

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        if (!text) {
            return m.reply(`*Contoh:*\n${usedPrefix + command} teks atas\n${usedPrefix + command} teks atas | teks bawah\n${usedPrefix + command} | teks bawah`);
        }

        let q = m.quoted ? m.quoted : m;
        let mime = (q.msg || q).mimetype || "";

        if (!mime.startsWith("image/")) {
            return m.reply(`🍂 *Reply atau kirim gambar terlebih dahulu.*`);
        }

        let raw = text.trim();
        let textT = "";
        let textB = "";

        if (raw.includes("|")) {
            let parts = raw.split("|");
            textT = parts[0]?.trim() || "";
            textB = parts[1]?.trim() || "";
        } else {
            textT = raw;
        }

        if (!textT && !textB) {
            return m.reply(`🍂 *Teks tidak boleh kosong.*`);
        }

        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        let buffer = await q.download();
        if (!buffer) {
            return m.reply(`🍂 *Gagal membaca gambar.*`);
        }

        let imageUrl = await uploader(buffer);

        let apiUrl =
            "https://api.nekolabs.web.id/canvas/meme" +
            `?imageUrl=${encodeURIComponent(imageUrl)}` +
            `&textT=${encodeURIComponent(textT)}` +
            `&textB=${encodeURIComponent(textB)}`;

        let res = await fetch(apiUrl, {
            headers: {
                "User-Agent": "Mozilla/5.0",
                Accept: "image/*"
            }
        });

        if (!res.ok) {
            return m.reply(`🍂 *Gagal membuat meme.*`);
        }

        let imgBuffer = Buffer.from(await res.arrayBuffer());

        let sticker = await sharp(imgBuffer)
            .resize(512, 512, { fit: "inside" })
            .webp({ quality: 90 })
            .toBuffer();

        await conn.sendMessage(
            m.chat,
            { sticker },
            { quoted: m }
        );

    } catch (e) {
        await m.reply(`🍂 *Smeme gagal diproses.*`);
    } finally {
        await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });
    }
};

handler.help = ["smeme"];
handler.tags = ["maker"];
handler.command = ["smeme"];
handler.limit = true;
handler.register = false; // true kan jika ada fitur register atau daftar di bot mu.

export default handler;