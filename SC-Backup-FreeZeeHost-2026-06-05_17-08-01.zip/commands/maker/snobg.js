import axios from "axios";
import { Sticker } from 'wa-sticker-formatter';

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!/image/.test(mime)) return m.reply(`📌 Contoh: Kirim/Reply gambar dengan perintah *${usedPrefix + command}*`);

    await m.react("⏳");
    try {
        let media = await q.download();
        if (!media) throw new Error("Gagal mendownload gambar.");

        // 1. Upload ke Telegra.ph / Catbox untuk dapetin URL (Alyachan API butuh URL)
        // Kita pakai uploader yang ada di core
        const { uploadImage } = await import("../../core/uploadImage.js");
        const imageUrl = await uploadImage(media);

        // 2. Remove Background via Neoxr
        const res = await axios.get("https://api.neoxr.eu/api/nobg", {
            params: { url: imageUrl, apikey: global.neoxr }
        });

        if (!res.data?.status || !res.data.data?.url) throw new Error("Gagal menghapus background.");

        // 3. Convert ke Sticker
        const noBgBuffer = await axios.get(res.data.data.url, { responseType: 'arraybuffer' });
        
        let sticker = new Sticker(noBgBuffer.data, {
            pack: global.botname,
            author: global.ownername,
            type: 'FULL',
            quality: 100
        });

        await conn.sendMessage(m.chat, { sticker: await sticker.toBuffer() }, { quoted: m });
        await m.react("✨");

    } catch (e) {
        console.error("Sticker NoBG Error:", e.message);
        m.reply(`❌ *[ ERROR ]* Gagal membuat stiker tanpa background. Pastikan gambar jelas.`);
        await m.react("❌");
    }
};

handler.help = ["snobg", "sbg"];
handler.tags = ["sticker"];
handler.command = /^(snobg|sbg|stickernobg)$/i;
handler.register = true;
handler.limit = true;

export default handler;