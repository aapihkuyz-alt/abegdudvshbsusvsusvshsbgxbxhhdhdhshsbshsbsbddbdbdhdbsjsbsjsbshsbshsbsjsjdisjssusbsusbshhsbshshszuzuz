import {
    Sticker
} from 'wa-sticker-formatter'

let handler = async (m, {
    conn
}) => {
    let q = m.quoted || m
    let mime = (q.msg || q).mimetype || ''

    if (!/image|video/.test(mime))
        return m.reply('Reply / kirim gambar atau video!')

    if ((q.msg?.seconds || q.seconds) > 10)
        return m.reply('Video maksimal 10 detik!')

    let media = await q.download()
    if (!media) return m.reply('Gagal download media')

    let sticker = new Sticker(media, {
        pack: global.namebot, // PACK NAME (GLOBAL)
        author: global.ownername, // AUTHOR (GLOBAL)
        type: 'FULL', // FULL sticker
        quality: 100
    })

    await conn.sendMessage(
        m.chat, {
            sticker: await sticker.toBuffer()
        }, {
            quoted: m
        }
    )
}

handler.help = ['sticker', 's']
handler.tags = ['sticker']
handler.command = ['sticker', 's']
handler.register = true

export default handler