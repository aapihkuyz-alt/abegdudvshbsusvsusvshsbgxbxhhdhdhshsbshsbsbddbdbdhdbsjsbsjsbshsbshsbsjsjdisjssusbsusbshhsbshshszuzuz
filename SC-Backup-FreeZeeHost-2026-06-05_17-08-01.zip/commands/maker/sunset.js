import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 🌇 SUNSET TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format penggunaan:
┃ ➜ .sunset teks
┃
┃ Contoh:
┃ ➜ .sunset neoxr
┃
┃ Efek teks dengan latar
┃ suasana matahari terbenam.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React mulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "🌇",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/sunset", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate sunset image")

        const caption = `
╭━━━〔 🌅 SUNSET EFFECT 〕━━━⬣
┃ 📝 Text    : ${text}
┃ 🎨 Style   : Sunset Glow
┃
┃ Nuansa hangat sore hari.
┃ Estetik, kalem, tapi tetap
┃ punya aura dramatis.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("SUNSET MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek sunset.
┃ Coba lagi beberapa saat.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["sunset"]
handler.tags = ["maker"]
handler.help = ["sunset <teks>"]

export default handler