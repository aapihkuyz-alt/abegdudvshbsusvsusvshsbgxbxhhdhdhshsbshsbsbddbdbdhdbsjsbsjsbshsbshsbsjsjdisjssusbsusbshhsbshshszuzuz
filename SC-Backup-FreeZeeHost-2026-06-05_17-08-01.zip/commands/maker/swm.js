import {
    Sticker
} from "wa-sticker-formatter"

let handler = async (m, {
    conn,
    text
}) => {

    if (!m.quoted) return m.reply("Reply sticker.")

    let mime = m.quoted?.msg?.mimetype || ""

    if (!/webp/.test(mime)) {
        return m.reply("Reply sticker yang valid.")
    }

    let pack = "Sticker Bot"
    let author = "WhatsApp Bot"

    if (text) {
        let args = text.split("|")
        pack = args[0] ? args[0].trim() : pack
        author = args[1] ? args[1].trim() : author
    }

    let media = await m.quoted.download()

    let sticker = new Sticker(media, {
        pack,
        author,
        type: "full",
        quality: 80
    })

    let buffer = await sticker.toBuffer()

    await conn.sendMessage(
        m.chat, {
            sticker: buffer
        }, {
            quoted: m
        }
    )

}

handler.command = ["wm", "swm"]
handler.tags = ["sticker"]
handler.help = ["wm pack|author"]

export default handler