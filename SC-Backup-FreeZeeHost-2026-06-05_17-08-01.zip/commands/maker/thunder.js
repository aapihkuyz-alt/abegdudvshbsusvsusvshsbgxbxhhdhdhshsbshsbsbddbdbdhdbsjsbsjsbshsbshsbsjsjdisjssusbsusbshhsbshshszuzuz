import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 ⚡ THUNDER TEXT MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .thunder teks
┃
┃ Contoh:
┃ ➜ .thunder neoxr
┃
┃ Masukkan satu teks saja.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React mulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "⚡",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/thunder", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate thunder image")

        const caption = `
╭━━━〔 ⚡ THUNDER EFFECT 〕━━━⬣
┃ 📝 Text     : ${text}
┃ 🎨 Style    : Lightning Storm
┃ 📦 Size     : ${data.data.size || "-"}
┃
┃ Efek kilat menyambar.
┃ Aura gelap + listrik brutal.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

⚡ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("THUNDER MAKER ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat efek Thunder.
┃ Coba lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["thunder"]
handler.tags = ["maker"]
handler.help = ["thunder <teks>"]

export default handler