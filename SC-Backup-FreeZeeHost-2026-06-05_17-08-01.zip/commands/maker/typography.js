import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 ✍️ TYPOGRAPHY MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .typography teks
┃
┃ Contoh:
┃ ➜ .typography neoxr
┃
┃ Masukkan satu teks saja.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React mulai
        await conn.sendMessage(m.chat, {
            react: {
                text: "🖋️",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/typography", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate typography")

        const caption = `
╭━━━〔 ✍️ TYPOGRAPHY EFFECT 〕━━━⬣
┃ 📝 Text     : ${text}
┃ 🎨 Style    : Modern Typography
┃
┃ Desain tipografi estetik.
┃ Clean, bold, dan visualnya rapi.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("TYPOGRAPHY ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat typography.
┃ Coba lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["typography"]
handler.tags = ["maker"]
handler.help = ["typography <teks>"]

export default handler