import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(`
╭━━━〔 💘 VALENTINE MAKER 〕━━━⬣
┃
┃ ➜ Format:
┃ ➜ .valentine teks
┃
┃ Contoh:
┃ ➜ .valentine neoxr
┃
┃ Masukkan satu teks romantis.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        // React proses
        await conn.sendMessage(m.chat, {
            react: {
                text: "💖",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/valentine", {
                params: {
                    text,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data?.data?.url)
            throw new Error("Gagal generate valentine image")

        const caption = `
╭━━━〔 💘 VALENTINE EFFECT 〕━━━⬣
┃ 💌 Text      : ${text}
┃ 🌹 Theme     : Romantic Valentine
┃
┃ Cocok buat status,
┃ atau pura-pura aesthetic.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣

✨ Powered by ${global.botname}
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.data.url
                },
                caption
            }, {
                quoted: m
            }
        )

        // React selesai
        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.error("VALENTINE ERROR:", e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(`
╭━━━〔 ⚠️ ERROR 〕━━━⬣
┃ Gagal membuat valentine image.
┃ Coba lagi nanti.
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim())
    }
}

handler.command = ["valentine"]
handler.tags = ["maker"]
handler.help = ["valentine <teks>"]

export default handler