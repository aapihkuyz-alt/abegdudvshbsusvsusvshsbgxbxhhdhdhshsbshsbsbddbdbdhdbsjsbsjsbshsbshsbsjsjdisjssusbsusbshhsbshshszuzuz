

const pickRandom = arr => arr[Math.floor(Math.random() * arr.length)]

const handler = async (m, {
    conn,
    text
}) => {
    if (!text)
        return m.reply(
            pickRandom([
                'Mau cari lagu apa? 👀',
                'Ketik judul lagu dong 🎵',
                'Judul lagunya apa nih?'
            ]) + '\n\nContoh:\n.spotify Komang'
        )

    await conn.sendMessage(m.chat, {
        react: {
            text: '⏳',
            key: m.key
        }
    })

    try {
        // 🔍 SEARCH
        const searchApi = `https://api.neoxr.eu/api/spotify-search?q=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const searchRes = await fetch(searchApi)
        const searchJson = await searchRes.json()

        if (!searchJson.status || !searchJson.data?.length)
            return m.reply(
                pickRandom([
                    'Hmm… lagunya nggak ketemu 😅',
                    'Kayaknya nggak ada di Spotify 🤔',
                    'Coba judul lain deh 🎧'
                ])
            )

        // 🎯 AUTO PICK
        const pick = searchJson.data[0]

        // ⬇️ DOWNLOAD
        const dlApi = `https://api.neoxr.eu/api/spotify?url=${encodeURIComponent(pick.url)}&apikey=${global.neoxr}`
        const dlRes = await fetch(dlApi)
        const dlJson = await dlRes.json()

        if (!dlJson.status || !dlJson.data)
            return m.reply(
                pickRandom([
                    'Lagunya ketahan server 😓',
                    'Download-nya gagal, coba lagi ya',
                    'Spotify lagi ngambek kayaknya 😵'
                ])
            )

        const data = dlJson.data

        // 📝 TEXT MODEL (acak)
        const headerText = pickRandom([
            '🎧 Lagu ketemu!',
            '🎶 Gas, ini lagunya',
            '👀 Ketemu nih lagunya',
            '🔥 Siap, dapet lagunya'
        ])

        const footerText = pickRandom([
            'Sedang dikirim ya 🎵',
            'Santai, lagi dikirim 🎶',
            'Nih lagunya, enjoy 👌',
            'Langsung play aja 🎧'
        ])

        const caption = `
${headerText}

Judul  : *${data.title}*
Artis  : *${data.artist.name}*
Durasi : *${data.duration}*

${footerText}
`.trim()

        // 🖼️ Thumbnail + info
        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.thumbnail
                },
                caption
            }, {
                quoted: m
            }
        )

        // 🎵 Audio
        await conn.sendMessage(
            m.chat, {
                audio: {
                    url: data.url
                },
                mimetype: 'audio/mpeg',
                fileName: `${data.title}.mp3`
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: '✅',
                key: m.key
            }
        })

    } catch (e) {
        console.error(e)
        await conn.sendMessage(m.chat, {
            react: {
                text: '❌',
                key: m.key
            }
        })
        m.reply(
            pickRandom([
                'Aduh error 😵 coba lagi bentar',
                'Ada yang crash, bentar ya',
                'Lagi error nih, ulangi lagi'
            ])
        )
    }
}

handler.help = ['spotify <judul lagu>']
handler.tags = ['music']
handler.command = /^spotify$/i

export default handler