import axios from "axios"

const handler = async (m, { conn, text, usedPrefix }) => {

    if (!text)
        return m.reply(`Contoh:\n${usedPrefix}apple a7x`)

    if (!global.neoxr)
        return m.reply("API key Neoxr belum diisi di global.neoxr")

    try {

        await conn.sendMessage(m.chat, {
            react: { text: "🍎", key: m.key }
        })

        const { data: res } = await axios.get(
            `https://api.neoxr.eu/api/applemusic-search?q=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        )

        if (!res.status || !res.data?.length)
            return m.reply("Tidak ada lagu ditemukan.")

        const results = res.data

        const rows = results.map((v, i) => ({
    title: `${i + 1}. ${v.title}`,
    description: `🎵 Song ID: ${v.id}`,
    id: `.amd ${v.url}`
}))

        const caption = `
╭━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 🍎 APPLE MUSIC SEARCH
┃
┃ 📌 Query :
┃ ➜ ${text}
┃
┃ 📊 Total Result :
┃ ➜ ${results.length} Lagu
┃
┃ 📎 Klik salah satu hasil
┃ untuk membuka di Apple Music.
┃
┃ ⚠️ Ini hanya redirect link,
┃ bukan download audio.
┃
╰━━━━━━━━━━━━━━━━━━━━━━⬣
        `.trim()

        await conn.sendMessage(
            m.chat,
            {
                text: caption,
                footer: "Apple Music • Neoxr API",
                buttons: [{
                    buttonId: "apple-list",
                    buttonText: { displayText: "🎧 Lihat Semua Lagu" },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: `Hasil Apple Music (${results.length})`,
                            sections: [{
                                title: "Semua Result",
                                rows
                            }]
                        })
                    }
                }]
            },
            { quoted: m }
        )

        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (e) {
        console.error("APPLE ERROR:", e)
        m.reply("❌ Terjadi kesalahan saat mengambil data.")
    }
}

handler.help = ["apple <query>"]
handler.tags = ["search"]
handler.command = /^apple$/i

export default handler