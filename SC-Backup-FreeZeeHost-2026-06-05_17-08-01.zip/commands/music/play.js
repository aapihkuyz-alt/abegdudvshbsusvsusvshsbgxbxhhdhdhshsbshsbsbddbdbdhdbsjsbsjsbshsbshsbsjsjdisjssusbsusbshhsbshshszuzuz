import axios from "axios";

let handler = async (m, { conn, text, usedPrefix, command, Func }) => {
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} Komang - Raim Laode*`);

    await m.react("🔍");
    
    // --- 1. SEND INITIAL LOADING MESSAGE ---
    const loading = await conn.reply(m.chat, "⏳ *Mencari lagu, mohon tunggu sebentar...*", m);

    try {
        // --- 2. SMART CACHE & FETCH ---
        const cacheKey = `play_${text}`;
        let res = global.responseCache?.get(cacheKey);

        if (!res) {
            const apikey = global.neoxr || "FreeZeeHost12";
            const apiRes = await axios.get(`https://api.neoxr.eu/api/play?q=${encodeURIComponent(text)}&apikey=${apikey}`).catch(() => null);
            
            if (!apiRes || !apiRes.data || !apiRes.data.status) {
                throw new Error("Musik tidak ditemukan atau server sedang sibuk.");
            }
            res = apiRes.data;
            global.responseCache?.set(cacheKey, res);
        }

        // --- 3. PREPARE DATA ---
        const { title, channel, thumbnail, fduration, views, publish, data, id } = res;
        const url = res.url || (id ? `https://www.youtube.com/watch?v=${id}` : text);
        
        if (!data || !data.url) throw new Error("Gagal mendapatkan link download dari server.");

        const finalCaption = `
╭━━━〔 🎵 *MUSIC PLAYER* 〕━━━⬣
┃ ◦ *Title:* ${String(title || 'Unknown')}
┃ ◦ *Artist:* ${String(channel || 'Unknown')}
┃ ◦ *Duration:* ${String(fduration || '-')}
┃ ◦ *Views:* ${String(views || '-')}
┃ ◦ *Release:* ${String(publish || '-')}
╰━━━━━━━━━━━━━━━━━━━━━━⬣`.trim();

        // Hapus loading
        await conn.sendMessage(m.chat, { delete: loading.key }).catch(() => {});

        // --- 4. SEND PREVIEW (THUMBNAIL + TEXT) ---
        let previewMsg;
        if (thumbnail) {
            previewMsg = await conn.sendMessage(m.chat, {
                image: { url: String(thumbnail) },
                caption: finalCaption
            }, { quoted: m });
        } else {
            previewMsg = await conn.sendMessage(m.chat, {
                text: finalCaption
            }, { quoted: m });
        }

        // --- 5. PROCESS & SEND AUDIO VIA FUNC HELPER ---
        await Func.sendPlayableAudio(conn, m, String(data.url), {
            title: title
        }, { quoted: previewMsg || m });

        await m.react("✅");

    } catch (e) {
        console.error("Play Error:", e);
        await conn.sendMessage(m.chat, { delete: loading.key }).catch(() => {});
        const errorMsg = e.message || "Internal Server Error";
        m.reply(`❌ *[ ERROR ]* Gagal memutar musik.\nReason: ${errorMsg}`);
        await m.react("❌");
    }
};

handler.help = ["play", "song"];
handler.tags = ["music"];
handler.command = /^(play|p|song|mainkan)$/i;
handler.register = true;
handler.limit = true;

export default handler;
