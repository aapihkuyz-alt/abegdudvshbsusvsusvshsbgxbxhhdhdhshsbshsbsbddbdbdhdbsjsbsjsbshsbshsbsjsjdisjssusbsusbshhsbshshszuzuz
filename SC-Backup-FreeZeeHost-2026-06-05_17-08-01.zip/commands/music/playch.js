import axios from "axios"
import fs from "fs"
import path from "path"
import ffmpeg from "fluent-ffmpeg"
import ffmpegInstaller from "@ffmpeg-installer/ffmpeg"
import { fileURLToPath } from "url"

ffmpeg.setFfmpegPath(ffmpegInstaller.path)

const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const tmpDir = path.join(__dirname, "tmp")
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir)

const handler = async (m, { conn, text }) => {
    if (!text) return m.reply("Contoh:\n.playch komang")
    if (!global.neoxr) return m.reply("API key neoxr belum diset")
    if (!global.channels) return m.reply("global.channels belum diset")

    try {

        const { data: res } = await axios.get(
            `https://api.neoxr.eu/api/play?q=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        )

        if (!res.status) return m.reply("Lagu tidak ditemukan")

        const { title, channel, thumbnail, fduration, views, publish, data } = res

        const caption = `
🎧 PLAY CHANNEL SYSTEM

🎵 Judul   : ${title}
👤 Channel : ${channel}
⏱ Durasi  : ${fduration}
👀 Views   : ${views}
📅 Rilis   : ${publish}
📦 Size    : ${data.size}

🚀 Audio dikirim sebagai PTT (Voice Note)
Powered by Neoxr API
        `.trim()

        // kirim info dulu
        await conn.sendMessage(m.chat, {
            image: { url: thumbnail },
            caption
        }, { quoted: m })

        // download mp3
        const input = path.join(tmpDir, Date.now() + "_in.mp3")
        const output = path.join(tmpDir, Date.now() + "_out.ogg")

        const audioRes = await axios.get(data.url, { responseType: "arraybuffer" })
        fs.writeFileSync(input, Buffer.from(audioRes.data))

        // convert ke ogg opus
        await new Promise((resolve, reject) => {
            ffmpeg(input)
                .audioCodec("libopus")
                .format("ogg")
                .on("end", resolve)
                .on("error", reject)
                .save(output)
        })

        const finalAudio = fs.readFileSync(output)

        // kirim ke SEMUA channel
        for (const jid of global.channels) {
            if (typeof jid !== "string") continue

            await conn.sendMessage(jid, {
                audio: finalAudio,
                mimetype: "audio/ogg; codecs=opus",
                ptt: true
            })
        }

        fs.unlinkSync(input)
        fs.unlinkSync(output)

        m.reply("✅ Audio berhasil dikirim ke semua channel")

    } catch (e) {
        console.error(e)
        m.reply("❌ Error:\n" + e)
    }
}

handler.command = ["playch"]
handler.tags = ["music"]
handler.help = ["playch <judul lagu>"]

export default handler