# Owner Structure

- `session/`
  - multi-session manager, watchdog, permission session
- `premium/`
  - premium user management
- `runtime/`
  - restart, run/eval, shell, plugin/runtime control, backup
- `privacy/`
  - bot privacy and auto-read/delete behavior
- `access/`
  - owner list, ban/unban, block/unblock
- `group-tools/`
  - owner-only group/channel utilities
- `misc/`
  - sisa utilitas owner umum yang tidak masuk kategori besar

Catatan:
- command name tetap sama
- hanya struktur folder yang dirapikan
- loader plugin memindai recursive, jadi subfolder aman
