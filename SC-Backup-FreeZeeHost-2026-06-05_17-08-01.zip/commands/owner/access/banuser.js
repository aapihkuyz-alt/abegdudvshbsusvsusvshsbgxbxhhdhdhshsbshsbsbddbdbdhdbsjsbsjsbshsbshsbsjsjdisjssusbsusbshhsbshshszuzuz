const handler = async (m, {
    text,
    db
}) => {
    let userId;
    if (m.quoted) userId = m.quoted.sender;
    else if (text) userId = text.trim();
    else return m.reply(".banuser via reply atau ID");

    const data = db.list();

    if (!data.user) data.user = {};
    if (!data.user[userId]) data.user[userId] = {
        banned: {
            status: false,
            expired: 0
        }
    };

    data.user[userId].banned = {
        status: true,
        expired: 0
    };

    await db.save();

    m.reply(`✅ User *${userId}* telah dibanned!`);
};

handler.command = ["banuser"];
handler.tags = "owner";
handler.description = "Ban user";
handler.owner = true;

export default handler;