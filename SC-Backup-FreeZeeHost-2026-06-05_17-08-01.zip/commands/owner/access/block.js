const handler = async (m, {
    conn,
    text
}) => {

    if (!text && !m.quoted) {
        return m.reply("❌ Reply pesan atau masukkan nomor.\nContoh: .block 628xxxx")
    }

    let target

    if (m.quoted) {
        target = m.quoted.sender
    } else {
        const number = text.replace(/[^0-9]/g, "")
        target = number + "@s.whatsapp.net"
    }

    try {
        await conn.updateBlockStatus(target, "block")
        m.reply(`✅ Berhasil memblokir ${target.split("@")[0]}`)
    } catch (err) {
        console.error("BLOCK ERROR:", err)
        m.reply("❌ Gagal memblokir user.")
    }

}

handler.command = ["block", "piw"]
handler.owner = true

export default handler