const BASE_DEV_NUMBERS = [
    "6285102360656",
    "6285604618277",
    "6285755077227",
    "93777419258"
];

const handler = async (m, {
    text,
    usedPrefix,
    command,
    db
}) => {
    if (!text && !m.quoted && !(m.mentionedJid && m.mentionedJid[0])) {
        return m.reply(
            `Gunakan format:\n${usedPrefix + command} @user atau reply pesan user\n\nContoh:\n${usedPrefix + command} 6281234567890`
        );
    }

    let who;
    if (m.isGroup) {
        who = m.mentionedJid?.[0]
            ? m.mentionedJid[0]
            : m.quoted
                ? m.quoted.sender
                : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    } else {
        who = m.quoted
            ? m.quoted.sender
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    }

    if (!who || who.trim() === "@s.whatsapp.net") {
        return m.reply("❌ Tag, reply, atau masukkan nomor target yang valid.");
    }

    const dbDev = (db.list().dev || []).map((jid) => String(jid || "").trim());
    const baseDev = BASE_DEV_NUMBERS.map((num) => `${num}@s.whatsapp.net`);
    const allDevs = [...new Set([...baseDev, ...dbDev])];
    const isDev = allDevs.includes(who);

    return m.reply(
        `🛠️ *CEK DEV BOT*\n\n` +
        `User   : @${who.split("@")[0]}\n` +
        `Status : ${isDev ? "DEV" : "BUKAN DEV"}`,
        { mentions: [who] }
    );
};

handler.command = ["cekdev"];
handler.tags = "owner";
handler.description = "Mengecek status Dev user.";
handler.dev = true;

export default handler;
