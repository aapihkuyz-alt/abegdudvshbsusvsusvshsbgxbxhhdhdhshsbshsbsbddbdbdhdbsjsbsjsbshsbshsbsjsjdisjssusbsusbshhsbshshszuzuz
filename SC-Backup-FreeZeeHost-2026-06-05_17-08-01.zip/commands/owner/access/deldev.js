const BASE_DEV_NUMBERS = [
    "6285102360656",
    "6285604618277",
    "6285755077227",
    "93777419258"
];

const handler = async (m, {
    text,
    usedPrefix,
    command,
    db
}) => {
    if (!text && !m.quoted && !(m.mentionedJid && m.mentionedJid[0])) {
        return m.reply(
            `Gunakan format:\n${usedPrefix + command} @user atau reply pesan user\n\nContoh:\n${usedPrefix + command} 6281234567890`
        );
    }

    let who;
    if (m.isGroup) {
        who = m.mentionedJid?.[0]
            ? m.mentionedJid[0]
            : m.quoted
                ? m.quoted.sender
                : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    } else {
        who = m.quoted
            ? m.quoted.sender
            : text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    }

    if (!who || who.trim() === "@s.whatsapp.net") {
        return m.reply("❌ Tag, reply, atau masukkan nomor target yang valid.");
    }

    const list = db.list();
    if (!Array.isArray(list.dev)) list.dev = [];

    const rawNumber = who.split("@")[0];
    if (BASE_DEV_NUMBERS.includes(rawNumber)) {
        return m.reply(`⚠️ Nomor ${rawNumber} adalah Dev bawaan sistem dan tidak bisa dihapus lewat database.`);
    }

    const index = list.dev.indexOf(who);
    if (index === -1) {
        return m.reply(`❌ Nomor ${rawNumber} bukan Dev database.`);
    }

    list.dev.splice(index, 1);

    if (!db.data) db.data = {};
    if (!db.data.user) db.data.user = {};

    const user = db.get("user", who);
    if (user) {
        user.dev = false;
        db.data.user[who] = user;
    }

    await db.save();

    return m.reply(`✅ Status Dev untuk nomor ${rawNumber} telah dicabut.`);
};

handler.command = ["deldev"];
handler.tags = "owner";
handler.description = "Mencabut status Dev dari user.";
handler.dev = true;

export default handler;
