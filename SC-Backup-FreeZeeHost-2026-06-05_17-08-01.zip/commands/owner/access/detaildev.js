const BASE_DEV_NUMBERS = [
    "6285102360656",
    "6285604618277",
    "6285755077227",
    "93777419258"
];

const handler = async (m, { conn, text, db }) => {
    const raw = String(text || "").replace(/[^0-9]/g, "");
    if (!raw) {
        return m.reply("Format salah.\n.detaildev 628xxxx");
    }

    const jid = `${raw}@s.whatsapp.net`;
    const dbDev = (db.list().dev || [])
        .map((value) => String(value || "").includes("@")
            ? String(value || "").trim()
            : `${String(value || "").replace(/[^0-9]/g, "")}@s.whatsapp.net`);

    const isBaseDev = BASE_DEV_NUMBERS.includes(raw);
    const isDbDev = dbDev.includes(jid);
    const isDev = isBaseDev || isDbDev;

    if (!isDev) {
        return m.reply(`❌ @${raw} bukan Dev terdaftar.`, { mentions: [jid] });
    }

    const actions = [
        {
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
                display_text: "📋 Copy Nomor",
                copy_code: raw
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "📋 List Dev",
                id: ".listdev"
            })
        }
    ];

    if (isDbDev) {
        actions.splice(1, 0, {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🗑️ Hapus Dev",
                id: `.deldev ${raw}`
            })
        });
    }

    return conn.sendMessage(m.chat, {
        text:
            `🛠️ *DETAIL DEV BOT*\n\n` +
            `Nomor   : @${raw}\n` +
            `JID     : ${jid}\n` +
            `Status  : DEV\n` +
            `Sumber  : ${isDbDev ? "database" : "bawaan sistem"}\n` +
            `Aksi    : ${isDbDev ? "bisa dihapus" : "read-only"}`,
        mentions: [jid],
        footer: "Developer Detail",
        interactive: actions
    }, { quoted: m });
};

handler.command = ["detaildev"];
handler.tags = "owner";
handler.description = "Menampilkan detail Dev bot.";
handler.dev = true;

export default handler;
