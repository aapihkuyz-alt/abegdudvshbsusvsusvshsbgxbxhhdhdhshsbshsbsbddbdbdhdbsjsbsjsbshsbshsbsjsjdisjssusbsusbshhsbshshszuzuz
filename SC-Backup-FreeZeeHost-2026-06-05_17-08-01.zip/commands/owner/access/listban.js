const handler = async (m, {
    db
}) => {
    const users = db.list().user || {};

    const bannedUsers = Object.entries(users)
        .filter(([jid, data]) => data.banned?.status)
        .map(([jid, data]) => {
            const expired = data.banned.expired === 0 ?
                "Permanen" :
                new Date(data.banned.expired).toLocaleString();
            return `- ${jid} | Expired: ${expired}`;
        });

    if (bannedUsers.length === 0) return m.reply("Tidak ada user yang dibanned saat ini.");

    const listText = `📋 Daftar User Banned:\n\n${bannedUsers.join("\n")}`;

    m.reply(listText);
};

handler.command = ["listban"];
handler.tags = "owner";
handler.description = "Menampilkan daftar user yang dibanned";
handler.owner = true;

export default handler;