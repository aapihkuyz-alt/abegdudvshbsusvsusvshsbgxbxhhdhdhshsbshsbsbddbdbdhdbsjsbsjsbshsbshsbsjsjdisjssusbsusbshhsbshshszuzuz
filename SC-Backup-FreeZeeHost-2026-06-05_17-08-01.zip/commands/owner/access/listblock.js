const handler = async (m, {
    conn
}) => {

    try {

        const blocked = await conn.fetchBlocklist()

        if (!blocked || blocked.length === 0) {
            return m.reply("✅ Tidak ada nomor yang diblokir.")
        }

        let teks = `╭━━━〔 🚫 BLOCK LIST 〕━━━⬣
┃ Total : ${blocked.length}
╰━━━━━━━━━━━━━━━━━━⬣

`

        for (const jid of blocked) {
            const number = jid.split("@")[0]
            teks += `• wa.me/${number}\n`
        }

        return m.reply(teks.trim())

    } catch (err) {
        console.error("LISTBLOCK ERROR:", err)
        return m.reply("❌ Gagal mengambil daftar block.")
    }

}

handler.command = ["listblock", "listblk"]
handler.owner = true

export default handler