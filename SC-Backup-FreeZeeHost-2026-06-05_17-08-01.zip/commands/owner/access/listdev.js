const BASE_DEV_NUMBERS = [
    "6285102360656",
    "6285604618277",
    "6285755077227",
    "93777419258"
];

const handler = async (m, { conn, db }) => {
    const dbDev = (db.list().dev || [])
        .map((jid) => {
            const value = String(jid || "").trim();
            return value.includes("@") ? value : `${value.replace(/[^0-9]/g, "")}@s.whatsapp.net`;
        })
        .filter((jid) => jid !== "@s.whatsapp.net");

    const baseDev = BASE_DEV_NUMBERS.map((num) => `${num}@s.whatsapp.net`);
    const allDevs = [...new Set([...baseDev, ...dbDev])];

    if (!allDevs.length) {
        return m.reply("❌ Tidak ada Dev yang terdaftar di sistem.");
    }

    return conn.sendMessage(m.chat, {
        text: `🛠️ *DAFTAR DEV BOT*\n\nTotal Dev: ${allDevs.length}\n\nPilih dev di panel bawah untuk melihat detail.`,
        footer: "Developer Manager",
        interactive: [{
            name: "single_select",
            buttonParamsJson: JSON.stringify({
                title: "Pilih Dev",
                sections: [{
                    title: `Developer List (${Math.min(allDevs.length, 20)}/${allDevs.length})`,
                    highlight_label: "Developer detail",
                    rows: allDevs.slice(0, 20).map((jid) => ({
                        header: "DEV",
                        title: jid.split("@")[0],
                        description: dbDev.includes(jid) ? "Dev database" : "Dev bawaan sistem",
                        id: `.detaildev ${jid.split("@")[0]}`
                    }))
                }]
            })
        }]
    }, { quoted: m });
};

handler.command = ["listdev"];
handler.tags = "owner";
handler.description = "Menampilkan daftar Dev bot.";
handler.dev = true;

export default handler;
