const handler = async (m, {
    conn,
    text,
    db
}) => {
    let userId;
    if (m.quoted) userId = m.quoted.sender;
    else if (text) {
        userId = text.trim();
        if (!userId.includes("@")) userId += "@s.whatsapp.net";
    }
    else return m.reply(".unbanuser via reply atau ID nomor");

    const user = db.get("user", userId);
    if (user) {
        user.banned = { status: false, expired: 0 };
    }

    // Pastikan unblock juga di WhatsApp
    await conn.updateBlockStatus(userId, "unblock").catch(() => {});
    await db.save();

    m.reply(`✅ User *${userId}* telah diunban and diunblock!`);
};

handler.command = ["unbanuser"];
handler.tags = "owner";
handler.description = "Unban user";
handler.owner = true;

export default handler;