const handler = async (m, {
    conn,
    text
}) => {

    if (!text && !m.quoted) {
        return m.reply("❌ Reply pesan atau masukkan nomor.\nContoh: .unblock 628xxxx")
    }

    let target

    if (m.quoted) {
        target = m.quoted.sender
    } else {
        const number = text.replace(/[^0-9]/g, "")
        target = number + "@s.whatsapp.net"
    }

    try {
        await conn.updateBlockStatus(target, "unblock")
        m.reply(`✅ Berhasil membuka blokir ${target.split("@")[0]}`)
    } catch (err) {
        console.error("UNBLOCK ERROR:", err)
        m.reply("❌ Gagal membuka blokir user.")
    }

}

handler.command = ["unblock", "ripep"]
handler.owner = true

export default handler