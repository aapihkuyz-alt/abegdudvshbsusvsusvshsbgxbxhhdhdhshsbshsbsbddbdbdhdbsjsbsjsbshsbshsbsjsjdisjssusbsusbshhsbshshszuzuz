let handler = async (m, { conn, text, usedPrefix, command, db }) => {
    if (!text) return m.reply(`*Format salah!*\n\nGunakan: *${usedPrefix + command} @tag amount*\nContoh: *${usedPrefix + command} @6285102360656 10000*`);

    let target;
    let amountStr;

    if (m.quoted) {
        target = m.quoted.sender;
        amountStr = text.trim();
    } else if (m.mentionedJid && m.mentionedJid[0]) {
        target = m.mentionedJid[0];
        amountStr = text.replace(/@\d+/g, "").trim();
    } else {
        const args = text.trim().split(/\s+/);
        if (args.length < 2) return m.reply(`*Format salah!*\n\nGunakan: *${usedPrefix + command} @tag amount*`);
        target = args[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        amountStr = args[1];
    }

    const amount = parseInt(amountStr);
    if (isNaN(amount)) return m.reply("❌ Jumlah saldo harus berupa angka.");

    let user = db.get("user", target);
    if (!user) return m.reply("❌ User tidak ditemukan di database.");

    if (command === "addbalance") {
        user.saldo = (user.saldo || 0) + amount;
        await db.save();
        m.reply(`✅ *BERHASIL!*\n\nBerhasil menambahkan *Rp${amount.toLocaleString()}* ke @${target.split('@')[0]}.\nSaldo sekarang: *Rp${user.saldo.toLocaleString()}*`, null, { mentions: [target] });
    } else {
        user.saldo = Math.max(0, (user.saldo || 0) - amount);
        await db.save();
        m.reply(`✅ *BERHASIL!*\n\nBerhasil mengurangi *Rp${amount.toLocaleString()}* dari @${target.split('@')[0]}.\nSaldo sekarang: *Rp${user.saldo.toLocaleString()}*`, null, { mentions: [target] });
    }
};

handler.help = ["addbalance @tag <amount>", "delbalance @tag <amount>"];
handler.tags = ["owner"];
handler.command = /^(add|del)balance$/i;
handler.owner = true;

export default handler;