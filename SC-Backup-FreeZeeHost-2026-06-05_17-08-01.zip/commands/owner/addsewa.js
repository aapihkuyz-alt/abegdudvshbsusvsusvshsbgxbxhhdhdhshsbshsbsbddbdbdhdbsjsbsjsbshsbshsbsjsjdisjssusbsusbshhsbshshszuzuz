let handler = async (m, { conn, text, db, usedPrefix, command }) => {
    let [type, jid, duration] = text.split("|").map(v => v.trim());
    if (!type || !jid) return m.reply(`📌 Contoh: *${usedPrefix + command} prem | 628xxx | 30* (30 hari)`);

    let targetJid = jid.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    let user = db.get("user", targetJid);
    if (!user) return m.reply("❌ User tidak ditemukan di database.");

    const ms = parseInt(duration) * 24 * 60 * 60 * 1000;
    const now = Date.now();

    if (type === "prem") {
        if (!user.premium) user.premium = { status: false, expired: 0 };
        user.premium.status = true;
        user.premium.expired = (user.premium.expired > now ? user.premium.expired : now) + ms;
        await m.reply(`✅ Berhasil menambahkan Premium ke *@${targetJid.split("@")[0]}* selama ${duration} hari.`, null, { mentions: [targetJid] });
    } 
    
    else if (type === "owner") {
        if (!user.owner_access) user.owner_access = { status: false, expired: 0 };
        user.owner_access.status = true;
        user.owner_access.expired = duration === "0" ? 0 : (user.owner_access.expired > now ? user.owner_access.expired : now) + ms;
        await m.reply(`✅ Berhasil menambahkan Akses Owner ke *@${targetJid.split("@")[0]}* ${duration === "0" ? "Permanen" : "selama " + duration + " hari"}.`, null, { mentions: [targetJid] });
    }

    await db.save();
};

handler.help = ["addsewa prem/owner | jid | days"];
handler.tags = ["owner"];
handler.command = /^(addsewa|setsewa)$/i;
handler.owner = true;

export default handler;