const handler = async (m, { db, args, usedPrefix, command }) => {
    const settings = db.list().settings;
    if (!args[0]) return m.reply(`*Format:*
◦ ${usedPrefix + command} on/off
◦ ${usedPrefix + command} <detik>

*Contoh:*
◦ ${usedPrefix + command} on
◦ ${usedPrefix + command} 5 (Set cooldown jadi 5 detik)`);

    if (args[0] === 'on') {
        settings.antispam = true;
        await db.save();
        m.reply("✅ *Anti-Spam Global* dinyalakan.");
    } else if (args[0] === 'off') {
        settings.antispam = false;
        await db.save();
        m.reply("❌ *Anti-Spam Global* dimatikan.");
    } else if (!isNaN(args[0])) {
        const cd = parseInt(args[0]) * 1000;
        if (cd < 500) return m.reply("❌ Minimal cooldown adalah 0.5 detik.");
        if (cd > 60000) return m.reply("❌ Maksimal cooldown adalah 60 detik.");
        
        settings.cooldown = cd;
        await db.save();
        m.reply(`✅ *Cooldown Anti-Spam* berhasil diatur ke *${args[0]}* detik.`);
    } else {
        m.reply(`Gunakan: ${usedPrefix + command} on/off atau <angka detik>`);
    }
};

handler.help = ['antispam <on/off/detik>'];
handler.tags = ['owner'];
handler.command = ['antispam'];
handler.owner = true;

export default handler;
