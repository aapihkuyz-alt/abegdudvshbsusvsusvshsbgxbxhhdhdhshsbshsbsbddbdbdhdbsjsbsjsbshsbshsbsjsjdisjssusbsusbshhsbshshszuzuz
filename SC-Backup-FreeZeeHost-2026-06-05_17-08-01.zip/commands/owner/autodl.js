let handler = async (m, { db, text, usedPrefix, command }) => {
    let settings = db.list().settings;
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} on* atau *off*`);

    if (text === "on") {
        settings.autodl = true;
        await db.save();
        m.reply("✅ *Auto-Downloader* berhasil diaktifkan secara global.");
    } else if (text === "off") {
        settings.autodl = false;
        await db.save();
        m.reply("❌ *Auto-Downloader* berhasil dimatikan.");
    } else {
        m.reply(`📌 Contoh: *${usedPrefix + command} on* atau *off*`);
    }
};

handler.help = ["autodl on/off"];
handler.tags = ["owner", "main"];
handler.command = /^(autodl)$/i;
handler.owner = true;

export default handler;