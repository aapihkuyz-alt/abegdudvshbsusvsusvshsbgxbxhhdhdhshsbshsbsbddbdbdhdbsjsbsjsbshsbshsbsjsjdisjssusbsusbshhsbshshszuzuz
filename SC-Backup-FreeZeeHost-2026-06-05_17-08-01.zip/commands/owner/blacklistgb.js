import { generateWAMessageFromContent, proto } from "baileys";

let handler = async (m, { conn, text, usedPrefix, command, db, isOwner }) => {
    if (!isOwner) return m.reply("❌ Khusus Owner, Bang.");
    
    const settings = db.list().settings;
    if (!settings.blacklistgb) settings.blacklistgb = [];

    // 1. ADD TO BLACKLIST (.blgb atau .blacklistgb)
    if (command === 'blgb' || command === 'blacklistgb') {
        let jid = text ? text.replace(/[^0-9]/g, '') + '@g.us' : m.chat;
        if (!jid.endsWith('@g.us')) return m.reply("❌ Format JID grup salah.");

        if (settings.blacklistgb.includes(jid)) return m.reply("ℹ️ Grup tersebut sudah ada di blacklist.");

        settings.blacklistgb.push(jid);
        await db.save();
        
        await m.reply(`✅ *BLACKLIST BERHASIL*\n\nID: ${jid}\n\nBot akan otomatis keluar and mengabaikan grup ini.`);
        return await conn.groupLeave(jid);
    }

    // 2. LIST BLACKLIST (.listblgb)
    if (command === 'listblgb') {
        if (settings.blacklistgb.length === 0) return m.reply("ℹ️ Belum ada grup di blacklist.");

        let list = `╭─❍ *DAFTAR BLACKLIST GB* ❍─\n│\n`;
        settings.blacklistgb.forEach((jid, i) => {
            list += `│ *${i + 1}.* ${jid}\n`;
        });
        list += `│\n╰─────────────────────❍\n\n💡 Ketik *${usedPrefix}delblgb* untuk menghapus.`;
        return m.reply(list);
    }

    // 3. DELETE FROM BLACKLIST (.delblgb)
    if (command === 'delblgb') {
        if (settings.blacklistgb.length === 0) return m.reply("ℹ️ Belum ada grup di blacklist.");

        // Jika ada text JID langsung (manual)
        if (text) {
            let jid = text.includes('@g.us') ? text : text.replace(/[^0-9]/g, '') + '@g.us';
            if (!settings.blacklistgb.includes(jid)) return m.reply("❌ JID tidak ditemukan di blacklist.");
            
            settings.blacklistgb = settings.blacklistgb.filter(id => id !== jid);
            await db.save();
            return m.reply(`✅ Berhasil menghapus ${jid} dari blacklist.`);
        }

        // Tampilkan Interactive Single Select (List) untuk hapus
        const sections = [{
            title: "PILIH GRUP UNTUK DIHAPUS",
            rows: settings.blacklistgb.map((jid, i) => ({
                header: `GRUP #${i + 1}`,
                title: jid,
                description: "Klik untuk menghapus dari blacklist",
                id: `${usedPrefix}delblgb ${jid}`
            }))
        }];

        const msg = generateWAMessageFromContent(m.chat, {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: "📊 *MANAJEMEN BLACKLIST GRUP*\n\nSilakan pilih grup di bawah ini yang ingin Bang hapus dari daftar blokir."
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: global.botname }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                            title: "🗑️ HAPUS BLACKLIST",
                            sections: sections
                        })
                    }]
                })
            })
        }, { quoted: m });

        return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
    }
};

handler.help = ["blgb", "listblgb", "delblgb"];
handler.tags = ["owner"];
handler.command = /^(blgb|blacklistgb|listblgb|delblgb)$/i;
handler.owner = true;

export default handler;
