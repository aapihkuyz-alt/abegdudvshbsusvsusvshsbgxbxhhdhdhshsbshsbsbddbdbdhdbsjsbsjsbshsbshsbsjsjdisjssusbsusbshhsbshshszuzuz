import os from "os";

let handler = async (m, { conn, db, usedPrefix }) => {
    const settings = db.list().settings;
    const stats = settings.stats || {};

    // Urutkan command berdasarkan pemakaian terbanyak
    const sortedStats = Object.entries(stats)
        .sort((a, b) => b[1].count - a[1].count)
        .slice(0, 10);

    let report = `╭─❍ *GLOBAL BOT STATISTICS* ❍─
│
│ 📊 *Top 10 Used Features:*
│\n`;

    sortedStats.forEach(([cmd, data], i) => {
        const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : "🔹";
        report += `│ ${medal} *${cmd}*: ${data.count} uses\n`;
    });

    const totalHits = Object.values(stats).reduce((acc, curr) => acc + curr.count, 0);

    report += `│
├─────────────────────
│ 📈 *Total Overall Hits:* ${totalHits.toLocaleString()}
│ 🖥️ *System RAM:* ${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB / ${Math.round(os.totalmem() / 1024 / 1024)}MB
│ 📂 *Active Plugins:* ${Object.keys(global.cmd.plugins).length}
╰─────────────────────❍`;

    await m.reply(report);
};

handler.help = ["botstats", "hits"];
handler.tags = ["owner", "info"];
handler.command = /^(botstats|hits|topcmd)$/i;

export default handler;