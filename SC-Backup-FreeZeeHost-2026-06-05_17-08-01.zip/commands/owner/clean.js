import { cleanupTrashData } from '../../core/cron.js';
import fs from 'fs';
import path from 'path';

const handler = async (m, { conn, Func }) => {
    await m.react("🧹");
    
    const before = process.memoryUsage().rss;
    
    // 1. Jalankan cleanup file sampah
    await cleanupTrashData();
    
    // 2. Clear temp folder
    const tmpDir = path.join(process.cwd(), 'tmp');
    if (fs.existsSync(tmpDir)) {
        const files = fs.readdirSync(tmpDir);
        for (const file of files) {
            try {
                fs.unlinkSync(path.join(tmpDir, file));
            } catch {}
        }
    }
    
    // 3. Trigger Garbage Collector jika tersedia
    if (global.gc) {
        global.gc();
    }
    
    const after = process.memoryUsage().rss;
    const freed = ((before - after) / 1024 / 1024).toFixed(2);

    m.reply(`✅ *Bot Cleanup Success* ✅\n\n- Trash files purged.\n- Temp folder cleared.\n- RAM Optimasi: ${freed > 0 ? freed : 0} MB dibebaskan.`);
};

handler.help = ['clean', 'clear'];
handler.tags = ['owner'];
handler.command = ['clean', 'clear', 'purge'];
handler.owner = true;

export default handler;
