import fs from "fs"
import axios from "axios"
import FormData from "form-data"

const DB_FILE = "./databasee.json"

let handler = async (m, {
    conn,
    text,
    db
}) => {

    // =========================
    // AUTO CREATE DB FILE
    // =========================
    if (!fs.existsSync(DB_FILE)) {
        fs.writeFileSync(DB_FILE, JSON.stringify({
            user: {}
        }, null, 2))
    }

    // =========================
    // DETECT IMAGE
    // =========================
    const quoted = m.quoted ? m.quoted : m

    const isImage =
        quoted?.mimetype?.includes("image") ||
        quoted?.message?.imageMessage

    if (!isImage) {
        return m.reply("Reply foto dulu njir 🗿\n\nContoh:\n.addbini Siska,19")
    }

    // =========================
    // FORMAT
    // =========================
    if (!text.includes(",")) {
        return m.reply("Format salah.\nContoh: .addbini Siska,19")
    }

    let [nama, umur] = text.split(",").map(v => v.trim())

    if (!nama || !umur) return m.reply("Nama atau umur kosong.")

    umur = parseInt(umur)
    if (isNaN(umur)) return m.reply("Umur harus angka.")

    if (umur < 16) return m.reply("❌ Lu Pedo kah? 😒 umur minimal 16 tahun.")

    // =========================
    // LOAD DB
    // =========================
    let data = JSON.parse(fs.readFileSync(DB_FILE))

    if (!data.user[m.sender]) {
        data.user[m.sender] = {
            bini: []
        }
    }

    let user = data.user[m.sender]

    if (!user.bini) user.bini = []

    // =========================
    // DOWNLOAD FOTO
    // =========================
    let media = await quoted.download?.()
    if (!media) return m.reply("❌ Gagal ambil foto.")

    await conn.sendMessage(m.chat, {
        react: {
            text: "📤",
            key: m.key
        }
    })

    // =========================
    // UPLOAD CATBOX
    // =========================
    let form = new FormData()
    form.append("fileToUpload", media, "bini.jpg")
    form.append("reqtype", "fileupload")

    let {
        data: res
    } = await axios.post(
        "https://catbox.moe/user/api.php",
        form, {
            headers: form.getHeaders()
        }
    )

    if (!res || !res.startsWith("https")) {
        return m.reply("❌ Gagal upload ke Catbox.")
    }

    let link = res.trim()

    // =========================
    // SIMPAN
    // =========================
    user.bini.push({
        nama,
        umur,
        foto: link,
        createdAt: Date.now()
    })

    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2))

    await conn.sendMessage(m.chat, {
        react: {
            text: "✅",
            key: m.key
        }
    })

    await conn.sendMessage(m.chat, {
        image: {
            url: link
        },
        caption: `💍 Bini ditambahkan

👰 Nama: ${nama}
🎂 Umur: ${umur}
📊 Total: ${user.bini.length}`
    }, {
        quoted: m
    })
}

handler.command = ["addbini"]
handler.tags = ["owner"]

export default handler