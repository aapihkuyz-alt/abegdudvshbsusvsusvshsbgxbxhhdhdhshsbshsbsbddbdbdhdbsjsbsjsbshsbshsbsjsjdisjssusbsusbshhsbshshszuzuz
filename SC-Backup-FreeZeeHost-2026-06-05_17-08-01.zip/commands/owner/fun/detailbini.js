import fs from "fs"

const DB_FILE = "./databasee.json"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply("Pilih dari menu njir.")

    let index = parseInt(text)

    if (isNaN(index)) return m.reply("Index gak valid.")

    let data = JSON.parse(fs.readFileSync(DB_FILE))
    let user = data.user?.[m.sender]

    if (!user || !user.bini || !user.bini[index]) {
        return m.reply("Bini tidak ditemukan.")
    }

    let b = user.bini[index]

    const buttons = [{
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🗑 Hapus",
                id: `.delbini ${index}`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "📋 List",
                id: `.mybini`
            })
        }
    ]

    await conn.sendMessage(m.chat, {
        image: {
            url: b.foto
        },
        caption: `💍 *DETAIL BINI*

👰 Nama: ${b.nama}
🎂 Umur: ${b.umur}
🕒 Ditambahkan: ${new Date(b.createdAt).toLocaleString("id-ID")}`,
        footer: "FreeZeeHost System",
        interactive: buttons
    }, {
        quoted: m
    })
}

handler.command = ["detailbini"]
handler.tags = ["owner"]

export default handler