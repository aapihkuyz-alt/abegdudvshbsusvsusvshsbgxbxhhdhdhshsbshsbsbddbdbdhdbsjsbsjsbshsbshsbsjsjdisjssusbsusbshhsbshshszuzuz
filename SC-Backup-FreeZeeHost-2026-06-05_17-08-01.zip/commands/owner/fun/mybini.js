import fs from "fs"

const DB_FILE = "./databasee.json"

let handler = async (m, {
    conn
}) => {

    if (!fs.existsSync(DB_FILE)) {
        return m.reply("Database kosong njir.")
    }

    let data = JSON.parse(fs.readFileSync(DB_FILE))
    let user = data.user?.[m.sender]

    if (!user || !user.bini || user.bini.length === 0) {
        return m.reply("Lu jomblo 😭")
    }

    let rows = user.bini.map((v, i) => ({
        header: `Bini ${i + 1}`,
        title: v.nama,
        description: `Umur ${v.umur}`,
        id: `.detailbini ${i}`
    }))

    const button = [{
        name: "single_select",
        buttonParamsJson: JSON.stringify({
            title: "💍 Pilih Bini",
            sections: [{
                title: "Daftar Bini",
                highlight_label: "MyBini",
                rows
            }]
        })
    }]

    await conn.sendMessage(m.chat, {
        text: `💍 *LIST BINI LU*\n\nTotal: ${user.bini.length}`,
        footer: "FreeZeeHost System",
        interactive: button
    }, {
        quoted: m
    })
}

handler.command = ["mybini"]
handler.tags = ["owner"]

export default handler