let handler = async (m, { db, text, usedPrefix, command }) => {
    let settings = db.list().settings;
    if (!text) return m.reply(`📌 Status Ghost: *${settings.stealth ? "AKTIF" : "MATI"}*\n\nKetik *${usedPrefix + command} on* untuk menghilang dari radar (Tanpa Typing/Read).`);

    if (text === "on") {
        settings.stealth = true;
        await db.save();
        m.reply("👤 *[ GHOST MODE ON ]* \nKamu sekarang dalam mode Stealth. Bot tidak akan menunjukkan status 'Mengetik' atau 'Membaca' saat kamu berinteraksi.");
    } else if (text === "off") {
        settings.stealth = false;
        await db.save();
        m.reply("👤 *[ GHOST MODE OFF ]* \nKamu kembali terlihat normal oleh sistem.");
    } else {
        m.reply(`📌 Contoh: *${usedPrefix + command} on* atau *off*`);
    }
};

handler.help = ["ghost on/off"];
handler.tags = ["owner"];
handler.command = /^(ghost|stealth)$/i;
handler.owner = true;

export default handler;