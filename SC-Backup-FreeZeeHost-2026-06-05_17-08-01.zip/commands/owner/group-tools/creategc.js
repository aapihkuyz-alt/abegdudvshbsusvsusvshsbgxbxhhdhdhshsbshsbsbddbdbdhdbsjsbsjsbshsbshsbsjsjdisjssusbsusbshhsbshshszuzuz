const handler = async (m, {
    conn,
    text
}) => {
    if (!text) {
        return m.reply(
            "⚠️ *Format salah!*\n\n" +
            "Contoh:\n" +
            ".creategc Nama Grup @user1 @user2\n" +
            "atau\n" +
            ".creategc Nama Grup 628xxxx 628xxxx"
        );
    }

    // Ambil mention
    let mention = m.mentionedJid || [];

    // Ambil nomor dari text
    let nums = text.match(/\d{5,}/g) || [];

    // Gabungkan member
    let members = [
        ...mention,
        ...nums.map(n => n + "@s.whatsapp.net")
    ];

    // Bersihin duplikat & sender
    members = [...new Set(members)].filter(v => v !== m.sender);

    if (members.length < 1) {
        return m.reply("⚠️ Minimal masukkan 1 anggota.");
    }

    // Nama grup (hapus mention & nomor)
    let groupName = text
        .replace(/@\d+/g, "")
        .replace(/\d{5,}/g, "")
        .trim();

    if (!groupName) {
        return m.reply("⚠️ Nama grup tidak boleh kosong.");
    }

    // Tambahkan pembuat grup
    members.unshift(m.sender);

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        });

        let gc = await conn.groupCreate(groupName, members);

        if (!gc?.id) throw new Error("FAILED_CREATE_GROUP");

        let link = "Tidak tersedia";
        try {
            let code = await conn.groupInviteCode(gc.id);
            link = `https://chat.whatsapp.com/${code}`;
        } catch {}

        let result =
            `✅ *Grup berhasil dibuat!*\n\n` +
            `📛 Nama: *${groupName}*\n` +
            `👥 Anggota: *${gc.participants.length}*\n` +
            `🆔 ID: ${gc.id}\n\n` +
            `🔗 Link:\n${link}`;

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        });

        return m.reply(result);

    } catch (e) {
        console.error("[CREATEGROUP]", e);

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        });

        let errMsg = "⚠️ Gagal membuat grup.";
        if (/not allowed/i.test(e.message))
            errMsg += "\nBot tidak punya izin membuat grup.";
        if (/participant/i.test(e.message))
            errMsg += "\nAda member tidak valid.";

        return m.reply(errMsg);
    }
};

/* ================== CONFIG ================== */
handler.help = ["creategc <nama> <member>"];
handler.tags = ["group"];
handler.command = /^creategc|buatgc|cgc$/i;
handler.owner = true;

export default handler;