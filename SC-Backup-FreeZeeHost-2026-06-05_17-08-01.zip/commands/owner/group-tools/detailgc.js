let handler = async (m, { conn, text }) => {
    if (!text)
        return m.reply(
            "❌ Silakan masukkan link undangan grup WhatsApp.\n\nContoh:\n#detailgc https://chat.whatsapp.com/xxxxx"
        )

    if (!text.includes("chat.whatsapp.com"))
        return m.reply("❌ Link tidak valid. Pastikan menggunakan link invite resmi WhatsApp.")

    try {
        await conn.sendMessage(m.chat, {
            react: { text: "🔍", key: m.key }
        })

        const code = text.split("chat.whatsapp.com/")[1]?.split("?")[0]
        if (!code) return m.reply("❌ Kode undangan tidak ditemukan.")

        const info = await conn.groupGetInviteInfo(code)

        const created = info.creation
            ? new Date(info.creation * 1000).toLocaleString()
            : "-"

        const caption = `
╭━━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 👥 *GROUP CONTROL PANEL*
┃
┃ 📌 STATUS ANALISA GROUP
┃ Sistem berhasil mengambil metadata
┃ dari link undangan yang diberikan.
┃
┃━━━━━━━━━━━━━━━━━━━━━━━
┃ 🏷 *INFORMASI UMUM*
┃
┃ • Nama Grup :
┃   ${info.subject}
┃
┃ • ID Grup :
┃   ${info.id}
┃
┃ • Total Member :
┃   ${info.size} Anggota
┃
┃ • Dibuat Pada :
┃   ${created}
┃
┃ • Owner Grup :
┃   ${info.owner ? info.owner.split("@")[0] : "-"}
┃
┃━━━━━━━━━━━━━━━━━━━━━━━
┃ 🔎 KETERANGAN TAMBAHAN
┃
┃ • Data diambil langsung dari sistem
┃   WhatsApp melalui kode undangan.
┃
┃ • Jika bot belum tergabung,
┃   maka informasi hanya bersifat preview.
┃
┃ • Gunakan fitur ini dengan bijak
┃   dan hanya untuk kebutuhan manajemen.
┃
┃━━━━━━━━━━━━━━━━━━━━━━━
┃ ⚠ AKSES TERBATAS
┃ Fitur ini hanya dapat digunakan
┃ oleh Owner Bot.
┃
╰━━━━━━━━━━━━━━━━━━━━━━━⬣
        `.trim()

        await conn.sendMessage(
            m.chat,
            {
                text: caption,
                footer: "Ryuu Group Management System",
                buttons: [
                    {
                        buttonId: `.leavegc ${info.id}`,
                        buttonText: { displayText: "🚪 Leave Group (Jika Sudah Join)" },
                        type: 1
                    }
                ]
            },
            { quoted: m }
        )

    } catch (e) {
        console.error("DETAILGC ERROR:", e)
        m.reply(
            "❌ Gagal mengambil metadata grup.\n\nKemungkinan:\n• Link sudah kedaluwarsa\n• Link tidak valid\n• Grup telah direset invite-nya"
        )
    }
}

handler.command = ["detailgc"]
handler.owner = true

export default handler