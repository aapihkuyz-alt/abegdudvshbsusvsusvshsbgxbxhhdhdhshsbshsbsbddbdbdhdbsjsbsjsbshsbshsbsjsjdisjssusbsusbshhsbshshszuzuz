let handler = async (m, {
    args,
    conn,
    isOwner,
    command,
    prefix
}) => {
    if (!isOwner) return

    const mode = (args[0] || '').toLowerCase()
    const groupList = Object.entries(conn.chats || {})
        .filter(([jid]) => jid.endsWith('@g.us'))

    // ================= MENU =================
    if (!mode) {
        let teks = `*LEAVE GROUP MENU*\n\n`
        teks += `.leavegc all\n`
        teks += `.leavegc tertutup\n`
        teks += `.leavegc pilih\n\n`
        teks += `Total grup: ${groupList.length}`

        return m.reply(teks)
    }

    // ================= ALL =================
    if (mode === 'all') {
        m.reply(`Keluar dari ${groupList.length} grup...`)

        for (const [jid] of groupList) {
            await conn.groupLeave(jid).catch(() => {})
            await new Promise(r => setTimeout(r, 800))
        }

        return m.reply('✔ Selesai keluar dari semua grup.')
    }

    // ================= TERTUTUP =================
    if (mode === 'tertutup') {
        let total = 0
        m.reply('Scanning grup tertutup (bot bukan admin)...')

        for (const [jid] of groupList) {
            const meta = await conn.groupMetadata(jid).catch(() => null)
            if (!meta || !meta.announce) continue

            const isBotAdmin = meta.participants.some(
                p => p.id === conn.user.jid && p.admin
            )

            if (!isBotAdmin) {
                await conn.groupLeave(jid).catch(() => {})
                total++
                await new Promise(r => setTimeout(r, 500))
            }
        }

        return m.reply(`✔ Keluar dari ${total} grup tertutup.`)
    }

    // ================= PILIH =================
    if (mode === 'pilih') {
        let teks = '*DAFTAR GRUP*\n\n'
        let i = 1

        for (const [jid] of groupList) {
            const meta = await conn.groupMetadata(jid).catch(() => null)
            if (!meta) continue

            const isBotAdmin = meta.participants.some(
                p => p.id === conn.user.jid && p.admin
            )

            teks += `${i}. ${meta.subject}\n`
            teks += `   Status: ${meta.announce ? 'Tertutup' : 'Terbuka'}\n`
            teks += `   Bot Admin: ${isBotAdmin ? 'Ya' : 'Tidak'}\n`
            teks += `   Cmd: .leavegcid ${jid}\n\n`
            i++
        }

        return m.reply(teks)
    }
}

// ================= LEAVE VIA ID =================
handler.before = async (m, {
    args,
    conn,
    command,
    isOwner
}) => {
    if (!isOwner) return
    if (command !== 'leavegcid') return

    const gid = args[0]
    if (!gid || !gid.endsWith('@g.us')) return

    await conn.groupLeave(gid).catch(() => {})
    m.reply(`✔ Berhasil keluar dari:\n${gid}`)
}

// ================= META =================
handler.command = /^(leavegc|leavegcid)$/i
handler.tags = ['owner']
handler.help = [
    'leavegc',
    'leavegc all',
    'leavegc tertutup',
    'leavegc pilih',
    'leavegcid <id>'
]
handler.owner = true
handler.register = true

export default handler