const handler = async (m, {
    conn
}) => {

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "📢",
                key: m.key
            }
        })

        const list_newsletter = await conn.newsletterFetchAllParticipating()

        if (!list_newsletter || !list_newsletter.length)
            return m.reply("⚠️ Bot belum join newsletter manapun.")

        let teks = `
╭━━━〔 📢 LIST NEWSLETTER 〕━━━⬣
┃ 📚 Total Join :
┃ ➜ *${list_newsletter.length} Channel*
┃
`.trim()

        list_newsletter.forEach((v, i) => {
            teks += `
┣━━━━━━━━━━━━━━━━━━⬣
┃ ${i + 1}. *${v.name || "Tanpa Nama"}*
┃ 🆔 ID      : ${v.id}
┃ 👥 Member  : ${v.subscribers || "Tidak diketahui"}
┃ 📝 Status  : ${v.state || "Aktif"}
`
        })

        teks += `
╰━━━━━━━━━━━━━━━━━━⬣
✨ Newsletter System
`.trim()

        await conn.sendMessage(
            m.chat, {
                text: teks
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.log(e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil daftar newsletter.")
    }
}

handler.command = ["listch"]
handler.tags = ["owner"]
handler.help = ["listch"]
handler.owner = true

export default handler