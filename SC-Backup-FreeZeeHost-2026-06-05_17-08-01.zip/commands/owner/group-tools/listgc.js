let handler = async (m, { conn }) => {
    try {

        await conn.sendMessage(m.chat, {
            react: { text: "📂", key: m.key }
        })

        const groups = await conn.groupFetchAllParticipating()
        const list = Object.values(groups)

        if (!list.length)
            return m.reply("🤷 Bot belum tergabung di grup mana pun.")

        const rows = list.map((g, i) => ({
            header: "GROUP",
            title: `${i + 1}. ${g.subject}`,
            description: `👥 ${g.participants.length} Member`,
            id: `.detailgc https://chat.whatsapp.com/${g.inviteCode || ""}`
        }))

        const caption = `
╭━━━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 👥 *GROUP CONTROL PANEL*
┃
┃ 🤖 STATUS BOT
┃ Bot saat ini terdeteksi aktif dan
┃ tergabung di beberapa grup WhatsApp.
┃
┃━━━━━━━━━━━━━━━━━━━━━━━━
┃ 📊 TOTAL GROUP TERDAFTAR
┃ ➜ ${list.length} Grup Aktif
┃
┃━━━━━━━━━━━━━━━━━━━━━━━━
┃ 📌 PETUNJUK PENGGUNAAN
┃ • Tekan tombol di bawah ini
┃ • Pilih salah satu grup
┃ • Sistem akan menampilkan
┃   informasi lengkap grup tersebut
┃
┃━━━━━━━━━━━━━━━━━━━━━━━━
┃ 📋 INFORMASI YANG DITAMPILKAN
┃ • Nama Grup
┃ • Total Member
┃ • ID Grup
┃ • Tanggal Pembuatan
┃ • Owner Grup
┃ • Tombol Leave Group
┃
┃━━━━━━━━━━━━━━━━━━━━━━━━
┃ 🔐 AKSES TERBATAS
┃ Fitur ini hanya dapat digunakan
┃ oleh Owner Bot.
┃ Gunakan dengan tanggung jawab.
┃
╰━━━━━━━━━━━━━━━━━━━━━━━━⬣
        `.trim()

        await conn.sendMessage(
            m.chat,
            {
                text: caption,
                footer: "Ryuu Group Management System",
                buttons: [{
                    buttonId: "open-group-list",
                    buttonText: { displayText: "📋 Pilih Grup Untuk Detail" },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "📂 Daftar Grup Bot",
                            sections: [{
                                title: `Total ${list.length} Grup Aktif`,
                                rows
                            }]
                        })
                    }
                }]
            },
            { quoted: m }
        )

    } catch (e) {
        console.error("LISTGC ERROR:", e)
        m.reply("⚠️ Gagal mengambil daftar grup.")
    }
}

handler.command = ["listgc", "listgrup"]
handler.owner = true

export default handler