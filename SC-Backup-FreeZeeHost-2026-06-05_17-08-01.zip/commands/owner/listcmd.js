import fs from 'fs';

const dbPath = './database/stickercmd.json';

const handler = async (m, {
    conn,
    usedPrefix,
    command
}) => {
    if (!fs.existsSync(dbPath)) return m.reply("❌ Belum ada command stiker/emoji yang terdaftar.");

    let db = JSON.parse(fs.readFileSync(dbPath));
    let keys = Object.keys(db);

    if (keys.length === 0) return m.reply("❌ Database sticker command masih kosong.");

    let teks = `📂 *LIST STICKER & EMOJI COMMAND*\n\n`;
    let stikerCount = 0;
    let emojiCount = 0;

    keys.forEach((key, i) => {
        // Kalau panjang key lebih dari 20, berarti itu Hash Stiker (Base64)
        if (key.length > 20) {
            stikerCount++;
            teks += `${i + 1}. [Stiker] ➔ *${db[key]}*\n`;
        } else {
            emojiCount++;
            teks += `${i + 1}. ${key} ➔ *${db[key]}*\n`;
        }
    });

    teks += `\n*Total:* ${keys.length} (${stikerCount} Stiker, ${emojiCount} Emoji/Teks)`;
    teks += `\n\n_Gunakan ${usedPrefix}delcmd untuk menghapus._`;

    m.reply(teks);
};

handler.command = ['listcmd', 'lscmd'];
handler.tags = ['owner'];
handler.help = ['listcmd'];
handler.owner = true;

export default handler;