let handler = async (m, { conn, db }) => {
    const users = db.list().user;
    const now = Date.now();

    let premiumList = [];
    let ownerList = [];

    // Filter User
    Object.entries(users).forEach(([jid, user]) => {
        // Cek Premium
        if (user.premium?.status && (user.premium.expired === 0 || user.premium.expired > now)) {
            premiumList.push({
                jid,
                expired: user.premium.expired,
                name: user.name || "User"
            });
        }
        
        // Cek Owner Access
        if (user.owner_access?.status && (user.owner_access.expired === 0 || user.owner_access.expired > now)) {
            ownerList.push({
                jid,
                expired: user.owner_access.expired,
                name: user.name || "User"
            });
        }
    });

    let report = `╭─❍ *ACTIVE RENTAL LIST* ❍─\n│\n`;

    // 👑 SEWA OWNER
    report += `╠══  「 👑 *OWNER ACCESS* 」\n`;
    if (ownerList.length === 0) {
        report += `│ ◦ _Kosong_\n`;
    } else {
        ownerList.forEach((u, i) => {
            const exp = u.expired === 0 ? "PERMANENT" : new Date(u.expired).toLocaleString();
            report += `│ *${i + 1}.* @${u.jid.split("@")[0]}\n│    ┗ 📅 Exp: ${exp}\n`;
        });
    }

    report += `│\n`;

    // 💎 SEWA PREMIUM
    report += `╠══  「 💎 *PREMIUM ACCESS* 」\n`;
    if (premiumList.length === 0) {
        report += `│ ◦ _Kosong_\n`;
    } else {
        premiumList.forEach((u, i) => {
            const exp = u.expired === 0 ? "PERMANENT" : new Date(u.expired).toLocaleString();
            report += `│ *${i + 1}.* @${u.jid.split("@")[0]}\n│    ┗ 📅 Exp: ${exp}\n`;
        });
    }

    report += `│\n╰─────────────────────❍`;

    await conn.sendMessage(m.chat, { 
        text: report, 
        contextInfo: { 
            mentionedJid: [...premiumList.map(v => v.jid), ...ownerList.map(v => v.jid)],
            forwardingScore: 999,
            isForwarded: true
        } 
    }, { quoted: m });
};

handler.help = ["listsewa", "listpremium"];
handler.tags = ["owner", "main"];
handler.command = /^(listsewa|listsewabot|listpremium|listprem)$/i;

export default handler;