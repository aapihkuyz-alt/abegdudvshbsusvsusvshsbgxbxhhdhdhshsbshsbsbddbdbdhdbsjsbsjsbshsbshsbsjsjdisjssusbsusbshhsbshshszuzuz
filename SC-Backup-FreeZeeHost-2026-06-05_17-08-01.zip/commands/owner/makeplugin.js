import {
    GoogleGenAI
} from "@google/genai";
import axios from 'axios';
import * as cheerio from 'cheerio';

// Inisialisasi SDK BARU 
const ai = new GoogleGenAI({
    apiKey: "AIzaSyCoQXZHdx2nX-xaljwBg2FNpdp5mi7bSew"
});

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    if (!isOwner) return m.reply("❌ Khusus Owner.");

    let [url, ...prompt] = text.split('|');
    if (!url || !prompt.length) return m.reply(`*CARA PAKAI (Dua Mode):*\n\n1. *Auto:* ${usedPrefix + command} https://link.com | buat fitur fbdl\n2. *Manual (Anti-Block):* ${usedPrefix + command} manual | [Copy Teks API/Curl Disini]`);

    await m.react("⏳");
    const isManual = url.trim().toLowerCase() === 'manual';
    const targetUrl = isManual ? "Manual Input" : (url.trim().startsWith('http') ? url.trim() : 'https://' + url.trim());

    try {
        let bodyData = "";

        if (!isManual) {
            try {
                const {
                    data: html
                } = await axios.get(targetUrl, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0'
                    },
                    timeout: 5000
                });
                const $ = cheerio.load(html);
                $('script, style, noscript, footer, nav, header, aside').remove();
                bodyData = $('body').text().replace(/\s\s+/g, ' ').slice(0, 8000);
            } catch (e) {
                bodyData = "Gagal mengambil HTML. Fokus saja pada instruksi prompt user.";
            }
        } else {
            bodyData = prompt.join('|');
        }

        await m.react("🧠");

        const aiPrompt = `
Kamu adalah Senior WhatsApp Bot Developer (ESM Specialist).
Tugas: Membuat plugin .js berdasarkan instruksi atau data HTML.
Aturan Wajib:
1. Output HANYA kode JavaScript ESM.
2. Gunakan 'import' di awal, bukan 'require'.
3. Struktur: export default handler, handler.command, handler.tags, handler.help.
4. Jika ada indikasi API berbayar (Bearer/Token/Header), buatkan kodingan axios dengan headers: { Authorization: 'Bearer ...' }.

CONTEXT URL: ${targetUrl}
REFERENSI DATA: 
${bodyData}

USER REQUEST: ${prompt.join('|')}

TUGAS: Buatkan file plugin WhatsApp Bot ESM (.js) lengkap. 
- Berikan try-catch di dalam handler agar bot tidak crash.
`.trim();

        // MENGGUNAKAN MODEL GEMINI 3 FLASH (Aman buat Free Tier) ⚡
        const response = await ai.models.generateContent({
            model: "gemini-3-flash",
            contents: aiPrompt,
        });

        const aiResult = response.text;
        let code = aiResult.replace(/```javascript|```js|```/g, '').trim();

        const finalMsg = `✅ *AI 3 FLASH PLUGIN GENERATED* ⚡

🌐 *Source:* ${targetUrl === 'Manual Input' ? 'User Data' : targetUrl}
📝 *Request:* ${prompt.join('|')}

\`\`\`javascript
${code}
\`\`\`

_Paste kode di atas ke folder commands/ lalu restart bot._`;

        await m.reply(finalMsg);
        await m.react("✨");

    } catch (e) {
        console.error(e);
        m.reply(`❌ *ERROR SYSTEM!*\n\n*Info:* ${e.message}\n_Cek terminal untuk detail._`);
        await m.react("❌");
    }
};

handler.command = ['makeplugin', 'scrape', 'cfitur'];
handler.tags = ['owner'];
handler.help = ['makeplugin <url> | <prompt>'];
handler.owner = true;

export default handler;