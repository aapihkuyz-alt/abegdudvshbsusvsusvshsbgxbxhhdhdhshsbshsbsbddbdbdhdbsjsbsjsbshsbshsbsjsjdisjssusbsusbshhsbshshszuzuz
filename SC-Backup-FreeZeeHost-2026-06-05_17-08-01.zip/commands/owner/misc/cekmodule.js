import fs from 'fs'
import path from 'path'
import os from 'os'

const pick = arr => arr[Math.floor(Math.random() * arr.length)]

const handler = async (m) => {
    try {
        const root = process.cwd()
        const pkgPath = path.join(root, 'package.json')
        const lockPath = path.join(root, 'package-lock.json')

        if (!fs.existsSync(pkgPath)) {
            return m.reply('❌ package.json nggak ketemu. Ini proyek Node beneran kan?')
        }

        const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'))
        const lock = fs.existsSync(lockPath) ?
            JSON.parse(fs.readFileSync(lockPath, 'utf8')) :
            null

        const formatDeps = (deps = {}) => {
            if (!Object.keys(deps).length) return '_kosong_'

            return Object.entries(deps)
                .map(([name, ver]) => {
                    const locked = lock?.packages?.[`node_modules/${name}`]?.version
                    return `• ${name} (${locked || ver})`
                })
                .join('\n')
        }

        const deps = pkg.dependencies || {}
        const devDeps = pkg.devDependencies || {}

        const opening = pick([
            '🔍 Oke, gue cek isi dapur bot lu ya…',
            '🛠️ Status mesin bot saat ini:',
            '📦 Nih kondisi project bot lu sekarang 👇'
        ])

        const projectInfo = `
📌 *Project*
Nama   : ${pkg.name || '-'}
Versi  : ${pkg.version || 'N/A'}
Desc   : ${pkg.description || '-'}
`.trim()

        const systemInfo = `
💻 *System*
Node     : ${process.version}
Platform : ${os.platform()} (${os.arch()})
OS       : ${os.release()}
`.trim()

        const depInfo = `
📦 *Dependencies* (${Object.keys(deps).length})
${formatDeps(deps)}
`.trim()

        const devDepInfo = `
🧪 *Dev Dependencies* (${Object.keys(devDeps).length})
${formatDeps(devDeps)}
`.trim()

        const closing = pick([
            '✅ Semua itu yang lagi dipakai bot lu.',
            '⚙️ Kurang lebih segini isi mesin bot-nya.',
            '🚀 Bot siap jalan dengan konfigurasi ini.'
        ])

        const text = `
${opening}

${projectInfo}

${systemInfo}

────────────────

${depInfo}

────────────────

${devDepInfo}

${closing}
`.trim()

        m.reply(text)

    } catch (e) {
        console.error('[cekmodule]', e)
        m.reply('❌ Gagal ngecek modul. Ada yang bermasalah di sistem.')
    }
}

handler.help = ['cekmodule']
handler.tags = ['info']
handler.command = /^cekmodule$/i
handler.owner = true

export default handler