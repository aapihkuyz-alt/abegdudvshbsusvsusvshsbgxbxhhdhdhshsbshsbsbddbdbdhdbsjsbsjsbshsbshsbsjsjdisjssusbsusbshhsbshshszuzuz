const handler = async (m, { conn, text, usedPrefix, command }) => {
  try {
    let jid = null
    let num = null
    const normalizeJid = (value) => {
      let clean = String(value || "").trim()
      if (clean.includes("@")) clean = clean.split("@")[0]
      if (clean.includes(":")) clean = clean.split(":")[0]
      clean = clean.replace(/\D/g, "")
      if (!clean) return null
      if (clean.startsWith("0")) clean = "62" + clean.slice(1)
      else if (!clean.startsWith("62")) clean = "62" + clean
      return clean + "@s.whatsapp.net"
    }

    // ===== PRIORITAS 1: REPLY TARGET =====
    if (m.quoted?.sender) {
      jid = normalizeJid(m.quoted.sender)
      num = jid?.split("@")[0]
    }

    // ===== PRIORITAS 2: MENTION =====
    else if (m.mentions && m.mentions.length > 0) {
      jid = normalizeJid(m.mentions[0])
      num = jid?.split("@")[0]
    }

    // ===== PRIORITAS 3: INPUT ANGKA =====
    else if (text) {
      num = text.replace(/\D/g, "")
      if (!num) return m.reply("❌ Nomor tidak valid")

      if (num.startsWith("0")) num = "62" + num.slice(1)
      else if (!num.startsWith("62")) num = "62" + num
      jid = normalizeJid(num)

      const cek = await conn.onWhatsApp(jid)
      if (!cek[0]?.exists) {
        return m.reply("❌ Nomor ini tidak terdaftar di WhatsApp")
      }
    }

    if (!jid) {
      return m.reply(
        `📸 *Get Profile Picture*\n\n` +
        `Contoh:\n` +
        `• ${usedPrefix + command} 62812xxxx\n` +
        `• ${usedPrefix + command} @tag`
      )
    }

    const pp = await conn
      .profilePictureUrl(jid, "image")
      .catch(() => "https://btch.pages.dev/file/70e8de9b1879568954f09.jpg")

    const caption =
      `📸 *PROFILE PICTURE*\n` +
      `━━━━━━━━━━━━━━━\n` +
      `📞 wa.me/${num}\n` +
      `━━━━━━━━━━━━━━━\n` +
      `_Powered by ${global.ownername}_`

    await conn.sendMessage(
      m.chat,
      {
        image: { url: pp },
        caption
      },
      { quoted: m }
    )

  } catch (e) {
    console.error("GETPP ERROR:", e)
    m.reply("❌ Gagal mengambil foto profil")
  }
}

handler.command = ["getpp", "pp", "cekpp"]
handler.tags = ["tools"]
handler.help = ["getpp <nomor|@tag>"]

export default handler
