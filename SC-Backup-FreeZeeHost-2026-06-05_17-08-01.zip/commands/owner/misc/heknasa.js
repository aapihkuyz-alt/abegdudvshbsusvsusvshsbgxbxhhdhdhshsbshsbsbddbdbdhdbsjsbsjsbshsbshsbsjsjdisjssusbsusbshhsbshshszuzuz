// heknasa.js
export default async function handler(m, {
    conn,
    isOwner,
    mess
}) {
    if (!isOwner) return m.reply(mess.owner)

    const verify = await verifyPhoneNumber(m.sender)
    if (!verify.success) return m.reply(verify.message)

    const steps = [
        '🛰 Mengunci target jaringan NASA...',
        '🔐 Menyusun ulang kunci enkripsi firewall...',
        '📡 Sinkronisasi satelit orbit rendah...',
        '🗂 Membaca database internal...',
        '📥 Mengekstrak file rahasia...',
        '🔓 Eskalasi akses server inti...',
        '🧠 Analisis data proyek...',
        '📤 Mengamankan hasil...',
        '✅ Operasi selesai.'
    ]

    // pesan progress (1 pesan)
    let progressMsg = await conn.sendMessage(
        m.chat, {
            text: '⚙️ *Menjalankan protokol HEKNASA...*'
        }, {
            quoted: m
        }
    )

    // edit progress
    for (let step of steps) {
        await delay(2500)
        await editMessage(conn, m.chat, progressMsg, step)
    }

    // random data
    const randomIP = generateRandomIP()
    const codename = generateCodename()
    const coordinate = generateCoordinate()

    // hasil akhir (pesan baru)
    const result = `
🚀 *OPERATION HEKNASA SUCCESS* 🚀

🕒 *Waktu:* ${new Date().toLocaleString()}
🛰 *Node:* NASA Private Cloud
🌐 *Target IP:* ${randomIP}
🛡 *Firewall:* Breached
📡 *Satelit:* Online
🗄 *Database:* Full Access

📁 *Data Diamankan:*
• Codename Proyek: **${codename}**
• Satellite Coordinate: **${coordinate}**
• Alien File: **REDACTED**
• Quantum Blueprint
• Root Token

🧹 Log dibersihkan
🔚 Koneksi ditutup
`

    await delay(1500)
    await conn.sendMessage(m.chat, {
        text: result
    }, {
        quoted: progressMsg
    })
}

// ===== util =====
const delay = ms => new Promise(res => setTimeout(res, ms))

async function editMessage(conn, chat, msg, text) {
    try {
        if (msg.edit) return await msg.edit(text)
        return await conn.sendMessage(chat, {
            text,
            edit: msg.key
        })
    } catch {
        return conn.sendMessage(chat, {
            text
        })
    }
}

function generateRandomIP() {
    return Array.from({
            length: 4
        }, () =>
        Math.floor(Math.random() * 256)
    ).join('.')
}

function generateCodename() {
    const words = [
        'ORION', 'NEBULA', 'ATLAS', 'PHOENIX',
        'ZENITH', 'NOVA', 'COSMOS', 'ECLIPSE',
        'ASTRA', 'HYPERION'
    ]
    const word = words[Math.floor(Math.random() * words.length)]
    const code = Math.random().toString(36).substring(2, 6).toUpperCase()
    return `${word}-${code}`
}

function generateCoordinate() {
    const lat = (Math.random() * 180 - 90).toFixed(4)
    const lon = (Math.random() * 360 - 180).toFixed(4)
    const latDir = lat >= 0 ? 'N' : 'S'
    const lonDir = lon >= 0 ? 'E' : 'W'
    return `${Math.abs(lat)}° ${latDir}, ${Math.abs(lon)}° ${lonDir}`
}

async function verifyPhoneNumber(number) {
    if (!number) return {
        success: false,
        message: '❌ Nomor tidak valid.'
    }
    return {
        success: true
    }
}

// ===== command config =====
handler.command = ['heknasa']
handler.owner = true
handler.tags = ['owner', 'fun']
handler.help = ['heknasa']