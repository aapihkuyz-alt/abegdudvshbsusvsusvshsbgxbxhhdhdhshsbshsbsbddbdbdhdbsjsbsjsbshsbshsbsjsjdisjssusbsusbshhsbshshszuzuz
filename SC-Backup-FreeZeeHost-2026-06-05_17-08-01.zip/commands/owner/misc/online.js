let handler = async (m, {
    conn,
    args
}) => {
    try {

        if (!args[0]) {
            return m.reply(`Gunakan:
.online all     → Online terlihat semua orang
.online match   → Ikuti pengaturan last seen`)
        }

        const option = args[0].toLowerCase()

        if (option === "all") {
            await conn.updateOnlinePrivacy("all")
            global.onlinePrivacy = "all"
            return m.reply("✅ Status online sekarang terlihat semua orang.")
        }

        if (option === "match") {
            await conn.updateOnlinePrivacy("match_last_seen")
            global.onlinePrivacy = "match_last_seen"
            return m.reply("🔒 Status online sekarang mengikuti pengaturan last seen.")
        }

        return m.reply("❌ Pilihan tidak valid. Gunakan: all atau match.")

    } catch (err) {
        console.log("ONLINE PRIVACY ERROR:", err)
        m.reply("❌ Gagal mengubah status online.")
    }
}

handler.help = ["online all/match"]
handler.tags = ["owner"]
handler.command = ["online"]
handler.owner = true

export default handler