const handler = async (m, { text, db }) => {
    const settings = db.list().settings;
    if (!text) {
        settings.onlygc = !settings.onlygc;
        await db.save();
        return m.reply(`✅ Mode Only Group telah *${settings.onlygc ? "AKTIF" : "NONAKTIF"}*!`);
    }

    const value = text.toLowerCase();
    if (!["on", "off"].includes(value)) return m.reply("Gunakan on atau off! Contoh: .onlygc on");

    const isOnlyGC = value === 'on';
    settings.onlygc = isOnlyGC;
    await db.save();

    m.reply(`✅ Mode Only Group telah *${isOnlyGC ? "AKTIF" : "NONAKTIF"}*!`);
};

handler.command = ["onlygc", "gconly"];
handler.tags = ["owner"];
handler.description = "Mengaktifkan/menonaktifkan mode hanya di grup (hanya owner).";
handler.owner = true;

export default handler;
