const handler = async (m, { text, db }) => {
    const settings = db.list().settings;
    if (!text) {
        settings.onlypv = !settings.onlypv;
        await db.save();
        return m.reply(`✅ Mode Only Private telah *${settings.onlypv ? "AKTIF" : "NONAKTIF"}*!`);
    }

    const value = text.toLowerCase();
    if (!["on", "off"].includes(value)) return m.reply("Gunakan on atau off! Contoh: .onlypv on");

    const isOnlyPV = value === 'on';
    settings.onlypv = isOnlyPV;
    await db.save();

    m.reply(`✅ Mode Only Private telah *${isOnlyPV ? "AKTIF" : "NONAKTIF"}*!`);
};

handler.command = ["onlypv", "pconly"];
handler.tags = ["owner"];
handler.description = "Mengaktifkan/menonaktifkan mode hanya di private (hanya owner).";
handler.owner = true;

export default handler;
