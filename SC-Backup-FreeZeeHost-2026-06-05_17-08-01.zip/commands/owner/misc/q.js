import util from "util"

let handler = async (m, {
    conn,
    command
}) => {

    if (!m.quoted) {
        return m.reply("Reply pesan yang ingin di extract.")
    }

    try {

        let raw = m.quoted
        let msg = raw.message || raw.msg || raw

        /* ================= BASIC JSON ================= */

        if (command === "q") {

            let result = {
                header: msg
            }

            return conn.sendMessage(
                m.chat, {
                    text: JSON.stringify(result, null, 2)
                }, {
                    quoted: m
                }
            )

        }

        /* ================= FULL JSON ================= */

        if (command === "q2") {

            let result = {
                key: raw.key || null,
                sender: raw.sender || null,
                message: msg,
                contextInfo: raw.msg?.contextInfo || null
            }

            return conn.sendMessage(
                m.chat, {
                    text: JSON.stringify(result, null, 2)
                }, {
                    quoted: m
                }
            )

        }

        /* ================= RELAY GENERATOR ================= */

        if (command === "qrelay") {

            let raw = m.quoted

            let code = `/* GENERATED RELAY MESSAGE */

let remoteJid = "${m.chat}"

await conn.relayMessage(
remoteJid,
${JSON.stringify(raw.message, null, 2)},
{
messageId: conn.generateMessageTag()
}
)
`

            return conn.sendMessage(
                m.chat, {
                    text: code
                }, {
                    quoted: m
                }
            )

        }

    } catch (e) {

        console.log(e)

        m.reply("❌ Gagal mengambil data pesan")

    }

}

handler.command = ["q", "q2", "qrelay"]
handler.tags = ["owner"]
handler.help = ["q", "q2", "qrelay"]
handler.owner = true

export default handler