import axios from "axios"

let handler = async (m, {
    conn,
    args
}) => {

    if (!handler.owner)
        return m.reply("❌ Fitur ini khusus owner.")

    try {

        // ================= REMOVE =================
        if (args[0] === "remove") {
            await conn.removeProfilePicture(conn.user.id)
            return m.reply("✅ Foto profil bot berhasil dihapus.")
        }

        let media

        // ================= DARI URL =================
        if (args[0] && args[0].startsWith("http")) {

            const res = await axios.get(args[0], {
                responseType: "arraybuffer"
            })

            media = res.data
        }

        // ================= DARI REPLY =================
        else if (m.quoted) {

            const type = Object.keys(m.quoted.message || {})[0]

            if (type !== "imageMessage")
                return m.reply("❌ Reply foto asli, bukan dokumen atau teks.")

            media = await m.quoted.download()
        } else {
            return m.reply("Reply foto atau kirim URL.\n#setppbot remove untuk hapus.")
        }

        if (!media)
            return m.reply("❌ Gagal mengambil gambar.")

        await conn.updateProfilePicture(conn.user.id, media)

        m.reply("✅ Foto profil bot berhasil diperbarui.")

    } catch (err) {
        console.error(err)
        m.reply("❌ Gagal mengganti foto profil.")
    }
}

handler.command = ["setppbot"]
handler.owner = true

export default handler