let handler = async (m, {
    conn,
    text
}) => {
    try {

        if (!text || !text.includes("|")) {
            return m.reply("Format:\n.swtag teks|628xxx,628xxx")
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        let [caption, numbers] = text.split("|")
        caption = caption.trim()
        numbers = numbers.trim()

        let list = numbers.split(",")
        let jids = list.map(num =>
            num.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
        )

        let content = {}

        if (m.quoted) {

            let quoted = m.quoted
            let mime = quoted.mimetype || quoted.msg?.mimetype || ""

            if (!/image|video/.test(mime)) {
                return m.reply("Reply foto/video saja.")
            }

            let buffer =
                await quoted.download?.() ||
                await conn.downloadMediaMessage(quoted)

            if (mime.startsWith("image")) {
                content = {
                    image: buffer,
                    caption
                }
            } else {
                content = {
                    video: buffer,
                    caption
                }
            }

        } else {
            content = {
                text: caption
            }
        }

        await conn.sendStatusMentions(content, jids)

        await conn.sendMessage(m.chat, {
            react: {
                text: "🔥",
                key: m.key
            }
        })

        return true

    } catch (err) {
        console.error("SWTAG ERROR:", err)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
    }
}

handler.command = ["swtag"]
handler.tags = ["owner"]
handler.owner = true

export default handler