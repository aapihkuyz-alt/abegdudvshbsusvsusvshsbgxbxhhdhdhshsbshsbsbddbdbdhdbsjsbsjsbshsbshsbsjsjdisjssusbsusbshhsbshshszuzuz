import moment from "moment-timezone";

const normalizeTargetJid = (jid) => {
  let value = String(jid || "").trim();
  if (value.includes("@")) value = value.split("@")[0];
  if (value.includes(":")) value = value.split(":")[0];
  value = value.replace(/[^0-9]/g, "");
  if (value.startsWith("0")) value = "62" + value.slice(1);
  return value + "@s.whatsapp.net";
};

const findUserRecord = (db, jid) => {
  const normalized = normalizeTargetJid(jid);
  const number = normalized.split("@")[0];
  const users = db.list().user || {};

  const exact = users[normalized];
  if (exact) return { key: normalized, user: exact };

  const foundKey = Object.keys(users).find((key) => {
    let value = String(key || "");
    if (value.includes("@")) value = value.split("@")[0];
    if (value.includes(":")) value = value.split(":")[0];
    value = value.replace(/[^0-9]/g, "");
    return value === number;
  });

  if (foundKey) return { key: foundKey, user: users[foundKey] };
  return { key: normalized, user: null };
};

const handler = async (m, { text, usedPrefix, command, db }) => {
  if (!text) {
    return m.reply(
      `Gunakan format:\n${usedPrefix + command} @user <durasi>\n\nContoh:\n${usedPrefix + command} @user 30d\n\nDurasi:\nd = hari\nh = jam\nm = menit`
    );
  }

  let who;
  if (m.isGroup) {
    who =
      m.mentionedJid?.[0] ||
      m.quoted?.sender ||
      (text.replace(/[^0-9]/g, "")
        ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
        : null);
  } else {
    who = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
  }

  if (!who || who === "@s.whatsapp.net") {
    return m.reply("Tag, reply, atau masukkan nomor user yang valid.");
  }

  who = normalizeTargetJid(who)

  const durationMatch = text.match(/(\d+)([dhm])/i);
  if (!durationMatch) {
    return m.reply("Format durasi salah.\nContoh: 30d | 12h | 45m");
  }

  const value = parseInt(durationMatch[1]);
  const unit = durationMatch[2].toLowerCase();

  const durationMs =
    value *
    {
      d: 86400000,
      h: 3600000,
      m: 60000,
    }[unit];

  const found = findUserRecord(db, who);
  let user = found.user;
  if (!user) {
    user = {
      name: "",
      limit: 100,
      register: false,
      owner: false,
      premium: {
        status: false,
        expired: 0
      },
      banned: {
        status: false,
        expired: 0
      },
      saldo: 0
    };
    await db.add("user", found.key, user);
  }

  user.premium ??= {
    status: false,
    expired: 0,
  };

  const expired = Date.now() + durationMs;
  user.premium.status = true;
  user.premium.expired = expired;

  await db.save();

  m.reply(
    `✅ *PREMIUM AKTIF*\n\n` +
      `👤 User: @${who.split("@")[0]}\n` +
      `⏳ Durasi: ${value}${unit}\n` +
      `📆 Expired: ${moment(expired)
        .tz("Asia/Jakarta")
        .format("DD MMMM YYYY, HH:mm:ss")} WIB`,
    { mentions: [who] }
  );
};

handler.command = ["addprem", "addpremium"];
handler.tags = "owner";
handler.description = "Menambahkan user sebagai premium";
handler.owner = true;

export default handler;
