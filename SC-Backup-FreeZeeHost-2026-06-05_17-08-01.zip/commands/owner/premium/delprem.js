const normalizeTargetJid = (jid) => {
  let value = String(jid || "").trim();
  if (value.includes("@")) value = value.split("@")[0];
  if (value.includes(":")) value = value.split(":")[0];
  value = value.replace(/[^0-9]/g, "");
  if (value.startsWith("0")) value = "62" + value.slice(1);
  return value + "@s.whatsapp.net";
};

const findUserRecord = (db, jid) => {
  const normalized = normalizeTargetJid(jid);
  const number = normalized.split("@")[0];
  const users = db.list().user || {};

  const exact = users[normalized];
  if (exact) return { key: normalized, user: exact };

  const foundKey = Object.keys(users).find((key) => {
    let value = String(key || "");
    if (value.includes("@")) value = value.split("@")[0];
    if (value.includes(":")) value = value.split(":")[0];
    value = value.replace(/[^0-9]/g, "");
    return value === number;
  });

  if (foundKey) return { key: foundKey, user: users[foundKey] };
  return { key: normalized, user: null };
};

const handler = async (m, { text, usedPrefix, command, db }) => {
  if (!text && !m.quoted) {
    return m.reply(`Gunakan format:\n${usedPrefix + command} @user\n${usedPrefix + command} 628xxx`);
  }

  let who =
    m.mentionedJid?.[0] ||
    m.quoted?.sender ||
    (text.replace(/[^0-9]/g, "")
      ? text.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
      : null);

  if (!who || who === "@s.whatsapp.net") {
    return m.reply("Tag, reply, atau masukkan nomor user yang valid.");
  }

  who = normalizeTargetJid(who)

  const found = findUserRecord(db, who);
  const user = found.user;
  if (!user) {
    return m.reply("User tidak ditemukan di database.");
  }

  if (!user.premium || !user.premium.status) {
    return m.reply(
      `User @${who.split("@")[0]} bukan pengguna premium.`,
      { mentions: [who] }
    );
  }

  user.premium.status = false;
  user.premium.expired = 0;

  await db.save();

  m.reply(
    `✅ Status premium @${who.split("@")[0]} berhasil dihapus.`,
    { mentions: [who] }
  );
};

handler.command = ["delprem", "delpremium"];
handler.tags = "owner";
handler.description = "Menghapus status premium dari user.";
handler.owner = true;

export default handler;
