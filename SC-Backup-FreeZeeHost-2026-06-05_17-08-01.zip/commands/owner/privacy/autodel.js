let handler = async (m, {
    conn,
    args
}) => {

    if (!args[0]) {
        return m.reply(`❌ Format salah.

Contoh:
.disappear 24h
.disappear 7d
.disappear 90d
.disappear off`)
    }

    const input = args[0].toLowerCase()
    let seconds = 0

    if (input === "24h") seconds = 86400
    else if (input === "7d") seconds = 604800
    else if (input === "90d") seconds = 7776000
    else if (input === "off" || input === "0") seconds = 0
    else return m.reply("❌ Opsi tidak valid.")

    try {
        await conn.updateDefaultDisappearingMode(seconds)

        const map = {
            0: "Disabled",
            86400: "24 Hours",
            604800: "7 Days",
            7776000: "90 Days"
        }

        m.reply(`✅ Default Disappearing Mode diubah ke: *${map[seconds]}*`)
    } catch (err) {
        console.log(err)
        m.reply("❌ Gagal mengubah Disappearing Mode.")
    }
}

handler.command = ["disappear", "autodel"]
handler.owner = true
handler.tags = ["owner"]
handler.help = ["disappear <24h/7d/90d/off>"]

export default handler