let handler = async (m, { conn, text, usedPrefix, command, db }) => {
  let settings = db.list().settings;
  if (!text) return m.reply(`Gunakan: ${usedPrefix + command} on/off`);
  
  let status = text.toLowerCase() === "on";
  settings.auto_forward_status = status;
  await db.save();
  
  m.reply(`✅ *Auto-Forward Status* berhasil di *${status ? "aktifkan" : "matikan"}*.\nBot akan ${status ? "otomatis mengirim status teman ke chat kamu" : "berhenti mengirim status otomatis"}.`);
};

handler.help = ["autoforwardsw on/off"];
handler.tags = ["owner"];
handler.command = ["autoforwardsw", "forwardsw"];
handler.owner = true;

export default handler;
