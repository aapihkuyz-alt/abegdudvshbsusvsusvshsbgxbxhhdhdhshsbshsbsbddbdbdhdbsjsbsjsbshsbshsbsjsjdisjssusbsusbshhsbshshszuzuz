let handler = async (m, {
    conn,
    args
}) => {
    try {

        if (!args[0]) {
            return m.reply(`Gunakan:
.autoread on  → Tampilkan centang biru
.autoread off → Sembunyikan centang biru`)
        }

        const option = args[0].toLowerCase()

        if (option === "on") {
            await conn.updateReadReceiptsPrivacy("all")
            global.autoRead = true
            return m.reply("✅ Auto Read diaktifkan (centang biru terlihat).")
        }

        if (option === "off") {
            await conn.updateReadReceiptsPrivacy("none")
            global.autoRead = false
            return m.reply("🚫 Auto Read dimatikan (centang biru disembunyikan).")
        }

        return m.reply("❌ Pilih on atau off.")

    } catch (err) {
        console.log("AUTOREAD ERROR:", err)
        m.reply("❌ Terjadi kesalahan saat mengubah pengaturan.")
    }
}

handler.help = ["autoread on/off"]
handler.tags = ["owner"]
handler.command = ["autoread"]
handler.owner = true

export default handler