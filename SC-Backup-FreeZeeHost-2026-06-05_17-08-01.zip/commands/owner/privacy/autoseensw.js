let handler = async (m, { conn, text, usedPrefix, command, db }) => {
  let settings = db.list().settings;
  if (!text) return m.reply(`Gunakan: ${usedPrefix + command} on/off`);
  
  let status = text.toLowerCase() === "on";
  settings.auto_view_status = status;
  await db.save();
  
  m.reply(`✅ *Auto-View Status* berhasil di *${status ? "aktifkan" : "matikan"}*.\nBot akan ${status ? "otomatis melihat status teman" : "berhenti melihat status otomatis"}.`);
};

handler.help = ["autoseensw on/off"];
handler.tags = ["owner"];
handler.command = ["autoseensw", "autoseen"];
handler.owner = true;

export default handler;
