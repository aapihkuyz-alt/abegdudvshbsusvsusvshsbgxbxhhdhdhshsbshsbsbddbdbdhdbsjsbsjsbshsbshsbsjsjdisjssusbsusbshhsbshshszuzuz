let handler = async (m, {
    conn,
    args
}) => {

    if (!args[0]) {
        return m.reply(`❌ Format salah.

Contoh:
.gaddprivacy all
.gaddprivacy contacts
.gaddprivacy blacklist`)
    }

    const input = args[0].toLowerCase()
    let mode

    if (input === "all") mode = "all"
    else if (input === "contacts") mode = "contacts"
    else if (input === "blacklist") mode = "contact_blacklist"
    else return m.reply("❌ Opsi tidak valid.")

    try {
        await conn.updateGroupsAddPrivacy(mode)

        const map = {
            all: "Everyone",
            contacts: "Contacts Only",
            contact_blacklist: "Contacts Blacklist"
        }

        m.reply(`✅ Group Add Privacy berhasil diubah ke: *${map[mode]}*`)
    } catch (err) {
        console.log(err)
        m.reply("❌ Gagal mengubah Group Add Privacy.")
    }
}

handler.command = ["gaddprivacy", "setgaddprivacy"]
handler.owner = true
handler.tags = ["owner"]
handler.help = ["gaddprivacy <all/contacts/blacklist>"]

export default handler