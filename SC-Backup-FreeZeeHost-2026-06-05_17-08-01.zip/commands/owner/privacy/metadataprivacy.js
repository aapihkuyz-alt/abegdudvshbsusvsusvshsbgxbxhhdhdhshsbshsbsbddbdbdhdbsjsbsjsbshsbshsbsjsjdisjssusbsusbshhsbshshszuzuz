const handler = async (m, {
    conn
}) => {

    try {
        const privacy = await conn.fetchPrivacySettings(true)

        const teks = `
🔐 *BOT PRIVACY SETTINGS*

👁 Last Seen       : ${privacy.last || "-"}
📸 Profile Photo   : ${privacy.profile || "-"}
📄 About           : ${privacy.status || "-"}
👥 Group Add       : ${privacy.groupadd || "-"}
📖 Read Receipts   : ${privacy.readreceipts || "-"}
🟢 Online Status   : ${privacy.online || "-"}
`.trim()

        m.reply(teks)

    } catch (err) {
        console.error("PRIVACY ERROR:", err)
        m.reply("❌ Gagal mengambil metadata privacy.")
    }

}

handler.command = ["metapriv", "privacybot"]
handler.owner = true

export default handler