let handler = async (m, {
    conn,
    args
}) => {

    if (!args[0]) {
        return m.reply(`❌ Format salah.

Contoh:
.ppprivacy all
.ppprivacy contacts
.ppprivacy blacklist
.ppprivacy none`)
    }

    const input = args[0].toLowerCase()
    let mode

    if (input === "all") mode = "all"
    else if (input === "contacts") mode = "contacts"
    else if (input === "blacklist") mode = "contact_blacklist"
    else if (input === "none") mode = "none"
    else return m.reply("❌ Opsi tidak valid.")

    try {
        await conn.updateProfilePicturePrivacy(mode)

        const map = {
            all: "Everyone",
            contacts: "Contacts",
            contact_blacklist: "Contacts Blacklist",
            none: "Hidden"
        }

        m.reply(`✅ Profile picture privacy berhasil diubah ke: *${map[mode]}*`)
    } catch (err) {
        console.log(err)
        m.reply("❌ Gagal mengubah profile picture privacy.")
    }
}

handler.command = ["ppprivacy", "setppprivacy"]
handler.owner = true
handler.tags = ["owner"]
handler.help = ["ppprivacy <all/contacts/blacklist/none>"]

export default handler