let handler = async (m, {
    conn,
    args
}) => {

    if (!args[0]) {
        return m.reply(`❌ Format salah.

Contoh:
.statusprivacy all
.statusprivacy contacts
.statusprivacy blacklist
.statusprivacy none`)
    }

    const input = args[0].toLowerCase()
    let mode

    if (input === "all") mode = "all"
    else if (input === "contacts") mode = "contacts"
    else if (input === "blacklist") mode = "contact_blacklist"
    else if (input === "none") mode = "none"
    else return m.reply("❌ Opsi tidak valid.")

    try {
        await conn.updateStatusPrivacy(mode)

        const map = {
            all: "Everyone",
            contacts: "Contacts",
            contact_blacklist: "Contacts Blacklist",
            none: "Hidden"
        }

        m.reply(`✅ Status privacy berhasil diubah ke: *${map[mode]}*`)
    } catch (err) {
        console.log(err)
        m.reply("❌ Gagal mengubah status privacy.")
    }
}

handler.command = ["statusprivacy", "setstatusprivacy"]
handler.owner = true
handler.tags = ["owner"]
handler.help = ["statusprivacy <all/contacts/blacklist/none>"]

export default handler