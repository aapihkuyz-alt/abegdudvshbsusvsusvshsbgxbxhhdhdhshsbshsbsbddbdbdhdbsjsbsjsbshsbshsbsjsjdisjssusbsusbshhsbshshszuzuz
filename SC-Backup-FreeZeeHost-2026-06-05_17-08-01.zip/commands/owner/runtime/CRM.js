import fs from 'fs';
import path from 'path';

let handler = async (m, { conn, isOwner }) => {
    if (!isOwner) return;

    if (!m.quoted) {
        return await m.reply("❌ Reply pesan yang ingin dijadikan script Relay (CRM).");
    }

    try {
        await m.react("⏳");
        
        const raw = m.quoted;
        let msgPayload = raw.message || raw.msg || raw;

        // Bersihkan data yang tidak perlu agar relay lebih bersih
        if (msgPayload.messageContextInfo) delete msgPayload.messageContextInfo;

        const code = `/* GENERATED CRM (Copy Relay Message) SCRIPT */
/* Anda bisa mengedit JSON di bawah ini sebelum menjalankan perintah .run */

const targetJid = "${m.chat}";

const payload = ${JSON.stringify(msgPayload, null, 4)};

await conn.relayMessage(
    targetJid,
    payload,
    { messageId: conn.generateMessageTag() }
);

m.reply("✅ CRM Script berhasil dieksekusi!");
`;

        // Buat file sementara
        const fileName = `CRM_${Date.now()}.js`;
        const filePath = path.join(process.cwd(), 'tmp', fileName);
        
        fs.writeFileSync(filePath, code);

        // Kirim sebagai dokumen
        await conn.sendMessage(m.chat, { 
            document: fs.readFileSync(filePath), 
            mimetype: 'application/javascript', 
            fileName: fileName,
            caption: `✅ *CRM (Create Relay Module) BERHASIL*\n\n_File script berhasil dibuat dari pesan yang direply. Detail objek (seperti tombol/media) sudah tersimpan akurat seperti fitur .q_\n\n_Balas file ini dengan *.run* untuk mengirim ulang pesan, atau download file ini untuk mengedit isinya (misal: ganti nama tombol) sebelum di-run._`
        }, { quoted: m });

        // Hapus file setelah dikirim
        fs.unlinkSync(filePath);
        await m.react("✅");

    } catch (e) {
        console.error(e);
        await m.reply(`❌ Gagal membuat CRM: ${e.message}`);
    }
}

handler.help = ["crm"];
handler.tags = ["owner"];
handler.command = /^crm$/i;
handler.owner = true;

export default handler;
