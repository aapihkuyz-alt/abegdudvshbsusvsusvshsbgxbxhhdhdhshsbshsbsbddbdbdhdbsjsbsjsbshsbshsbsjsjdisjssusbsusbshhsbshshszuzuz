import fs from "fs"
import {
    execSync
} from "child_process"
import chokidar from "chokidar"
import moment from "moment-timezone"

/* ================= GLOBAL STATE ================= */
global.autoBackup = global.autoBackup ?? false
global.autoBackupWatcher = global.autoBackupWatcher ?? null
let debounceTimer = null
let notified = false

/* ================= HELPER BACKUP ================= */
const doBackup = async (conn, to) => {
    const tempDir = "./tmp"
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, {
        recursive: true
    })

    const time = moment().tz("Asia/Jakarta").format("YYYY-MM-DD_HH-mm-ss")
    const backupName = `Backup-${global.botname}-${time}`
    const backupPath = `${tempDir}/${backupName}.tar.gz`

    try {
        const excludes = [
            "node_modules",
            "sessions",
            "package-lock.json",
            ".npm",
            ".cache",
            ".git",
            "*.zip",
            "*.tar.gz",
            "*.wav",
            "data/sampah",
            "tmp",
            "database.json",
            "databasee.json"
        ].map(item => `--exclude="${item}"`).join(" ");

        execSync(`tar ${excludes} -czf ${backupPath} .`, { stdio: "ignore" });

        await conn.sendMessage(
            to, {
                document: fs.readFileSync(backupPath),
                fileName: `${backupName}.tar.gz`,
                mimetype: "application/gzip",
                caption: `✅ *Backup Berhasil (TAR.GZ)*\n🗓️ *Waktu:* ${time}`
            }
        );

        if (fs.existsSync(backupPath)) fs.unlinkSync(backupPath);
    } catch (e) {
        throw e;
    }
}

/* ================= AUTO BACKUP ================= */
const startAutoBackup = (conn, target) => {
    if (global.autoBackupWatcher) return

    global.autoBackupWatcher = chokidar.watch(".", {
        ignored: /node_modules|sessions|\.npm|\.cache|data\/sampah|tmp|\.git/,
        ignoreInitial: true,
        persistent: true,
    })

    global.autoBackupWatcher.on("all", () => {
        if (!global.autoBackup) return

        // notif sekali
        if (!notified) {
            notified = true
            conn.sendMessage(target, {
                text: "🛠 *Update terdeteksi!*\n" +
                    "Bot sedang backup script...\n\n" +
                    "⏳ Mohon tunggu sebentar."
            }).catch(() => {})
        }

        if (debounceTimer) clearTimeout(debounceTimer)

        debounceTimer = setTimeout(async () => {
            try {
                await doBackup(conn, target)
                console.log("[AUTO BACKUP] ✔ Backup terkirim")
            } catch (e) {
                console.error("[AUTO BACKUP ERROR]", e)
            } finally {
                notified = false
            }
        }, 5000)
    })

    console.log("[AUTO BACKUP] 🚀 Aktif")
}

const stopAutoBackup = () => {
    if (global.autoBackupWatcher) {
        global.autoBackupWatcher.close()
        global.autoBackupWatcher = null
    }
    global.autoBackup = false
    console.log("[AUTO BACKUP] ❌ Dimatikan")
}

/* ================= HANDLER ================= */
let handler = async (m, {
    conn,
    command,
    text
}) => {

    const owner = m.sender
    const target = owner

    /* ===== BACKUP MANUAL ===== */
    if (command === "backup") {
        try {
            await m.reply("*📦 Memproses backup script bot...*")

            await doBackup(conn, target)

            if (m.isGroup) {
                await m.reply("✅ Backup berhasil dikirim ke private chat Anda.")
            }

        } catch (e) {
            console.error(e)
            m.reply("❌ *Gagal membuat backup script!*")
        }
        return
    }

    /* ===== AUTO BACKUP ===== */
    if (command === "autobackup") {
        const arg = text?.toLowerCase()

        if (arg === "on") {
            global.autoBackup = true
            startAutoBackup(conn, target)
            return m.reply(
                "✅ *Auto backup diaktifkan.*\n" +
                "Bot akan backup otomatis setiap ada perubahan script ke private chat Anda."
            )
        }

        if (arg === "off") {
            stopAutoBackup()
            return m.reply("❌ *Auto backup dimatikan.*")
        }

        if (arg === "status") {
            return m.reply(
                `📊 *AUTO BACKUP STATUS*\n\nStatus: ${
                    global.autoBackup ? "🟢 AKTIF" : "🔴 NONAKTIF"
                }`
            )
        }

        return m.reply(
            "Gunakan:\n" +
            "#autobackup on\n" +
            "#autobackup off\n" +
            "#autobackup status"
        )
    }
}

/* ================= CONFIG ================= */
handler.help = ["backup", "autobackup on/off/status"]
handler.tags = ["owner"]
handler.command = ["backup", "autobackup"]
handler.mods = true
handler.owner = true

export default handler