import fs from "fs"
import { execSync } from "child_process"
import moment from "moment-timezone"
import chalk from "chalk"

let handler = async (m, { conn, command }) => {
    if (!m.isGroup) return m.reply("❌ Fitur ini hanya dapat digunakan di dalam grup!")
    
    try {
        await m.reply(`⏳ *Sedang memproses backup SC...*\n_File akan dikirimkan ke grup ini jika sudah selesai._`)

        const tempDir = "./tmp"
        if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true })

        const time = moment().tz("Asia/Jakarta").format("YYYY-MM-DD_HH-mm-ss")
        const backupName = `SC-Backup-${global.botname || "Bot"}-${time}`
        const backupPath = `${tempDir}/${backupName}.zip`

        // List file/folder yang dikecualikan (keamanan & efisiensi)
        const excludes = [
            "node_modules",
            "sessions",
            "package-lock.json",
            ".npm",
            ".cache",
            ".git",
            ".env",
            "tmp",
            "*.zip",
            "*.tar.gz",
            "database.json",
            "databasee.json",
            "data/sampah"
        ]

        // Menggunakan zip command (lebih umum untuk dikirim ke grup)
        const excludeFlags = excludes.map(item => `-x "${item}/*" -x "${item}"`).join(" ")
        
        try {
            // Cek apakah zip terinstal
            execSync("zip -v", { stdio: "ignore" })
            execSync(`zip -r ${backupPath} . ${excludeFlags}`, { stdio: "ignore" })
        } catch (e) {
            // Fallback ke tar jika zip tidak ada
            console.log(chalk.yellow("[BACKUP-GC] 'zip' command not found, falling back to 'tar'"))
            const tarExcludes = excludes.map(item => `--exclude="${item}"`).join(" ")
            const tarPath = backupPath.replace(".zip", ".tar.gz")
            execSync(`tar ${tarExcludes} -czf ${tarPath} .`, { stdio: "ignore" })
            
            await conn.sendMessage(m.chat, {
                document: fs.readFileSync(tarPath),
                fileName: `${backupName}.tar.gz`,
                mimetype: "application/gzip",
                caption: `✅ *Backup SC Berhasil (TAR.GZ)*\n🗓️ *Waktu:* ${time}\n📌 *Grup:* ${m.chat}`
            }, { quoted: m })

            if (fs.existsSync(tarPath)) fs.unlinkSync(tarPath)
            return
        }

        await conn.sendMessage(m.chat, {
            document: fs.readFileSync(backupPath),
            fileName: `${backupName}.zip`,
            mimetype: "application/zip",
            caption: `✅ *Backup SC Berhasil (ZIP)*\n🗓️ *Waktu:* ${time}\n📌 *Grup:* ${m.chat}`
        }, { quoted: m })

        if (fs.existsSync(backupPath)) fs.unlinkSync(backupPath)

    } catch (e) {
        console.error(e)
        m.reply(`❌ *Gagal membuat backup script!*\nError: ${e.message}`)
    }
}

handler.help = ["backupgc"]
handler.tags = ["owner"]
handler.command = ["backupgc"]
handler.owner = true
handler.group = true

export default handler