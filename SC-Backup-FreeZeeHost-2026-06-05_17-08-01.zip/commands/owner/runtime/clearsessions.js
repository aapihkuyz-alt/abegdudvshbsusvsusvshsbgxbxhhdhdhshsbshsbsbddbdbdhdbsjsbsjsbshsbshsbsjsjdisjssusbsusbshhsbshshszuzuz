import fs from "fs"
import path from "path"

const SESSION_DIR = "./sessions"

// 🔥 hitung size folder
const getSize = (dir) => {
    let total = 0
    const files = fs.readdirSync(dir)

    for (let file of files) {
        const full = path.join(dir, file)
        const stat = fs.statSync(full)

        if (stat.isDirectory()) {
            total += getSize(full)
        } else {
            total += stat.size
        }
    }

    return (total / 1024 / 1024).toFixed(2) + " MB"
}

let handler = async (m, {
    conn
}) => {

    if (!fs.existsSync(SESSION_DIR)) {
        return m.reply("❌ Folder sessions tidak ditemukan.")
    }

    const sessions = fs.readdirSync(SESSION_DIR).filter(v => {
        const full = path.join(SESSION_DIR, v)
        return fs.lstatSync(full).isDirectory()
    })

    if (!sessions.length) {
        return m.reply("❌ Tidak ada session.")
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: "📂",
            key: m.key
        }
    })

    // 🔥 QUICK BUTTON
    const quickButtons = [{
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🔴 Clear All",
                id: ".clsall"
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "📊 Refresh",
                id: ".cls"
            })
        }
    ]

    // 🔥 LIST SESSION
    const rows = sessions.map((name, i) => {
        const full = path.join(SESSION_DIR, name)
        const size = getSize(full)

        const isRunning = Boolean(global.sessionSockets?.get?.(name))

        return {
            header: `Session ${i + 1}`,
            title: name,
            description: `📊 ${size} | ${isRunning ? "🟢 Running" : "🟡 Idle"}`,
            id: `.clsrun ${name}`
        }
    })

    const nativeFlowButton = [{
        name: "single_select",
        buttonParamsJson: JSON.stringify({
            title: "🧹 Session Cleaner",
            sections: [{
                title: "Pilih Session",
                highlight_label: "Clear Cache Mode",
                rows
            }]
        })
    }]

    await conn.sendMessage(m.chat, {
        text: `🧹 *SESSION CLEANER SYSTEM*

Total Session : ${sessions.length}

Pilih session untuk membersihkan cache tanpa menghapus login.`,
        footer: "FreeZeeHost Cleaner",
        interactive: [...quickButtons, ...nativeFlowButton]
    }, {
        quoted: m
    })
}

handler.command = ["clearsession", "cls"]
handler.owner = true
handler.tags = ["owner"]

export default handler