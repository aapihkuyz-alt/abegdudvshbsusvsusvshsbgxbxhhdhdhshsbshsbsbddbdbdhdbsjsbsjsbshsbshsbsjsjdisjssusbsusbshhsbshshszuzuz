import fs from "fs"
import path from "path"

let handler = async (m, {
    conn
}) => {

    const base = "./sessions"

    await conn.sendMessage(m.chat, {
        react: {
            text: "🧹",
            key: m.key
        }
    })

    let deleted = 0

    const sessions = fs.readdirSync(base)

    for (const sess of sessions) {

        const dir = path.join(base, sess)
        if (!fs.lstatSync(dir).isDirectory()) continue

        const files = fs.readdirSync(dir)

        for (const file of files) {

            if (file === "creds.json") continue
            if (file === "keys") continue

            fs.rmSync(path.join(dir, file), {
                recursive: true,
                force: true
            })

            deleted++
        }
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: "✅",
            key: m.key
        }
    })

    m.reply(`🔴 Semua cache session dibersihkan\n✅ ${deleted} file dihapus`)
}

handler.command = ["clsall"]
handler.owner = true

export default handler