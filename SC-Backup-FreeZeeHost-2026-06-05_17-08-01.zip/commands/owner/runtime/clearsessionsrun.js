import fs from "fs"
import path from "path"

let handler = async (m, {
    text,
    conn
}) => {

    if (!text) return m.reply("❌ Session tidak dipilih.")

    const target = path.join("./sessions", text)

    if (!fs.existsSync(target)) {
        return m.reply("❌ Session tidak ditemukan.")
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: "🧹",
            key: m.key
        }
    })

    const files = fs.readdirSync(target)
    let deleted = 0

    for (const file of files) {

        if (file === "creds.json") continue
        if (file === "keys") continue

        fs.rmSync(path.join(target, file), {
            recursive: true,
            force: true
        })

        deleted++
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: "✅",
            key: m.key
        }
    })

    m.reply(`🧹 Cache session *${text}* dibersihkan\n✅ ${deleted} file dihapus`)
}

handler.command = ["clsrun"]
handler.owner = true

export default handler