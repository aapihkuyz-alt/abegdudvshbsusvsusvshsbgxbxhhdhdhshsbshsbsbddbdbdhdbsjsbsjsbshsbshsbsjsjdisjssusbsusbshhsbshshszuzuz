import { exec } from "child_process";
import util from "util";
import { createRequire } from 'module';
import axios from 'axios';
import fs from 'fs';

const require = createRequire(import.meta.url);
const execPromise = util.promisify(exec);
const handler = {};

// Fungsi utama: menangani pesan masuk
handler.onMessage = async (m, { conn, sock, text, isOwner, isDev, db, Func, store, cmd }) => {
  if (!isOwner && !isDev) return;
  if (!sock) sock = conn;
  const budy = String(m.text || text || "").trim();
  if (!budy) return;


  if (budy.startsWith("=>")) {
    try {
      let evaled = await eval(`(async () => { ${budy.slice(2)} })()`);
      if (typeof evaled !== "string") evaled = util.inspect(evaled);
      await m.reply(evaled);
    } catch (err) {
      await m.reply(String(err));
    }
    return;
  }

  if (budy.startsWith(">")) {
    try {
      let evaled = await eval(budy.slice(1));
      if (typeof evaled !== "string") evaled = util.inspect(evaled);
      await m.reply(evaled);
    } catch (err) {
      await m.reply(String(err));
    }
    return;
  }

  if (budy.startsWith("$")) {
    try {
      const command = budy.slice(1).trim();
      if (!command) {
        await m.reply("Masukkan shell command.");
        return;
      }

      const { stdout, stderr } = await execPromise(command);
      const output = [stdout?.trim(), stderr?.trim()].filter(Boolean).join("\n");
      await m.reply(output || "Command selesai tanpa output.");
    } catch (err) {
      const output = [err?.stdout?.trim(), err?.stderr?.trim(), err?.message].filter(Boolean).join("\n");
      await m.reply(output || String(err));
    }
    return;
  }

};

handler.command = "eval"; // Dummy trigger to pass the Integrity Guard
handler.category = "owner";
export default handler;
