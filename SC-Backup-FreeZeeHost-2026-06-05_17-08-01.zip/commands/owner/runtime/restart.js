import { spawn } from "child_process"
import path from "path"

const isPterodactyl = () =>
    Boolean(
        process.env.PTERODACTYL ||
        process.env.P_SERVER_UUID ||
        process.env.P_SERVER_LOCATION ||
        process.env.P_SERVER_ALLOCATION_LIMIT
    )

const isSystemd = () => Boolean(process.env.INVOCATION_ID)

let handler = async (m) => {
    global.isRestarting = true

    if (typeof process.send === "function") {
        await m.reply("```RESTART MODE: IPC MANAGER```")
        process.send("reset")
        return
    }

    if (process.env.pm_id !== undefined) {
        await m.reply("```RESTART MODE: PM2```")
        setTimeout(() => process.exit(0), 1000)
        return
    }

    if (isPterodactyl()) {
        await m.reply("```RESTART MODE: PTERODACTYL```")
        setTimeout(() => process.exit(1), 1000)
        return
    }

    if (isSystemd()) {
        await m.reply("```RESTART MODE: SYSTEMD```")
        setTimeout(() => process.exit(1), 1000)
        return
    }

    const entryFile = path.resolve(process.cwd(), "index.js")
    const logFile = "/tmp/freezeehost-restart.log"
    const restartCmd = `cd "${process.cwd()}" && nohup "${process.execPath}" "${entryFile}" >"${logFile}" 2>&1 < /dev/null &`

    await m.reply("```RESTART MODE: VPS / MANUAL```")

    spawn("bash", ["-lc", restartCmd], {
        cwd: process.cwd(),
        detached: true,
        stdio: "ignore",
        env: process.env
    }).unref()

    setTimeout(() => process.exit(0), 1500)
}

handler.help = ["restart"]
handler.tags = ["owner"]
handler.command = /^(res(tart)?)$/i
handler.owner = true

export default handler
