import util from "util";

let handler = async (m, { conn, isOwner, text }) => {
    if (!isOwner) return;

    try {
        const quoted = m.quoted;
        let code = "";

        const isDoc =
            quoted &&
            quoted.type === "documentMessage" &&
            typeof quoted.download === "function";

        if (isDoc) {
            const buffer = await quoted.download();
            code = buffer.toString();
        } else if (quoted?.text) {
            code = quoted.text;
        } else if (text) {
            code = text;
        }

        if (!code || !code.trim()) {
            return await m.reply("Masukkan code atau reply pesan yang berisi code.");
        }

        const AsyncFunction = Object.getPrototypeOf(async function() {}).constructor;
        const runner = new AsyncFunction(
            "m",
            "conn",
            "util",
            "global",
            "Buffer",
            code
        );
        const result = await runner(m, conn, util, global, Buffer);

        const output =
            typeof result === "string" ?
            result :
            util.inspect(result, {
                depth: null,
                maxArrayLength: null,
            });

        if (output && output !== "undefined") {
            await m.reply(output);
        }
    } catch (e) {
        const err = e?.stack || e?.message || String(e);
        await m.reply(err);
    }
}

handler.help = ["run"];
handler.tags = ["owner"];
handler.command = /^run$/i;
handler.owner = true;

export default handler;
