import fs from "fs";
import path from "path";
import { scanCodeSecurity } from "../../core/security.js";

let handler = async (m, { text, usedPrefix, command }) => {
    if (!m.quoted || !m.quoted.text) return m.reply(`📌 Reply kodenya dan kasih nama file!\n\nContoh: *${usedPrefix + command} download/ytmp4.js*`);
    if (!text) return m.reply(`📌 Kasih nama filenya, Bang!\n\nContoh: *${usedPrefix + command} main/test.js*`);

    const code = m.quoted.text;

    // --- SECURITY SCAN ---
    const scanResult = scanCodeSecurity(code);
    if (!scanResult.safe) {
        let warningText = `⚠️ *[ SECURITY ALERT ]* ⚠️\n\nSistem mendeteksi perintah berbahaya dalam kode ini:\n`;
        scanResult.warnings.forEach(w => warningText += `◦ ${w}\n`);
        warningText += `\nTetap simpan file ini? Jika ya, ketik *y* (Owner only).`;
        
        await m.reply(warningText);

        const sessionKey = `${m.from}:${m.sender}`;
        global.interactiveSessions.set(sessionKey, {
            messageId: m.key.id,
            callback: async (response) => {
                if (response.text.toLowerCase() === 'y') {
                    return await saveFile(path.join(process.cwd(), "commands", text), code, m);
                } else {
                    await m.reply("❌ Proses penyimpanan dibatalkan demi keamanan.");
                }
            }
        });
        return;
    }
    // ----------------------

    await saveFile(path.join(process.cwd(), "commands", text), code, m);
};

async function saveFile(pathFile, code, m) {
    const folder = path.dirname(pathFile);
    try {
        if (!fs.existsSync(folder)) fs.mkdirSync(folder, { recursive: true });
        fs.writeFileSync(pathFile, code);
        await m.reply(`✅ *Plugin Saved!* \n\n📂 *Path:* \`commands/${path.basename(pathFile)}\`\n🛡️ *Status:* Active (Hot-Reloaded)`);
    } catch (e) {
        m.reply(`❌ *[ ERROR ]* Gagal menyimpan: ${e.message}`);
    }
}

handler.help = ["saveplugin"];
handler.tags = ["owner"];
handler.command = ["saveplugin", "sp", "sf"];
handler.owner = true;

export default handler;