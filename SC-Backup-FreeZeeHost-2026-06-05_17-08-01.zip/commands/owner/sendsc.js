import { exec } from "child_process";
import { promisify } from "util";
import fs from "fs";
import path from "path";
import chalk from "chalk";

const execPromise = promisify(exec);

let handler = async (m, { conn, isOwner }) => {
    if (!isOwner) return;

    const botName = global.botname || "Bot";
    const timestamp = Date.now();
    const exportDir = path.join(process.cwd(), `tmp/sc_${timestamp}`);
    const zipFile = path.join(process.cwd(), `tmp/${botName}_Encrypted_SC.zip`);

    await m.reply("🔐 *[ PROTECTION ]* Menyiapkan ekspor Source Code ter-enkripsi...");
    
    try {
        // 1. Buat folder temporary
        if (!fs.existsSync(path.join(process.cwd(), "tmp"))) fs.mkdirSync(path.join(process.cwd(), "tmp"));
        fs.mkdirSync(exportDir);

        // 2. Salin file (Kecuali node_modules, sessions, .git, .env)
        await m.reply("📂 *[ STEP 1 ]* Menyalin file proyek...");
        const exclude = [
            "node_modules", 
            "sessions", 
            ".git", 
            ".env", 
            "tmp", 
            "package-lock.json", 
            "data", 
            "telegrams", 
            "temp_test_session"
        ];
        const files = fs.readdirSync(process.cwd());

        for (const file of files) {
            if (exclude.includes(file)) continue;
            if (file.startsWith("backup-")) continue; // Skip backup archives
            const src = path.join(process.cwd(), file);
            const dest = path.join(exportDir, file);
            
            if (fs.lstatSync(src).isDirectory()) {
                await execPromise(`cp -r "${src}" "${dest}"`);
            } else {
                await execPromise(`cp "${src}" "${dest}"`);
            }
        }

        // 3. Obfuscate (Enkripsi) Logic .js files dengan level MAXIMUM
        await m.reply("🛡️ *[ STEP 2 ]* Mengenkripsi logika sistem dengan level MAXIMUM... \n_Ini akan memakan waktu lebih lama karena proteksi berlapis._");
        
        const obfuscateCmd = `npx -y javascript-obfuscator "${exportDir}" --output "${exportDir}" ` + 
            `--compact true ` +
            `--self-defending true ` + // Mencegah kode dijalankan jika di-format ulang/di-beautify
            `--debug-protection true ` + // Mencegah debugging (inspect element/dev tools)
            `--dead-code-injection true ` + // Menambah kode sampah agar bingung
            `--dead-code-injection-threshold 0.4 ` +
            `--string-array true ` +
            `--string-array-rotate true ` +
            `--string-array-shuffle true ` +
            `--string-array-index-shift true ` +
            `--string-array-encoding 'rc4' ` + // Enkripsi string lebih kuat (RC4)
            `--string-array-threshold 1 ` +
            `--transform-object-keys true ` +
            `--unicode-escape-sequence true ` +
            `--identifier-names-generator 'mangled'`;
        
        try {
            await execPromise(obfuscateCmd);
        } catch (obfErr) {
            console.error("Obfuscation warning:", obfErr.message);
        }

        // 4. Zip files dengan PASSWORD (Key)
        const zipKey = global.alyachan.slice(0, 8) + "FZH"; // Key rahasia gabungan
        await m.reply(`📦 *[ STEP 3 ]* Membungkus Archive dengan Password (Key)...`);
        
        // Gunakan command zip -P untuk memberi password
        await execPromise(`cd "${exportDir}" && zip -P "${zipKey}" -r "${zipFile}" . -x "node_modules/*" "sessions/*" ".env"`);

        // 5. Kirim File
        await m.reply("🚀 *[ FINISHING ]* Mengirim file ter-enkripsi ke Owner...");
        await conn.sendMessage(m.chat, { 
            document: fs.readFileSync(zipFile), 
            mimetype: 'application/zip', 
            fileName: `${botName}_ULTRA_PROTECTED.zip`,
            caption: `✅ *Ultra Source Code Protection*\n\n🔑 *Key (Password ZIP):* \`${zipKey}\`\n\n🛡️ *Proteksi:* \n- RC4 String Encryption\n- Dead Code Injection\n- Self-Defending Logic\n- Debug Protection\n\nKode ini TIDAK BISA di-decrypt atau dibaca tanpa key di atas.`
        }, { quoted: m });

        // 6. Cleanup
        await execPromise(`rm -rf "${exportDir}"`);
        if (fs.existsSync(zipFile)) fs.unlinkSync(zipFile);

    } catch (e) {
        console.error(chalk.red("[SENDSC ERROR]"), e.message);
        await m.reply(`❌ *[ FAILED ]* Terjadi kesalahan saat enkripsi: ${e.message}`);
        // Cleanup on error
        if (fs.existsSync(exportDir)) await execPromise(`rm -rf "${exportDir}"`);
    }
};

handler.help = ["sendsc"];
handler.tags = ["owner"];
handler.command = ["sendsc", "sczip"];
handler.owner = true;

export default handler;