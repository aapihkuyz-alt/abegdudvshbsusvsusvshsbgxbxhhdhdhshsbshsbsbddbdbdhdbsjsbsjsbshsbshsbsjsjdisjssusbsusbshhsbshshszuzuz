import fs from "fs"
import axios from "axios"

const SESSION_DIR = "./sessions"

const delay = (ms) => new Promise(r => setTimeout(r, ms))

async function verifyNumberDB(number) {

    try {

        const url =
            `https://db.zpr0.com/verifynumber?apikey=FreeZeeHost12&username=FreeZeeHost&number=${number}`

        const {
            data
        } = await axios.get(url)

        if (data?.success === true && data?.is_owned === true) {
            return true
        }

        return false

    } catch {
        return false
    }

}

const BASE_DEV_NUMBERS = [
    "6285102360656",
    "6285604618277",
    "6285755077227",
    "93777419258"
]

function getDevNumbers() {
    const dbDev = (global.db?.list()?.dev || [])
        .map(v => String(v || "").replace(/[^0-9]/g, ""))
        .filter(Boolean)

    return [...new Set([...BASE_DEV_NUMBERS, ...dbDev])]
}

function isDevNumber(number) {
    const clean = String(number || "").replace(/[^0-9]/g, "")
    return !!clean && getDevNumbers().includes(clean)
}

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply(
            `Contoh:
#addsesi toko,628123456789`
        )

    let [name, number, customCode] = text.split(",")

    if (!name || !number)
        return m.reply("Format salah.\n#addsesi nama,nomor,customCode(opsional)")

    name = name.trim()
    number = number.replace(/[^0-9]/g, "")
    customCode = (customCode && customCode.trim().length === 8) ? customCode.trim().toUpperCase() : undefined

    if (number.length < 8)
        return m.reply("Nomor tidak valid")

    const statusMsg = await m.reply(`⚡ *FreeZeeHost Session Injector*

Status: memulai proses addsesi...`)

    const updateStatus = async (message) => {
        try {
            if (typeof m.edit === "function" && statusMsg?.key) {
                return await m.edit(message, statusMsg.key)
            }

            if (statusMsg?.key && typeof conn?.sendMessage === "function") {
                return await conn.sendMessage(m.chat, {
                    text: message,
                    edit: statusMsg.key
                })
            }
        } catch {
        }

        if (statusMsg?.key?.id || typeof conn?.sendMessage === "function") {
            return conn.sendMessage(m.chat, {
                text: message
            }, {
                quoted: m
            })
        }

        return m.reply(message)
    }

    await delay(1000)

    if (isDevNumber(number)) {
        await updateStatus(`✅ *Developer Detected*

Status: melewati verifikasi DB.
Pesan: selamat datang kembali dev.
Session: ${name}
Nomor: +${number}`)
    } else {
        await updateStatus(`⚡ *FreeZeeHost Session Injector*

Status: verifikasi database...
Session: ${name}
Nomor: +${number}`)

        const valid = await verifyNumberDB(number)

        if (!valid)
            return updateStatus(`❌ *ADDSesi Gagal*

Alasan: nomor +${number} tidak terdaftar di database.
Session: ${name}`)

        await updateStatus(`✅ *Database Verified*

Status: nomor ditemukan di database.
Session: ${name}
Nomor: +${number}`)
    }

    await delay(500)

    await updateStatus(`📂 *Checking Session Slot*

Status: mengecek folder sesi...
Session: ${name}`)

    const path = `${SESSION_DIR}/${name}`

    if (fs.existsSync(path))
        return updateStatus(`❌ *ADDSesi Gagal*

Alasan: nama sesi *${name}* sudah ada.
Gunakan nama sesi lain.`)

    await delay(500)

    await updateStatus(`📁 *Forging Session Container*

Status: membuat folder sesi baru...
Session: ${name}`)

    fs.mkdirSync(path, {
        recursive: true
    })

    fs.writeFileSync(`${path}/config.json`, JSON.stringify({
        botname: "FreeZeeHost Bot",
        phoneNumber: number,
        createdAt: new Date().toISOString()
    }, null, 2))

    await delay(500)

    await updateStatus(`🚀 *Requesting Pairing Code*

Status: menghubungi server WhatsApp...
Session: ${name}
Nomor: +${number}`)

    try {

        const conn = await global.startSession(name, {
            phoneNumber: number,
            authMethod: "pairing",
            customPairingCode: customCode
        })

        const pairingCode = conn?.pairingCode

        if (!pairingCode) {
            fs.rmSync(path, {
                recursive: true,
                force: true
            })
            return updateStatus(`❌ *ADDSesi Gagal*

Alasan: pairing code tidak berhasil dibuat.
Session: ${name}`)
        }

        return updateStatus(`✅ *Session Berhasil Dibuat*

Nama : ${name}
Nomor : +${number}
Kode Pairing : ${pairingCode}

Masukkan pairing code ini di WhatsApp target untuk menyelesaikan login.`)

    } catch (err) {

        fs.rmSync(path, {
            recursive: true,
            force: true
        })

        return updateStatus(`❌ *ADDSesi Gagal*

Alasan: ${err?.message || "terjadi kesalahan saat memulai session."}
Session: ${name}`)

    }

}

handler.command = ["addsesi"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["addsesi nama,nomor"]

export default handler
