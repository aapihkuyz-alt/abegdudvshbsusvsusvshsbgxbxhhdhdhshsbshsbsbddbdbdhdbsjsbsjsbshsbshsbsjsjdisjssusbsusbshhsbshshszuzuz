import fs from "fs"

const SESSION_DIR = "./sessions"

let handler = async (m, { text }) => {
    const [name, ...rest] = (text || "").trim().split(/\s+/)
    const commandName = rest.join(" ").trim().toLowerCase()

    if (!name || !commandName) {
        return m.reply("Format salah.\n.allowcmdsesi namasesi command")
    }

    if (!fs.existsSync(`${SESSION_DIR}/${name}`)) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }
    const current = global.getSessionConfig?.(name)

    const allowedCommands = Array.from(new Set([
        ...(current.permissions?.allowedCommands || []).map(v => String(v).toLowerCase()),
        commandName
    ]))

    global.saveSessionConfig?.(name, {
        permissions: {
            ...(current.permissions || {}),
            allowedCommands
        }
    })
    global.appendSessionAudit?.(name, "allow_command", { command: commandName })

    return m.reply(`✅ Command *${commandName}* diizinkan di sesi *${name}*.`)
}

handler.command = ["allowcmdsesi"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["allowcmdsesi namasesi command"]

export default handler
