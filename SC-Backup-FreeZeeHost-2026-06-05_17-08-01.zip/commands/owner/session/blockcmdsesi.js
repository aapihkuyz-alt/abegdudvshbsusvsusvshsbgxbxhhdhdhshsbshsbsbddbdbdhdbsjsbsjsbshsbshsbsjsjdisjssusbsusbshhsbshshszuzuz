import fs from "fs"

const SESSION_DIR = "./sessions"

let handler = async (m, { text }) => {
    const [name, ...rest] = (text || "").trim().split(/\s+/)
    const commandName = rest.join(" ").trim().toLowerCase()

    if (!name || !commandName) {
        return m.reply("Format salah.\n.blockcmdsesi namasesi command")
    }

    if (!fs.existsSync(`${SESSION_DIR}/${name}`)) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }
    const current = global.getSessionConfig?.(name)

    const blockedCommands = Array.from(new Set([
        ...(current.permissions?.blockedCommands || []).map(v => String(v).toLowerCase()),
        commandName
    ]))

    global.saveSessionConfig?.(name, {
        permissions: {
            ...(current.permissions || {}),
            blockedCommands
        }
    })
    global.appendSessionAudit?.(name, "block_command", { command: commandName })

    return m.reply(`✅ Command *${commandName}* diblok di sesi *${name}*.`)
}

handler.command = ["blockcmdsesi"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["blockcmdsesi namasesi command"]

export default handler
