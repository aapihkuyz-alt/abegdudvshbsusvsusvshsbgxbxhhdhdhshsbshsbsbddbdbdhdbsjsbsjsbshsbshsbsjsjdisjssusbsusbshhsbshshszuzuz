import fs from "fs"

const SESSION_DIR = "./sessions"

let handler = async (m, { text }) => {
    const name = text?.trim()

    if (!name) {
        return m.reply("Format salah.\n#delsesi namasesi")
    }

    const path = `${SESSION_DIR}/${name}`

    if (!fs.existsSync(path)) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }

    if (global.sessionSockets?.has?.(name)) {
        await global.stopSession?.(name)
    }

    fs.rmSync(path, {
        recursive: true,
        force: true
    })

    global.sessionIntents?.delete?.(name)

    return m.reply(`✅ Sesi *${name}* berhasil dihapus.`)
}

handler.command = ["delsesi", "deletesesi", "delsession"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["delsesi namasesi"]

export default handler
