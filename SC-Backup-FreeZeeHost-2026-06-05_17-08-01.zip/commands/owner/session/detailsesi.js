import fs from "fs"

const SESSION_DIR = "./sessions"

const readSessionInfo = (name) => {
    const sessionPath = `${SESSION_DIR}/${name}`
    if (!fs.existsSync(sessionPath)) return null

    const configPath = `${sessionPath}/config.json`
    const credsPath = `${sessionPath}/creds.json`
    const stats = fs.statSync(sessionPath)

    let config = {}
    if (fs.existsSync(configPath)) {
        try {
            config = JSON.parse(fs.readFileSync(configPath, "utf8"))
        } catch {
        }
    }

    return {
        name,
        hasCreds: fs.existsSync(credsPath),
        isRunning: Boolean(global.sessionSockets?.get?.(name)),
        phoneNumber: config.phoneNumber || "-",
        botname: config.botname || "FreeZeeHost Bot",
        createdAt: config.createdAt || stats.birthtime.toISOString(),
        startedAt: config.startedAt || null,
        lastStoppedAt: config.lastStoppedAt || null,
        lastDisconnectAt: config.lastDisconnectAt || null,
        lastDisconnectCode: config.lastDisconnectCode ?? "-",
        lastPairingAt: config.lastPairingAt || null,
        restartCount: config.restartCount || 0,
        permissions: config.permissions || {
            ownerOnly: false,
            allowedCommands: [],
            blockedCommands: []
        },
        auditLog: Array.isArray(config.auditLog) ? config.auditLog : []
    }
}

let handler = async (m, { conn, text }) => {
    const name = text?.trim()

    if (!name) {
        return m.reply("Format salah.\n.detailsesi namasesi")
    }

    const session = readSessionInfo(name)

    if (!session) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }

    const quickButtons = [
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "▶️ Start",
                id: `.startsesi ${name}`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "⏹️ Stop",
                id: `.stopsesi ${name}`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🗑️ Hapus",
                id: `.delsesi ${name}`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🧾 Log",
                id: `.logsesi ${name}`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: session.permissions.ownerOnly ? "🔓 OwnerOff" : "🔒 OwnerOn",
                id: `.setsesiperm ${name},${session.permissions.ownerOnly ? "off" : "on"}`
            })
        },
        {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "🚨 Watchdog",
                id: `.watchdogsesi`
            })
        }
    ]

    const nativeFlowButton = [{
        name: "single_select",
        buttonParamsJson: JSON.stringify({
            title: "Session Control Center",
            sections: [{
                title: `Manage ${name}`,
                highlight_label: "Permission & Action",
                rows: [
                    {
                        header: "PERMISSION",
                        title: session.permissions.ownerOnly ? "🔓 OwnerOnly OFF" : "🔒 OwnerOnly ON",
                        description: "Toggle mode owner only",
                        id: `.setsesiperm ${name},${session.permissions.ownerOnly ? "off" : "on"}`
                    },
                    {
                        header: "ALLOW",
                        title: "✅ Allow command",
                        description: "Format lanjut: .allowcmdsesi namasesi command",
                        id: `.allowcmdsesi ${name} menu`
                    },
                    {
                        header: "UNALLOW",
                        title: "🧹 Hapus allow command",
                        description: "Format lanjut: .unallowcmdsesi namasesi command",
                        id: `.unallowcmdsesi ${name} menu`
                    },
                    {
                        header: "BLOCK",
                        title: "⛔ Block command",
                        description: "Format lanjut: .blockcmdsesi namasesi command",
                        id: `.blockcmdsesi ${name} menu`
                    },
                    {
                        header: "UNBLOCK",
                        title: "♻️ Unblock command",
                        description: "Format lanjut: .unblockcmdsesi namasesi command",
                        id: `.unblockcmdsesi ${name} menu`
                    },
                    {
                        header: "WATCHDOG",
                        title: "🧾 Lihat audit log",
                        description: "Buka audit log sesi ini",
                        id: `.logsesi ${name}`
                    }
                ]
            }]
        })
    }]

    const createdAt = new Date(session.createdAt)
    const formattedCreatedAt = Number.isNaN(createdAt.getTime())
        ? session.createdAt
        : createdAt.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    const formatDate = (value) => {
        if (!value) return "-"
        const date = new Date(value)
        return Number.isNaN(date.getTime())
            ? value
            : date.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
    }

    const status = session.isRunning
        ? "🟢 running"
        : session.hasCreds
            ? "🟡 idle"
            : "🔴 belum login"

    const lastAudit = session.auditLog[0]
        ? `${session.auditLog[0].action} @ ${formatDate(session.auditLog[0].at)}`
        : "-"

    return conn.sendMessage(m.chat, {
        text: `📄 *DETAIL SESI FREEZEEHOST*

Nama Sesi : ${session.name}
Status    : ${status}
Nomor     : ${session.phoneNumber}
Bot Name  : ${session.botname}
Created   : ${formattedCreatedAt}
Started   : ${formatDate(session.startedAt)}
Stopped   : ${formatDate(session.lastStoppedAt)}
Last Disc : ${formatDate(session.lastDisconnectAt)}
Disc Code : ${session.lastDisconnectCode}
Pairing   : ${formatDate(session.lastPairingAt)}
Reconnect : ${session.restartCount}

OwnerOnly : ${session.permissions.ownerOnly ? "yes" : "no"}
Allow Cmd : ${(session.permissions.allowedCommands || []).length}
Block Cmd : ${(session.permissions.blockedCommands || []).length}
Audit     : ${lastAudit}

Gunakan tombol cepat di bawah untuk mengelola sesi ini.`,
        footer: "FreeZeeHost Session Detail",
        interactive: [...quickButtons, ...nativeFlowButton]
    }, { quoted: m })
}

handler.command = ["detailsesi", "detailsession"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["detailsesi namasesi"]

export default handler
