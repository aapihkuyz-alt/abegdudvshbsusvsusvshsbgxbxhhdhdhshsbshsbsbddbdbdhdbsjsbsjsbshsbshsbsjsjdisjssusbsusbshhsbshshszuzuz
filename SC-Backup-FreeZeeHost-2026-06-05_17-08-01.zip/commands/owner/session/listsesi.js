import fs from "fs"

const SESSION_DIR = "./sessions"

const getLocalSessions = () => {
    if (!fs.existsSync(SESSION_DIR)) return []

    return fs.readdirSync(SESSION_DIR)
        .filter((name) => fs.statSync(`${SESSION_DIR}/${name}`).isDirectory())
        .map((name) => ({
            name,
            hasCreds: fs.existsSync(`${SESSION_DIR}/${name}/creds.json`),
            isRunning: Boolean(global.sessionSockets?.get?.(name))
        }))
}

let handler = async (m, { conn }) => {
    const sessions = getLocalSessions()

    if (!sessions.length) {
        const native_flow_button = [{
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
                display_text: "➕ Tambah Sesi",
                id: ".addsesi namasesi,628xxxx"
            })
        }]

        return conn.sendMessage(m.chat, {
            text: `📂 *SESSION MANAGER FREEZEEHOST*

Belum ada sesi yang tersimpan.

Tekan tombol di bawah untuk langsung membuat sesi baru.`,
            footer: "FreeZeeHost Session Manager",
            interactive: native_flow_button
        }, { quoted: m })
    }

    const sessionText = sessions.map((session, index) => {
        const status = session.isRunning
            ? "🟢 running"
            : session.hasCreds
                ? "🟡 idle"
                : "🔴 belum login"

        return `${index + 1}. ${session.name} - ${status}`
    }).join("\n")

    const native_flow_button = [{
        name: "single_select",
        buttonParamsJson: JSON.stringify({
            title: "Selection Button",
            sections: [{
                title: "Daftar Sesi FreeZeeHost",
                highlight_label: "Detail Session",
                rows: sessions.map((session) => ({
                    header: "DETAILSESI",
                    title: session.name,
                    description: session.isRunning
                        ? "Lihat detail sesi aktif"
                        : session.hasCreds
                            ? "Lihat detail sesi idle"
                            : "Lihat detail sesi belum login",
                    id: `.detailsesi ${session.name}`
                }))
            }]
        })
    }]

    return conn.sendMessage(m.chat, {
        text: `📂 *DAFTAR SESI FREEZEEHOST*

${sessionText}

Pilih salah satu sesi dari menu di bawah untuk melihat detailnya.`,
        footer: "FreeZeeHost Session Manager",
        interactive: native_flow_button
    }, { quoted: m })
}

handler.command = ["listsesi", "listsession"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["listsesi"]

export default handler
