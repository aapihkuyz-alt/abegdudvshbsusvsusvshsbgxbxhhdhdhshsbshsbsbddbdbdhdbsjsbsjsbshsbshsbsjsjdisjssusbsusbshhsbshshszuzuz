import fs from "fs"

const SESSION_DIR = "./sessions"

const readAuditLog = (name) => {
    const configPath = `${SESSION_DIR}/${name}/config.json`
    if (!fs.existsSync(configPath)) return null

    try {
        const config = JSON.parse(fs.readFileSync(configPath, "utf8"))
        return Array.isArray(config.auditLog) ? config.auditLog : []
    } catch {
        return []
    }
}

let handler = async (m, { text }) => {
    const name = text?.trim()

    if (!name) {
        return m.reply("Format salah.\n.logsesi namasesi")
    }

    const logs = readAuditLog(name)

    if (logs === null) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }

    if (!logs.length) {
        return m.reply(`📭 Belum ada audit log untuk sesi *${name}*.`)
    }

    const lines = logs.slice(0, 10).map((log, index) => {
        const time = new Date(log.at).toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })
        return `${index + 1}. ${log.action} - ${time}`
    })

    return m.reply(`🧾 *AUDIT LOG SESI ${name.toUpperCase()}*\n\n${lines.join("\n")}`)
}

handler.command = ["logsesi", "sessionslog"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["logsesi namasesi"]

export default handler
