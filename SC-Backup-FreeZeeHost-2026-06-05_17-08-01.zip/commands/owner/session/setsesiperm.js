import fs from "fs"

const SESSION_DIR = "./sessions"

let handler = async (m, { text }) => {
    const [name, mode] = (text || "").split(",").map(v => v?.trim())

    if (!name || !mode) {
        return m.reply("Format salah.\n.setsesiperm namasesi,on/off")
    }

    if (!fs.existsSync(`${SESSION_DIR}/${name}`)) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }
    const current = global.getSessionConfig?.(name)

    const ownerOnly = ["on", "true", "1"].includes(mode.toLowerCase())
    global.saveSessionConfig?.(name, {
        permissions: {
            ...(current.permissions || {}),
            ownerOnly
        }
    })
    global.appendSessionAudit?.(name, "permissions_owner_only", { value: ownerOnly })

    return m.reply(`✅ OwnerOnly sesi *${name}* diubah menjadi *${ownerOnly ? "ON" : "OFF"}*.`)
}

handler.command = ["setsesiperm"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["setsesiperm namasesi,on/off"]

export default handler
