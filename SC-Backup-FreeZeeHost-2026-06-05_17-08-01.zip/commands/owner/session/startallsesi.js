let handler = async (m) => {
    const results = await global.startAllSessions?.()

    if (!results?.length) {
        return m.reply("❌ Tidak ada sesi yang tersimpan.")
    }

    const lines = results.map((item) => {
        if (item.status === "started") return `✅ ${item.name} - started`
        if (item.status === "running") return `⚠️ ${item.name} - sudah berjalan`
        if (item.status === "no_creds") return `❌ ${item.name} - belum login`
        return `• ${item.name} - ${item.status}`
    })

    return m.reply(`🚀 *START ALL SESI*\n\n${lines.join("\n")}`)
}

handler.command = ["startallsesi", "startallsession"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["startallsesi"]

export default handler
