import fs from "fs"

const SESSION_DIR = "./sessions"

let handler = async (m, { text }) => {
    const name = text?.trim()

    if (!name) {
        return m.reply("Format salah.\n#startsesi namasesi")
    }

    const path = `${SESSION_DIR}/${name}`
    if (!fs.existsSync(path)) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }

    const credsPath = `${path}/creds.json`
    if (!fs.existsSync(credsPath)) {
        return m.reply(`❌ Sesi *${name}* belum login.\nGunakan #addsesi ${name},628xxxx untuk pairing baru.`)
    }

    const info = global.listSessions?.().find(v => v.name === name)
    if (info?.isRunning) {
        return m.reply(`⚠️ Sesi *${name}* sudah berjalan.`)
    }

    await global.startSession(name, null, { allowAuthPrompt: false })
    return m.reply(`✅ Sesi *${name}* sedang dijalankan.`)
}

handler.command = ["startsesi", "startsession"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["startsesi namasesi"]

export default handler
