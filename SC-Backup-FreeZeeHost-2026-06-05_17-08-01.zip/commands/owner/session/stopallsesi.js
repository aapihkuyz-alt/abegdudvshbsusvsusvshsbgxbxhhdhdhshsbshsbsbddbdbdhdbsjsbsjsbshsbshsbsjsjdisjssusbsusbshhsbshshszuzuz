let handler = async (m) => {
    const sessions = global.listSessions?.() || []
    const running = sessions.filter(v => v.isRunning)

    if (!running.length) {
        return m.reply("❌ Tidak ada sesi yang sedang berjalan.")
    }

    for (const session of running) {
        await global.stopSession?.(session.name)
    }

    return m.reply(`✅ Berhasil menghentikan ${running.length} sesi.`)
}

handler.command = ["stopallsesi", "stopallsession"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["stopallsesi"]

export default handler
