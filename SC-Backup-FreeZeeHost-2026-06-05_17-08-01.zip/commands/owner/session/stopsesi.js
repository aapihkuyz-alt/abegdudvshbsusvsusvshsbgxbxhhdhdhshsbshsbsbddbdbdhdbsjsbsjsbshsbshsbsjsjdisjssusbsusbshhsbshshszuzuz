let handler = async (m, { text }) => {
    const name = text?.trim()

    if (!name) {
        return m.reply("Format salah.\n#stopsesi namasesi")
    }

    const stopped = await global.stopSession?.(name)

    if (!stopped) {
        return m.reply(`❌ Sesi *${name}* tidak sedang berjalan.`)
    }

    return m.reply(`✅ Sesi *${name}* berhasil dihentikan.`)
}

handler.command = ["stopsesi", "stopsession"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["stopsesi namasesi"]

export default handler
