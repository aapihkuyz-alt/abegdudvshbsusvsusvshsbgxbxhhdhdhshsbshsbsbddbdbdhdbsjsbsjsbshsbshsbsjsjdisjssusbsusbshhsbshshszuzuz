import fs from "fs"

const SESSION_DIR = "./sessions"

let handler = async (m, { text }) => {
    const [name, ...rest] = (text || "").trim().split(/\s+/)
    const commandName = rest.join(" ").trim().toLowerCase()

    if (!name || !commandName) {
        return m.reply("Format salah.\n.unallowcmdsesi namasesi command")
    }

    if (!fs.existsSync(`${SESSION_DIR}/${name}`)) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }

    const current = global.getSessionConfig?.(name)
    const allowedCommands = (current.permissions?.allowedCommands || [])
        .map(v => String(v).toLowerCase())
        .filter(v => v !== commandName)

    global.saveSessionConfig?.(name, {
        permissions: {
            ...(current.permissions || {}),
            allowedCommands
        }
    })
    global.appendSessionAudit?.(name, "unallow_command", { command: commandName })

    return m.reply(`✅ Command *${commandName}* dihapus dari allow list sesi *${name}*.`)
}

handler.command = ["unallowcmdsesi"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["unallowcmdsesi namasesi command"]

export default handler
