import fs from "fs"

const SESSION_DIR = "./sessions"

let handler = async (m, { text }) => {
    const [name, ...rest] = (text || "").trim().split(/\s+/)
    const commandName = rest.join(" ").trim().toLowerCase()

    if (!name || !commandName) {
        return m.reply("Format salah.\n.unblockcmdsesi namasesi command")
    }

    if (!fs.existsSync(`${SESSION_DIR}/${name}`)) {
        return m.reply(`❌ Sesi *${name}* tidak ditemukan.`)
    }

    const current = global.getSessionConfig?.(name)
    const blockedCommands = (current.permissions?.blockedCommands || [])
        .map(v => String(v).toLowerCase())
        .filter(v => v !== commandName)

    global.saveSessionConfig?.(name, {
        permissions: {
            ...(current.permissions || {}),
            blockedCommands
        }
    })
    global.appendSessionAudit?.(name, "unblock_command", { command: commandName })

    return m.reply(`✅ Command *${commandName}* dihapus dari block list sesi *${name}*.`)
}

handler.command = ["unblockcmdsesi"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["unblockcmdsesi namasesi command"]

export default handler
