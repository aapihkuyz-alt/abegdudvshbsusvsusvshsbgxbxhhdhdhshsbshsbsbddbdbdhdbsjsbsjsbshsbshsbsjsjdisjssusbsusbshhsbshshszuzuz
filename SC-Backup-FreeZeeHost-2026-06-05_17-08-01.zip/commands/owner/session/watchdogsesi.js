import fs from "fs"

const SESSION_DIR = "./sessions"
const RUNTIME_LOG_PATH = "./data/sampah/logs/session-runtime.log"

const getSessions = () => {
    if (!fs.existsSync(SESSION_DIR)) return []
    return fs.readdirSync(SESSION_DIR).filter((name) => fs.statSync(`${SESSION_DIR}/${name}`).isDirectory())
}

const parseRuntimeSummary = () => {
    if (!fs.existsSync(RUNTIME_LOG_PATH)) return {}

    const lines = fs.readFileSync(RUNTIME_LOG_PATH, "utf8")
        .split("\n")
        .filter(Boolean)
        .slice(-400)

    const summary = {}

    for (const line of lines) {
        const match = line.match(/^\[[^\]]+\] \[([^\]]+)\] (.+)$/)
        if (!match) continue

        const [, sessionName, message] = match
        if (!summary[sessionName]) {
            summary[sessionName] = {
                reconnects: 0,
                closes: 0,
                lastEvent: "-"
            }
        }

        if (message.includes("reconnect scheduled")) {
            summary[sessionName].reconnects += 1
        }

        if (message.includes("connection state: close")) {
            summary[sessionName].closes += 1
        }

        summary[sessionName].lastEvent = message
    }

    return summary
}

let handler = async (m, { conn }) => {
    const sessions = getSessions()

    if (!sessions.length) {
        return m.reply("❌ Tidak ada sesi yang tersimpan.")
    }

    const runtimeSummary = parseRuntimeSummary()

    const reports = sessions.map((name) => {
        const config = global.getSessionConfig?.(name)
        const lastDisconnect = config?.lastDisconnectAt
        const restartCount = config?.restartCount || 0
        const runtime = runtimeSummary[name] || {
            reconnects: 0,
            closes: 0,
            lastEvent: "-"
        }
        const isProblem =
            Boolean(lastDisconnect) ||
            restartCount >= 3 ||
            runtime.reconnects >= 2 ||
            runtime.closes >= 2

        return {
            name,
            restartCount,
            lastDisconnect: lastDisconnect || "-",
            lastDisconnectCode: config?.lastDisconnectCode ?? "-",
            reconnects: runtime.reconnects,
            closes: runtime.closes,
            lastEvent: runtime.lastEvent,
            isProblem
        }
    }).sort((a, b) => {
        const scoreA = (a.restartCount * 2) + a.reconnects + a.closes
        const scoreB = (b.restartCount * 2) + b.reconnects + b.closes
        return scoreB - scoreA
    })

    const problems = reports.filter(v => v.isProblem)

    if (!problems.length) {
        return m.reply("✅ Semua sesi terlihat aman. Tidak ada alert watchdog.")
    }

    const lines = problems.slice(0, 10).map((item, index) => {
        return `${index + 1}. ${item.name}\n` +
            `   Restart: ${item.restartCount}\n` +
            `   Reconnect: ${item.reconnects}\n` +
            `   CloseEvt: ${item.closes}\n` +
            `   LastDisc: ${item.lastDisconnect}\n` +
            `   Code: ${item.lastDisconnectCode}\n` +
            `   LastEvt: ${item.lastEvent}`
    })

    const buttons = problems.slice(0, 5).map((item) => ({
        name: "quick_reply",
        buttonParamsJson: JSON.stringify({
            display_text: item.name,
            id: `.detailsesi ${item.name}`
        })
    }))

    return conn.sendMessage(m.chat, {
        text: `⚠️ *WATCHDOG SESSION REPORT*\n\n${lines.join("\n\n")}`,
        footer: "Tap sesi bermasalah untuk buka detail",
        interactive: buttons
    }, { quoted: m })
}

handler.command = ["watchdogsesi", "sessionwatchdog"]
handler.tags = ["owner"]
handler.owner = true
handler.help = ["watchdogsesi"]

export default handler
