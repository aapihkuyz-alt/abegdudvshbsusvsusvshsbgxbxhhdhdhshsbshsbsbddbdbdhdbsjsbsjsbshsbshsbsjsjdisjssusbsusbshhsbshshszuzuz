import fs from 'fs';
import {
    proto,
    generateWAMessageFromContent
} from 'baileys';

const dbPath = './database/stickercmd.json';

// Inisialisasi Database
if (!fs.existsSync('./database')) fs.mkdirSync('./database');
if (!fs.existsSync(dbPath)) fs.writeFileSync(dbPath, JSON.stringify({}));

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    if (!isOwner) return m.reply("❌ Khusus Owner, Bang!");

    let db = JSON.parse(fs.readFileSync(dbPath));
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';

    // ==========================================
    // 1. FITUR SET (STIKER / EMOJI)
    // ==========================================
    if (command === 'setcmd') {
        let key, cmdValue;

        if (m.quoted && /webp/.test(mime)) {
            if (!text) return m.reply(`Balas stiker lalu ketik: ${usedPrefix + command} .menu`);
            let hash = (q.msg || q).fileSha256;
            key = Buffer.from(hash).toString('base64');
            cmdValue = text.trim();
        } else if (text.includes('|')) {
            let [targetCmd, inputKey] = text.split('|').map(v => v.trim());
            key = inputKey;
            cmdValue = targetCmd;
        } else {
            return m.reply(`*Format:* \n1. Stiker: Reply stiker + ${usedPrefix + command} .menu\n2. Emoji: ${usedPrefix + command} .menu | 🗿`);
        }

        db[key] = cmdValue;
        fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
        m.reply(`✅ *BERHASIL!* Berhasil menyimpan command.`);
    }

    // ==========================================
    // 2. FITUR DELETE DENGAN SELECT BUTTON
    // ==========================================
    if (command === 'delcmd') {
        let keys = Object.keys(db);
        if (keys.length === 0) return m.reply("❌ Database masih kosong.");

        // Jika Abang reply stiker langsung buat hapus
        if (m.quoted && /webp/.test(mime)) {
            let hash = (q.msg || q).fileSha256;
            let hashKey = Buffer.from(hash).toString('base64');
            if (db[hashKey]) {
                delete db[hashKey];
                fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
                return m.reply("✅ Stiker command berhasil dihapus!");
            }
        }

        // Bikin list pilihan untuk Button
        let sections = [{
            title: "Daftar Command Tersedia",
            rows: keys.map((k, i) => ({
                title: k.length > 20 ? `[Stiker] ${db[k]}` : `${k} (${db[k]})`,
                description: `Klik untuk menghapus command ini`,
                id: `${usedPrefix}confirmdel ${k}` // Mengarah ke case confirmdel
            }))
        }];

        let listMessage = {
            title: "🗑️ DELETE COMMAND SELECTOR",
            sections
        };

        // Kirim Button List (Native Flow)
        const msg = await generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        body: {
                            text: "Silakan pilih command yang ingin dihapus dari daftar di bawah ini:"
                        },
                        footer: {
                            text: global.footer
                        },
                        header: {
                            hasVideoMessage: false
                        },
                        nativeFlowMessage: {
                            buttons: [{
                                name: "single_select",
                                buttonParamsJson: JSON.stringify(listMessage)
                            }]
                        }
                    })
                }
            }
        }, {
            quoted: m
        });

        await conn.relayMessage(m.chat, msg.message, {
            messageId: msg.key.id
        });
    }

    // ==========================================
    // 3. INTERNAL HANDLER: EKSEKUSI HAPUS (Hidden)
    // ==========================================
    if (command === 'confirmdel') {
        if (!text) return;
        if (db[text]) {
            let info = db[text];
            delete db[text];
            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
            m.reply(`✅ Berhasil menghapus command: *${info}*`);
        } else {
            m.reply("❌ Data sudah tidak ada.");
        }
    }
};

handler.command = ['setcmd', 'delcmd', 'confirmdel'];
handler.tags = ['owner'];
handler.owner = true;

export default handler;