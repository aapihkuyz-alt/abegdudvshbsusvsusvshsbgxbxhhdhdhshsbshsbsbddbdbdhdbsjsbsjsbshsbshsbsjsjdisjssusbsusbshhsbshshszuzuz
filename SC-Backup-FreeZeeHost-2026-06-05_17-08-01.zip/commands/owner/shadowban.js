let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} 628xxx*`);
    
    let jid = text.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
    let user = global.db.get("user", jid);
    
    if (!user) return m.reply("❌ User tidak ditemukan di database.");

    if (command === "shadowban") {
        user.shadowBan = true;
        m.reply(`🛡️ *[ SHADOW BAN ]* User *@${jid.split("@")[0]}* berhasil dimasukkan ke daftar bayangan.\n\n_User tetap bisa kirim perintah, tapi akan selalu dibalas dengan pesan error palsu._`, null, { mentions: [jid] });
    } else {
        user.shadowBan = false;
        m.reply(`🔓 *[ UN-SHADOW BAN ]* User *@${jid.split("@")[0]}* telah dihapus dari daftar bayangan.`, null, { mentions: [jid] });
    }
    
    await global.db.save();
};

handler.help = ["shadowban", "unshadowban"];
handler.tags = ["owner"];
handler.command = /^(shadowban|unshadowban)$/i;
handler.owner = true;

export default handler;