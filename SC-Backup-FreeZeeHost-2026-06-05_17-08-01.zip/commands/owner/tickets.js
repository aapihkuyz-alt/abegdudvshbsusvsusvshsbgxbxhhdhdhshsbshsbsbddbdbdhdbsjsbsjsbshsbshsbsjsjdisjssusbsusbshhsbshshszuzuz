import crypto from "crypto";

let handler = async (m, { conn, text, usedPrefix, command, db, isOwner }) => {
    const data = db.list();
    if (!data.tickets) data.tickets = [];

    switch (command) {
        case 'genticket':
        case 'generatecode': {
            if (!isOwner) return m.reply("❌ Khusus Owner, Bang.");
            let [days, count] = text.split("|").map(v => v.trim());
            if (!days || !count) return m.reply(`📌 Contoh: *${usedPrefix + command} 30 | 5* \n(Generate 5 tiket durasi 30 hari)`);

            let newTickets = [];
            for (let i = 0; i < parseInt(count); i++) {
                const code = `FZH-${crypto.randomBytes(3).toString('hex').toUpperCase()}-${days}D`;
                data.tickets.push({
                    code,
                    duration: parseInt(days) * 24 * 60 * 60 * 1000, // ms
                    status: "active"
                });
                newTickets.push(code);
            }
            
            await db.save();
            await m.reply(`✅ *Generated ${count} Tickets:*\n\n\`\`\`${newTickets.join("\n")}\`\`\``);
            break;
        }

        case 'redeem': {
            if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} FZH-XXXX-30D*`);
            
            const ticketIndex = data.tickets.findIndex(t => t.code === text.trim() && t.status === "active");
            
            if (ticketIndex === -1) return m.reply("❌ Kode tiket tidak valid atau sudah digunakan.");

            const ticket = data.tickets[ticketIndex];
            const user = db.get("user", m.sender);

            if (!user.premium) user.premium = { status: false, expired: 0 };
            
            const now = Date.now();
            const currentExpired = user.premium.expired > now ? user.premium.expired : now;
            
            user.premium.status = true;
            user.premium.expired = currentExpired + ticket.duration;
            
            // Tandai tiket sudah dipakai
            ticket.status = "used";
            ticket.usedBy = m.sender;
            ticket.usedAt = now;

            await db.save();

            const dateStr = new Date(user.premium.expired).toLocaleString();
            await m.reply(`🎉 *REDEEM BERHASIL!* 🎉\n\nSelamat! Akun kamu sekarang menjadi *Premium*.\n📅 *Expired:* ${dateStr}\n\nTerima kasih telah berlangganan!`);
            break;
        }
    }
};

handler.help = ["genticket", "redeem"];
handler.tags = ["owner", "main"];
handler.command = /^(genticket|generatecode|redeem)$/i;

export default handler;