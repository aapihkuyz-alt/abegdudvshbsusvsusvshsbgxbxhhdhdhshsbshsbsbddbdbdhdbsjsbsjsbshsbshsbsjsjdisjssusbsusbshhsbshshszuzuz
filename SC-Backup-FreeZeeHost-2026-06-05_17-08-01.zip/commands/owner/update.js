import { exec } from "child_process";
import { promisify } from "util";
import chalk from "chalk";

const execPromise = promisify(exec);

let handler = async (m, { conn, isOwner }) => {
    if (!isOwner) return;

    await m.reply("🛰️ *[ UPDATE ]* Memulai proses pembaruan dari GitHub...");
    
    try {
        // 1. Git Pull
        const { stdout, stderr } = await execPromise("git pull");
        
        if (stdout.includes("Already up to date.")) {
            return await m.reply("✅ *[ UPDATE ]* Bot sudah dalam versi terbaru.");
        }

        let report = `📂 *[ GIT PULL ]*\n\`\`\`${stdout}\`\`\``;
        if (stderr) report += `\n\n⚠️ *[ STDERR ]*\n\`\`\`${stderr}\`\`\``;
        
        await m.reply(report);

        // 2. Install Dependencies if package.json changed
        if (stdout.includes("package.json")) {
            await m.reply("📦 *[ NPM ]* Perubahan package.json terdeteksi. Mengupdate dependencies...");
            await execPromise("npm install");
        }

        // 3. Restart via PM2
        await m.reply("🔄 *[ RESTART ]* Melakukan restart via PM2 untuk menerapkan perubahan...");
        
        // Wait a bit to ensure messages are sent
        setTimeout(async () => {
            try {
                await execPromise("pm2 restart all");
            } catch (e) {
                console.error("PM2 Restart failed:", e.message);
                process.exit(0); // Fallback to process exit if PM2 fails
            }
        }, 2000);

    } catch (e) {
        console.error(chalk.red("[UPDATE ERROR]"), e.message);
        await m.reply(`❌ *[ UPDATE FAILED ]*\nError: ${e.message}`);
    }
};

handler.help = ["update"];
handler.tags = ["owner"];
handler.command = ["update", "upgrade"];
handler.owner = true;

export default handler;