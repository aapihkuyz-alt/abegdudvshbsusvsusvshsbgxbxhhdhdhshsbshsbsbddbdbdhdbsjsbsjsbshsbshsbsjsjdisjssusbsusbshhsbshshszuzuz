import fs from 'fs';
import {
    pathToFileURL
} from 'url';
import {
    downloadMediaMessage
} from 'baileys'; // <--- MESIN DOWNLOAD MURNI ANTI-GAGAL

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    if (!isOwner) return m.reply("❌ Akses ditolak. Khusus Owner/Root!");

    const pathFile = './handler.js';
    const backupPath = './handler.js.bak';
    const tempPath = './handler_temp.js'; // Ruang uji coba kodingan

    const usage = `⚙️ *UPDATE HANDLER SYSTEM (AUTO-RESTORE)* ⚙️
_Aman 100%! Jika kodingan error, bot akan membatalkan update otomatis._

*1. FITUR TEKS (Ubah/Hapus Baris Kode):*
◦ ${usedPrefix + command} --replace | kode_lama | kode_baru
◦ ${usedPrefix + command} --delete | kode_yang_dihapus

*2. FITUR FILE (Upload File):*
◦ ${usedPrefix + command} --get (Untuk mendownload handler saat ini)
◦ _Reply/Balas file .js dengan:_ ${usedPrefix + command}

*3. MANUAL RESTORE:*
◦ ${usedPrefix + command} --restore (Kembalikan ke backup manual)`;

    // =====================================
    // FUNGSI UJI COBA KODINGAN (ANTI-CRASH)
    // =====================================
    const testCodeSafe = async (contentBuffer) => {
        try {
            fs.writeFileSync(tempPath, contentBuffer);
            const testModule = await import(`${pathToFileURL(tempPath).href}?update=${Date.now()}`);
            if (typeof testModule.default !== 'function') throw new Error("File tidak memiliki 'export default' yang valid.");
            fs.unlinkSync(tempPath);
            return {
                success: true
            };
        } catch (e) {
            if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
            return {
                success: false,
                error: e
            };
        }
    };

    // =====================================
    // MODE 1: UPLOAD/REPLACE PAKAI FILE .JS
    // =====================================
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || q.mediaType || '';

    if (/application\/javascript|text\/javascript/.test(mime) || (q.fileName && q.fileName.endsWith('.js'))) {
        await m.react("⏳");
        try {
            // DOWNLOAD MURNI DARI BAILEYS
            const media = await downloadMediaMessage(
                q,
                'buffer', {}, {
                    reuploadRequest: conn.updateMediaMessage
                }
            );

            if (!media) throw new Error("Buffer media kosong.");

            // 🛑 UJI COBA KODINGAN DULU SEBELUM DITIMPA!
            const test = await testCodeSafe(media);

            if (!test.success) {
                await m.react("❌");
                return m.reply(`⚠️ *AUTO-RESTORE AKTIF! UPDATE DIBATALKAN!* ⚠️\n\nBot mendeteksi adanya *Syntax Error* pada kodingan yang Abang kirim. File utama aman dan tidak jadi ditimpa.\n\n*Detail Error:*\n\`\`\`${test.error.message}\`\`\``);
            }

            // Kalau lolos, baru kita backup dan timpa
            if (fs.existsSync(pathFile)) fs.copyFileSync(pathFile, backupPath);
            fs.writeFileSync(pathFile, media);

            await m.react("✅");
            return m.reply("✅ *FILE HANDLER BERHASIL DIUPDATE!*\n\n_Kodingan lolos uji sintaks. Sistem hot-reload sedang memuat ulang handler.js..._");
        } catch (e) {
            return m.reply(`❌ Gagal mengunggah file: ${e.message}\n\n*⚠️ TIPS PENTING:*\nJika error "bad decrypt" masih muncul, coba kirim ulang file *handler.js* nya langsung dari *HP (WhatsApp Mobile)*, JANGAN dikirim lewat WhatsApp Web/PC!`);
        }
    }

    if (!text) return m.reply(usage);

    // =====================================
    // MODE 2: DOWNLOAD FILE HANDLER SAAT INI
    // =====================================
    if (text.trim() === '--get') {
        if (!fs.existsSync(pathFile)) return m.reply("❌ File handler.js tidak ditemukan!");
        await m.react("⏳");
        return conn.sendMessage(m.chat, {
            document: fs.readFileSync(pathFile),
            fileName: 'handler.js',
            mimetype: 'application/javascript'
        }, {
            quoted: m
        });
    }

    // =====================================
    // MODE 3: RESTORE MANUAL KEMBALIKAN BACKUP
    // =====================================
    if (text.trim() === '--restore') {
        if (!fs.existsSync(backupPath)) return m.reply("❌ Tidak ada file backup (handler.js.bak) yang ditemukan!");
        try {
            fs.copyFileSync(backupPath, pathFile);
            return m.reply("✅ *SISTEM BERHASIL DI-RESTORE!*\n\nKodingan handler.js telah dikembalikan ke versi aman sebelumnya.");
        } catch (e) {
            return m.reply(`❌ Gagal restore: ${e.message}`);
        }
    }

    // =====================================
    // MODE 4: REPLACE & DELETE KODE (TEKS)
    // =====================================
    let [action, param1, param2] = text.split('|').map(v => v ? v.trim() : '');

    if (action === '--replace' || action === '--delete') {
        if (!fs.existsSync(pathFile)) return m.reply("❌ File handler.js tidak ditemukan!");

        let content = fs.readFileSync(pathFile, 'utf8');

        if (action === '--replace') {
            if (!param1 || !param2) return m.reply(`❌ Format salah!\nContoh: ${usedPrefix + command} --replace | kode_lama | kode_baru`);
            if (!content.includes(param1)) return m.reply("❌ Kode lama tidak ditemukan di dalam handler.js. Pastikan besar kecil huruf dan spasinya sama persis!");

            // Bikin konten simulasi
            let newContent = content.replace(param1, param2);

            // 🛑 UJI COBA KODINGAN!
            const test = await testCodeSafe(Buffer.from(newContent, 'utf-8'));
            if (!test.success) {
                return m.reply(`⚠️ *AUTO-RESTORE AKTIF! UPDATE DIBATALKAN!* ⚠️\n\nEditan teks Abang menyebabkan *Error*. File utama batal diubah.\n\n*Penyebab Error:*\n\`\`\`${test.error.message}\`\`\``);
            }

            // Lolos Uji
            fs.copyFileSync(pathFile, backupPath); // Backup yg lama
            fs.writeFileSync(pathFile, newContent); // Timpa yg baru
            m.reply(`✅ *KODE BERHASIL DIGANTI DAN LOLOS UJI!*`);
        } else if (action === '--delete') {
            if (!param1) return m.reply(`❌ Format salah!\nContoh: ${usedPrefix + command} --delete | kode_hapus`);
            if (!content.includes(param1)) return m.reply("❌ Kode tersebut tidak ditemukan di dalam handler.js!");

            // Bikin konten simulasi
            let newContent = content.replace(param1, '');

            // 🛑 UJI COBA KODINGAN!
            const test = await testCodeSafe(Buffer.from(newContent, 'utf-8'));
            if (!test.success) {
                return m.reply(`⚠️ *AUTO-RESTORE AKTIF! UPDATE DIBATALKAN!* ⚠️\n\nMenghapus kode ini menyebabkan *Error*. File utama batal diubah.\n\n*Penyebab Error:*\n\`\`\`${test.error.message}\`\`\``);
            }

            // Lolos Uji
            fs.copyFileSync(pathFile, backupPath); // Backup
            fs.writeFileSync(pathFile, newContent); // Timpa
            m.reply(`✅ *KODE BERHASIL DIHAPUS DAN LOLOS UJI!*`);
        }
    } else {
        m.reply("❌ Parameter tidak dikenali. Ketik *.updatehandler* tanpa teks untuk melihat menu.");
    }
};

handler.command = ['updatehandler', 'uphandler', 'uph'];
handler.tags = ['owner'];
handler.owner = true;

export default handler;