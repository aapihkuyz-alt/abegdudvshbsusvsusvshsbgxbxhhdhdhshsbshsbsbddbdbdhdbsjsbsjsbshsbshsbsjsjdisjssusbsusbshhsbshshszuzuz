import fs from 'fs';
import {
    pathToFileURL
} from 'url';

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner
}) => {
    if (!isOwner) return m.reply("❌ Akses ditolak. Khusus Owner!");

    const pathFile = './settings.js';
    const backupPath = './settings.js.bak';
    const tempPath = './settings_temp.js';

    const usage = `⚙️ *UPDATE SETTINGS SYSTEM* ⚙️
_Ganti settingan bot langsung dari WA._

*Format:*
${usedPrefix + command} | variabel | nilai_baru

*Contoh:*
◦ Ganti Nama Bot:
  ${usedPrefix + command} | botname | FreeZeeHost V2
◦ Ganti Footer:
  ${usedPrefix + command} | footer | Bot By Andre
◦ Ganti Link Channel:
  ${usedPrefix + command} | linkch | https://whatsapp.com/xxx

*Lainnya:*
◦ ${usedPrefix + command} --get (Download file settings.js)
◦ ${usedPrefix + command} --restore (Balikin ke backup)`;

    // =====================================
    // 1. MODE DOWNLOAD & RESTORE
    // =====================================
    if (text.trim() === '--get') {
        await m.react("⏳");
        return conn.sendMessage(m.chat, {
            document: fs.readFileSync(pathFile),
            fileName: 'settings.js',
            mimetype: 'application/javascript'
        }, {
            quoted: m
        });
    }

    if (text.trim() === '--restore') {
        if (!fs.existsSync(backupPath)) return m.reply("❌ Tidak ada file backup!");
        fs.copyFileSync(backupPath, pathFile);
        return m.reply("✅ Settings berhasil di-restore ke versi sebelumnya!");
    }

    // =====================================
    // 2. MODE REPLACE VARIABEL
    // =====================================
    let [key, ...valueArray] = text.split('|').map(v => v.trim());
    let value = valueArray.join('|'); // Biar link yang ada '|' tetap aman

    if (!key || !value) return m.reply(usage);

    await m.react("⏳");

    try {
        let content = fs.readFileSync(pathFile, 'utf8');

        // Regex canggih: Cari global.key = "apapun" atau global.key = 'apapun'
        // Mendukung kutip satu, kutip dua, dan backtick
        const regex = new RegExp(`(global\\.${key}\\s*=\\s*['"\`]).*?(['"\`])`, 'g');

        if (!regex.test(content)) {
            return m.reply(`❌ Variabel *global.${key}* tidak ditemukan di settings.js!\nPastikan penulisan variabel sama persis.`);
        }

        // Jalankan perubahan
        let newContent = content.replace(regex, `$1${value}$2`);

        // --- VALIDASI SYNTAX (ANTI MATI) ---
        fs.writeFileSync(tempPath, newContent);
        try {
            await import(`${pathToFileURL(tempPath).href}?update=${Date.now()}`);
            fs.unlinkSync(tempPath);
        } catch (e) {
            if (fs.existsSync(tempPath)) fs.unlinkSync(tempPath);
            return m.reply(`⚠️ *UPDATE BATAL!* Nilai baru menyebabkan error.\n\n*Detail:* \`\`\`${e.message}\`\`\``);
        }

        // Jika lolos uji coba
        fs.copyFileSync(pathFile, backupPath); // Backup
        fs.writeFileSync(pathFile, newContent); // Simpan permanen

        await m.react("✅");
        m.reply(`✅ *BERHASIL DIUPDATE!*\n\n*Variabel:* global.${key}\n*Nilai Baru:* ${value}\n\n_Bot akan memuat ulang settingan otomatis._`);

    } catch (e) {
        m.reply(`❌ Gagal: ${e.message}`);
    }
};

handler.command = ['updatesettings', 'upset', 'setglobal', 'ups'];
handler.tags = ['owner'];
handler.owner = true;

export default handler;