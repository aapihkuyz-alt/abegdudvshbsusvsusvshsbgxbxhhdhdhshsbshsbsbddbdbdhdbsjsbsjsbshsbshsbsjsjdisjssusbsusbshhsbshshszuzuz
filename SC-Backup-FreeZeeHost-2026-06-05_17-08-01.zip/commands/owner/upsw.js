import fs from "fs";
import path from "path";
import os from "os";
import util from "util";
import axios from "axios";
import ffmpeg from "fluent-ffmpeg";
import ffprobeStatic from "ffprobe-static";

ffmpeg.setFfprobePath(ffprobeStatic.path);
const ffprobe = util.promisify(ffmpeg.ffprobe);

/* ================= DOWNLOADER HELPER ================= */
async function aio(url) {
    try {
        const { data } = await axios.get("https://api.neoxr.eu/api/aio", {
            params: { url, apikey: global.neoxr }
        });
        return data.status ? data.data : null;
    } catch { return null; }
}

let handler = async (m, { conn, text, store, usedPrefix, command }) => {
    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || "";
    let mediaBuffer;
    let finalMime = mime;
    let caption = text || "";

    await m.react("⏳");

    try {
        // --- 1. DETEKSI LINK (AIO DOWNLOADER) ---
        const urlMatch = text.match(/https?:\/\/[^\s]+/);
        if (urlMatch && !mime) {
            const link = urlMatch[0];
            m.reply(`🚀 *Detecting Link:* ${link}\n_Downloading media for status..._`);
            
            const dl = await aio(link);
            if (dl && dl.length > 0) {
                const target = dl.find(v => v.type === "mp4") || dl[0];
                const res = await axios.get(target.url, { responseType: 'arraybuffer' });
                mediaBuffer = Buffer.from(res.data);
                finalMime = target.type === "mp3" ? "audio/mpeg" : "video/mp4";
            } else {
                throw new Error("Gagal mendownload media dari link tersebut.");
            }
        } 
        
        // --- 2. DETEKSI CLONE (REPLY STATUS) ---
        else if (m.quoted && m.quoted.remoteJid === "status@broadcast") {
            mediaBuffer = await q.download();
            caption = caption || q.text || "";
        }

        // --- 3. DETEKSI DIRECT MEDIA ---
        else if (/image|video|audio/.test(mime)) {
            mediaBuffer = await q.download();
        }

        // --- 4. TEXT STATUS (IF NO MEDIA) ---
        else if (text) {
            const contacts = Object.values(store.contacts).map(v => v.id).filter(v => v && v.endsWith("@s.whatsapp.net"));
            await conn.sendMessage("status@broadcast", {
                text: text
            }, { statusJidList: contacts });
            
            await m.react("✅");
            return m.reply("✅ *Status Teks Berhasil Diunggah!*");
        }

        else {
            return m.reply(`⚠️ *Cara Pakai:*\n1. Reply media lalu ketik *${usedPrefix + command}*\n2. Ketik *${usedPrefix + command} <link>* (TikTok/YT/IG)\n3. Reply status orang lain untuk clone.\n4. Ketik *${usedPrefix + command} <teks>* untuk status tulisan.`);
        }

        if (!mediaBuffer) throw new Error("Media tidak ditemukan.");

        // Simpan sementara untuk cek durasi
        const ext = finalMime.split("/")[1].split(";")[0] || "bin";
        const tmpPath = path.join(os.tmpdir(), `upsw-${Date.now()}.${ext}`);
        fs.writeFileSync(tmpPath, mediaBuffer);

        let options = {};
        
        // --- 4. DURATION CHECK (MAX 5 MENIT) ---
        if (/video|audio/.test(finalMime)) {
            try {
                const meta = await ffprobe(tmpPath);
                const duration = meta.format.duration;
                if (duration > 300) throw new Error("Durasi media terlalu panjang. Maksimal 5 menit.");
            } catch (e) {
                console.log("Ffprobe error (ignored for non-standard files):", e.message);
            }
        }

        // --- 5. FETCH CONTACTS ---
        const contacts = Object.values(store.contacts).map(v => v.id).filter(v => v && v.endsWith("@s.whatsapp.net"));
        options.statusJidList = contacts;

        // --- 6. UPLOAD ---
        if (/image/.test(finalMime)) {
            await conn.sendMessage("status@broadcast", { image: mediaBuffer, caption }, options);
        } else if (/video/.test(finalMime)) {
            await conn.sendMessage("status@broadcast", { video: mediaBuffer, caption }, options);
        } else if (/audio/.test(finalMime)) {
            await conn.sendMessage("status@broadcast", { 
                audio: mediaBuffer, 
                mimetype: "audio/mp4", 
                ptt: true 
            }, options);
        }

        await m.react("✅");
        m.reply(`✅ *Status Berhasil Diunggah!* (${finalMime.split("/")[0]})`);

        if (fs.existsSync(tmpPath)) fs.unlinkSync(tmpPath);

    } catch (e) {
        console.error("UPSW ERROR:", e);
        m.reply(`❌ *[ ERROR ]* Gagal upload status.\nReason: ${e.message}`);
        await m.react("❌");
    }
};

handler.help = ["upsw <caption/link>"];
handler.tags = ["owner"];
handler.command = /^(upsw|uploadsw|sw|clonesw)$/i;
handler.owner = true;

export default handler;
