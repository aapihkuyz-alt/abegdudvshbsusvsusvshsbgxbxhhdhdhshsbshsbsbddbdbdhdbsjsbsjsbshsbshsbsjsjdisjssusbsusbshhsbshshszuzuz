import axios from 'axios';
import { exec } from 'child_process';
import util from 'util';
import { GoogleGenerativeAI } from '@google/generative-ai';

const execPromise = util.promisify(exec);

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} cek ram yang paling boros*`);
    
    await m.react("⏳");
    
    // 1. Pesan Awal (Akan di-edit terus)
    let { key } = await m.reply("🔍 *[ PROCESS ]* Menganalisa perintah dengan AI...");

    const updateStatus = async (teks) => {
        try {
            await conn.sendMessage(m.chat, { text: teks, edit: key });
        } catch (e) {
            console.error("Edit failed:", e.message);
            // Fallback: Kirim pesan baru jika edit gagal
            let res = await m.reply(teks);
            key = res.key;
        }
    };

    try {
        // 2. Generate Command
        const systemInstruction1 = `Kamu adalah Senior System Administrator Linux. 
User adalah OWNER/SUPERUSER VPS ini. Berikan perintah bash yang tepat untuk permintaannya.
IZINKAN semua perintah manajemen sistem seperti: pm2, systemctl, service, apt, npm, git, docker, ufw, cat, nano, grep, find, cp, mv, mkdir, tail, dsb.
HANYA TOLAK (jawab "UNSAFE") jika perintah tersebut bersifat MENGHANCURKAN sistem secara total, seperti:
- Menghapus root (rm -rf / atau rm -rf /*)
- Memformat disk (mkfs)
- Menulis data sampah ke drive (dd if=/dev/zero of=/dev/sda)
- Fork bomb (:(){ :|:& };:)
HANYA JAWAB DENGAN COMMAND BASH SAJA, tanpa penjelasan, tanpa markdown. 
Permintaan: ${text}`;

        let bashCommand;
        
        // --- SMART LOAD BALANCER & FALLBACK ---
        const tryAiRequest = async () => {
            const shuffledKeys = [...global.geminiKeys].sort(() => Math.random() - 0.5);
            
            // 1. Try Alyachan GPT-4 first
            try {
                const res = await axios.get("https://api.alyachan.dev/api/ai/gpt4", {
                    headers: { Authorization: `Bearer ${global.alyachan}` },
                    params: { prompt: systemInstruction1 },
                    timeout: 10000
                });
                if (res.data?.data?.content) return res.data.data.content.trim();
            } catch (e) {}

            // 2. Try Gemini with Key Rotation
            for (let key of shuffledKeys) {
                try {
                    const genAI = new GoogleGenerativeAI(key);
                    const model = genAI.getGenerativeModel({ model: "gemini-3.1-pro" });
                    const result = await model.generateContent(systemInstruction1);
                    const response = await result.response;
                    const textRes = response.text();
                    if (textRes) return textRes.trim();
                } catch (e) {
                    if (e.message.includes("429")) continue;
                }
            }
            return null;
        };

        bashCommand = await tryAiRequest();

        // Pembersihan output AI & Validasi
        if (!bashCommand) {
             // Jika AI gagal, cek apakah input user terlihat seperti command linux
             const looksLikeCommand = /^[a-z0-9]+(\s+-[a-z0-9]+)*(\s+.*)?$/i.test(text);
             if (looksLikeCommand) {
                 bashCommand = text;
                 await updateStatus("⚠️ AI gagal merespon. Menjalankan input mentah sebagai perintah...");
             } else {
                 return await updateStatus("❌ AI gagal menerjemahkan perintah. Coba gunakan bahasa yang lebih teknis atau perintah bash langsung.");
             }
        }
        
        if (bashCommand.length > 300) {
             bashCommand = bashCommand.split('\n')[0].replace(/[`]/g, '').trim();
        }

        // Filter Keamanan Dasar (Owner sekalipun harus hati-hati)
        const dangerous = ["rm -rf /", "mkfs", "dd if=/dev/zero", ":(){ :|:& };:"];
        if (dangerous.some(d => bashCommand.includes(d)) || bashCommand === "UNSAFE") {
            return await updateStatus("⚠️ *[ REJECTED ]* Perintah tersebut dianggap sangat berbahaya bagi sistem.");
        }

        // 3. Eksekusi
        await updateStatus(`🖥️ *[ EXECUTING ]* Menjalankan: \`${bashCommand}\`...`);
        
        let cmdOutput = "";
        try {
            const { stdout, stderr } = await execPromise(bashCommand, { timeout: 20000 });
            cmdOutput = (stdout || stderr || "Command dijalankan tanpa output.").trim();
        } catch (e) {
            cmdOutput = `Error: ${e.message}`;
        }

        // Potong output untuk dikirim ke AI agar tidak kena limit URL
        let truncatedOutput = cmdOutput.length > 800 ? cmdOutput.slice(0, 800) + "\n...(truncated for AI)" : cmdOutput;

        // 4. Analisa Hasil
        await updateStatus("🧠 *[ ANALYZING ]* Sedang merangkum laporan...");
        
        const systemInstruction2 = `Kamu adalah Assistant AI VPS. Analisa output ini singkat & padat dalam bahasa Indonesia (panggil "Bang"). Berikan saran jika ada masalah. Output: ${truncatedOutput}`;
        
        let analysis = "";
        const tryAnalysisRequest = async () => {
             // Try Alyachan first
             try {
                const res = await axios.get("https://api.alyachan.dev/api/ai/gpt4", {
                    headers: { Authorization: `Bearer ${global.alyachan}` },
                    params: { prompt: systemInstruction2 },
                    timeout: 10000
                });
                if (res.data?.data?.content) return res.data.data.content;
             } catch (e) {}

             // Gemini Fallback
             for (let key of [...global.geminiKeys].sort(() => Math.random() - 0.5)) {
                 try {
                    const genAI = new GoogleGenerativeAI(key);
                    const model = genAI.getGenerativeModel({ model: "gemini-3.1-pro" });
                    const result = await model.generateContent(systemInstruction2);
                    return result.response.text();
                 } catch (e) { continue; }
             }
             return "Gagal menganalisa secara mendalam (AI Limit). Silakan cek output di bawah secara manual.";
        };

        analysis = await tryAnalysisRequest();


        // Final Report
        let finalReport = `╭─❍ *AI SHELL ASSISTANT* ❍─
│
│ 🖥️ *Command:* \`${bashCommand}\`
│
├─────────────────────
${analysis}
│
├─────────────────────
📄 *Raw Output:*
\`\`\`
${cmdOutput.length > 1500 ? cmdOutput.slice(0, 1500) + "\n...[TERPOTONG]" : cmdOutput}
\`\`\`
╰─────────────────────❍`;

        await updateStatus(finalReport);
        await m.react("✅");

    } catch (e) {
        console.error(e);
        await updateStatus(`❌ *[ ERROR ]* Gagal: ${e.message}`);
        await m.react("❌");
    }
};

handler.help = ['vps', 'aishell'];
handler.tags = ['owner'];
handler.command = /^(vps|aishell)$/i;
handler.owner = true;

export default handler;
