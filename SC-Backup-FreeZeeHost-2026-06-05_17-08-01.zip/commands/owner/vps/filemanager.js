import fs from 'fs';
import path from 'path';

let handler = async (m, { conn, text, usedPrefix, command, Func }) => {
    // PROTEKSI: Fitur ini hanya untuk owner
    
    if (command === 'getfile') {
        if (!text) return m.reply(`📌 Contoh: *${usedPrefix}getfile commands/main/menu.js*`);
        
        let targetPath = path.resolve(process.cwd(), text.trim());
        
        if (!fs.existsSync(targetPath)) return m.reply(`❌ File tidak ditemukan di:\n${targetPath}`);
        
        try {
            let stats = fs.statSync(targetPath);
            if (stats.isDirectory()) {
                return m.reply(`❌ Path tersebut adalah direktori, bukan file.`);
            }

            // Jika ukuran file di atas 5MB, kirim sebagai dokumen
            if (stats.size > 5 * 1024 * 1024) {
                await conn.sendFile(m.chat, targetPath, path.basename(targetPath), 'Ini filenya Bang.', m);
                return;
            }

            // Jika file kecil dan teks, baca dan kirim isinya
            let ext = path.extname(targetPath).toLowerCase();
            let isText = ['.js', '.cjs', '.json', '.txt', '.md', '.html', '.css', '.env'].includes(ext);

            if (isText) {
                let fileContent = fs.readFileSync(targetPath, 'utf8');
                let displayContent = fileContent.length > 5000 
                    ? fileContent.substring(0, 5000) + '\n\n... [TERPOTONG KARENA TERLALU PANJANG]' 
                    : fileContent;

                const fileName = path.basename(targetPath);
                let lang = ext.replace('.', '') || 'text';
                if (lang === 'js' || lang === 'cjs') lang = 'javascript';
                
                // Enhanced Highlighting for common JS keywords
                let codeBlocks = [];
                const jsKeywords = ["async", "await", "break", "case", "catch", "class", "const", "continue", "debugger", "default", "delete", "do", "else", "enum", "export", "extends", "false", "finally", "for", "function", "if", "implements", "import", "in", "instanceof", "interface", "let", "new", "null", "package", "private", "protected", "public", "return", "static", "super", "switch", "this", "throw", "true", "try", "typeof", "var", "void", "while", "with", "yield", "of"];

                if (lang === 'javascript' || lang === 'json') {
                    const regex = new RegExp(`(\\b(?:${jsKeywords.join("|")})\\b)`, "g");
                    const parts = displayContent.split(regex);
                    for (let part of parts) {
                        if (part) {
                            codeBlocks.push({
                                highlightType: jsKeywords.includes(part) ? 1 : 0,
                                codeContent: part
                            });
                        }
                    }
                } else {
                    codeBlocks.push({ highlightType: 0, codeContent: displayContent });
                }

                const richData = {
                    mainText: `📄 *File Reader: ${fileName}*`,
                    submessages: [
                        { 
                            messageType: 2, 
                            messageText: `Berhasil mengambil file *${fileName}* dari sistem.` 
                        },
                        {
                            messageType: 4,
                            tableMetadata: {
                                title: "File Metadata",
                                rows: [
                                    { items: ["Property", "Value"], isHeading: true },
                                    { items: ["Name", fileName] },
                                    { items: ["Size", Func ? Func.formatSize(stats.size) : `${(stats.size / 1024).toFixed(2)} KB`] },
                                    { items: ["Location", targetPath] }
                                ]
                            }
                        },
                        { 
                            messageType: 5, 
                            codeMetadata: { 
                                codeLanguage: lang, 
                                codeBlocks: codeBlocks 
                            } 
                        }
                    ],
                    unifiedResponseData: {
                        response_id: `getfile-${fileName}`,
                        sections: [
                            {
                                view_model: {
                                    primitive: { 
                                        text: `### 📄 File: ${fileName}\n- **Size:** \`${stats.size} bytes\`\n- **Location:** \`${targetPath}\``, 
                                        __typename: "GenAIMarkdownTextUXPrimitive" 
                                    },
                                    __typename: "GenAISingleLayoutViewModel"
                                }
                            }
                        ]
                    }
                };

                await conn.sendRichMessage(m.chat, richData, { quoted: m });
            } else {
                // Jika bukan teks (misal foto), kirim sebagai dokumen
                await conn.sendFile(m.chat, targetPath, path.basename(targetPath), 'Ini filenya Bang.', m);
            }

            m.react("✅");
        } catch (e) {
            console.error(e);
            m.reply(`❌ Gagal membaca file: ${e.message}`);
        }
    } 
    
    else if (command === 'savefile') {
        if (!text) return m.reply(`📌 Contoh: *${usedPrefix}savefile commands/ai/custom.js*\n(Pastikan Abang me-reply pesan/kode yang ingin disimpan)`);
        
        let q = m.quoted ? m.quoted : null;
        if (!q || !q.text) return m.reply(`❌ Reply teks/kode yang ingin disimpan ke file.`);

        let targetPath = path.resolve(process.cwd(), text.trim());
        
        try {
            // Buat direktori jika belum ada
            let dir = path.dirname(targetPath);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, { recursive: true });
            }

            // Simpan file
            fs.writeFileSync(targetPath, q.text);
            
            m.reply(`✅ *Berhasil menyimpan file!*\n\n📁 *Path:* ${targetPath}\n_Sistem hot-reload akan mendeteksi perubahan jika file berada di folder plugin._`);
            m.react("✅");
        } catch (e) {
            console.error(e);
            m.reply(`❌ Gagal menyimpan file: ${e.message}`);
        }
    }
};

handler.help = ['getfile <path>', 'savefile <path>'];
handler.tags = ['owner'];
handler.command = /^(getfile|savefile)$/i;
handler.owner = true;

export default handler;
