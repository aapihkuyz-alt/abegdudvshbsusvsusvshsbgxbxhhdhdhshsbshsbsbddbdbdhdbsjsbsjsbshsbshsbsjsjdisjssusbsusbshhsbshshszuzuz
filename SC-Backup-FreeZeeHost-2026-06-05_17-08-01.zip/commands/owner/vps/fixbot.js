import axios from 'axios';
import { exec } from 'child_process';
import util from 'util';
import fs from 'fs';
import path from 'path';

const execPromise = util.promisify(exec);

// Fungsi Helper untuk panggil AI (Alyachan GPT-4 atau Alyachan Gemini sebagai fallback)
async function callAI(prompt, timeout = 30000) {
    try {
        // 1. Coba GPT-4 Alyachan
        const res = await axios.get("https://api.alyachan.dev/api/ai/gpt4", {
            headers: { Authorization: `Bearer ${global.alyachan}` },
            params: { prompt },
            timeout
        });
        return res.data?.data?.content;
    } catch (e) {
        // 2. Fallback ke Gemini Alyachan (Bukan Google Direct biar ga 404)
        const res = await axios.get("https://api.alyachan.dev/api/ai/gemini", {
            headers: { Authorization: `Bearer ${global.alyachan}` },
            params: { prompt },
            timeout
        });
        return res.data?.data?.content || res.data?.data?.message;
    }
}

let handler = async (m, { conn, usedPrefix, command }) => {
    await m.react("⏳");
    
    // 1. Pesan Awal (Live Update)
    let { key } = await m.reply("🔍 *[ PROCESS ]* Sedang mengambil log error terakhir di PM2...");

    const updateStatus = async (teks) => {
        try {
            await conn.sendMessage(m.chat, { text: teks, edit: key });
        } catch (e) {
            let res = await m.reply(teks);
            key = res.key;
        }
    };

    try {
        let errorLog = "";
        const logPath = "/root/.pm2/logs/botz-error.log";
        
        if (fs.existsSync(logPath)) {
            const { stdout } = await execPromise(`tail -n 50 ${logPath}`);
            errorLog = stdout;
        } else {
            const { stdout, stderr } = await execPromise(`pm2 logs botz --err --lines 50 --nostream`);
            errorLog = stdout || stderr;
        }

        if (!errorLog || errorLog.trim().length === 0) {
            return await updateStatus("✅ *[ SAFE ]* Tidak ada error yang ditemukan di log PM2.");
        }

        await updateStatus("🧠 *[ ANALYZING ]* AI sedang mendiagnosa file yang bermasalah...");

        // Step 1: Identifikasi File
        const findFileInstruction = `Analisa log error PM2 ini. Tentukan PATH FILE mana yang menyebabkan error dan apa masalahnya. HANYA JAWAB DENGAN FORMAT JSON: {"path": "commands/xxx/file.js", "issue": "deskripsi"}. Log: ${errorLog.slice(-1000)}`;

        let aiTask;
        const resTask = await callAI(findFileInstruction);
        try {
            aiTask = JSON.parse(resTask.replace(/```json|```/g, ''));
        } catch (e) {
            throw new Error("AI gagal memberikan diagnosa dalam format yang benar.");
        }

        if (!aiTask.path || aiTask.path === "unknown") {
            throw new Error("AI tidak bisa menemukan path file dari log.");
        }

        let absolutePath = path.resolve(process.cwd(), aiTask.path);
        if (!fs.existsSync(absolutePath)) {
            throw new Error(`File tidak ditemukan di: ${aiTask.path}`);
        }

        // Step 2: Perbaikan Penuh
        await updateStatus(`📖 *[ READING ]* Membaca isi file: _${aiTask.path}_...`);
        const originalCode = fs.readFileSync(absolutePath, 'utf8');

        const fixInstruction = `Kamu adalah Senior Programmer. Perbaiki file ini berdasarkan masalah: ${aiTask.issue}. FILE: ${aiTask.path}. KODE ASLI: ${originalCode}. HANYA JAWAB DENGAN KODE SAJA, tanpa penjelasan, tanpa markdown.`;

        const fixedCodeRaw = await callAI(fixInstruction, 45000);
        if (!fixedCodeRaw) throw new Error("AI gagal merangkai kode perbaikan.");
        
        const fixedCode = fixedCodeRaw.replace(/^```[a-z]*\n?/gm, '').replace(/```$/gm, '').trim();

        await updateStatus(`💾 *[ APPLYING ]* Menulis ulang file dengan kode baru...`);
        fs.writeFileSync(absolutePath, fixedCode);

        let finalReport = `✅ *[ AUTO-FIX SUCCESS ]*

📁 *File:* ${aiTask.path}
📛 *Masalah:* ${aiTask.issue}
✨ *Status:* File telah diperbaiki otomatis!

_Sistem akan memuat ulang file ini dalam sekejap._`;

        await updateStatus(finalReport);
        await m.react("✅");

    } catch (e) {
        console.error("FIXBOT ERROR:", e);
        await updateStatus(`❌ *[ ERROR ]* Gagal: ${e.message}`);
        await m.react("❌");
    }
};

handler.help = ['fixbot'];
handler.tags = ['owner'];
handler.command = /^(fixbot|fixerror)$/i;
handler.owner = true;

export default handler;
