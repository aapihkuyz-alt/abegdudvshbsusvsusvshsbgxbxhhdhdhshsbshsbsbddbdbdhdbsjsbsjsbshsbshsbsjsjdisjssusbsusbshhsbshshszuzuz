import fs from "fs";
import path from "path";
import { exec } from "child_process";
import { promisify } from "util";

const execPromise = promisify(exec);

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text && command !== 'ls') return m.reply(`📌 Contoh:\n*${usedPrefix + command} /root/bott*\n*${usedPrefix}cat index.js*\n*${usedPrefix}upload* (sambil reply file)`);

    try {
        await m.react("📂");

        // 1. LIST FILES (.ls)
        if (command === 'ls') {
            const targetDir = text || process.cwd();
            const files = fs.readdirSync(targetDir);
            let report = `📂 *DIRECTORY LISTING* 📂\n\n📍 *Path:* ${targetDir}\n\n`;
            
            files.forEach(file => {
                const isDir = fs.lstatSync(path.join(targetDir, file)).isDirectory();
                report += `${isDir ? '📁' : '📄'} ${file}\n`;
            });
            
            return m.reply(report);
        }

        // 2. READ FILE (.cat)
        if (command === 'cat') {
            const filePath = path.isAbsolute(text) ? text : path.join(process.cwd(), text);
            if (!fs.existsSync(filePath)) return m.reply("❌ File tidak ditemukan.");
            if (fs.lstatSync(filePath).isDirectory()) return m.reply("❌ Itu adalah direktori, bukan file.");

            const content = fs.readFileSync(filePath, "utf8");
            return m.reply(`📄 *FILE CONTENT: ${path.basename(filePath)}*\n\n\`\`\`${content.substring(0, 4000)}\`\`\``);
        }

        // 3. UPLOAD FILE (.upload)
        if (command === 'upload') {
            if (!m.quoted) return m.reply("📌 Reply file yang mau diupload ke VPS!");
            const buffer = await m.quoted.download();
            const fileName = text || m.quoted.fileName || `upload_${Date.now()}`;
            const destPath = path.join(process.cwd(), fileName);

            fs.writeFileSync(destPath, buffer);
            return m.reply(`✅ *FILE UPLOADED!* \n\n📍 *Saved to:* \`${destPath}\``);
        }

    } catch (e) {
        console.error("FileManager Error:", e.message);
        m.reply(`❌ *[ ERROR ]* ${e.message}`);
    }
};

handler.help = ["ls", "cat", "upload"];
handler.tags = ["owner"];
handler.command = /^(ls|cat|upload)$/i;
handler.owner = true;

export default handler;