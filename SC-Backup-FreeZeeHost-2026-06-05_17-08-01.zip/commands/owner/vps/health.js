import { exec } from 'child_process';
import os from 'os';
import util from 'util';
import axios from 'axios';
import { createCanvas, loadImage } from 'canvas';
import chalk from 'chalk';
import moment from 'moment-timezone';

const execPromise = util.promisify(exec);

const THEME = {
    bg: "#0f172a",
    card: "#1e293b",
    primary: "#3b82f6",
    success: "#10b981",
    warning: "#f59e0b",
    danger: "#ef4444",
    text: "#f1f5f9",
    textDim: "#94a3b8"
};

let handler = async (m, { conn, db, Func }) => {
    await m.react("🩺");
    await m.reply("🔬 *The System Medic sedang mendiagnosa kesehatan server...*");

    try {
        // 1. GATHER DATA
        const totalRam = os.totalmem();
        const freeRam = os.freemem();
        const usedRam = totalRam - freeRam;
        
        // CPU Load
        const cpus = os.cpus();
        const cpuModel = cpus[0].model.split(' @')[0];
        const cpuLoad = (os.loadavg()[0] * 100 / cpus.length).toFixed(1);
        
        // Disk Usage
        let diskInfo = { percent: 0 };
        try {
            const { stdout } = await execPromise("df -h / | tail -1");
            const parts = stdout.trim().split(/\s+/);
            diskInfo.percent = parts[4].replace('%', '');
        } catch (e) {}

        // Network Latency (Ping to WA Server)
        const startPing = Date.now();
        await conn.query({ tag: 'iq', attrs: { type: 'get', xmlns: 'w:p', to: '@s.whatsapp.net' }, content: [{ tag: 'ping', attrs: {} }] }).catch(() => {});
        const latency = Date.now() - startPing;

        // Session Health
        const sessions = global.listSessions ? global.listSessions() : [];
        const waOnline = sessions.filter(s => s.isRunning).length;
        const tgOnline = global.telegramBots ? global.telegramBots.size : 0;

        // 2. CANVAS DRAWING
        const W = 1000;
        const H = 600;
        const canvas = createCanvas(W, H);
        const ctx = canvas.getContext('2d');

        // Background
        ctx.fillStyle = THEME.bg;
        ctx.fillRect(0, 0, W, H);

        // Header
        ctx.fillStyle = THEME.primary;
        ctx.font = "bold 40px Arial";
        ctx.fillText("SYSTEM VITAL DASHBOARD", 50, 60);
        ctx.fillStyle = THEME.textDim;
        ctx.font = "20px Arial";
        ctx.fillText(`Timestamp: ${moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")} WIB`, 50, 95);

        const drawMetric = (label, value, percent, x, y, w, h) => {
            ctx.fillStyle = THEME.card;
            ctx.roundRect ? ctx.beginPath() || ctx.roundRect(x, y, w, h, 10) || ctx.fill() : ctx.fillRect(x, y, w, h);
            
            ctx.fillStyle = THEME.text;
            ctx.font = "bold 25px Arial";
            ctx.fillText(label, x + 20, y + 40);
            
            ctx.font = "20px Arial";
            ctx.fillStyle = THEME.textDim;
            ctx.fillText(value, x + 20, y + 70);

            // Progress Bar
            const barW = w - 40;
            ctx.fillStyle = "#334155";
            ctx.fillRect(x + 20, y + 90, barW, 10);
            
            let barColor = THEME.success;
            if (percent > 70) barColor = THEME.warning;
            if (percent > 90) barColor = THEME.danger;
            
            ctx.fillStyle = barColor;
            ctx.fillRect(x + 20, y + 90, barW * (percent / 100), 10);
        };

        drawMetric("PROCESSOR", `${cpuModel} (${cpuLoad}%)`, cpuLoad, 50, 130, 440, 120);
        drawMetric("MEMORY (RAM)", `${(usedRam / 1024 / 1024 / 1024).toFixed(2)}GB / ${(totalRam / 1024 / 1024 / 1024).toFixed(2)}GB`, (usedRam / totalRam) * 100, 510, 130, 440, 120);
        drawMetric("STORAGE (DISK)", `Root Partition Usage: ${diskInfo.percent}%`, diskInfo.percent, 50, 270, 440, 120);
        drawMetric("NETWORK LATENCY", `WA Socket Response: ${latency}ms`, Math.min(latency / 10, 100), 510, 270, 440, 120);

        // Session Grid
        ctx.fillStyle = THEME.card;
        ctx.fillRect(50, 410, 900, 150);
        ctx.fillStyle = THEME.text;
        ctx.font = "bold 25px Arial";
        ctx.fillText("ACTIVE CORE STATUS", 70, 450);
        
        ctx.font = "20px Arial";
        ctx.fillStyle = THEME.textDim;
        ctx.fillText(`• WhatsApp Sessions : ${waOnline} Active`, 70, 490);
        ctx.fillText(`• Telegram Instances : ${tgOnline} Active`, 70, 520);
        ctx.fillText(`• System Uptime     : ${Func.toTime(process.uptime() * 1000)}`, 500, 490);
        ctx.fillText(`• Node.js Version    : ${process.version}`, 500, 520);

        const buffer = canvas.toBuffer('image/png');

        // 3. AI ANALYSIS
        let analysis = "Menganalisa data...";
        try {
            const query = `Analisa data server berikut and beri kesimpulan singkat (2 kalimat) apakah sehat atau butuh upgrade: 
RAM: ${((usedRam / totalRam) * 100).toFixed(1)}%, CPU: ${cpuLoad}%, Disk: ${diskInfo.percent}%, Ping: ${latency}ms.`;
            const { data } = await axios.get("https://api.neoxr.eu/api/gpt4-session", {
                params: { q: query, session: "health_analyst", apikey: global.neoxr }
            });
            analysis = data?.status ? data.data.message : "Sistem terlihat berjalan normal.";
        } catch (e) {
            analysis = "Sistem dalam kondisi optimal.";
        }

        const caption = `📊 *SYSTEM VITAL REPORT* 📊\n\n` +
                        `🖥️ *CPU:* ${cpuLoad}% Load\n` +
                        `💾 *RAM:* ${((usedRam / totalRam) * 100).toFixed(1)}% Used\n` +
                        `🛰️ *Ping:* ${latency}ms\n\n` +
                        `🧠 *AI Diagnostic:* \n_${analysis}_`;

        await conn.sendMessage(m.chat, { image: buffer, caption }, { quoted: m });
        await m.react("✅");

    } catch (e) {
        console.error(e);
        m.reply(`❌ *DIAGNOSIS FAILED:* ${e.message}`);
    }
};

handler.help = ['vpshealth', 'health', 'statusvps'];
handler.tags = ['owner', 'vps'];
handler.command = /^(vpshealth|health|statusvps|vps)$/i;
handler.owner = true;

export default handler;
