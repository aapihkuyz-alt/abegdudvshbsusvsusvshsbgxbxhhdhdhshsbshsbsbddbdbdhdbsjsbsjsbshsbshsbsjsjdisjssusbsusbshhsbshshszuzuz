import axios from 'axios';
import { GoogleGenerativeAI } from '@google/generative-ai';
import fs from 'fs';
import path from 'path';

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} buatkan fitur downloader ig dengan command .ig*`);
    
    await m.react("⏳");
    let { key } = await m.reply("🧠 *[ PROCESS ]* Menganalisa permintaan dan merangkai kode...");

    const updateStatus = async (teks) => {
        try {
            await conn.sendMessage(m.chat, { text: teks, edit: key });
        } catch (e) {
            let res = await m.reply(teks);
            key = res.key;
        }
    };

    try {
        const systemInstruction = `Kamu adalah Senior Programmer AI ahli pembuatan plugin WhatsApp Bot Baileys.
Tugasmu:
1. Buat kode plugin Node.js (Format ESM: export default handler) sesuai permintaan user.
2. Plugin WAJIB memiliki properti:
   handler.command = ['nama_command']
   handler.tags = ['custom']
   handler.help = ['nama_command']
3. Gunakan m.reply() untuk membalas pesan.
4. Output HARUS murni blok kode JavaScript saja. Jangan gunakan format markdown (\`\`\`), jangan ada penjelasan di luar kode. Pastikan kodenya langsung bisa dijalankan.
Permintaan User: ${text}`;

        let codeResult;
        
        // 1. Coba pake Alyachan (Primary)
        try {
            const res = await axios.get("https://api.alyachan.dev/api/ai/gpt4", {
                headers: { Authorization: `Bearer ${global.alyachan}` },
                params: { prompt: systemInstruction },
                timeout: 30000
            });
            codeResult = res.data?.data?.content;
        } catch (e) {
            // 2. Fallback Gemini SDK
            const genAI = new GoogleGenerativeAI(global.googleAiApiKey);
            const model = genAI.getGenerativeModel({ model: "gemini-3.1-pro" });
            const result = await model.generateContent(systemInstruction);
            codeResult = result.response.text();
        }

        if (!codeResult) throw new Error("Gagal generate plugin (AI No Response).");

        // Pembersihan
        codeResult = codeResult.replace(/^```[a-z]*\n?/gm, '').replace(/```$/gm, '').trim();

        // Cari nama command
        let matchCommand = codeResult.match(/handler\.command\s*=\s*(?:\[\s*['"]([^'"]+)['"]\s*\]|['"]([^'"]+)['"])/);
        let fileName = matchCommand ? (matchCommand[1] || matchCommand[2]) : `plugin_${Date.now()}`;
        fileName = fileName.replace(/[^a-zA-Z0-9]/g, '');

        await updateStatus(`💾 *[ SAVING ]* Menyimpan kode ke commands/tools/${fileName}.js...`);

        const customDir = path.join(process.cwd(), 'commands', 'tools');
        if (!fs.existsSync(customDir)) fs.mkdirSync(customDir, { recursive: true });

        const filePath = path.join(customDir, `${fileName}.js`);
        fs.writeFileSync(filePath, codeResult);

        let finalReport = `╭─❍ *AI PLUGIN INSTALLER* ❍─
│
│ ✅ *Status:* Berhasil Diinstall!
│ 📁 *File:* commands/tools/${fileName}.js
│ ⚙️ *Command:* .${fileName}
│
│ _Sistem hot-reload akan otomatis memuat plugin ini dalam beberapa detik._
╰─────────────────────❍`;

        await updateStatus(finalReport);
        await m.react("✅");

    } catch (e) {
        console.error(e);
        await updateStatus(`❌ *[ ERROR ]* Gagal: ${e.message}`);
        await m.react("❌");
    }
};

handler.help = ['installplugin'];
handler.tags = ['owner'];
handler.command = /^(installplugin|buatplugin|aiplugin)$/i;
handler.owner = true;

export default handler;
