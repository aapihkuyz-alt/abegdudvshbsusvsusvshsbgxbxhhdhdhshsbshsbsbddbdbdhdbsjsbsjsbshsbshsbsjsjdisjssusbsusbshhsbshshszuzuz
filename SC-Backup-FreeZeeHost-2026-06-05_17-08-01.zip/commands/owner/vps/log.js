import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

const handler = async (m, { conn, args, usedPrefix, command }) => {
    await m.react("📄");
    
    // Default 20 baris terakhir
    const lines = parseInt(args[0]) || 20;
    if (lines > 100) return m.reply("❌ Maksimal 100 baris demi kenyamanan chat.");

    try {
        // Cek apakah running via PM2 atau Node biasa
        let logCommand = `tail -n ${lines} ~/.pm2/logs/*.log`; // Default PM2 log
        
        // Jika tidak ada PM2, coba baca file log bot jika ada
        if (process.env.pm_id === undefined) {
            logCommand = `tail -n ${lines} ./data/sampah/logs/session-runtime.log`;
        }

        const { stdout, stderr } = await execAsync(logCommand);
        
        if (!stdout && !stderr) {
            return m.reply("Logs kosong atau tidak ditemukan.");
        }

        const logOutput = stdout || stderr;
        const caption = `
📋 *REMOTE VPS LOGS* 📋
_Menampilkan ${lines} baris terakhir._

\`\`\`
${logOutput.slice(-3800)} 
\`\`\`
`.trim();

        m.reply(caption);
    } catch (e) {
        console.error("LOG VIEWER ERROR:", e);
        m.reply(`❌ Gagal mengambil log: ${e.message}\n\nCobalah perintah: \`.exec tail -n 20 ~/.pm2/logs/index-out.log\``);
    }
};

handler.help = ['vpslog <lines>', 'botlog'];
handler.tags = ['owner'];
handler.command = ['vpslog', 'botlog', 'readlog'];
handler.owner = true;

export default handler;
