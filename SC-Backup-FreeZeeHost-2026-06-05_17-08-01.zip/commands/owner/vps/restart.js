import { exec } from 'child_process';

const handler = async (m, { conn, usedPrefix, command }) => {
    await m.reply("🚀 *SYSTEM RESTART INITIATED*\n\nBot akan mati and menyala kembali dalam beberapa detik via PM2. Mohon tunggu...");
    
    setTimeout(() => {
        exec("pm2 restart all", (err, stdout, stderr) => {
            if (err) {
                console.error("RESTART ERROR:", err);
                return;
            }
            console.log("System restarted via PM2 command.");
        });
    }, 2000);
};

handler.help = ['restart', 'reboot'];
handler.tags = ['owner'];
handler.command = ['restart', 'reboot'];
handler.owner = true;

export default handler;
