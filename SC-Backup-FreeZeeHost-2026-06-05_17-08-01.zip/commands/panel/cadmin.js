import {
    generateWAMessageFromContent
} from "baileys"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text) return m.reply(`Contoh:
#cadmin username,628xxxx
#cadmin username,@tag
atau reply pesan user`)

    await m.react("⏳")

    let args = text.split(",")

    let username = (args[0] || "").trim().toLowerCase().replace(/[^a-z0-9]/g, "")
    let nomor = (args[1] || "").trim()

    if (!username) return m.reply("Username tidak valid")

    let email = username + "@host.id"
    let password = "1"

    let target = m.sender

    if (m.quoted) target = m.quoted.sender
    else if (m.mentionedJid && m.mentionedJid[0]) target = m.mentionedJid[0]
    else if (nomor) {
        nomor = nomor.replace(/[^0-9]/g, "")
        target = nomor + "@s.whatsapp.net"
    }

    let res = await fetch(`${global.domain}/api/application/users`, {
        method: "POST",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${global.apikey}`
        },
        body: JSON.stringify({
            email,
            username,
            first_name: username,
            last_name: "Admin",
            root_admin: true,
            language: "en",
            password
        })
    })

    let data = await res.json()

    if (data.errors) {
        await m.react("❌")
        return m.reply(JSON.stringify(data.errors[0], null, 2))
    }

    let user = data.attributes

    let teks = `
╭───〔 📦 *ADMIN PANEL CREATED* 〕───╮

🆔 *User ID*
${user.id}

👤 *Username*
${user.username}

📧 *Email Login*
${email}

🔐 *Password*
${password}

🌐 *Panel Login*
${global.domain}

────────────────────

📋 *Informasi Akun*
• Gunakan data di atas untuk login ke panel
• Jangan bagikan akun ke orang lain
• Simpan data login dengan baik
• Hindari menghapus server sembarangan

⚡ *Tips*
Gunakan tombol di bawah untuk menyalin username / password
atau langsung membuka panel.

╰────────────────────╯
`

    let msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    body: {
                        text: teks
                    },
                    footer: {
                        text: "Panel Creator"
                    },
                    nativeFlowMessage: {
                        buttons: [{
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Copy Username",
                                    copy_code: user.username
                                })
                            },
                            {
                                name: "cta_copy",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Copy Password",
                                    copy_code: password
                                })
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Open Panel",
                                    url: global.domain,
                                    merchant_url: global.domain
                                })
                            }
                        ]
                    }
                }
            }
        }
    }, {
        userJid: conn.user.id,
        quoted: m // <-- ini yang bikin pesan jadi reply
    })

    await conn.relayMessage(target, msg.message, {
        messageId: msg.key.id
    })

    await m.react("✅")

    if (m.isGroup) {
        m.reply("✅ Admin berhasil dibuat dan data dikirim ke private chat user.")
    }

}

handler.command = ["cadmin"]
handler.tags = ["panel"]
handler.help = ["cadmin username,628xxx"]
handler.owner = true

export default handler