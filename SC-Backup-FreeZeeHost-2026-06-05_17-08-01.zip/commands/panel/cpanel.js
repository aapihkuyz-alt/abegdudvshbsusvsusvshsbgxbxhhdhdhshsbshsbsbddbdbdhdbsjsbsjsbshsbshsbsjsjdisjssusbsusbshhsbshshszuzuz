import {
    generateWAMessageFromContent
} from "baileys"

let handler = async (m, {
    conn,
    command,
    text,
    args
}) => {
    // Validasi Input
    if (!text) return m.reply(`*CARA PAKAI:*\n\n1. Tag orang: .${command} user @tag\n2. Reply: .${command} user (sambil reply chat)\n3. Manual: .${command} user, 628xxx`)

    await m.react("⏳")

    // ================= GET TARGET =================
    let target;
    let usernamePart;

    if (m.quoted) {
        // Jika reply pesan
        target = m.quoted.sender
        usernamePart = text.trim().split(' ')[0]
    } else if (m.mentionedJid && m.mentionedJid[0]) {
        // Jika tag orang
        target = m.mentionedJid[0]
        usernamePart = text.replace(/@\d+/g, "").trim().split(' ')[0]
    } else if (text.includes(',')) {
        // Jika format: username, nomor
        let [u, n] = text.split(',').map(v => v.trim())
        usernamePart = u
        target = n.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
    } else {
        // Fallback ke pengirim sendiri jika tidak ada indikasi target lain
        target = m.sender
        usernamePart = text.trim().split(' ')[0]
    }

    if (!target || !usernamePart) {
        await m.react("❌")
        return m.reply("Target atau username tidak ditemukan.")
    }

    // ================= SPEC SERVER =================
    const spec = {
        "1gb": [1000, 1000, 40],
        "2gb": [2000, 2000, 60],
        "3gb": [3000, 3000, 80],
        "4gb": [4000, 4000, 100],
        "5gb": [5000, 5000, 120],
        "6gb": [6000, 6000, 140],
        "7gb": [7000, 7000, 160],
        "8gb": [8000, 8000, 180],
        "9gb": [9000, 9000, 200],
        "10gb": [10000, 10000, 220],
        "unlimited": [0, 0, 0],
        "unli": [0, 0, 0]
    }

    let [ram, disk, cpu] = spec[command]
    let username = usernamePart.toLowerCase().replace(/[^a-z0-9]/g, "")
    let email = username + "@host.id"
    let password = "1"
    let name = username + " Server"

    try {
        // ================= CREATE USER =================
        let createUser = await fetch(`${global.domain}/api/application/users`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${global.apikey}`
            },
            body: JSON.stringify({
                email,
                username,
                first_name: name,
                last_name: "Server",
                language: "en",
                password
            })
        })

        let userData = await createUser.json()
        if (userData.errors) {
            await m.react("❌")
            return m.reply(`❌ *FAILED CREATE USER:*\n${userData.errors[0].detail}`)
        }

        let user = userData.attributes

        // ================= GET STARTUP EGG =================
        let eggData = await fetch(`${global.domain}/api/application/nests/${global.nestid}/eggs/${global.egg}`, {
            method: "GET",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${global.apikey}`
            }
        })
        let eggJson = await eggData.json()
        let startup = eggJson.attributes.startup

        // ================= CREATE SERVER =================
        let createServer = await fetch(`${global.domain}/api/application/servers`, {
            method: "POST",
            headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${global.apikey}`
            },
            body: JSON.stringify({
                name,
                description: `Created via ${global.botname}`,
                user: user.id,
                egg: parseInt(global.egg),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
                startup,
                environment: {
                    INST: "npm",
                    USER_UPLOAD: "0",
                    AUTO_UPDATE: "0",
                    CMD_RUN: "npm start"
                },
                limits: {
                    memory: ram,
                    swap: 0,
                    disk: disk,
                    io: 500,
                    cpu: cpu
                },
                feature_limits: {
                    databases: 5,
                    backups: 5,
                    allocations: 5
                },
                deploy: {
                    locations: [parseInt(global.loc)],
                    dedicated_ip: false,
                    port_range: []
                }
            })
        })

        let serverData = await createServer.json()
        if (serverData.errors) {
            await m.react("❌")
            return m.reply(`❌ *FAILED CREATE SERVER:*\n${serverData.errors[0].detail}`)
        }

        let server = serverData.attributes

        // ================= PREPARE TEXT =================
        let ramTxt = ram == 0 ? "Unlimited" : (ram / 1000) + "GB"
        let diskTxt = disk == 0 ? "Unlimited" : (disk / 1000) + "GB"
        let cpuTxt = cpu == 0 ? "Unlimited" : cpu + "%"

        let teks = `
╭───〔 📦 PANEL SERVER CREATED 〕───╮

🆔 Server ID : ${server.id}
👤 Username  : ${user.username}
📧 Email     : ${email}
🔐 Password  : ${password}
🌐 Login     : ${global.domain}

────────────────────
⚙️ Spesifikasi:
💾 RAM  : ${ramTxt}
📀 Disk : ${diskTxt}
⚡ CPU  : ${cpuTxt}
────────────────────
📋 Laporan: Akun dikirim ke @${target.split('@')[0]}
╰────────────────────╯
`.trim()

        // ================= SEND TO TARGET (PC) =================
        let msg = generateWAMessageFromContent(target, {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        body: {
                            text: teks
                        },
                        footer: {
                            text: global.footer
                        },
                        nativeFlowMessage: {
                            buttons: [{
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Copy Username",
                                        copy_code: user.username
                                    })
                                },
                                {
                                    name: "cta_copy",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "🔑 Copy Password",
                                        copy_code: password
                                    })
                                },
                                {
                                    name: "cta_url",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "🌐 Login Panel",
                                        url: global.domain
                                    })
                                }
                            ]
                        }
                    }
                }
            }
        }, {
            userJid: conn.user.id
        })

        await conn.relayMessage(target, msg.message, {
            messageId: msg.key.id
        })

        // ================= FEEDBACK DI GRUP =================
        if (m.isGroup) {
            m.reply(`✅ *SUCCESS!*\nPanel *${command}* berhasil dibuat untuk @${target.split('@')[0]}.\nData login sudah dikirim ke Private Chat.`, null, {
                mentions: [target]
            })
        } else {
            m.reply("✅ *SUCCESS!* Data login sudah ada di atas.")
        }

        await m.react("✅")

    } catch (e) {
        console.log(e)
        m.reply("❌ Terjadi kesalahan pada sistem API Panel.")
    }
}

handler.command = ["1gb", "2gb", "3gb", "4gb", "5gb", "6gb", "7gb", "8gb", "9gb", "10gb", "unlimited", "unli"]
handler.tags = ["owner"]
handler.owner = true

export default handler