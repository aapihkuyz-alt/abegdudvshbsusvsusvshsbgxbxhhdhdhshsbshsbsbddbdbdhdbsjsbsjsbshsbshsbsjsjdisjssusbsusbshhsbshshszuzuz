let handler = async (m, {
    conn,
    text
}) => {

    await m.react("⏳")

    let res = await fetch(global.domain + "/api/application/servers?page=1", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        }
    })

    let json = await res.json()

    if (!json?.data) {
        await m.react("❌")
        return conn.sendMessage(m.chat, {
            text: `❌ Gagal mengambil data server panel.

Periksa:
• API Key panel
• Domain panel
• Permission Application API`
        }, {
            quoted: m
        })
    }

    let servers = json.data

    // ================= LIST SERVER =================

    if (!text) {

        if (servers.length === 0) {
            await m.react("❌")
            return conn.sendMessage(m.chat, {
                text: "📦 Tidak ada server panel."
            }, {
                quoted: m
            })
        }

        let rows = []

        for (let server of servers) {

            let s = server.attributes

            let ram = s.limits.memory == 0 ? "Unlimited" : `${s.limits.memory}MB`
            let disk = s.limits.disk == 0 ? "Unlimited" : `${s.limits.disk}MB`
            let cpu = s.limits.cpu == 0 ? "Unlimited" : `${s.limits.cpu}%`

            rows.push({
                header: "SERVER PANEL",
                title: `${s.name} (ID ${s.id})`,
                description: `RAM ${ram} | DISK ${disk} | CPU ${cpu}`,
                id: `.delpanel ${s.id}`
            })

        }

        await conn.sendMessage(m.chat, {
            text: `📦 *Panel Server Manager*

Berikut daftar server yang ada di panel.

Pilih server dari menu di bawah untuk menghapus server dari panel.

⚠️ Menghapus server akan menghapus semua data server secara permanen.`,
            footer: "FreezeeHost Panel System",
            buttons: [{
                buttonId: 'action',
                buttonText: {
                    displayText: 'Pilih Server Panel'
                },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: "List Server Panel",
                        sections: [{
                            title: "Server Panel",
                            rows
                        }]
                    })
                }
            }],
            headerType: 1,
            viewOnce: true
        }, {
            quoted: m
        })

        await m.react("✅")

        return
    }

    // ================= DELETE SERVER =================

    let nameSrv
    let sections

    for (let server of servers) {

        let s = server.attributes

        if (Number(text) === s.id) {

            sections = s.name.toLowerCase()
            nameSrv = s.name

            await fetch(global.domain + `/api/application/servers/${s.id}`, {
                method: "DELETE",
                headers: {
                    Accept: "application/json",
                    "Content-Type": "application/json",
                    Authorization: "Bearer " + global.apikey
                }
            })

        }

    }

    if (!sections) {
        await m.react("❌")
        return conn.sendMessage(m.chat, {
            text: "❌ Server panel tidak ditemukan."
        }, {
            quoted: m
        })
    }

    // ================= DELETE USER =================

    let cek = await fetch(global.domain + "/api/application/users?page=1", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        }
    })

    let userJson = await cek.json()

    if (userJson?.data) {

        for (let user of userJson.data) {

            let u = user.attributes

            if (u.first_name.toLowerCase() === sections) {

                await fetch(global.domain + `/api/application/users/${u.id}`, {
                    method: "DELETE",
                    headers: {
                        Accept: "application/json",
                        "Content-Type": "application/json",
                        Authorization: "Bearer " + global.apikey
                    }
                })

            }

        }

    }

    await m.react("✅")

    conn.sendMessage(m.chat, {
        text: `🗑️ *Server Berhasil Dihapus*

Server *${nameSrv}* berhasil dihapus dari panel.

Semua resource server telah dibersihkan dari sistem panel.`
    }, {
        quoted: m
    })

}

handler.command = ["delpanel"]
handler.tags = ["panel"]
handler.owner = true

export default handler