let handler = async (m, {
    conn,
    text
}) => {

    await m.react("⏳")

    let res = await fetch(global.domain + "/api/application/users?page=1", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        }
    })

    let json = await res.json()

    if (!json?.data) {
        await m.react("❌")
        return m.reply("❌ Gagal mengambil data user panel.")
    }

    let users = json.data

    // ================= LIST USER =================

    if (!text) {

        if (users.length == 0) {
            await m.react("❌")
            return m.reply("Tidak ada user panel.")
        }

        let rows = []

        for (let user of users) {

            let u = user.attributes

            rows.push({
                header: "PANEL USER",
                title: `${u.username} (ID ${u.id})`,
                description: `${u.email}`,
                id: `.deluser ${u.id}`
            })

        }

        return conn.sendMessage(m.chat, {
            text: `👤 *Panel User Manager*

Berikut daftar user panel.

Pilih user yang ingin dihapus dari sistem panel.

⚠️ Menghapus user akan menghapus akses panel secara permanen.`,
            footer: "Panel System",
            buttons: [{
                buttonId: 'action',
                buttonText: {
                    displayText: 'Pilih User'
                },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: "List User Panel",
                        sections: [{
                            title: "Panel Users",
                            rows
                        }]
                    })
                }
            }],
            headerType: 1,
            viewOnce: true
        }, {
            quoted: m
        })

    }

    // ================= DELETE USER =================

    let targetUser = null

    for (let user of users) {

        let u = user.attributes

        if (Number(text) === u.id || text.toLowerCase() === u.username.toLowerCase()) {
            targetUser = u
        }

    }

    if (!targetUser) {
        await m.react("❌")
        return m.reply("❌ User panel tidak ditemukan.")
    }

    await fetch(global.domain + `/api/application/users/${targetUser.id}`, {
        method: "DELETE",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        }
    })

    await m.react("✅")

    m.reply(`🗑️ *User Panel Berhasil Dihapus*

👤 Username : ${targetUser.username}
🆔 ID : ${targetUser.id}
📧 Email : ${targetUser.email}

User telah dihapus dari sistem panel.`)

}

handler.command = ["deluser"]
handler.tags = ["panel"]
handler.owner = true

export default handler