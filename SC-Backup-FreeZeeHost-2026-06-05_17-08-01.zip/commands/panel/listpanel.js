let handler = async (m, {
    conn,
    text
}) => {

    await m.react("⏳")

    let res = await fetch(global.domain + "/api/application/servers?page=1", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        }
    })

    let json = await res.json()

    if (!json?.data) {
        await m.react("❌")
        return m.reply("❌ Gagal mengambil data server panel.")
    }

    let servers = json.data

    // ================= LIST SERVER =================

    if (!text) {

        if (servers.length === 0) {
            await m.react("❌")
            return m.reply("Tidak ada server panel.")
        }

        let rows = []

        for (let server of servers) {

            let s = server.attributes

            rows.push({
                header: "SERVER PANEL",
                title: `${s.name}`,
                description: `ID ${s.id} • RAM ${s.limits.memory}MB • CPU ${s.limits.cpu}%`,
                id: `.listpanel ${s.id}`
            })

        }

        await conn.sendMessage(m.chat, {
            text: `📦 *Panel Server Manager*

Silahkan pilih server panel untuk melihat detail server.`,
            footer: "Panel System",
            buttons: [{
                buttonId: 'action',
                buttonText: {
                    displayText: 'Pilih Server'
                },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: "List Server Panel",
                        sections: [{
                            title: "Server List",
                            rows
                        }]
                    })
                }
            }],
            headerType: 1,
            viewOnce: true
        }, {
            quoted: m
        })

        await m.react("✅")

        return
    }

    // ================= DETAIL SERVER =================

    let target = null

    for (let server of servers) {

        let s = server.attributes

        if (Number(text) === s.id) target = s

    }

    if (!target) {
        await m.react("❌")
        return m.reply("❌ Server panel tidak ditemukan.")
    }

    let ram = target.limits.memory == 0 ? "Unlimited" : target.limits.memory + " MB"
    let disk = target.limits.disk == 0 ? "Unlimited" : target.limits.disk + " MB"
    let cpu = target.limits.cpu == 0 ? "Unlimited" : target.limits.cpu + "%"

    let teks = `
╭───〔 📦 PANEL SERVER DETAIL 〕───╮

🆔 Server ID
${target.id}

🧬 UUID
${target.uuid}

📛 Nama Server
${target.name}

💾 RAM
${ram}

📀 Disk
${disk}

⚡ CPU
${cpu}

🧱 Node
${target.node}

🥚 Egg
${target.egg}

📅 Created
${target.created_at}

────────────────────

⚠️ Informasi
Server ini berjalan di sistem panel hosting.
Jika server sudah tidak digunakan lagi,
disarankan untuk menghapusnya agar resource
tidak terpakai secara sia-sia.

Gunakan tombol di bawah untuk menghapus server.

╰────────────────────╯
`

    await conn.sendMessage(m.chat, {
        text: teks,
        buttons: [{
            buttonId: `.delpanel ${target.id}`,
            buttonText: {
                displayText: "🗑 Delete Server"
            },
            type: 1
        }],
        headerType: 1
    }, {
        quoted: m
    })

    await m.react("✅")

}

handler.command = ["listpanel"]
handler.tags = ["panel"]
handler.owner = true

export default handler