let handler = async (m, {
    conn,
    text
}) => {

    await m.react("⏳")

    let res = await fetch(global.domain + "/api/application/users?page=1", {
        method: "GET",
        headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: "Bearer " + global.apikey
        }
    })

    let json = await res.json()

    if (!json?.data) {
        await m.react("❌")
        return m.reply("❌ Gagal mengambil data user panel.")
    }

    let users = json.data

    // ================= LIST USER =================

    if (!text) {

        let rows = []

        for (let user of users) {

            let u = user.attributes

            rows.push({
                header: "PANEL USER",
                title: `${u.username}`,
                description: `ID ${u.id} • ${u.email}`,
                id: `.listuser ${u.id}`
            })

        }

        await conn.sendMessage(m.chat, {
            text: `👤 *Panel User Manager*

Silahkan pilih user dari menu di bawah untuk melihat detail akun panel.`,
            footer: "Panel System",
            buttons: [{
                buttonId: 'action',
                buttonText: {
                    displayText: 'Pilih User'
                },
                type: 4,
                nativeFlowInfo: {
                    name: 'single_select',
                    paramsJson: JSON.stringify({
                        title: "List User Panel",
                        sections: [{
                            title: "Panel Users",
                            rows
                        }]
                    })
                }
            }],
            headerType: 1,
            viewOnce: true
        }, {
            quoted: m
        })

        await m.react("✅")

        return
    }

    // ================= DETAIL USER =================

    let target = null

    for (let user of users) {

        let u = user.attributes

        if (Number(text) === u.id) target = u

    }

    if (!target) {
        await m.react("❌")
        return m.reply("❌ User tidak ditemukan.")
    }

    let teks = `
╭───〔 👤 PANEL USER DETAIL 〕───╮

🆔 User ID
${target.id}

🧬 UUID
${target.uuid}

👤 Username
${target.username}

📛 Nama
${target.first_name} ${target.last_name}

📧 Email Login
${target.email}

🛡️ Root Admin
${target.root_admin ? "Yes" : "No"}

🔐 2FA Status
${target["2fa"] ? "Enabled" : "Disabled"}

📅 Created
${target.created_at}

🕒 Last Update
${target.updated_at}

────────────────────

⚙️ Informasi
Akun ini merupakan bagian dari sistem panel hosting.
Pastikan hanya memberikan akses kepada orang yang dipercaya.

Jika akun ini tidak lagi digunakan,
hapus akun untuk menjaga keamanan server.

╰────────────────────╯
`

    await conn.sendMessage(m.chat, {
        text: teks,
        buttons: [{
            buttonId: `.deluser ${target.id}`,
            buttonText: {
                displayText: "🗑 Delete User"
            },
            type: 1
        }],
        headerType: 1
    }, {
        quoted: m
    })

    await m.react("✅")

}

handler.command = ["listuser"]
handler.tags = ["panel"]
handler.owner = true

export default handler