let handler = async (m, { conn, db }) => {
    let user = db.list().user[m.sender];
    let name = m.name || "User";
    
    let caption = `╭─❍ *USER BALANCE* ❍─
│
│ 👤 *Nama:* ${name}
│ 💰 *Saldo:* Rp ${(user.saldo || 0).toLocaleString()}
│ 🎫 *Status:* ${user.premium?.status ? "Premium" : "Gratis"}
│ 📊 *Limit:* ${user.limit}
│
╰─────────────────────❍
_Gunakan *.deposit* untuk isi saldo_
_Gunakan *.order* untuk beli pulsa/data_`;

    await m.reply(caption);
};

handler.help = ['balance', 'saldo'];
handler.tags = ['store'];
handler.command = /^(balance|saldo|mybalance)$/i;

export default handler;
