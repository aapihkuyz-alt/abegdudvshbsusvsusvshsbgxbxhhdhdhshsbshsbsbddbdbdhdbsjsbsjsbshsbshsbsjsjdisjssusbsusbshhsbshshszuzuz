import axios from 'axios';
import {
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    proto
} from "baileys";

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    Func,
    db
}) => {
    // 1. LOGIKA CEK STATUS (Berdasarkan Bagian E: Transaction Detail API)
    if (command === 'cekdepo') {
        let [order_id, amount_raw] = text.split('|');
        if (!order_id || !amount_raw) return m.reply("❌ Data transaksi tidak valid.");
        
        await m.react("⏳");
        try {
            const res = await axios.get(`https://app.pakasir.com/api/transactiondetail?project=${global.pakasirSlug}&amount=${amount_raw}&order_id=${order_id}&api_key=${global.pakasirKey}`);
            const data = res.data.transaction;

            if (data.status === 'completed') {
                // ... (success logic)
            } else {
                // TAMPILKAN TOMBOL CEK LAGI JIKA PENDING
                const msg = generateWAMessageFromContent(m.chat, {
                    interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                        body: proto.Message.InteractiveMessage.Body.fromObject({
                            text: `⏳ *TRANSAKSI PENDING*\n\n🆔 *Order ID:* ${order_id}\n💰 *Nominal:* Rp ${parseInt(amount_raw).toLocaleString()}\n📊 *Status:* MENUNGGU PEMBAYARAN\n\n_Silakan selesaikan pembayaran. Jika sudah bayar, tunggu 1-3 menit lalu klik tombol di bawah._`
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: global.botname }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "🔄 Cek Lagi",
                                        id: `${usedPrefix}cekdepo ${order_id}|${amount_raw}`
                                    })
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "❌ Batalkan",
                                        id: `${usedPrefix}bataldepo ${order_id}|${amount_raw}`
                                    })
                                }
                            ]
                        })
                    })
                }, { quoted: m });

                return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
            }
        } catch (e) {
            return m.reply("❌ Transaksi tidak ditemukan atau belum dibayar.");
        }
    }

    // 2. LOGIKA BATALKAN (Berdasarkan Bagian C.5: Transaction Cancel)
    if (command === 'bataldepo') {
        let [order_id, amount_raw] = text.split('|');
        try {
            await axios.post('https://app.pakasir.com/api/transactioncancel', {
                project: global.pakasirSlug,
                order_id: order_id,
                amount: parseInt(amount_raw),
                api_key: global.pakasirKey
            });
            return m.reply(`✅ *TRANSAKSI DIBATALKAN*\n\n🆔 *Order ID:* ${order_id}`);
        } catch (e) {
            return m.reply("❌ Gagal membatalkan transaksi.");
        }
    }

    // 3. LOGIKA UTAMA DEPOSIT (Berdasarkan Bagian C.2: Transaction create)
    if (!text) return m.reply(`📌 Masukkan nominal deposit.\nContoh: *${usedPrefix + command} 10000*`);

    let amount = parseInt(text.replace(/[^0-9]/g, ''));
    if (isNaN(amount) || amount < 1000) return m.reply("❌ Minimal deposit adalah Rp 1.000");

    await m.react("⏳");

    try {
        let order_id = `DEP-${Date.now()}`;
        
        const res = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
            project: global.pakasirSlug,
            order_id: order_id,
            amount: amount,
            api_key: global.pakasirKey
        });

        const payData = res.data.payment;
        const qrString = payData.payment_number;
        
        // Generate QR Image dari QR String (Gunakan API QRServer)
        const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(qrString)}&size=512x512`;
        const qrBuffer = await Func.fetchBuffer(qrImageUrl);

        let caption = `╭─❍ *DEPOSIT SALDO* ❍─
│
│ 💳 *Nominal:* Rp ${amount.toLocaleString()}
│ 🆔 *Order ID:* ${order_id}
│ ⏳ *Expired:* ${payData.expired_at.replace('T', ' ').split('.')[0]}
│
├─────────────────────
│ 📌 *Instruksi:*
│ 1. Scan QRIS di atas menggunakan E-Wallet.
│ 2. Saldo masuk otomatis 1-3 menit setelah bayar.
╰─────────────────────❍`;

        // Jika ini Telegram (conn.waUploadToServer tidak ada)
        if (!conn.waUploadToServer) {
            return await conn.sendMessage(m.chat, {
                image: qrBuffer,
                caption: caption + `\n\n📌 *Note:* Setelah bayar, ketik *.cekdepo ${order_id}|${amount}*`
            }, { quoted: m });
        }

        const mediaQr = await prepareWAMessageMedia({ image: qrBuffer }, { upload: conn.waUploadToServer });

        const msg = generateWAMessageFromContent(m.chat, {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: "💠 *FREEZEEHOST PAYMENT*",
                    hasMediaAttachment: true,
                    imageMessage: mediaQr.imageMessage
                }),
                body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Powered by Pakasir" }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "🔍 Cek Status",
                                id: `${usedPrefix}cekdepo ${order_id}|${amount}`
                            })
                        },
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "❌ Batalkan",
                                id: `${usedPrefix}bataldepo ${order_id}|${amount}`
                            })
                        }
                    ]
                })
            })
        }, { quoted: m });

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
        await m.react("✅");

    } catch (e) {
        console.error(e);
        m.reply(`❌ *Gagal:* ${e.response?.data?.message || e.message}`);
    }
};

handler.help = ['deposit <nominal>'];
handler.tags = ['store'];
handler.command = /^(deposit|depo|topup|cekdepo|bataldepo)$/i;

export default handler;
