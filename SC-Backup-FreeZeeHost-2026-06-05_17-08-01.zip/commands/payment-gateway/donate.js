import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    if (!text)
        return m.reply("Contoh:\n#donate 15000")

    const amount = parseInt(text)
    if (isNaN(amount) || amount < 1000)
        return m.reply("❌ Minimal donasi 1000")

    global.saweria = global.saweria || {}

    if (global.saweria[m.sender])
        return m.reply("⚠️ Kamu masih punya transaksi aktif.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "💳",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/saweria-create", {
                params: {
                    userid: "8d263100-bac9-4cfc-b0f3-4e0af74c25bb",
                    amount,
                    message: `Donation from ${m.pushName}`,
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status)
            throw new Error("Gagal membuat invoice")

        const pay = data.data

        const caption = `
╭━━━〔 💳 DONASI QRIS 〕━━━⬣
┃ 💰 Nominal      : Rp${amount.toLocaleString()}
┃ 🏷 Total Bayar  : Rp${pay.amount.toLocaleString()}
┃ 🆔 Invoice ID   : ${pay.id}
┃
┃ ⏳ Expired      : ${pay.expired_at}
┃
┃ 📌 Silakan scan QR di atas
┃ menggunakan aplikasi e-wallet / m-banking
┃
┃ ⚠️ Jangan keluar sebelum bayar
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

        const qrBuffer = Buffer.from(
            pay.qr_image.split(",")[1],
            "base64"
        )

        const msg = await conn.sendMessage(
            m.chat, {
                image: qrBuffer,
                caption
            }, {
                quoted: m
            }
        )

        global.saweria[m.sender] = {
            invoice: pay.id,
            messageId: msg.key.id,
            expired: pay.expired_at,
            timeout: setTimeout(async () => {

                if (!global.saweria[m.sender]) return

                await conn.sendMessage(m.chat, {
                    text: `
╭━━━〔 ⌛ EXPIRED 〕━━━⬣
┃ Invoice telah kedaluwarsa.
┃
┃ Silakan buat ulang jika
┃ ingin melakukan pembayaran.
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()
                })

                delete global.saweria[m.sender]

            }, 10 * 60 * 1000) // 10 menit
        }

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal membuat QRIS.")
    }
}

handler.command = ["donate"]
handler.tags = ["payment"]
handler.help = ["donate <amount>"]

export default handler