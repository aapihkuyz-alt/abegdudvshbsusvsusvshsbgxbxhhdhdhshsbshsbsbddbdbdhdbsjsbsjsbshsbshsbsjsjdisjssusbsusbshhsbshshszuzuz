import axios from 'axios';
import crypto from 'crypto';

let handler = async (m, { conn, text, usedPrefix, command, db }) => {
    if (global.okID === "ISI_ID_MERCHANT_OKECONNECT_DISINI") {
        return m.reply("❌ API OrderKuota belum dikonfigurasi oleh owner.");
    }

    if (!text) {
        return m.reply(`╭─❍ *PPOB STORE* ❍─
│
│ 📱 *Pulsa / Data / Token*
│
├─────────────────────
│ 📑 *Cara Order:*
│ *${usedPrefix + command} list*
│ (Untuk melihat daftar produk)
│
│ *${usedPrefix + command} <kode_produk> <no_tujuan>*
│ (Untuk membeli produk)
│
│ 💡 Contoh:
│ *${usedPrefix + command} S5 08123456789*
╰─────────────────────❍`);
    }

    let [cmd, target] = text.split(' ');

    // 1. LIHAT DAFTAR PRODUK (Dummy/Static List for Speed, or API call)
    if (cmd.toLowerCase() === 'list') {
        await m.react("⏳");
        try {
            // Kita hit API OkeConnect untuk ambil harga real-time
            // Biasanya butuh signature: md5(ID + KEY + 'pricelist')
            let sign = crypto.createHash('md5').update(global.okID + global.okKey + 'pricelist').digest('hex');
            
            // Note: Endpoint OkeConnect bervariasi, ini pola umumnya
            const res = await axios.post('https://okeconnect.com/api/json/', {
                method: 'pricelist',
                id: global.okID,
                sign: sign
            });

            if (res.data?.status === 'failed') throw res.data.message;

            let products = res.data?.data || [];
            let txt = `╭─❍ *DAFTAR HARGA* ❍─\n│\n`;
            products.slice(0, 50).forEach(p => {
                txt += `│ ▫️ *${p.code}* - ${p.name}\n│    Harga: Rp ${parseInt(p.price).toLocaleString()}\n`;
            });
            txt += `│\n╰─────────────────────❍\n_Gunakan *${usedPrefix + command} <kode> <nomor>* untuk beli._`;
            
            m.reply(txt);
            await m.react("✅");
        } catch (e) {
            console.error(e);
            m.reply("❌ Gagal mengambil daftar harga. Silakan coba lagi nanti.");
        }
        return;
    }

    // 2. PROSES ORDER
    if (!target) return m.reply(`📌 Contoh: *${usedPrefix + command} S5 08123456789*`);

    let productCode = cmd.toUpperCase();
    let customerNo = target.replace(/[^0-9]/g, '');
    let user = db.list().user[m.sender];

    await m.react("⏳");

    try {
        // Cek harga dulu (untuk potong saldo user)
        let signPrice = crypto.createHash('md5').update(global.okID + global.okKey + 'pricelist').digest('hex');
        const resPrice = await axios.post('https://okeconnect.com/api/json/', {
            method: 'pricelist',
            id: global.okID,
            sign: signPrice
        });

        let product = resPrice.data?.data?.find(p => p.code === productCode);
        if (!product) return m.reply("❌ Kode produk tidak valid.");

        let price = parseInt(product.price);
        let markup = 500; // Untung buat Abang
        let finalPrice = price + markup;

        if (user.saldo < finalPrice) {
            return m.reply(`❌ Saldo Abang tidak cukup.\n💰 Saldo: Rp ${user.saldo.toLocaleString()}\n🏷️ Harga: Rp ${finalPrice.toLocaleString()}\n\nKetik *.deposit* untuk isi saldo.`);
        }

        // Eksekusi Transaksi ke OrderKuota
        let ref_id = `ORD-${Date.now()}`;
        let signOrder = crypto.createHash('md5').update(global.okID + global.okKey + ref_id).digest('hex');

        const resOrder = await axios.post('https://okeconnect.com/api/json/', {
            method: 'order',
            id: global.okID,
            product: productCode,
            dest: customerNo,
            refID: ref_id,
            sign: signOrder
        });

        if (resOrder.data?.status === 'success' || resOrder.data?.status === 'pending') {
            // Potong saldo user
            user.saldo -= finalPrice;
            await db.save();

            let report = `✅ *ORDER BERHASIL DIAJUKAN*

🆔 *Ref ID:* ${ref_id}
📱 *Produk:* ${product.name}
📞 *Tujuan:* ${customerNo}
💰 *Total Bayar:* Rp ${finalPrice.toLocaleString()}
📊 *Status:* ${resOrder.data?.status.toUpperCase()}

_Saldo Abang sekarang: Rp ${user.saldo.toLocaleString()}_`;
            
            m.reply(report);
            await m.react("✅");
        } else {
            throw resOrder.data?.message || "Transaksi ditolak oleh provider.";
        }

    } catch (e) {
        console.error(e);
        m.reply(`❌ *Gagal Order:* ${e.message || e}`);
        await m.react("❌");
    }
};

handler.help = ['order <kode> <nomor>', 'store'];
handler.tags = ['store'];
handler.command = /^(order|beli|store)$/i;

export default handler;
