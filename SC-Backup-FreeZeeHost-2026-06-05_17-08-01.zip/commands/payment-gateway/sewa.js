import axios from 'axios';
import {
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    proto
} from "baileys";

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    Func,
    db
}) => {
    // 1. LOGIKA PROSES PEMILIHAN (TRIGGER DARI BUTTON)
    if (command === 'sewa_exec') {
        let [name, number, days, type] = text.split('|');
        if (!name || !number || !days || !type) return m.reply("❌ Data sewa tidak valid.");

        // Hitung Harga dengan Diskon & Permanent
        let amount;
        let durationMs;
        const d = parseInt(days);

        if (d === 0) { // PERMANENT
            amount = 30000;
            durationMs = 0;
        } else {
            // Rp 1000/hari, diskon jika > 5 hari (misal jadi 800/hari)
            const rate = d > 5 ? 800 : 1000;
            amount = d * rate;
            durationMs = d * 24 * 60 * 60 * 1000;
        }

        const cleanNumber = number.replace(/[^0-9]/g, "");

        await m.react("⏳");

        try {
            let order_id = `SEWA-${type.toUpperCase()}-${Date.now()}`;
            
            const res = await axios.post('https://app.pakasir.com/api/transactioncreate/qris', {
                project: global.pakasirSlug,
                order_id: order_id,
                amount: amount,
                api_key: global.pakasirKey
            });

            const payData = res.data.payment;
            const qrString = payData.payment_number;
            const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?data=${encodeURIComponent(qrString)}&size=512x512`;
            const qrBuffer = await Func.fetchBuffer(qrImageUrl);

            let caption = `╭─❍ *PEMBAYARAN SEWA BOT* ❍─
│
│ 👤 *Nama:* ${name}
│ 📱 *Nomor:* ${cleanNumber}
│ 📦 *Tipe:* ${type.toUpperCase()}
│ ⏳ *Durasi:* ${d === 0 ? "PERMANEN" : d + " Hari"}
│ 💳 *Nominal:* Rp ${amount.toLocaleString()}
│ 🆔 *Order ID:* ${order_id}
│
├─────────────────────
│ 📌 *Instruksi:*
│ 1. Scan QRIS di atas untuk membayar.
│ 2. Akses aktif + Pairing otomatis setelah klik "Cek Status".
╰─────────────────────❍`;

            // Jika ini Telegram (conn.waUploadToServer tidak ada)
            if (!conn.waUploadToServer) {
                return await conn.sendMessage(m.chat, {
                    image: qrBuffer,
                    caption: caption + `\n\n📌 *Note:* Setelah bayar, ketik *.ceksewa ${order_id}|${amount}|${type}|${durationMs}|${cleanNumber}|${name}*`
                }, { quoted: m });
            }

            const mediaQr = await prepareWAMessageMedia({ image: qrBuffer }, { upload: conn.waUploadToServer });

            const msg = generateWAMessageFromContent(m.chat, {
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    header: proto.Message.InteractiveMessage.Header.fromObject({
                        title: "💠 *FREEZEEHOST PAYMENT*",
                        hasMediaAttachment: true,
                        imageMessage: mediaQr.imageMessage
                    }),
                    body: proto.Message.InteractiveMessage.Body.fromObject({ text: caption }),
                    footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: "Powered by Pakasir" }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [
                            {
                                name: "quick_reply",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "🔍 Cek Status",
                                    id: `${usedPrefix}ceksewa ${order_id}|${amount}|${type}|${durationMs}|${cleanNumber}|${name}`
                                })
                            }
                        ]
                    })
                })
            }, { quoted: m });

            return await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

        } catch (e) {
            console.error(e);
            return m.reply(`❌ *Gagal:* ${e.response?.data?.message || e.message}`);
        }
    }

    // 2. LOGIKA CEK STATUS SEWA + PAIRING
    if (command === 'ceksewa') {
        let [order_id, amount_raw, type, duration, cleanNumber, name] = text.split('|');
        if (!order_id || !amount_raw) return m.reply("❌ Data transaksi tidak valid.");
        
        await m.react("⏳");
        try {
            const res = await axios.get(`https://app.pakasir.com/api/transactiondetail?project=${global.pakasirSlug}&amount=${amount_raw}&order_id=${order_id}&api_key=${global.pakasirKey}`);
            const data = res.data.transaction;

            if (data.status === 'completed') {
                const targetJid = cleanNumber + "@s.whatsapp.net";
                let user = db.get("user", targetJid);
                
                if (!user.deposit_history) user.deposit_history = [];
                if (user.deposit_history.includes(order_id)) return m.reply("ℹ️ Transaksi sudah diproses.");

                const now = Date.now();
                const ms = parseInt(duration);

                // A. Aktivasi Akses di DB
                if (type === "prem") {
                    if (!user.premium) user.premium = { status: false, expired: 0 };
                    user.premium.status = true;
                    // Jika ms = 0 maka permanen
                    user.premium.expired = ms === 0 ? 0 : (user.premium.expired > now ? user.premium.expired : now) + ms;
                } else {
                    if (!user.owner_access) user.owner_access = { status: false, expired: 0 };
                    user.owner_access.status = true;
                    user.owner_access.expired = ms === 0 ? 0 : (user.owner_access.expired > now ? user.owner_access.expired : now) + ms;
                }

                user.deposit_history.push(order_id);
                await db.save();

                const expStr = ms === 0 ? "PERMANEN" : new Date(Date.now() + ms).toLocaleString();
                await m.reply(`✅ *PEMBAYARAN DITERIMA!*\n\nAkses ${type.toUpperCase()} telah diaktifkan untuk @${cleanNumber}.\n📅 *Masa Aktif:* ${expStr}\n\n🚀 *Memulai proses Pairing Bot...* \nMohon tunggu kode pairing muncul.`, null, { mentions: [targetJid] });

                // B. Proses Pairing (Jadi Bot)
                try {
                    const sessionName = `sewa_${cleanNumber}_${Date.now().toString(36)}`;
                    const childConn = await global.startSession(sessionName, cleanNumber, { authMethod: "pairing" });
                    
                    const pCode = childConn?.pairingCode;
                    if (pCode) {
                        const finalPCode = pCode.match(/.{1,4}/g)?.join("-") || pCode;
                        const pairingMsg = `🔑 *KODE PAIRING ANDA* 🔑\n\nID: ${finalPCode}\n\nMasukkan kode di atas pada perangkat yang ingin Anda jadikan Bot.\n\n*Cara:* \nWA Web -> Tautkan Perangkat -> Tautkan dengan nomor telepon.`;
                        
                        await m.reply(pairingMsg);
                        await conn.sendMessage(targetJid, { text: pairingMsg });
                    } else {
                        await m.reply("❌ Gagal mendapatkan kode pairing secara otomatis. Silakan hubungi Owner untuk bantuan manual.");
                    }
                } catch (pairErr) {
                    console.error("Pairing Error:", pairErr);
                    await m.reply("⚠️ Akses sudah aktif, tapi sistem pairing sedang sibuk. Silakan coba login manual atau hubungi owner.");
                }

            } else {
                return m.reply("⏳ *TRANSAKSI PENDING*\n\nMohon bayar dulu, lalu cek status lagi.");
            }
        } catch (e) {
            console.error(e);
            return m.reply("❌ Transaksi belum dibayar atau tidak ditemukan.");
        }
    }

    // 3. LOGIKA UTAMA (.sewabot nama,nomor,hari)
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} MyBot,628xxx,30*`);

    let [name, number, days] = text.split(',').map(v => v.trim());
    if (!name || !number || !days || isNaN(days)) return m.reply(`📌 Format salah! Contoh: *${usedPrefix + command} NamaBot,628xxx,30*`);

    const cleanNumber = number.replace(/[^0-9]/g, "");
    if (cleanNumber.length < 10) return m.reply("❌ Nomor tidak valid.");

    const d = parseInt(days);
    // Logic Harga: 1k/hari, diskon jika > 5 hari, 30k permanen
    let price;
    let priceInfo = "Rp1.000 / Hari";
    
    if (d > 0) {
        if (d > 5) {
            price = d * 800; // Diskon jadi 800/hari
            priceInfo = "Rp800 / Hari (Diskon > 5 Hari)";
        } else {
            price = d * 1000;
        }
    } else {
        price = 30000;
    }

    const confirmText = `🤖 *KONFIRMASI SEWA BOT* 🤖\n\n📝 *Nama:* ${name}\n📱 *Nomor:* ${cleanNumber}\n⏳ *Durasi:* ${days === "0" ? "PERMANEN" : days + " Hari"}\n💰 *Total Harga:* Rp ${price.toLocaleString()}\n\n🎁 *Promo:* 30K UNTUK PERMANEN!\n\nSilakan pilih jenis akses yang diinginkan:`;

    // Jika ini Telegram (conn.waUploadToServer tidak ada)
    if (!conn.waUploadToServer) {
        return m.reply(`${confirmText}\n\n📌 *Pilihan Akses:*\n1. Ketik: *${usedPrefix}sewa_exec ${name}|${cleanNumber}|${days}|prem* (Premium)\n2. Ketik: *${usedPrefix}sewa_exec ${name}|${cleanNumber}|${days}|own* (Owner)\n3. Ketik: *${usedPrefix}sewa_exec ${name}|${cleanNumber}|0|own* (Permanen 30K)`);
    }

    const msg = generateWAMessageFromContent(m.chat, {
        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
            body: proto.Message.InteractiveMessage.Body.fromObject({
                text: confirmText
            }),
            footer: proto.Message.InteractiveMessage.Footer.fromObject({ text: `Harga Normal: ${priceInfo}` }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                buttons: [
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "💎 Premium",
                            id: `${usedPrefix}sewa_exec ${name}|${cleanNumber}|${days}|prem`
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "👑 Owner",
                            id: `${usedPrefix}sewa_exec ${name}|${cleanNumber}|${days}|own`
                        })
                    },
                    {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({
                            display_text: "🛡️ PERMANEN (30K)",
                            id: `${usedPrefix}sewa_exec ${name}|${cleanNumber}|0|own`
                        })
                    }
                ]
            })
        })
    }, { quoted: m });

    await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id });
};

handler.help = ['sewabot <nama>,<nomor>,<hari>'];
handler.tags = ['store', 'main'];
handler.command = /^(sewabot|sewa|buysewa|sewa_exec|ceksewa)$/i;

export default handler;