import axios from "axios"

const handler = async (m, {
    conn,
    text
}) => {

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    if (!text)
        return m.reply("❌ Masukkan kata mimpi.\n\nContoh:\n#artimimpi belanja")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🔮",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/artimimpi", {
                params: {
                    q: text,
                    apikey: global.neoxr
                },
                timeout: 20000
            }
        )

        if (!data?.status || !data?.data)
            throw new Error("Arti mimpi tidak ditemukan")

        const result = data.data.result || "Tidak tersedia"
        const solusi = data.data.solusi || "Tidak tersedia"

        const caption = `
╭━━━〔 🔮 PRIMBON ARTI MIMPI 〕━━━⬣
┃ 🌙 Mimpi tentang :
┃ ➜ *${text}*
┃
┣━━━━━━━━━━━━━━━━━━⬣
┃ 📖 Tafsir Mimpi :
┃
┃ ${result}
┃
┣━━━━━━━━━━━━━━━━━━⬣
┃ 🧿 Saran / Solusi :
┃
┃ ${solusi}
┃
┣━━━━━━━━━━━━━━━━━━⬣
┃ ⚠️ Catatan :
┃ Tafsir ini hanyalah
┃ interpretasi tradisional.
┃ Percaya atau tidak
┃ kembali pada keyakinanmu.
╰━━━━━━━━━━━━━━━━━━⬣

✨ Primbon Nusantara System
`.trim()

        await conn.sendMessage(
            m.chat, {
                text: caption
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✨",
                key: m.key
            }
        })

    } catch (e) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil arti mimpi.")
    }
}

handler.command = ["artimimpi"]
handler.tags = ["primbon"]
handler.help = ["artimimpi <kata>"]

export default handler