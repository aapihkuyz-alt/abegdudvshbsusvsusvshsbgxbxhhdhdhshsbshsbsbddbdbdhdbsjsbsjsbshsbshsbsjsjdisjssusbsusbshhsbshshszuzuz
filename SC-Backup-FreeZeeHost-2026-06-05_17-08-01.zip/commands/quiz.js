let handler = async (m, {
    conn
}) => {

    let options = ["162", "150", "148", "gtau"]

    await conn.sendMessage(m.chat, {
        poll: {
            name: "brp tb ak?",
            values: options,
            selectableCount: 1
        },
        messageContextInfo: {
            pollCreationMessage: {
                name: "brp tb ak?",
                options: options.map(v => ({
                    optionName: v
                })),
                selectableOptionsCount: 1,
                correctAnswer: 0 // index jawaban benar
            }
        }
    })

}

handler.command = ["quizzz"]

export default handler