import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply("Contoh:\n.apk whatsapp")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔎",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/apk", {
                params: {
                    q: text,
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data?.length)
            throw new Error("Tidak ditemukan")

        // Paksa hanya 5 hasil
        const results = data.data.slice(0, 5)

        const buttons = results.map((v, i) => ({
            buttonId: `.apkget ${text}|${i + 1}`,
            buttonText: {
                displayText: `${i + 1}. ${v.name}`
            },
            type: 1
        }))

        await conn.sendMessage(
            m.chat, {
                text: `📦 *Hasil Pencarian APK*\n\nQuery : ${text}\n\nMenampilkan 5 hasil teratas 👇`,
                buttons,
                headerType: 1
            }, {
                quoted: m
            }
        )

    } catch (e) {
        console.error("APK SEARCH ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ APK tidak ditemukan atau API error.")
    }
}

handler.help = ["apk <query>"]
handler.tags = ["search"]
handler.command = ["apk"]

export default handler