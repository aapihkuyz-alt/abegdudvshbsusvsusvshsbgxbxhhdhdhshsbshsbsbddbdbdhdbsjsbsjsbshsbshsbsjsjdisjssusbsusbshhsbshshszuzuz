import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply("Contoh:\n.chord komang")

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🎸",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/chord", {
                params: {
                    q: text,
                    apikey: global.neoxr
                }
            }
        )

        if (!data.status || !data.data?.chord)
            throw new Error("Chord tidak ditemukan")

        const chord = data.data.chord

        // kalau terlalu panjang, potong biar tidak error panjang message
        const maxLength = 3500
        const output =
            chord.length > maxLength ?
            chord.slice(0, maxLength) + "\n\n... (Chord dipotong karena terlalu panjang)" :
            chord

        await conn.sendMessage(
            m.chat, {
                text: `🎶 *Chord: ${text}*\n\n${output}`
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✔️",
                key: m.key
            }
        })

    } catch (e) {
        console.error("CHORD ERROR:", e)
        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
        m.reply("❌ Chord tidak ditemukan atau API error.")
    }
}

handler.help = ["chord <judul lagu>"]
handler.tags = ["music"]
handler.command = ["chord"]

export default handler