import axios from "axios"

const handler = async (m, { conn, text }) => {

    if (!text)
        return m.reply("Contoh:\n.cpudetail <id_cpu>")

    if (!global.neoxr)
        return m.reply("API key Neoxr belum diisi di global.neoxr")

    try {

        await conn.sendMessage(m.chat, {
            react: { text: "⚙️", key: m.key }
        })

        const { data: res } = await axios.get(
            "https://api.neoxr.eu/api/cpu-get",
            {
                params: {
                    id: text.trim(),
                    apikey: global.neoxr
                }
            }
        )

        if (!res.status || !res.data)
            return m.reply("Detail CPU tidak ditemukan.")

        const cpu = res.data

        // ===== FORMAT SPESIFIKASI =====
        let specText = ""

        for (let section of cpu.spesification) {

            specText += `\n╭───〔 ${section.name.toUpperCase()} 〕\n`

            for (let item of section.data) {
                specText += `│ ${item.name} : ${item.value}\n`
            }

            specText += `╰────────────────────\n`
        }

        const caption = `
╭━━━〔 🧠 CPU DETAIL 〕━━━⬣

📌 Name :
➜ ${cpu.name}

📝 Description :
${cpu.description.slice(0, 600)}...

${specText}

╰━━━━━━━━━━━━━━━━━━━━━━⬣
        `.trim()

        await conn.sendMessage(
            m.chat,
            {
                image: { url: cpu.image },
                caption
            },
            { quoted: m }
        )

        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (e) {

        console.error("CPU DETAIL ERROR:", e.response?.data || e.message)

        await conn.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })

        m.reply("❌ Gagal mengambil detail CPU.")
    }
}

handler.command = ["cpudetail"]

export default handler