import axios from "axios"

const handler = async (m, { conn, text }) => {

    if (!text)
        return m.reply("Contoh:\n.cpu ryzen 7")

    if (!global.neoxr)
        return m.reply("API key Neoxr belum diisi di global.neoxr")

    try {

        await conn.sendMessage(m.chat, {
            react: { text: "🧠", key: m.key }
        })

        const { data: res } = await axios.get(
            "https://api.neoxr.eu/api/cpu",
            {
                params: {
                    q: text,
                    apikey: global.neoxr
                }
            }
        )

        if (!res.status || !res.data.length)
            return m.reply("CPU tidak ditemukan.")

        const results = res.data

        const rows = results.map((v, i) => ({
            title: `${i + 1}. ${v.name}`,
            description: `${v.cores} • ${v.clock} • ${v.process}`,
            id: `.cpudetail ${v.id}`
        }))

        const caption = `
╭━━━〔 🧠 CPU SEARCH ENGINE 〕━━━⬣
┃
┃ 🔎 Query :
┃ ➜ ${text}
┃
┃ 📊 Total ditemukan :
┃ ➜ ${res.total} CPU
┃
┃ 📌 Pilih salah satu CPU
┃ untuk melihat detail lengkap.
┃
┃ Data mencakup:
┃ • Codename
┃ • Core / Thread
┃ • Clock Speed
┃ • Socket
┃ • Fabrication Process
┃ • L3 Cache
┃ • TDP
┃ • Release Date
┃
╰━━━━━━━━━━━━━━━━━━━━━━⬣
        `.trim()

        await conn.sendMessage(
            m.chat,
            {
                text: caption,
                footer: "Powered by Neoxr API",
                buttons: [{
                    buttonId: "cpu-list",
                    buttonText: { displayText: "📋 Lihat Daftar CPU" },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "Daftar CPU",
                            sections: [{
                                title: `Total: ${results.length} CPU`,
                                rows
                            }]
                        })
                    }
                }]
            },
            { quoted: m }
        )

        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (e) {
        console.error("CPU SEARCH ERROR:", e.response?.data || e.message)

        await conn.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })

        m.reply("❌ Gagal mengambil data CPU.")
    }
}

handler.help = ["cpu <query>"]
handler.tags = ["search"]
handler.command = ["cpu"]

export default handler