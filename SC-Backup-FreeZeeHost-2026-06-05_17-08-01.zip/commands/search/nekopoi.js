import axios from 'axios'
import * as cheerio from 'cheerio'

/* ================== SEARCH ================== */
async function NekopoiSearch(query, page = 1) {
    const baseUrl = 'https://nekopoi.care/search/'
    const results = []

    try {
        const url =
            page === 1 ?
            `${baseUrl}${encodeURIComponent(query)}` :
            `${baseUrl}${encodeURIComponent(query)}/page/${page}/?${encodeURIComponent(query)}`

        const response = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        })

        const $ = cheerio.load(response.data)
        const items = $('div.result ul li')
        if (!items.length) return results

        items.each((i, el) => {
            const titleEl = $(el).find('h2 a')
            const title = titleEl.text().trim()
            const url = titleEl.attr('href')
            const thumbnail = $(el).find('img').attr('src')

            if (title && url) {
                results.push({
                    title,
                    url,
                    thumbnail
                })
            }
        })

        return results
    } catch (e) {
        console.error('Error Nekopoi Search:', e.message)
        return []
    }
}

/* ================== DETAIL ================== */
async function NekopoiDetail(url) {
    try {
        const response = await axios.get(url, {
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
        })

        const $ = cheerio.load(response.data)

        const result = {
            title: $('div.eroinfo h1').text().trim(),
            parody: '',
            producer: '',
            duration: '',
            views: '',
            date: '',
            thumbnail: $('div.thm img').attr('src') || '',
            sizes: {},
            streams: [],
            downloads: {}
        }

        $('div.konten p').each((i, el) => {
            const text = $(el).text().trim()

            if (text.startsWith('Parody'))
                result.parody = text.replace('Parody : ', '').trim()
            else if (text.startsWith('Producers'))
                result.producer = text.replace('Producers : ', '').trim()
            else if (text.startsWith('Duration'))
                result.duration = text.replace('Duration : ', '').trim()
            else if (text.includes('Size')) {
                const matches = text.match(/(\d+P)\s*:\s*([\d.]+mb)/gi)
                if (matches) {
                    matches.forEach(m => {
                        const [res, size] = m.split(' : ')
                        result.sizes[res.trim()] = size.trim()
                    })
                }
            }
        })

        const viewsDate = $('div.eroinfo p').text().trim()
        result.views =
            viewsDate.match(/Dilihat\s+([\d.]+)\s+kali/)?.[1] || ''
        result.date = viewsDate.match(/\/\s+(.+)/)?.[1] || ''

        $('div#show-stream iframe').each((i, el) => {
            const src = $(el).attr('src')
            if (src)
                result.streams.push({
                    name: `Stream ${i + 1}`,
                    url: src
                })
        })

        $('div.boxdownload div.liner').each((i, el) => {
            const res = $(el)
                .find('div.name')
                .text()
                .match(/\[(\d+p)\]/)?.[1]

            if (!res) return

            const links = {
                normal: [],
                ouo: []
            }

            $(el)
                .find('div.listlink p a')
                .each((_, a) => {
                    const href = $(a).attr('href')
                    const name = $(a).text().trim()
                    if (!href) return

                    if (href.includes('ouo.io'))
                        links.ouo.push({
                            name,
                            url: href
                        })
                    else links.normal.push({
                        name,
                        url: href
                    })
                })

            result.downloads[res] = links
        })

        return result
    } catch (e) {
        console.error('Error Nekopoi Detail:', e.message)
        return null
    }
}

/* ================== HANDLER ================== */
let handler = async (m, {
    args,
    schnee
}) => {
    const sub = (args[0] || '').toLowerCase()

    switch (sub) {
        case 'search': {
            const keyword = args.slice(1).join(' ')
            if (!keyword)
                return m.reply(
                    'Masukkan judul hentai!\nContoh: .nekopoi search Alya'
                )

            m.reply('Mencari di Nekopoi...')

            const results = await NekopoiSearch(keyword)
            if (!results.length) return m.reply('Tidak ditemukan.')

            const album = []

            for (let i = 0; i < Math.min(results.length, 5); i++) {
                const item = results[i]
                album.push({
                    image: {
                        url: item.thumbnail
                    },
                    caption: `*${item.title}*\n\n` +
                        ` Lihat detail:\n` +
                        `.nekopoi detail ${item.url}`
                })
            }

            await schnee.sendAlbum(m.chat, album, {
                quoted: m
            })
            break
        }

        case 'detail': {
            const url = args[1]
            if (!url || !url.startsWith('http'))
                return m.reply(
                    'Link tidak valid!\nContoh:\n.nekopoi detail https://nekopoi.care/...'
                )

            m.reply('Mengambil detail..')

            const data = await NekopoiDetail(url)
            if (!data) return m.reply('Gagal mengambil detail.')

            let teks = `*${data.title}*\n\n`
            teks += `• Parody: ${data.parody}\n`
            teks += `• Producer: ${data.producer}\n`
            teks += `• Durasi: ${data.duration}\n`
            teks += `• Views: ${data.views}\n`
            teks += `• Tanggal: ${data.date}\n\n`

            teks += `*Ukuran File:*\n`
            for (let [r, s] of Object.entries(data.sizes)) {
                teks += `- ${r}: ${s}\n`
            }

            teks += `\n*Streaming:*`
            if (data.streams.length) {
                data.streams.forEach(v => {
                    teks += `\n- ${v.name}: ${v.url}`
                })
            } else {
                teks += '\nTidak tersedia.'
            }

            teks += `\n\n*Download:*\n`
            for (let [r, l] of Object.entries(data.downloads)) {
                teks += `\n*${r}*\n`
                l.normal.forEach(v => (teks += `- ${v.name}: ${v.url}\n`))
                l.ouo.forEach(v => (teks += `- ${v.name}: ${v.url}\n`))
            }

            await schnee.sendAlbum(
                m.chat,
                [{
                    image: {
                        url: data.thumbnail
                    },
                    caption: teks
                }], {
                    quoted: m
                }
            )
            break
        }

        default:
            m.reply(
                'Gunakan:\n.nekopoi search <judul>\n.nekopoi detail <url>'
            )
    }
}

handler.command = /^(nekopoi)$/i
handler.tags = ['search']
handler.help = ['nekopoi search <judul>', 'nekopoi detail <url>']
handler.register = true

export default handler