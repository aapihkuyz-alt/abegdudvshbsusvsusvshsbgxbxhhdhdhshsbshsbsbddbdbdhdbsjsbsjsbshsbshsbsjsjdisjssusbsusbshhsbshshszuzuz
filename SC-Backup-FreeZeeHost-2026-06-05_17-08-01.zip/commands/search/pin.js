import axios from 'axios';
const {
    proto,
    generateWAMessageFromContent,
    generateWAMessageContent
} = await import('baileys');

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) return m.reply(`⊏|⊐ *Contoh:* ${usedPrefix + command} nemophila flowers`);

    await conn.sendMessage(m.chat, {
        react: {
            text: `⏱️`,
            key: m.key
        }
    });

    async function createImage(url) {
        const {
            imageMessage
        } = await generateWAMessageContent({
            image: {
                url
            }
        }, {
            upload: conn.waUploadToServer
        });
        return imageMessage;
    }

    try {
        // Menggunakan API Neoxr v2 dengan global.neoxr
        const { data } = await axios.get(`https://api.neoxr.eu/api/pinterest-v2`, {
            params: {
                q: text,
                show: 10,
                type: 'image', // Mengambil tipe image sesuai contoh JSON
                apikey: global.neoxr
            }
        });

        if (!data.status || !data.data || data.data.length === 0) 
            return m.reply('❌ Tidak ada gambar ditemukan.');

        let push = [];
        let i = 1;

        for (let item of data.data) {
            // Mengambil URL dari content array pertama
            const imageUrl = item.content[0].url;
            
            push.push({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: item.title !== "-" ? item.title : `Image ke - ${i++}`,
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: '乂 P I N T E R E S T',
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: '',
                    hasMediaAttachment: true,
                    imageMessage: await createImage(imageUrl),
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [{
                        name: 'cta_url',
                        buttonParamsJson: JSON.stringify({
                            display_text: 'Source 🔍',
                            url: item.source,
                            merchant_url: item.source
                        }),
                    }],
                }),
            });
        }

        const message = generateWAMessageFromContent(
            m.chat, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2,
                        },
                        interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: `Hasil Pencarian: *${text}*`,
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: '乂 P I N T - C A R O U S E L',
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                hasMediaAttachment: false,
                            }),
                            carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
                                cards: [...push],
                            }),
                        }),
                    },
                },
            }, {
                quoted: m
            }
        );

        await conn.relayMessage(m.chat, message.message, {
            messageId: message.key.id
        });

        await conn.sendMessage(m.chat, {
            react: {
                text: `✅`,
                key: m.key
            }
        });

    } catch (e) {
        console.error(e);
        m.reply(`❌ Terjadi kesalahan: ${e.message}`);
    }
};

handler.help = ['pinterest'];
handler.tags = ['search'];
handler.command = /^(pinterest|pin)$/i;
handler.limit = true;
handler.register = true;

export default handler;
