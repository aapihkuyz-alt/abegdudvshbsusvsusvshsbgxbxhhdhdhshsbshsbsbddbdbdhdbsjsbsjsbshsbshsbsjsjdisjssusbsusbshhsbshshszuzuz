import { proto, generateWAMessageFromContent } from "baileys";
import { smartFetch } from "../../core/apiWrapper.js";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`Contoh: ${usedPrefix}${command} anime girl`)

    const isNext = m.text.includes("|next")
    const query = isNext ? text.split("|")[0] : text

    await m.react("🔍")
    
    try {
        const data = await smartFetch("pinterest", query);
        const results = data?.data || data;

        if (!results || results.length === 0) 
            throw new Error("Gambar tidak ditemukan.")

        // Ambil gambar secara acak dari hasil pencarian
        const imgUrl = results[Math.floor(Math.random() * results.length)]

        // Jika ini Telegram (conn.waUploadToServer tidak ada)
        if (!conn.waUploadToServer) {
            return await conn.sendMessage(m.chat, {
                image: { url: imgUrl },
                caption: `✅ *Pinterest Result*\n\nQuery: _${query}_`
            }, { quoted: m });
        }

        const msg = generateWAMessageFromContent(m.chat, {
            interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                body: proto.Message.InteractiveMessage.Body.fromObject({
                    text: `✅ *Pinterest Result*\n\nQuery: _${query}_`
                }),
                footer: proto.Message.InteractiveMessage.Footer.fromObject({
                    text: "Swipe/Click next for more"
                }),
                header: proto.Message.InteractiveMessage.Header.fromObject({
                    title: "💠 IMAGE SEARCH",
                    hasMediaAttachment: true,
                    imageMessage: (await prepareWAMessageMedia({ image: { url: imgUrl } }, { upload: conn.waUploadToServer })).imageMessage
                }),
                nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                    buttons: [
                        {
                            name: "quick_reply",
                            buttonParamsJson: JSON.stringify({
                                display_text: "⏭️ NEXT IMAGE",
                                id: `${usedPrefix}${command} ${query}|next`
                            })
                        },
                        {
                            name: "cta_url",
                            buttonParamsJson: JSON.stringify({
                                display_text: "🌐 SOURCE",
                                url: imgUrl
                            })
                        }
                    ]
                })
            })
        }, { quoted: m })

        await conn.relayMessage(m.chat, msg.message, { messageId: msg.key.id })

    } catch (e) {
        console.error(e)
        m.reply("❌ Gagal mencari gambar. Coba kata kunci lain.")
    }
}

handler.help = ["pin", "pinterest"]
handler.tags = ["search"]
handler.command = ["pin", "pinterest"]
handler.limit = true
handler.register = true

export default handler
