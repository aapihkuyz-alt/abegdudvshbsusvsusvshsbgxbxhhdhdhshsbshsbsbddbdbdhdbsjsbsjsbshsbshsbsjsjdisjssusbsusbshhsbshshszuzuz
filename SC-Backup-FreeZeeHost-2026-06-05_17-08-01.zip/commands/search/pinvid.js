import axios from 'axios'

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`⊏|⊐ *Contoh:* ${usedPrefix + command} https://pin.it/xxxxx`)

    await conn.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

    try {
        // Kita gunakan API Betabotz / Tio (Gratis & Direct MP4)
        const response = await axios.get(`https://api.botcahx.eu.org/api/dowloader/pinterestvideo`, {
            params: {
                url: text,
                apikey: 'pintu-gratis' // Apikey publik, jika limit ganti ke apikey pribadimu
            }
        })

        const res = response.data
        if (!res.status) return m.reply('❌ Gagal mengambil video. Pastikan link Pinterest benar.')

        let videoUrl = res.result.url
        
        // Cek apakah URL mengandung m3u8, jika iya, ini pasti gagal di WA
        if (videoUrl.includes('m3u8')) {
            return m.reply('⚠️ Video ini dalam format Stream (m3u8) yang tidak didukung WhatsApp. Coba link Pinterest yang lain.')
        }

        await conn.sendMessage(m.chat, {
            video: { url: videoUrl },
            caption: `✅ *Pinterest Downloader*`,
            mimetype: 'video/mp4'
        }, { quoted: m })

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } })

    } catch (e) {
        console.error(e)
        // Jika API pertama gagal, kita coba fallback ke API lain
        try {
            const res2 = await axios.get(`https://api.alyasany.my.id/api/pinterest?url=${text}&apikey=alyasany25`)
            const video2 = res2.data.result.data.video
            
            await conn.sendMessage(m.chat, {
                video: { url: video2 },
                caption: `✅ *Pinterest Downloader (Alternative)*`,
                mimetype: 'video/mp4'
            }, { quoted: m })
        } catch (err) {
            m.reply('❌ Semua server sibuk. Tidak dapat mengonversi video ke MP4.')
        }
    }
}

handler.help = ['pinvideo <url>']
handler.tags = ['downloader']
handler.command = /^(pinvideo|pindl|pinvid)$/i
handler.limit = true

export default handler
