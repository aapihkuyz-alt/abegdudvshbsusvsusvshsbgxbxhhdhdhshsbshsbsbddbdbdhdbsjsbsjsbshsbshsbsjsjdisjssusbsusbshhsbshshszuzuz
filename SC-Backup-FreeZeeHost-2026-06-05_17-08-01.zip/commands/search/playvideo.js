import axios from "axios"
import moment from "moment-timezone"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Masukkan judul video.\nContoh:\n.playvideo komang")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🔎",
                key: m.key
            }
        })

        // ===== 1. SEARCH VIDEO =====
        const searchApi = `https://api.neoxr.eu/api/video?q=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        const {
            data: search
        } = await axios.get(searchApi, {
            timeout: 20000
        })

        if (!search?.status || !search?.id)
            return m.reply("❌ Video tidak ditemukan.")

        // ===== 2. GET HD 720P =====
        const hdApi = `https://api.neoxr.eu/api/youtube?url=https://www.youtube.com/watch?v=${search.id}&type=video&quality=720p&apikey=${global.neoxr}`
        const {
            data
        } = await axios.get(hdApi, {
            timeout: 30000
        })

        if (!data?.status || !data?.data?.url)
            return m.reply("❌ Gagal mengambil video HD.")

        const now = moment().tz("Asia/Jakarta")
            .format("DD MMMM YYYY | HH:mm:ss")

        const caption = `
╭━━━〔 🎬 PLAY VIDEO HD 〕━━━⬣
┃ 🎵 Title     : ${data.title}
┃ 👤 Channel   : ${data.channel}
┃ ⏱ Duration  : ${data.fduration}
┃ 👁 Views     : ${data.views}
┃ 📦 Quality   : ${data.data.quality}
┃ 📁 Size      : ${data.data.size}
┃ 📅 Download  : ${now}
╰━━━━━━━━━━━━━━━━━━━━⬣

🔥 Auto HD 720p
🚀 Powered by ${global.botname}
`.trim()

        await conn.sendMessage(m.chat, {
            video: {
                url: data.data.url
            },
            mimetype: "video/mp4",
            caption: caption
        }, {
            quoted: m
        })

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (err) {

        console.log("PLAYVIDEO HD ERROR:", err.response?.data || err.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Terjadi error saat memproses video.")
    }
}

handler.command = ["playvideo", "playvid"]
handler.tags = ["search"]
handler.help = ["playvideo <judul video>"]

export default handler