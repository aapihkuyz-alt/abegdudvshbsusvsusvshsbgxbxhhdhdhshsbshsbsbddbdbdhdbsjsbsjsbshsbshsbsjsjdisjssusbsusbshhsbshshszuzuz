import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {
    if (!text) return m.reply(
        `╭━━━〔 📂 SFILE SEARCH 〕━━━╮
┃
┃ ➜ Contoh:
┃ ➜ .sfile config indosat
╰━━━━━━━━━━━━━━━━━━━━━━╯`
    )

    try {
        await conn.sendMessage(m.chat, {
            react: {
                text: "🔍",
                key: m.key
            }
        })

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/sfile-search", {
                params: {
                    q: text.trim(),
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !Array.isArray(data.data) || !data.data.length)
            throw new Error("Data kosong")

        const results = data.data

        const native_flow_button = [{
            name: 'single_select',
            buttonParamsJson: JSON.stringify({
                title: '📥 Pilih File',
                sections: [{
                    title: `Hasil untuk: ${text}`,
                    rows: results.map(v => ({
                        header: "SFile Result",
                        title: v.name,
                        description: `📦 ${v.size} • 📅 ${v.uploaded_at}`,
                        id: `.sfileget ${v.url}`
                    }))
                }]
            })
        }]

        const caption = `
╭━━━〔 📂 SFILE SEARCH 〕━━━╮
┃ 🔎 Kata Kunci :
┃ ➜ *${text}*
┃
┃ 📁 Total Ditemukan :
┃ ➜ *${data.data.length} File*
┃
┃ ⚡ Klik tombol di bawah
┃ untuk memilih file
╰━━━━━━━━━━━━━━━━━━━━━━╯
✨ Powered by ${global.ownername}
`.trim()

        await conn.sendMessage(
            m.chat, {
                text: caption,
                footer: "SFile Search System",
                interactive: native_flow_button
            }, {
                quoted: m
            }
        )

    } catch (e) {
        console.error("SFILE SEARCH ERROR:", e.response?.data || e.message)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ File tidak ditemukan atau API error.")
    }
}

handler.command = ["sfile"]
handler.tags = ["search"]
handler.help = ["sfile <query>"]

export default handler