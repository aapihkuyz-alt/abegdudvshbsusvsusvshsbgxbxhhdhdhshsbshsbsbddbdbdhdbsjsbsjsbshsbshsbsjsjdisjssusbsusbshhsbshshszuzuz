import axios from "axios"
import fs from "fs"
import path from "path"
import ffmpeg from "fluent-ffmpeg"

const tmpDir = "./data/sampah/tmp"
if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true })

const handler = async (m, { conn, text }) => {

    if (!text)
        return m.reply("URL sticker pack tidak valid.")

    if (!global.neoxr)
        return m.reply("API key Neoxr belum diisi.")

    try {

        await conn.sendMessage(m.chat, {
            react: { text: "📦", key: m.key }
        })

        const { data: res } = await axios.get(
            "https://api.neoxr.eu/api/sticker-get",
            {
                params: {
                    url: text.trim(),
                    apikey: global.neoxr
                }
            }
        )

        if (!res.status || !res.data.length)
            return m.reply("Sticker tidak ditemukan.")

        const stickers = res.data

        for (let i = 0; i < stickers.length; i++) {

            const input = path.join(tmpDir, `stk_${Date.now()}_${i}.gif`)
            const output = path.join(tmpDir, `stk_${Date.now()}_${i}.webp`)

            const stickerRes = await axios.get(stickers[i].url, {
                responseType: "arraybuffer",
                timeout: 60000
            })

            fs.writeFileSync(input, Buffer.from(stickerRes.data))

            await new Promise((resolve, reject) => {
                ffmpeg(input)
                    .outputOptions([
                        "-vcodec libwebp",
                        "-vf scale=512:512:force_original_aspect_ratio=decrease",
                        "-lossless 1",
                        "-qscale 1",
                        "-preset default",
                        "-loop 0",
                        "-an",
                        "-vsync 0"
                    ])
                    .save(output)
                    .on("end", resolve)
                    .on("error", reject)
            })

            const finalSticker = fs.readFileSync(output)

            await conn.sendMessage(
                m.chat,
                { sticker: finalSticker },
                { quoted: m }
            )

            fs.unlinkSync(input)
            fs.unlinkSync(output)
        }

        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (e) {

        console.error("STICKER GET ERROR:", e)

        await conn.sendMessage(m.chat, {
            react: { text: "❌", key: m.key }
        })

        m.reply("❌ Gagal mengambil sticker.")
    }
}

handler.command = ["stickerget"]

export default handler
