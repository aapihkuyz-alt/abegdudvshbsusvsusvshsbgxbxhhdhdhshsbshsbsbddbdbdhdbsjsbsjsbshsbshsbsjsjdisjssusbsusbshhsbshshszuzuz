import axios from "axios"
import fs from "fs"
import path from "path"
import ffmpeg from "fluent-ffmpeg"
import {
    tmpdir
} from "os"

/* ================= CONVERT GIF → WEBP ================= */
async function gifToWebp(buffer, filename) {
    const input = path.join(tmpdir(), filename + ".gif")
    const output = path.join(tmpdir(), filename + ".webp")

    fs.writeFileSync(input, buffer)

    await new Promise((resolve, reject) => {
        ffmpeg(input)
            .outputOptions([
                "-vcodec libwebp",
                "-vf scale=512:512:force_original_aspect_ratio=decrease",
                "-lossless 1",
                "-qscale 1",
                "-preset default",
                "-loop 0",
                "-an",
                "-vsync 0"
            ])
            .save(output)
            .on("end", resolve)
            .on("error", reject)
    })

    const result = fs.readFileSync(output)

    fs.unlinkSync(input)
    fs.unlinkSync(output)

    return result
}

/* ================= SEND STICKER PACK ================= */
async function sendStickerPack(conn, jid, pack, quoted) {
    try {

        const stickers = []

        for (let i = 0; i < pack.stickers.length; i++) {
            const s = pack.stickers[i]

            try {
                console.log("📥 DOWNLOAD:", s.url)

                const res = await axios.get(s.url, {
                    responseType: "arraybuffer",
                    timeout: 20000
                })

                console.log("⚙️ CONVERT:", i)

                const webp = await gifToWebp(
                    Buffer.from(res.data),
                    "stk_" + Date.now() + "_" + i
                )

                stickers.push({
                    data: webp,
                    emojis: ['']
                })

            } catch (e) {
                console.log("❌ GAGAL STICKER:", s.url, e.message)
            }
        }

        console.log("📊 TOTAL BERHASIL:", stickers.length)

        // ❌ kalau semua gagal
        if (!stickers.length) {
            await conn.sendMessage(jid, {
                text: "❌ Semua sticker gagal di convert (cek ffmpeg / API)"
            }, {
                quoted
            })
            return
        }

        await conn.sendMessage(jid, {
            stickerPack: {
                name: pack.name || "Sticker Pack",
                publisher: pack.publisher || "Bot",
                description: `${stickers.length} stickers`,
                cover: {
                    url: "https://files.catbox.moe/gjwqxy.webp"
                },
                stickers
            }
        }, {
            quoted
        })

        console.log("✅ STICKER PACK TERKIRIM")

    } catch (e) {
        console.log("🔥 SEND PACK ERROR:", e)
    }
}

/* ================= HANDLER ================= */
const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {

    if (!global.neoxr)
        return m.reply("API key neoxr belum diisi")

    /* ================= MODE DOWNLOAD ================= */
    if (text && text.startsWith("http")) {

        await conn.sendMessage(m.chat, {
            react: {
                text: "📦",
                key: m.key
            }
        })

        try {

            const {
                data: res
            } = await axios.get(
                "https://api.neoxr.eu/api/sticker-get", {
                    params: {
                        url: text.trim(),
                        apikey: global.neoxr
                    }
                }
            )

            if (!res.status || !res.data.length)
                return m.reply("Sticker tidak ditemukan")

            // 🔥 limit biar gak overload
            const limited = res.data.slice(0, 10)

            await sendStickerPack(conn, m.chat, {
                name: "Neoxr Pack",
                publisher: global.botname,
                stickers: limited.map(v => ({
                    url: v.url
                }))
            }, m)

            await conn.sendMessage(m.chat, {
                react: {
                    text: "✅",
                    key: m.key
                }
            })

        } catch (e) {

            console.log("❌ GET ERROR:", e)

            await conn.sendMessage(m.chat, {
                react: {
                    text: "❌",
                    key: m.key
                }
            })

            m.reply("❌ Gagal ambil pack")
        }

        return
    }

    /* ================= MODE SEARCH ================= */
    if (!text)
        return m.reply(`Contoh:\n${usedPrefix + command} kucing`)

    try {

        await conn.sendMessage(m.chat, {
            react: {
                text: "🔍",
                key: m.key
            }
        })

        const {
            data: res
        } = await axios.get(
            "https://api.neoxr.eu/api/sticker", {
                params: {
                    q: text,
                    apikey: global.neoxr
                }
            }
        )

        if (!res.status || !res.data.length)
            return m.reply("Sticker pack tidak ditemukan")

        const results = res.data

        const rows = results.slice(0, 20).map(v => ({
            header: v.name,
            title: `👤 ${v.creator}`,
            description: `📦 Sticker Pack`,
            id: `${usedPrefix + command} ${v.url}`
        }))

        const sections = [{
            title: "Sticker Packs",
            rows
        }]

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: results[0].thumbnail || results[0].url
                },
                caption: `🎨 Hasil: *${text}*\nTotal: ${results.length} pack`,
                footer: "Neoxr API",
                buttons: [{
                    buttonId: "sticker_select",
                    buttonText: {
                        displayText: "📦 Pilih Pack"
                    },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "Sticker Pack List",
                            sections
                        })
                    }
                }],
                headerType: 1,
                viewOnce: true
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {

        console.log("❌ SEARCH ERROR:", e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mencari sticker")
    }
}

handler.help = ["stcpack <query/url>"]
handler.tags = ["search"]
handler.command = ["stcpack", "stickerpack"]

export default handler