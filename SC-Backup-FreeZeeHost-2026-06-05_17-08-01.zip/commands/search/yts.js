import axios from "axios"

const handler = async (m, { conn, text, usedPrefix }) => {

    if (!text)
        return m.reply(`Contoh:\n${usedPrefix}yts komang`)

    if (!global.neoxr)
        return m.reply("API key Neoxr belum diisi di global.neoxr")

    try {

        await conn.sendMessage(m.chat, {
            react: { text: "🔎", key: m.key }
        })

        const { data: res } = await axios.get(
            `https://api.neoxr.eu/api/yts?q=${encodeURIComponent(text)}&apikey=${global.neoxr}`
        )

        if (!res.status || !res.data?.length)
            return m.reply("Tidak ada hasil ditemukan.")

        const results = res.data

        const rows = results.map((v, i) => {

            const views = v.views
                ? Number(v.views).toLocaleString()
                : "Tidak diketahui"

            const duration = v.timestamp || "Unknown"
            const author = v.author?.name || "Unknown"
            const upload = v.ago || "-"

            return {
                title: `${i + 1}. ${v.title}`,
                description:
                    `👤 ${author}\n` +
                    `⏱ ${duration} • 👁 ${views}\n` +
                    `📅 ${upload}`,
                id: `.yt ${v.url}`
            }
        })

        const caption = `
╭━━━━━━━━━━━━━━━━━━━━━━⬣
┃ 🔎 YOUTUBE SEARCH SYSTEM
┃
┃ 📌 Query :
┃ ➜ ${text}
┃
┃ 📊 Total Result :
┃ ➜ ${res.data.length} Video
┃
┃ 📎 Cara Pakai:
┃ • Tekan tombol di bawah
┃ • Pilih salah satu video
┃ • Bot akan menjalankan fitur .yt
┃
┃ ⚠️ Pastikan pilih video
┃ yang benar sebelum download.
┃
╰━━━━━━━━━━━━━━━━━━━━━━⬣
        `.trim()

        await conn.sendMessage(
            m.chat,
            {
                text: caption,
                footer: "YouTube Search • Neoxr API",
                buttons: [{
                    buttonId: "yts-list",
                    buttonText: { displayText: "🎬 Pilih Video" },
                    type: 4,
                    nativeFlowInfo: {
                        name: "single_select",
                        paramsJson: JSON.stringify({
                            title: "📂 Hasil Pencarian",
                            sections: [{
                                title: `Top 10 Result`,
                                rows
                            }]
                        })
                    }
                }]
            },
            { quoted: m }
        )

        await conn.sendMessage(m.chat, {
            react: { text: "✅", key: m.key }
        })

    } catch (e) {
        console.error("YTS ERROR:", e)
        m.reply("❌ Terjadi kesalahan saat mengambil data.")
    }
}

handler.help = ["yts <query>"]
handler.tags = ["search"]
handler.command = /^yts$/i

export default handler