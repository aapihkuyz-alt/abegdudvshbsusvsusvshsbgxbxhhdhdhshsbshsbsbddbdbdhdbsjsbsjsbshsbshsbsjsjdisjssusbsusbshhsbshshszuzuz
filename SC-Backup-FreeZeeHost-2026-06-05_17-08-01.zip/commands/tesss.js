let handler = async (m, {
    conn,
    text
}) => {
    try {
        await conn.sendReact(m.chat, "⏳", m.key)

        // Menggabungkan semua tipe tombol unik (tidak boleh ada nama tipe yang kembar)
        // Ini adalah jumlah maksimal tombol berjejer yang diizinkan oleh protokol WhatsApp
        const all_unique_buttons = [{
                name: 'quick_reply',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Shiroko Quick Reply',
                    id: '.ping'
                })
            },
            {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Shiroko CTA URL',
                    url: 'https://freezeehost.my.id',
                    merchant_url: 'https://freezeehost.my.id'
                })
            },
            {
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Shiroko CTA Copy',
                    copy_code: 'FREEZEE-2026-X'
                })
            },
            {
                name: 'cta_call',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Shiroko CTA Call',
                    phone_number: '6281234567890'
                })
            },
            {
                name: 'address_message',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Shiroko Address Form'
                })
            },
            {
                name: 'send_location',
                buttonParamsJson: JSON.stringify({
                    display_text: 'Shiroko Send Location'
                })
            },
            {
                name: 'open_webview',
                buttonParamsJson: JSON.stringify({
                    title: 'Shiroko Open Web Views',
                    link: {
                        in_app_webview: true,
                        url: 'https://freezeehost.my.id'
                    }
                })
            },
            {
                name: 'single_select',
                buttonParamsJson: JSON.stringify({
                    title: 'Shiroko Single Select',
                    sections: [{
                        title: 'Pilihan Layanan',
                        rows: [{
                            header: 'Hosting',
                            title: 'FreeZee Pterodactyl',
                            description: 'VPS Kencang',
                            id: '.vps'
                        }]
                    }]
                })
            }
        ]

        // Kirim langsung menggunakan engine @freezeehost/baileys
        await conn.sendMessage(m.chat, {
            text: "⚡ *FREEZEEHOST ALL UNIQUE BUTTONS*\n\nBerhasil memuat semua variasi tipe tombol native berjejer dalam satu pesan. Silakan tes klik di bawah:",
            buttons: all_unique_buttons,
            footer: "FreeZeeHost Bot Systems",
            viewOnce: true
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.error("ALL UNIQUE BUTTONS ERROR:", err)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply(`❌ Gagal memuat tombol berjejer: ${err.message}`)
    }
}

handler.command = ["testbutton", "allbutton", "flow"]
handler.tags = ["utility"]
handler.help = ["testbutton"]

export default handler