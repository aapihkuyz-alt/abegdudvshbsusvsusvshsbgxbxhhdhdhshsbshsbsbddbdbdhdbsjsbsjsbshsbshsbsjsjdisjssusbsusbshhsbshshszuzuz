import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    const input = text || m.quoted?.text

    if (!input) return m.reply("❌ Masukkan atau reply teks yang ingin dicek.")

    if (!global.neoxr) return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🔎", m.key)

        const url = `https://api.neoxr.eu/api/ai-detector`

        const {
            data
        } = await axios.get(url, {
            params: {
                text: input,
                apikey: global.neoxr
            },
            timeout: 20000
        })

        if (!data.status) return m.reply("❌ Gagal mendeteksi teks.")

        const result = data.data

        const caption = `
🤖 *AI Detector Result*

📝 Total Kata      : ${result.textWords}
🤖 AI Words        : ${result.aiWords}
📊 AI Percentage   : ${result.fakePercentage}%
🧠 Human Score     : ${result.isHuman}%

📌 Feedback:
${result.feedback}

🌐 Bahasa Terdeteksi:
${result.detected_language}
`.trim()

        await conn.sendMessage(m.chat, {
            text: caption
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("AI DETECTOR ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat cek teks.")
    }
}

handler.command = ["aidetect"]
handler.tags = ["tools"]
handler.help = ["aidetect <text>"]

export default handler