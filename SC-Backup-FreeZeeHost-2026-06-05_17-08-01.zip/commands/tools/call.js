let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("Contoh:\n#call audio\n#call video")

    const type =
        text.toLowerCase() === "video" ? 2 :
        text.toLowerCase() === "audio" ? 1 :
        null

    if (!type)
        return m.reply("Tipe harus audio atau video.")

    try {

        await conn.sendReact(m.chat, "📞", m.key)

        await conn.sendMessage(m.chat, {
            call: {
                name: "Incoming Call",
                type: type
            }
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("CALL ERROR:", err.message)
        m.reply("❌ Gagal mengirim call message.")
    }
}

handler.command = ["call"]
handler.tags = ["tools"]
handler.help = ["call audio", "call video"]

export default handler