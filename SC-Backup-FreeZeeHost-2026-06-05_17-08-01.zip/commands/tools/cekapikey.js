import axios from "axios"

let handler = async (m, { conn, text }) => {
  if (!text) {
    return m.reply(
`🔑 *CEK API KEY*

Format:
.cekapi APIKEY_KAMU

Contoh:
.cekapi FreeZeeHost12`
    )
  }

  const apiKey = text.trim()

  await m.reply("🔍 Lagi ngecek API key...\nTunggu bentar ya ⚡")

  try {
    const { data } = await axios.get(
      `https://api.neoxr.eu/api/check?apikey=${encodeURIComponent(apiKey)}`
    )

    // ❌ API key tidak valid
    if (!data || data.status !== true) {
      return m.reply(
`❌ *API KEY TIDAK VALID*

🔑 Key:
\`${apiKey}\`

💬 Keterangan:
${data?.msg || "API key tidak dikenali oleh server"}

— powered by ${global.ownername}`
      )
    }

    // ✅ API key valid
    const d = data.data

    const premiumStatus = d.premium
      ? `✅ Premium (exp: ${d.expired_at || "unknown"})`
      : "❌ Free user"

    let result =
`✅ *API KEY VALID*

🔑 Key:
\`${apiKey}\`

👤 User   : ${d.name || "-"}
⭐ Status : ${premiumStatus}
📊 Limit  : ${d.limit !== undefined ? d.limit.toLocaleString("id-ID") : "∞"}
📈 Total  : ${d.total !== undefined ? d.total.toLocaleString("id-ID") : "0"}
🕒 Last   : ${d.last_activity || "-"}

— powered by ${global.ownername}`

    await conn.sendMessage(m.chat, { text: result }, { quoted: m })

  } catch (err) {
    console.error("CEKAPI ERROR:", err)

    m.reply(
`⚠️ *Gagal cek API*

Kemungkinan:
• Server API down
• Koneksi error
• Rate limit
• API berubah

Coba lagi nanti ya.

— powered by ${global.ownername}`
    )
  }
}

handler.command = ["cekapikey"]
handler.tags = ["tools"]
handler.help = ["cekapi <apikey>"]

export default handler