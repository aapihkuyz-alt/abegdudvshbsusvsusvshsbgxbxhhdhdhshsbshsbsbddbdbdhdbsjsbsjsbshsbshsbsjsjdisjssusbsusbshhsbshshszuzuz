import axios from "axios"

const DNS_API = "https://dns.google/resolve"

const TYPES = [{
        name: "A",
        type: 1,
        icon: "📡"
    },
    {
        name: "AAAA",
        type: 28,
        icon: "🌍"
    },
    {
        name: "MX",
        type: 15,
        icon: "📬"
    },
    {
        name: "NS",
        type: 2,
        icon: "🧭"
    },
    {
        name: "TXT",
        type: 16,
        icon: "📄"
    },
    {
        name: "SOA",
        type: 6,
        icon: "📦"
    }
]

let handler = async (m, {
    text,
    usedPrefix,
    command
}) => {
    if (!text)
        return m.reply(`⚠️ Contoh:\n${usedPrefix + command} example.com`)

    const args = text.split(" ")
    const domain = args[0]
    const detail = args[1] === "detail"

    await m.react("⏳")

    try {
        const results = await Promise.all(
            TYPES.map(t =>
                axios.get(DNS_API, {
                    params: {
                        name: domain,
                        type: t.type
                    },
                    timeout: 10000
                }).catch(() => null)
            )
        )

        let out = `🌐 *DNS CHECK*\n📍 ${domain}\n\n`

        results.forEach((res, i) => {
            if (!res?.data?.Answer?.length) return
            const {
                name,
                icon
            } = TYPES[i]

            if (!detail && ["TXT", "SOA"].includes(name)) return

            out += `${icon} *${name}*\n`
            res.data.Answer.slice(0, 5).forEach(r => {
                out += `• ${r.data}\n`
            })
            out += "\n"
        })

        if (!detail)
            out += `_ketik *${usedPrefix + command} ${domain} detail* buat info lengkap_\n\n`

        out += `⚡ Google DNS`

        await m.reply(out.trim())
        await m.react("✅")

    } catch (e) {
        console.error(e)
        await m.react("❌")
        m.reply("❌ DNS lookup gagal")
    }
}

handler.command = ["cekdns"]
handler.tags = ["tools", "network"]
handler.help = ["cekdns <domain> [detail]"]

export default handler