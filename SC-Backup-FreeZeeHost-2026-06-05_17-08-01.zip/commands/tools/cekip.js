let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    // kalau kamu masih pakai verifyPhoneNumber, tinggal aktifin lagi
    // const verify = await verifyPhoneNumber(m.sender)
    // if (!verify.success) return m.reply(verify.message)

    if (!text)
        return m.reply(
            `🌐 *IP Checker*\n\nContoh:\n${usedPrefix + command} 8.8.8.8`
        )

    await m.react("⏳")

    try {
        const res = await fetch(`https://ipwho.is/${encodeURIComponent(text)}`)
        const data = await res.json()

        if (!data.success) {
            await m.react("❌")
            return m.reply("❌ IP tidak valid atau tidak ditemukan.")
        }

        const msg = `
🌍 *IP LOOKUP RESULT*
━━━━━━━━━━━━━━━
🔢 *IP*        : ${data.ip}
🌐 *Benua*     : ${data.continent} (${data.continent_code})
🏳️ *Negara*    : ${data.country} (${data.country_code}) ${data.flag?.emoji || ""}
🏙 *Wilayah*   : ${data.city}, ${data.region}
📮 *Kode Pos*  : ${data.postal || "-"}
📍 *Koordinat* : ${data.latitude}, ${data.longitude}

🕒 *Zona Waktu*
• ${data.timezone.id}
• UTC ${data.timezone.utc}

📡 *Jaringan*
• ISP    : ${data.connection.isp}
• ASN    : ${data.connection.asn}
• Domain : ${data.connection.domain}

━━━━━━━━━━━━━━━
⚡ Powered by ipwho.is
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: data.flag?.img
                },
                caption: msg
            }, {
                quoted: m
            }
        )

        await m.react("✅")

    } catch (e) {
        console.error("CEKIP ERROR:", e)
        await m.react("❌")
        m.reply("⚠️ Gagal ngecek IP. Coba lagi nanti.")
    }
}

handler.command = ["cekip", "ipcheck", "iplookup"]
handler.tags = ["tools"]
handler.help = ["cekip <ip address>"]

export default handler