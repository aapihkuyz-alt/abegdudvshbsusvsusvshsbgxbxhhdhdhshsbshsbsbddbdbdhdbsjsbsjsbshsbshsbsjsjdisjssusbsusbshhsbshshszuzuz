import fs from "fs"
import path from "path"
import os from "os"
import util from "util"
import ffmpeg from "fluent-ffmpeg"
import ffprobeStatic from "ffprobe-static"

// setup ffprobe
ffmpeg.setFfprobePath(ffprobeStatic.path)
const ffprobe = util.promisify(ffmpeg.ffprobe)

const handler = async (m, {
    conn
}) => {
    const q = m.quoted || m
    const mime = (q.msg || q).mimetype || ""

    if (!/image|video/.test(mime)) {
        return m.reply(
            "📸 Kirim atau reply *gambar / video* dulu dong.\nBiar bisa dicek resolusinya 👀"
        )
    }

    await conn.sendMessage(m.chat, {
        react: {
            text: "⏳",
            key: m.key
        }
    })

    let tmpPath

    try {
        // download media (AMAN, TANPA function aneh2)
        const buffer = await q.download()
        if (!buffer) throw new Error("Media gagal diunduh")

        // simpan ke temp file
        const ext = mime.split("/")[1] || "bin"
        tmpPath = path.join(os.tmpdir(), `res-${Date.now()}.${ext}`)
        fs.writeFileSync(tmpPath, buffer)

        // baca metadata
        const meta = await ffprobe(tmpPath)
        const stream = meta.streams.find(s => s.codec_type === "video")

        if (!stream?.width || !stream?.height) {
            throw new Error("Resolusi gak kebaca")
        }

        const width = stream.width
        const height = stream.height
        const sizeMB = (buffer.length / (1024 * 1024)).toFixed(2)

        const tipe = mime.startsWith("image") ? "Gambar" : "Video"

        const text = `
🎯 *Cek Resolusi Beres!*

📐 Resolusi : ${width} x ${height}
📦 Ukuran   : ${sizeMB} MB
🎞️ Tipe     : ${tipe}

Aman, masih cakep 😎
`.trim()

        await conn.sendMessage(
            m.chat, {
                text
            }, {
                quoted: m
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (e) {
        console.error("cekresolusi:", e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply(
            "⚠️ Gagal baca resolusi.\nCoba kirim file lain, siapa tau dia lagi bad mood."
        )
    } finally {
        if (tmpPath && fs.existsSync(tmpPath)) {
            fs.unlinkSync(tmpPath)
        }
    }
}

handler.command = ["cekresolusi", "resolusi"]
handler.tags = ["tools"]
handler.help = ["cekresolusi"]
handler.limit = true

export default handler