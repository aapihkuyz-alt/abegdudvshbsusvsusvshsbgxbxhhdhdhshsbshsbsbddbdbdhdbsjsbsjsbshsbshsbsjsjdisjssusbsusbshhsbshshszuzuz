let handler = async (m, {
    conn,
    args
}) => {
    try {
        // Ambil teks dari argumen atau quoted
        const text = args.length ? args.join(" ") : m.quoted?.text
        if (!text) return m.reply("Link web nya mana njeng?")

        // Ambil URL dari teks
        const urlMatch = text.match(/https?:\/\/[^\s]+/)
        if (!urlMatch) return m.reply("URL tidak ditemukan dalam teks.")

        const url = urlMatch[0]

        // Pesan tunggu (FIX: tidak pakai variabel wait yang undefined)
        await m.reply("⏳ Sedang memproses website, mohon tunggu...")

        // Proses clone web
        const result = await SaveWeb2zip(url)
        if (!result) return m.reply("❌ Gagal mengunduh website.")

        // Kirim file ZIP (FIX: nama file aman)
        await conn.sendMessage(
            m.chat, {
                document: Buffer.from(new Uint8Array(result.buffer)),
                mimetype: "application/zip",
                fileName: result.fileName,
                caption: "✅ Download Sukses!"
            }, {
                quoted: m
            }
        )

    } catch (e) {
        console.error(e)
        m.reply("❌ Terjadi error internal.")
    }
}

handler.help = ["cloneweb <url>"]
handler.tags = ["tools", "premium"]
handler.command = ["cweb", "cloneweb"]
handler.premium = true

export default handler

// ==============================
// SAVEWEB2ZIP FUNCTION
// ==============================
const SaveWeb2zip = async (link, options = {}) => {
    const apiUrl = "https://copier.saveweb2zip.com"
    let attempts = 0
    let md5

    try {
        // Request copy website
        const copyResponse = await fetch(`${apiUrl}/api/copySite`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/128.0.0.0 Mobile Safari/537.36",
                Referer: "https://saveweb2zip.com/en"
            },
            body: JSON.stringify({
                url: link,
                renameAssets: options.renameAssets || false,
                saveStructure: options.saveStructure || false,
                alternativeAlgorithm: options.alternativeAlgorithm || false,
                mobileVersion: options.mobileVersion || false
            })
        })

        const copyResult = await copyResponse.json()
        md5 = copyResult.md5
        if (!md5) throw new Error("MD5 tidak diterima dari API")

        // Cek status download
        while (attempts < 10) {
            const statusResponse = await fetch(`${apiUrl}/api/getStatus/${md5}`, {
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/128.0.0.0 Mobile Safari/537.36",
                    Referer: "https://saveweb2zip.com/en"
                }
            })

            const statusResult = await statusResponse.json()

            if (statusResult.isFinished) {
                // Download ZIP
                const downloadResponse = await fetch(
                    `${apiUrl}/api/downloadArchive/${md5}`, {
                        headers: {
                            "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/128.0.0.0 Mobile Safari/537.36",
                            Referer: "https://saveweb2zip.com/en"
                        }
                    }
                )

                const buffer = await downloadResponse.arrayBuffer()

                return {
                    fileName: `${md5}.zip`,
                    buffer,
                    link: `${apiUrl}/api/downloadArchive/${md5}`
                }
            }

            // Tunggu 60 detik
            await new Promise(resolve => setTimeout(resolve, 60000))
            attempts++
        }

        throw new Error("Timeout: Website terlalu lama diproses")

    } catch (err) {
        console.error("SaveWeb2zip Error:", err)
        return null
    }
}