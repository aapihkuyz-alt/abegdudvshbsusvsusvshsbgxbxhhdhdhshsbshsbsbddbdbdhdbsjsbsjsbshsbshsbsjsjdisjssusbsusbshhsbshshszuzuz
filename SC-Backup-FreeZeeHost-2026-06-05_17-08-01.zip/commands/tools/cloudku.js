/**
 * ╔══════════════════════
 * ⧉  [cloudku] — [tools]
 * ╚══════════════════════
 * ✺ Type     : Feature (ESM)
 * ✺ Support  : all media (audio, video, image, document)
 */

import {
    fileTypeFromBuffer
} from "file-type";

const DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    Accept: "*/*",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Cache-Control": "no-cache",
    Pragma: "no-cache"
};

const UPLOAD_TIMEOUT = 60000;

async function uploadCloudKu(buffer) {
    if (!buffer || !buffer.length) throw "Buffer kosong";

    const type = await fileTypeFromBuffer(buffer);
    if (!type) throw "Format file tidak dikenali";

    const formData = new FormData();
    const blob = new Blob([buffer], {
        type: type.mime
    });
    formData.append("file", blob, `upload.${type.ext}`);

    const res = await fetch("https://cloudkuimages.guru/upload.php", {
        method: "POST",
        headers: {
            ...DEFAULT_HEADERS,
            Origin: "https://cloudkuimages.guru",
            Referer: "https://cloudkuimages.guru/"
        },
        body: formData,
        signal: AbortSignal.timeout(UPLOAD_TIMEOUT)
    });

    if (!res.ok)
        throw `CloudKu HTTP ${res.status}: ${res.statusText}`;

    const json = await res.json();
    if (!json?.data?.url) throw "Response CloudKu invalid";

    return {
        url: json.data.url.trim(),
        mime: type.mime,
        ext: type.ext
    };
}

let handler = async (m, {
    conn
}) => {
    try {
        const q = m.quoted ? m.quoted : m;
        const msg = q.msg || q;

        if (!msg?.mimetype)
            return m.reply("Reply / kirim media apa saja");

        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        });

        const buffer = await q.download();
        const result = await uploadCloudKu(buffer);

        let caption =
            `✅ *Upload berhasil*\n\n` +
            `• *Type:* ${result.mime}\n` +
            `• *Ext:* .${result.ext}\n` +
            `• *URL:*\n${result.url}`;

        await m.reply(caption);
    } catch (e) {
        conn?.logger?.error(e);
        m.reply("❌ Gagal upload media");
    }
};

handler.command = ["cloudku", "cku"];
handler.tags = ["tools"];
handler.help = ["cloudku (reply media apa saja)"];

export default handler;