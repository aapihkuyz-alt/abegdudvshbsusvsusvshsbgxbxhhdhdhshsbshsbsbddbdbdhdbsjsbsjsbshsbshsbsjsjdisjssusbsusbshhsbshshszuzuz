import axios from "axios"
import FormData from "form-data"

let handler = async (m, {
    conn,
    args
}) => {

    if (!m.quoted)
        return m.reply("❌ Reply gambar yang ingin diberi efek.")

    const mime =
        m.quoted.mimetype ||
        m.quoted.msg?.mimetype ||
        m.quoted.mediaType ||
        ""

    if (!/image/.test(mime))
        return m.reply("❌ File harus berupa gambar.")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    const style = args[0] || "greyscale" // default

    try {

        await conn.sendReact(m.chat, "🎨", m.key)

        const media = await m.quoted.download()
        if (!media)
            return m.reply("❌ Gagal download gambar.")

        // Upload ke tmpfiles
        const form = new FormData()
        form.append("file", media, "image.jpg")

        const upload = await axios.post(
            "https://tmpfiles.org/api/v1/upload",
            form, {
                headers: form.getHeaders()
            }
        )

        if (!upload.data?.data?.url)
            return m.reply("❌ Gagal upload gambar.")

        const rawUrl = upload.data.data.url
        const imageUrl = rawUrl.replace("tmpfiles.org/", "tmpfiles.org/dl/")

        // Request ke API
        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/effect3", {
                params: {
                    style,
                    image: imageUrl,
                    apikey: global.neoxr
                },
                timeout: 60000
            }
        )

        if (!data?.status || !data.data?.url)
            return m.reply("❌ Gagal menerapkan efek.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.url
            },
            caption: `✨ Effect: ${style}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("EFFECT3 ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat memproses gambar.")
    }
}

handler.command = ["effect3"]
handler.tags = ["ai"]
handler.help = ["effect3 <style> (reply image)"]

export default handler