import crypto from "crypto";

function buildEncodedScript(source) {
    const marker = global.botname || "FreeZeeHost";
    const payload = Buffer.from(String(source), "utf8").toString("base64");
    const reversed = payload.split("").reverse().join("");
    const hash = crypto.createHash("sha256").update(String(source)).digest("hex").slice(0, 16);

    return [
        `const signature = "${marker}";`,
        `const layerId = "${marker}-${hash}";`,
        `const blob = "${reversed}";`,
        `const restored = blob.split("").reverse().join("");`,
        `const codec = ["base","64"].join("");`,
        `const code = Buffer.from(restored, codec).toString("utf8");`,
        `new Function(code)();`
    ].join("\n");
}

async function getSourceFromMessage(m) {
    if (!m.quoted) return null;
    if (typeof m.quoted.text === "string" && m.quoted.text.trim()) return m.quoted.text;
    if (m.quoted.isMedia) {
        const buffer = await m.quoted.download();
        return buffer?.toString("utf8") || null;
    }
    return null;
}

const handler = async (m, { conn, text, usedPrefix, command }) => {
    const inlineCode = String(text || "").trim();

    if (!inlineCode && !m.quoted) {
        return m.reply(
            `Gunakan format:\n${usedPrefix + command} kode\natau reply file/teks JS lalu ketik ${usedPrefix + command}`
        );
    }

    try {
        await m.react("⏳").catch(() => {});
        const source = inlineCode || await getSourceFromMessage(m);
        if (!source) {
            await m.react("❌").catch(() => {});
            return m.reply("❌ Kode tidak ditemukan. Reply teks/file JS atau isi langsung setelah command.");
        }

        const encoded = buildEncodedScript(source);
        const signature = global.botname || "FreeZeeHost";
        await conn.sendMessage(m.chat, {
            document: Buffer.from(encoded, "utf8"),
            mimetype: "application/javascript",
            fileName: `enc2-freezeehost-${Date.now()}.js`,
            caption: `✅ Encode layer-2 selesai.\nSignature = ${signature}`
        }, { quoted: m });
        await m.react("✅").catch(() => {});
    } catch (error) {
        await m.react("❌").catch(() => {});
        return m.reply(`❌ Gagal encode script.\n${error.message}`);
    }
};

handler.command = ["enc2"];
handler.tags = ["tools", "obfuscator"];
handler.help = ["enc2 <kode>"];

export default handler;
