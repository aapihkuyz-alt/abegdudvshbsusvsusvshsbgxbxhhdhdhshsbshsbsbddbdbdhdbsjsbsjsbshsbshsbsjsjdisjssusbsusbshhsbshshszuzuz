import crypto from "crypto";

function randomName(prefix = "_") {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let out = prefix;
    for (let i = 0; i < 10; i += 1) {
        out += chars[Math.floor(Math.random() * chars.length)];
    }
    return out;
}

function hardEncrypt(source) {
    const marker = global.botname || "FreeZeeHost";
    const key = crypto.randomBytes(8).toString("hex");
    const keyCodes = Array.from(Buffer.from(key, "utf8"));
    const sourceCodes = Array.from(Buffer.from(String(source), "utf8"));
    const mixed = sourceCodes.map((code, index) => code ^ keyCodes[index % keyCodes.length]);

    const a = randomName("_fz");
    const b = randomName("_fz");
    const c = randomName("_fz");
    const d = randomName("_fz");
    const e = randomName("_fz");
    const f = randomName("_fz");
    const g = randomName("_fz");
    const stamp = crypto.createHash("sha1").update(String(source)).digest("hex").slice(0, 12);

    return [
        `const ${a}="${marker}";`,
        `const ${b}="${marker}-${stamp}";`,
        `const ${c}="${key}";`,
        `const ${d}=[${mixed.join(",")}];`,
        `const ${e}=Array.from(Buffer.from(${c},"utf8"));`,
        `const ${f}=${d}.map((v,i)=>v^${e}[i%${e}.length]);`,
        `const ${g}=Buffer.from(${f}).toString("utf8");`,
        `new Function(${g})();`
    ].join("");
}

async function getQuotedJsFile(m) {
    const quoted = m.quoted;
    if (!quoted) return null;

    const fileName =
        quoted?.message?.documentMessage?.fileName ||
        quoted?.fileName ||
        "script.js";

    const mime =
        quoted?.message?.documentMessage?.mimetype ||
        quoted?.mimetype ||
        "";

    const isJsMime = mime === "application/javascript" || mime === "text/javascript" || mime === "application/x-javascript";
    const isJsName = /\.m?js$/i.test(fileName);

    if (!isJsMime && !isJsName) return null;

    const buffer = await quoted.download();
    if (!buffer) return null;

    return { buffer, fileName };
}

const handler = async (m, { conn, isOwner, isDev }) => {
    if (!isOwner && !isDev) {
        return m.reply("Perintah ini hanya untuk Owner/Developer.");
    }

    const quotedFile = await getQuotedJsFile(m);
    if (!quotedFile) {
        return m.reply("Reply file .js");
    }

    try {
        await m.react("⏳").catch(() => {});
        await m.reply("Memproses encrypt hard code . . .");

        const source = quotedFile.buffer.toString("utf8");
        const encrypted = hardEncrypt(source);
        const fileName = quotedFile.fileName.replace(/\.m?js$/i, "") + "-hard.js";
        const signature = global.botname || "FreeZeeHost";

        await conn.sendMessage(m.chat, {
            document: Buffer.from(encrypted, "utf8"),
            mimetype: "application/javascript",
            fileName,
            caption: `Encrypt File JS Sukses!\nType: Hard\nSignature: ${signature}`
        }, { quoted: m });

        await m.react("✅").catch(() => {});
    } catch (error) {
        await m.react("❌").catch(() => {});
        await m.reply(`Error: ${error.message}`);
    }
};

handler.command = ["enchard", "encrypthard"];
handler.tags = ["tools", "obfuscator"];
handler.help = ["enchard"];
handler.owner = true;

export default handler;
