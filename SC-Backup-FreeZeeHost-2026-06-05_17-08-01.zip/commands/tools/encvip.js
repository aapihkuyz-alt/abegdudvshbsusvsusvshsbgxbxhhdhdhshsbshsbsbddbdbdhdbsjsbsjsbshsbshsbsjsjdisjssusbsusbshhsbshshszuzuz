import crypto from "crypto";

function randomWord(length = 12) {
    const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
    let out = "";
    for (let i = 0; i < length; i += 1) {
        out += chars[Math.floor(Math.random() * chars.length)];
    }
    return out;
}

function buildVipEncrypted(source) {
    const marker = global.botname || "FreeZeeHost";
    const sourceBuffer = Buffer.from(String(source), "utf8");
    const keyA = crypto.randomBytes(6);
    const keyB = crypto.randomBytes(6);

    const mixed = Array.from(sourceBuffer).map((byte, index) => {
        const a = keyA[index % keyA.length];
        const b = keyB[index % keyB.length];
        return ((byte ^ a) + b) % 256;
    });

    const pieces = [];
    const order = [];
    for (let i = 0; i < mixed.length; i += 9) {
        pieces.push(mixed.slice(i, i + 9));
    }
    for (let i = 0; i < pieces.length; i += 1) order.push(i);
    order.reverse();

    const scrambled = order.map((index) => pieces[index].join(".")).join("|");
    const sign = crypto.createHash("sha256").update(String(source)).digest("hex").slice(0, 14);

    const v1 = `_${randomWord(10)}`;
    const v2 = `_${randomWord(10)}`;
    const v3 = `_${randomWord(10)}`;
    const v4 = `_${randomWord(10)}`;
    const v5 = `_${randomWord(10)}`;
    const v6 = `_${randomWord(10)}`;
    const v7 = `_${randomWord(10)}`;
    const v8 = `_${randomWord(10)}`;
    const v9 = `_${randomWord(10)}`;

    return [
        `const ${v1}="${marker}";`,
        `const ${v2}="${marker}-${sign}";`,
        `const ${v3}="${scrambled}";`,
        `const ${v4}="${Array.from(keyA).join(",")}";`,
        `const ${v5}="${Array.from(keyB).join(",")}";`,
        `const ${v6}=${JSON.stringify(order)};`,
        `const ${v7}=new Array(${v6}.length);`,
        `const ${v8}=${v3}.split("|").map(v=>v.split(".").map(Number));`,
        `for(let i=0;i<${v6}.length;i+=1){${v7}[${v6}[i]]=${v8}[i];}`,
        `const ${v9}=${v7}.flat().map((n,i)=>((n-(${v5}.split(",").map(Number))[i%(${v5}.split(",").map(Number)).length]+256)%256)^(${v4}.split(",").map(Number))[i%(${v4}.split(",").map(Number)).length]);`,
        `Function(Buffer.from(${v9}).toString("utf8"))();`
    ].join("");
}

async function getQuotedJsFile(m) {
    const quoted = m.quoted;
    if (!quoted) return null;

    const fileName =
        quoted?.message?.documentMessage?.fileName ||
        quoted?.fileName ||
        "script.js";

    const mime =
        quoted?.message?.documentMessage?.mimetype ||
        quoted?.mimetype ||
        "";

    const isJsMime = mime === "application/javascript" || mime === "text/javascript" || mime === "application/x-javascript";
    const isJsName = /\.m?js$/i.test(fileName);

    if (!isJsMime && !isJsName) return null;

    const buffer = await quoted.download();
    if (!buffer) return null;

    return { buffer, fileName };
}

const handler = async (m, { conn, isOwner, isDev }) => {
    if (!isOwner && !isDev) {
        return m.reply("Perintah ini hanya untuk Owner/Developer.");
    }

    const quotedFile = await getQuotedJsFile(m);
    if (!quotedFile) {
        return m.reply("Reply file .js");
    }

    try {
        await m.react("⏳").catch(() => {});
        await m.reply("Memproses encrypt VIP code . . .");

        const source = quotedFile.buffer.toString("utf8");
        const encrypted = buildVipEncrypted(source);
        const fileName = quotedFile.fileName.replace(/\.m?js$/i, "") + "-vip.js";
        const signature = global.botname || "FreeZeeHost";

        await conn.sendMessage(m.chat, {
            document: Buffer.from(encrypted, "utf8"),
            mimetype: "application/javascript",
            fileName,
            caption: `Encrypt File JS Sukses!\nType: VIP\nSignature: ${signature}`
        }, { quoted: m });

        await m.react("✅").catch(() => {});
    } catch (error) {
        await m.react("❌").catch(() => {});
        await m.reply(`Error: ${error.message}`);
    }
};

handler.command = ["encvip", "encryptvip"];
handler.tags = ["tools", "obfuscator"];
handler.help = ["encvip"];
handler.owner = true;

export default handler;
