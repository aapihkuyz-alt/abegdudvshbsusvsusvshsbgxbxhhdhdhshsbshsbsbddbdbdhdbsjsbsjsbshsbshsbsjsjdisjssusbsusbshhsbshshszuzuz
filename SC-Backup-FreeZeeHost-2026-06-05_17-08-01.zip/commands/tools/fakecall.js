let handler = async (m, {
    conn,
    text
}) => {
    try {

        if (!text) {
            return m.reply("Contoh:\n.fakecall voice\n.fakecall video")
        }

        let type = text.toLowerCase()

        if (!["voice", "video"].includes(type)) {
            return m.reply("Pilih: voice atau video")
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: "📞",
                key: m.key
            }
        })

        await conn.sendMessage(m.chat, {
            call: {
                name: "Incoming Call",
                type: type === "voice" ? 1 : 2
            }
        }, {
            quoted: m
        })

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (err) {
        console.error("FAKE CALL ERROR:", err)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })
    }
}

handler.command = ["fakecall"]
handler.tags = ["tools"]
handler.help = ["fakecall voice", "fakecall video"]

export default handler