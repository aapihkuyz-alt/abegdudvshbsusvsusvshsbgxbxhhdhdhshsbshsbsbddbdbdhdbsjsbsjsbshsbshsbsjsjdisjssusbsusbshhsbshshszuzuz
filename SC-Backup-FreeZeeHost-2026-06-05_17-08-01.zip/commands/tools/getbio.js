let handler = async (m, {
    conn,
    text
}) => {
    try {

        let target

        if (m.mentionedJid?.length) {
            target = m.mentionedJid[0]
        } else if (m.quoted) {
            target = m.quoted.sender
        } else if (text) {
            let num = text.replace(/[^0-9]/g, "")
            if (!num) return m.reply("❌ Nomor tidak valid")
            target = num + "@s.whatsapp.net"
        } else {
            target = m.sender
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧠",
                key: m.key
            }
        })

        const number = target.split("@")[0]

        // 🔥 FIX BIO
        let bio = "Tidak tersedia"

        try {
            // trigger WA biar kenal nomor
            await conn.onWhatsApp(target).catch(() => {})

            let res = await conn.fetchStatus(target)

            if (res?.status && res.status.trim() !== "") {
                bio = res.status
            } else {
                bio = "Tidak ada bio"
            }

        } catch {
            bio = "Bio disembunyikan / tidak bisa diakses"
        }

        await conn.sendMessage(m.chat, {
            text: `
🧠 *GET BIO*

👤 Target:
➜ @${number}

📌 Bio:
➜ ${bio}
`.trim(),
            mentions: [target],
            footer: global.botname,
            interactive: [{
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Salin Nomor",
                        copy_code: number
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🧾 Get Info",
                        id: `.getinfo ${number}`
                    })
                }
            ]
        }, {
            quoted: m
        })

    } catch (e) {
        console.error(e)
        m.reply("❌ Gagal mengambil bio.")
    }
}

handler.command = ["getbio"]
handler.tags = ["tools"]

export default handler