let handler = async (m, {
    conn,
    text,
    store
}) => {
    try {

        let target

        // DETECT TARGET
        if (m.mentionedJid?.length) {
            target = m.mentionedJid[0]
        } else if (m.quoted) {
            target = m.quoted.sender
        } else if (text) {
            let num = text.replace(/[^0-9]/g, "")
            if (!num) return m.reply("❌ Nomor tidak valid")
            target = num + "@s.whatsapp.net"
        } else {
            target = m.sender
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: "🧾",
                key: m.key
            }
        })

        const number = target.split("@")[0]

        // =========================
        // GET NAME (FIXED)
        // =========================
        let name = "Unknown"
        try {
            const contact = store?.contacts?.[target]

            if (contact?.name) name = contact.name
            else if (contact?.notify) name = contact.notify
            else if (target === m.sender && m.pushName) name = m.pushName
            else {
                let check = await conn.onWhatsApp(target)
                name = check?.[0]?.notify || "Unknown"
            }
        } catch {}

        // =========================
        // GET BIO (FIXED)
        // =========================
        let bio = "Tidak tersedia"
        try {
            await conn.onWhatsApp(target).catch(() => {})

            let res = await conn.fetchStatus(target)

            if (res?.status && res.status.trim() !== "") {
                bio = res.status
            } else {
                bio = "Tidak ada bio"
            }

        } catch {
            bio = "Bio disembunyikan / tidak bisa diakses"
        }

        // =========================
        // GET PP
        // =========================
        let pp
        try {
            pp = await conn.profilePictureUrl(target, "image")
        } catch {
            pp = "https://telegra.ph/file/24fa902ead26340f3df2c.png"
        }

        // =========================
        // SEND RESULT
        // =========================
        const caption = `
🧾 *USER INFO*

👤 Nama:
➜ ${name}

📱 Nomor:
➜ ${number}

📌 Bio:
➜ ${bio}
`.trim()

        await conn.sendMessage(m.chat, {
            image: {
                url: pp
            },
            caption,
            footer: global.botname,
            mentions: [target],
            interactive: [{
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Salin Nomor",
                        copy_code: number
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "👤 Get Name",
                        id: `.getname ${number}`
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🧠 Get Bio",
                        id: `.getbio ${number}`
                    })
                }
            ]
        }, {
            quoted: m
        })

    } catch (e) {
        console.error("GETINFO ERROR:", e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil info.")
    }
}

handler.command = ["getinfo", "whois"]
handler.tags = ["tools"]

export default handler