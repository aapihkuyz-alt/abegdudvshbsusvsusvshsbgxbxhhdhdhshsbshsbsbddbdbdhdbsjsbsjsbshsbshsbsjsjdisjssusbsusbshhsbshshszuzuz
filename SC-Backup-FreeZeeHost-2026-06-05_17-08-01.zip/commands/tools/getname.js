let handler = async (m, {
    conn,
    text,
    store
}) => {
    try {

        let target

        if (m.mentionedJid?.length) {
            target = m.mentionedJid[0]
        } else if (m.quoted) {
            target = m.quoted.sender
        } else if (text) {
            let num = text.replace(/[^0-9]/g, "")
            if (!num) return m.reply("❌ Nomor tidak valid")
            target = num + "@s.whatsapp.net"
        } else {
            target = m.sender
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: "👤",
                key: m.key
            }
        })

        const number = target.split("@")[0]

        // 🔥 FIX NAME
        let name = "Unknown"
        try {
            const contact = store?.contacts?.[target]

            if (contact?.name) name = contact.name
            else if (contact?.notify) name = contact.notify
            else if (target === m.sender && m.pushName) name = m.pushName
            else {
                let check = await conn.onWhatsApp(target)
                name = check?.[0]?.notify || "Unknown"
            }
        } catch {}

        await conn.sendMessage(m.chat, {
            text: `
👤 *GET NAME*

📱 Nomor:
➜ ${number}

📛 Nama:
➜ ${name}
`.trim(),
            footer: global.botname,
            mentions: [target],
            interactive: [{
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: "📋 Salin Nomor",
                        copy_code: number
                    })
                },
                {
                    name: "quick_reply",
                    buttonParamsJson: JSON.stringify({
                        display_text: "🧾 Get Info",
                        id: `.getinfo ${number}`
                    })
                }
            ]
        }, {
            quoted: m
        })

    } catch (e) {
        console.error(e)
        m.reply("❌ Gagal mengambil nama.")
    }
}

handler.command = ["getname"]
handler.tags = ["tools"]

export default handler