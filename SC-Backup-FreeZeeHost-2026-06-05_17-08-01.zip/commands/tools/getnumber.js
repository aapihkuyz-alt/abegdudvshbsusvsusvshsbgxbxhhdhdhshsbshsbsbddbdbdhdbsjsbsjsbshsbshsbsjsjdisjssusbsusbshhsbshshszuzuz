let handler = async (m, {
    conn
}) => {
    try {

        let target

        // PRIORITAS:
        // 1. mention
        if (m.mentionedJid?.length) {
            target = m.mentionedJid[0]

            // 2. reply
        } else if (m.quoted) {
            target = m.quoted.sender

            // 3. diri sendiri
        } else {
            target = m.sender
        }

        const number = target.split("@")[0]

        await conn.sendMessage(m.chat, {
            react: {
                text: "📱",
                key: m.key
            }
        })

        const text = `
📱 *GET NUMBER*

👤 Target:
➜ @${number}

📞 Nomor:
➜ *${number}*
`.trim()

        await conn.sendMessage(m.chat, {
            text,
            mentions: [target],
            footer: global.botname,
            interactive: [{
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "📋 Salin Nomor",
                    copy_code: number
                })
            }]
        }, {
            quoted: m
        })

    } catch (e) {
        console.error("GETNUMBER ERROR:", e)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        m.reply("❌ Gagal mengambil nomor.")
    }
}

handler.command = ["getnumber", "mynumber"]
handler.tags = ["tools"]
handler.help = ["getnumber [reply/tag]"]

export default handler