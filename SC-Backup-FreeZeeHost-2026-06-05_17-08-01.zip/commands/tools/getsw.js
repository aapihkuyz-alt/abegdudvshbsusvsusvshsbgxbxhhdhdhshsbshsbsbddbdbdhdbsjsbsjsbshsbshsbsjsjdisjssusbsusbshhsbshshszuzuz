const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const handler = async (m, {
    conn,
    usedPrefix,
    command,
    text
}) => {
    // ----------------------------------------------------
    // CASE 1: PROSES DOWNLOAD & KIRIM MEDIA (Jika JID dipilih)
    // ----------------------------------------------------
    if (text) {
        const targetJid = text.trim();
        const history = conn.getStatusesFrom(targetJid);

        if (!history || history.length === 0) {
            return m.reply("❌ Gagal memuat story atau story mungkin sudah kedaluwarsa.");
        }

        // Ambil nama push atau potong dari nomor langsung (Menghindari conn.getName bug)
        const name = conn.chats?.[targetJid]?.name || targetJid.split('@')[0];
        m.reply(`⏳ Sedang mengunduh dan mengirim ${history.length} story dari *${name}*...`);

        for (const story of history) {
            try {
                let caption = story.message?.imageMessage?.caption || story.message?.videoMessage?.caption || '';

                if (story.message?.imageMessage || story.message?.videoMessage) {
                    const buffer = await conn.downloadStatusMedia(story);

                    if (story.message?.imageMessage) {
                        await conn.sendMessage(m.chat, {
                            image: buffer,
                            caption: caption
                        }, {
                            quoted: m
                        });
                    } else {
                        await conn.sendMessage(m.chat, {
                            video: buffer,
                            caption: caption
                        }, {
                            quoted: m
                        });
                    }
                } else if (story.message?.extendedTextMessage) {
                    let txt = story.message.extendedTextMessage.text;
                    await conn.sendMessage(m.chat, {
                        text: `📝 *Status Teks ${name}:*\n\n${txt}`
                    }, {
                        quoted: m
                    });
                }
            } catch (err) {
                console.error("Gagal mendownload media SW:", err);
            }
            await delay(1500);
        }
        return;
    }

    // ----------------------------------------------------
    // CASE 2: MENU UTAMA (Native Flow Button)
    // ----------------------------------------------------
    const counts = conn.getStatusCounts();
    const jids = Object.keys(counts);

    if (jids.length === 0) {
        return m.reply("❌ Tidak ada status WhatsApp yang tersimpan di cache saat ini.");
    }

    // Ambil nama dari cache lokal conn.chats jika ada, kalau tidak ada potong dari JID
    const rows = jids.map(jid => {
        const localName = conn.chats?.[jid]?.name || jid.split("@")[0];
        return {
            header: "WhatsApp Status",
            title: localName,
            description: `Tersedia ${counts[jid]} story`,
            id: `${usedPrefix}${command} ${jid}`
        };
    });

    const native_flow_button = [{
        name: 'single_select',
        buttonParamsJson: JSON.stringify({
            title: 'Status List',
            sections: [{
                title: 'Active Contacts',
                rows: rows
            }]
        })
    }];

    await conn.sendMessage(m.chat, {
        text: `📂 *WHATSAPP STATUS DOWNLOADER*\n\nBerhasil mendeteksi *${jids.length}* kontak yang memperbarui status mereka. Silakan klik tombol di bawah untuk mengunduh.`,
        footer: "FreeZee Baileys Status Tracker",
        buttons: native_flow_button,
        headerType: 1
    }, {
        quoted: m
    });
};

handler.help = ['getsw', 'listsw'];
handler.tags = ['tools'];
handler.command = ['getsw', 'listsw'];

export default handler;