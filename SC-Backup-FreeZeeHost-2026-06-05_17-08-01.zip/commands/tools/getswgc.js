let handler = async (m, {
    conn
}) => {
    if (!m.quoted)
        return m.reply("Reply pesan SWGC yang mau diambil.")

    try {
        // ambil raw message object
        const wamc = m.quoted.message

        // hapus contextInfo biar gak error
        const key = Object.keys(wamc)[0]
        if (wamc[key].contextInfo)
            delete wamc[key].contextInfo

        // kirim ulang object tanpa buffer
        await conn.relayMessage(
            m.chat,
            wamc, {}
        )

        return m.reply("✅ Content sent")

    } catch (e) {
        console.error(e)
        m.reply("❌ Gagal ambil content.")
    }
}

handler.help = ["getcontent"]
handler.tags = ["tools"]
handler.command = ["getcontent", "getswgc"]
handler.group = true

export default handler