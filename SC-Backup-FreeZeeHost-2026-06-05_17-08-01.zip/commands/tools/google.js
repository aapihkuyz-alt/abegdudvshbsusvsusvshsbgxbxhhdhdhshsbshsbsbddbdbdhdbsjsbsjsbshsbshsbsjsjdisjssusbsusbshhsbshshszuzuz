import { smartFetch } from "../../core/apiWrapper.js";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} cara membuat bot WA*`);

    await m.react("🔍");
    
    try {
        const data = await smartFetch("search", text);
        const results = data?.data || data;

        if (!results || results.length === 0) throw new Error("Hasil tidak ditemukan.");

        let report = `╭─❍ *GOOGLE SEARCH* ❍─\n│\n│ 🔍 *Query:* ${text}\n│\n`;

        results.slice(0, 5).forEach((res, i) => {
            report += `│ *${i + 1}.* ${res.title}\n│ 🔗 ${res.url}\n│ 📝 ${res.description || res.snippet || "-"}\n│\n`;
        });

        report += `╰─────────────────────❍`;

        await m.reply(report);
        await m.react("✅");

    } catch (e) {
        console.error("Google Search Error:", e.message);
        m.reply(`❌ *[ ERROR ]* Gagal mencari informasi. Coba lagi nanti.`);
        await m.react("❌");
    }
};

handler.help = ["google", "search"];
handler.tags = ["tools"];
handler.command = /^(google|search)$/i;

export default handler;