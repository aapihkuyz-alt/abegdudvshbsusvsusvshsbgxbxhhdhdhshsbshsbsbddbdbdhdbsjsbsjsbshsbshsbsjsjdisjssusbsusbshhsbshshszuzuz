import fs from "fs";
import path from "path";
import crypto from "crypto";
import ffmpeg from "fluent-ffmpeg";
import ffmpegInstaller from "@ffmpeg-installer/ffmpeg";

ffmpeg.setFfmpegPath(ffmpegInstaller.path);

const TMP_DIR = "./data/sampah/tmp";

function ensureTmpDir() {
    if (!fs.existsSync(TMP_DIR)) {
        fs.mkdirSync(TMP_DIR, { recursive: true });
    }
}

function tempFile(ext) {
    ensureTmpDir();
    return path.join(TMP_DIR, `hd-${crypto.randomBytes(6).toString("hex")}.${ext}`);
}

function writeTempFile(buffer, ext = "bin") {
    const file = tempFile(ext);
    fs.writeFileSync(file, buffer);
    return file;
}

function cleanupFiles(...files) {
    for (const file of files) {
        if (file && fs.existsSync(file)) {
            try {
                fs.unlinkSync(file);
            } catch {
            }
        }
    }
}

function runFfmpeg(commandBuilder, outputPath) {
    return new Promise((resolve, reject) => {
        commandBuilder
            .on("end", () => resolve(outputPath))
            .on("error", reject)
            .save(outputPath);
    });
}

async function upscaleImage(buffer, mime) {
    const form = new FormData();
    form.append("scale", "2");
    form.append("image", new Blob([buffer], { type: mime }));

    const res = await fetch("https://api2.pixelcut.app/image/upscale/v1", {
        method: "POST",
        headers: {
            "x-client-version": "web"
        },
        body: form
    });

    if (!res.ok) {
        throw new Error(`Upscale image gagal (${res.status})`);
    }

    return Buffer.from(await res.arrayBuffer());
}

async function enhanceVideo(buffer) {
    const input = writeTempFile(buffer, "mp4");
    const output = tempFile("mp4");

    try {
        await runFfmpeg(
            ffmpeg(input)
                .videoCodec("libx264")
                .audioCodec("aac")
                .outputOptions([
                    "-preset medium",
                    "-crf 20",
                    "-movflags +faststart",
                    "-vf scale=1280:-2:flags=lanczos",
                    "-b:a 192k"
                ]),
            output
        );

        return fs.readFileSync(output);
    } finally {
        cleanupFiles(input, output);
    }
}

async function enhanceAudio(buffer) {
    const input = writeTempFile(buffer, "ogg");
    const output = tempFile("mp3");

    try {
        await runFfmpeg(
            ffmpeg(input)
                .audioCodec("libmp3lame")
                .outputOptions([
                    "-b:a 320k",
                    "-ar 48000",
                    "-ac 2"
                ]),
            output
        );

        return fs.readFileSync(output);
    } finally {
        cleanupFiles(input, output);
    }
}

const handler = async (m, { conn }) => {
    try {
        const q = m.quoted ? m.quoted : m;
        const mime = (q.msg || q).mimetype || "";

        if (!mime) {
            return m.reply("Reply media image, video, atau audio.");
        }

        await m.react("⏳").catch(() => {});

        if (mime.startsWith("image/")) {
            const img = await q.download();
            const buffer = await upscaleImage(img, mime);

            await conn.sendMessage(m.chat, {
                image: buffer,
                caption: "✅ HD image selesai."
            }, { quoted: m });

            await m.react("✅").catch(() => {});
            return;
        }

        if (mime.startsWith("video/")) {
            const video = await q.download();
            const buffer = await enhanceVideo(video);

            await conn.sendMessage(m.chat, {
                video: buffer,
                mimetype: "video/mp4",
                caption: "✅ HD video selesai."
            }, { quoted: m });

            await m.react("✅").catch(() => {});
            return;
        }

        if (mime.startsWith("audio/")) {
            const audio = await q.download();
            const buffer = await enhanceAudio(audio);

            await conn.sendMessage(m.chat, {
                audio: buffer,
                mimetype: "audio/mpeg",
                fileName: "hd-audio.mp3",
                ptt: false
            }, { quoted: m });

            await m.react("✅").catch(() => {});
            return;
        }

        await m.react("❌").catch(() => {});
        return m.reply("Media tidak didukung. Gunakan image, video, atau audio.");
    } catch (e) {
        await m.react("❌").catch(() => {});
        return m.reply(e.message);
    }
};

handler.help = ["remini", "hd"];
handler.command = ["remini", "hd"];
handler.tags = ["tools"];
handler.limit = true;
handler.register = true;

export default handler;
