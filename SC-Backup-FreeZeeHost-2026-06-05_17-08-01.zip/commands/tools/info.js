export default async function handler(m, {
    isOwner
}) {
    const senderNumber = m.sender.split('@')[0];

    const name =
        m.pushName ||
        m.notify ||
        m.name ||
        senderNumber;

    const status = isOwner ? 'Owner 👑' : 'Free User';

    // backtick aman (`)
    const bt = String.fromCharCode(96);
    const footer = `> powered by ${global.botname}`;

    const styles = [
        `👤 Info User
Nama   : ${name}
Nomor  : ${senderNumber}
Status : ${status}

${footer}`,

        `Halo 👋 ${name}
Nomor : ${senderNumber}
Role  : ${status}

${footer}`,

        `📌 USER DATA
• Nama   : ${name}
• Nomor  : ${senderNumber}
• Status : ${status}

${footer}`
    ];

    await m.reply(styles[Math.floor(Math.random() * styles.length)]);
}

handler.command = ['info'];
handler.tags = ['main'];
handler.help = ['info'];