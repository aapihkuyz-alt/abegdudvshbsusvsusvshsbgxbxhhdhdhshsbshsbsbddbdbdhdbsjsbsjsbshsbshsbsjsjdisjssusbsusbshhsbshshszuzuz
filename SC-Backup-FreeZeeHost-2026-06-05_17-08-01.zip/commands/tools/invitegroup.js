let handler = async (m, {
    conn,
    text
}) => {
    try {

        if (!text) {
            return m.reply("Contoh:\n.invitegroup https://chat.whatsapp.com/xxxxx")
        }

        // Ambil kode invite dari link atau langsung kode
        let code = text.includes("chat.whatsapp.com/") ?
            text.split("chat.whatsapp.com/")[1] :
            text.trim()

        if (!code) return m.reply("Kode invite tidak valid.")

        // Ambil metadata grup dari kode invite
        let meta = await conn.groupGetInviteInfo(code)

        if (!meta?.id) {
            return m.reply("❌ Gagal ambil info grup.")
        }

        await conn.sendMessage(m.chat, {
            groupInvite: {
                jid: meta.id,
                name: meta.subject,
                caption: "📨 Invitation To Join My Whatsapp Group",
                code: code,
                // expiration harus timestamp UNIX (detik)
                expiration: Math.floor(Date.now() / 1000) + 86400
            }
        }, {
            quoted: m
        })

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (err) {
        console.error("GROUP INVITE ERROR:", err)
        m.reply("❌ Gagal kirim group invite.")
    }
}

handler.command = ["invitegroup", "invtgc"]
handler.tags = ["tools"]
handler.help = ["invitegroup <link/code>"]

export default handler