import axios from "axios"

let handler = async (m, {
    conn,
    text
}) => {

    if (!text)
        return m.reply("❌ Contoh:\n#invoice Pecel Ayam|1|20000, Bebek|1|35000")

    if (!global.neoxr)
        return m.reply("❌ API key neoxr belum diset.")

    try {

        await conn.sendReact(m.chat, "🧾", m.key)

        const store = global.botname || "RyuuBotz Store"
        const invoice = "INV" + Date.now()
        const date = new Date().toLocaleDateString("id-ID")
        const status = "paid"

        const itemsRaw = text.split(",")

        const items = itemsRaw.map(v => {
            const [name, unit, price] = v.split("|")
            return {
                name: name?.trim() || "-",
                unit: (unit?.trim() || "1") + "x",
                price: Number(price) || 0
            }
        })

        const total = items.reduce((a, b) => a + b.price, 0)

        const {
            data
        } = await axios.get(
            "https://api.neoxr.eu/api/invoice-maker", {
                params: {
                    store,
                    invoice,
                    date,
                    status,
                    items: JSON.stringify(items),
                    total,
                    apikey: global.neoxr
                }
            }
        )

        if (!data?.status || !data.data?.image?.url)
            return m.reply("❌ Gagal membuat invoice.")

        await conn.sendMessage(m.chat, {
            image: {
                url: data.data.image.url
            },
            caption: `🧾 Invoice berhasil dibuat\nTotal: Rp ${total}`
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("INVOICE ERROR:", err.response?.data || err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat membuat invoice.")
    }
}

handler.command = ["invoice"]
handler.tags = ["ai"]
handler.help = ["invoice Pecel|1|20000, Bebek|1|35000"]

export default handler