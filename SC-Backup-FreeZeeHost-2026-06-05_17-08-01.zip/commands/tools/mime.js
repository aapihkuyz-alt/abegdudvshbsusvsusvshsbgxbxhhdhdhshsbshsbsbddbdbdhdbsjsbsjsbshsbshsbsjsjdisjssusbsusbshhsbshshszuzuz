export default async function handler(m, {
    conn
}) {
    // ambil message media (image, video, audio, document)
    const msg = m.message?.imageMessage ||
        m.message?.videoMessage ||
        m.message?.audioMessage ||
        m.message?.documentMessage

    // kalau bukan media, stop
    if (!msg) return

    // ambil mimetype
    const mime = msg.mimetype || ''

    // deteksi berdasarkan mime
    if (mime.startsWith('image/')) {
        m.reply('📸 Ini gambar')
    } else if (mime.startsWith('video/')) {
        m.reply('🎥 Ini video')
    } else if (mime.startsWith('audio/')) {
        if (mime.includes('opus')) {
            m.reply('🎤 Ini voice note')
        } else {
            m.reply('🎵 Ini audio')
        }
    } else if (mime === 'application/pdf') {
        m.reply('📄 Ini PDF')
    } else {
        m.reply(`❓ MIME tidak dikenal: ${mime}`)
    }
}

handler.help = ['detectmime']
handler.tags = ['tools']
handler.command = /^detectmime$/i