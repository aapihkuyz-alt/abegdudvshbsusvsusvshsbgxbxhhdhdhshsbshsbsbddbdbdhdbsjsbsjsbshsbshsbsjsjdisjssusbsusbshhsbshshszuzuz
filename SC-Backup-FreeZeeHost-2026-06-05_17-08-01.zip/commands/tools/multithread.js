import { Worker } from 'worker_threads';
import path from 'path';

const handler = async (m, { conn, args, usedPrefix, command }) => {
    const n = parseInt(args[0]) || 50000;
    if (n > 200000) return m.reply("❌ Angka terlalu besar, kasihan VPS nya (Maks 200rb).");

    await m.reply(`⚙️ *Multi-Threaded Math Processor* ⚙️\n\nSedang menghitung bilangan prima ke-*${n}* di jalur terpisah...\n\n_Bot akan tetap lancar merespon chat lain._`);

    const workerPath = path.join(process.cwd(), 'core/worker.js');
    const worker = new Worker(workerPath, {
        workerData: { 
            task: 'math_prime',
            data: { n }
        }
    });

    worker.on('message', (result) => {
        if (result.error) {
            return m.reply(`❌ Worker Error: ${result.error}`);
        }
        const stats = `
✅ *MATH TASK COMPLETE* ✅

📌 *Target:* Bilangan Prima ke-${result.target}
💎 *Result:* ${result.result}

_Tugas ini diselesaikan di background tanpa membebani respon bot._
`.trim();
        m.reply(stats);
    });

    worker.on('error', (err) => {
        console.error("Worker error:", err);
        m.reply("❌ Terjadi kesalahan pada Worker Thread.");
    });
};

handler.help = ['analyze <angka>'];
handler.tags = ['tools'];
handler.command = ['analyze', 'multithread'];

export default handler;
