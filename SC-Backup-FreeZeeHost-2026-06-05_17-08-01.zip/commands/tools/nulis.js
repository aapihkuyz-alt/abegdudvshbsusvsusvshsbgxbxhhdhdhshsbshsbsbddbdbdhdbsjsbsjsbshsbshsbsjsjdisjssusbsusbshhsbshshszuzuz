import axios from 'axios'

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text) {
        return m.reply(`Masukkan teks.\n\nContoh:\n${usedPrefix + command} Aku tidak akan menyontek lagi.`)
    }

    if (!global.neoxr) {
        return m.reply('API key tidak ditemukan di global.neoxr')
    }

    try {
        // React pena ✍️
        await conn.sendMessage(m.chat, {
            react: {
                text: '✍️',
                key: m.key
            }
        })

        // Pesan proses
        await m.reply('Bot sedang menulis...')

        const res = await axios.get('https://api.neoxr.eu/api/nulis', {
            params: {
                text: text,
                apikey: global.neoxr
            },
            timeout: 30000
        })

        if (!res.data?.status) {
            return m.reply('API gagal merespon dengan benar.')
        }

        const imageUrl = res.data?.data?.url
        if (!imageUrl) {
            return m.reply('Gagal mendapatkan gambar dari API.')
        }

        await conn.sendMessage(m.chat, {
            image: {
                url: imageUrl
            },
            caption: 'Selesai ✍️'
        }, {
            quoted: m
        })

    } catch (err) {
        console.error('[NULIS ERROR]', err)
        m.reply('Terjadi kesalahan saat membuat tulisan.')
    }
}

handler.help = ['nulis <text>']
handler.tags = ['tools']
handler.command = /^(nulis)$/i
handler.limit = true
handler.description = 'Mengubah teks menjadi tulisan tangan.'

export default handler