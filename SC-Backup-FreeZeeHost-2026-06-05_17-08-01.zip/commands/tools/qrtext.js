import fs from 'fs';
import generatorqrtext from '../../core/qrtext.js';

let handler = async (m, { conn, args }) => {
  try {
    if (!args.length)
      return m.reply('Contoh:\n.qr halo dunia');

    const text = args.join(' ');
    const file = await generatorqrtext(text);

    await conn.sendFile(
      m.chat,
      fs.readFileSync(file),
      'qrcode.png',
      '✅ QR berhasil dibuat',
      m
    );

    fs.unlinkSync(file);
  } catch (e) {
    m.reply('❌ Error: ' + e.message);
  }
};

handler.help = ['qr'];
handler.tags = ['tools'];
handler.command = ['qr', 'cqr'];

export default handler;