import axios from 'axios'

let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text || !text.includes("|")) {
        return conn.reply(
            m.chat,
            "Gunakan:\n.react-channel <link channel> | <emoji>\n\nContoh:\n.react-channel https://whatsapp.com/channel/xxxx/725 | 🤭😘☺️",
            m
        )
    }

    let [url, reactRaw] = text.split("|").map(v => v.trim())

    if (!url.startsWith("https://whatsapp.com/channel/")) {
        return conn.reply(m.chat, "Link channel tidak valid.", m)
    }

    if (!reactRaw) {
        return conn.reply(m.chat, "Emoji reaction tidak boleh kosong.", m)
    }

    const react = reactRaw.replace(/\s+/g, "")

    await m.react("🕑")

    try {
        const res = await axios.get(
            "https://api-faa.my.id/faa/react-channel", {
                params: {
                    url,
                    react
                },
                headers: {
                    "User-Agent": "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Mobile Safari/537.36",
                    "Accept": "application/json",
                    "Referer": "https://api-faa.my.id/",
                    "Origin": "https://api-faa.my.id"
                },
                timeout: 60000
            }
        )

        if (!res.data || res.data.status !== true) {
            throw res.data
        }

        await m.react("✅")
        conn.reply(
            m.chat,
            `✅ *Reaction Channel Berhasil*\n\n• Channel:\n${url}\n• Reaction:\n${react}`,
            m
        )

    } catch (e) {
        console.error("REACT CHANNEL ERROR:", e?.response?.data || e)
        await m.react("❌")
        conn.reply(
            m.chat,
            "eror pek: " + (e?.response?.data || e),
            m
        )
    }
}

handler.help = ['react-channel']
handler.tags = ['tools']
handler.command = ['rch', 'reactch']

export default handler