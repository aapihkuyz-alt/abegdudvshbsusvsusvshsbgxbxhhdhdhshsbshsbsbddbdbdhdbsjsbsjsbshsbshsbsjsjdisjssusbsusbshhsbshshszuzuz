import axios from "axios";

let handler = async (m, { conn, usedPrefix, command }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    if (!/image/.test(mime)) return m.reply(`📌 Contoh: Kirim/Reply gambar dengan perintah *${usedPrefix + command}* untuk menjernihkan.`);

    await m.react("⏳");
    await m.reply("💠 *Sedang menjernihkan gambar (Upscaling)...* \n_Mohon tunggu sebentar._");

    try {
        let media = await q.download();
        if (!media) throw new Error("Gagal mendownload gambar.");

        const { uploadImage } = await import("../../core/uploadImage.js");
        const imageUrl = await uploadImage(media);

        // Menggunakan Neoxr Remini/HD API
        const res = await axios.get("https://api.neoxr.eu/api/remini", {
            params: { image: imageUrl, apikey: global.neoxr },
            timeout: 60000 // Menjernihkan gambar butuh waktu lebih lama
        });

        if (!res.data?.status || !res.data.data?.url) throw new Error("Gagal memproses gambar.");

        await conn.sendMessage(m.chat, { 
            image: { url: res.data.data.url }, 
            caption: `✅ *UPSCALING BERHASIL!* \n\n_Gambar kini lebih jernih and tajam (HD)._` 
        }, { quoted: m });
        
        await m.react("✨");

    } catch (e) {
        console.error("Upscale Error:", e.message);
        m.reply(`❌ *[ ERROR ]* Gagal menjernihkan gambar. Coba lagi nanti.`);
        await m.react("❌");
    }
};

handler.help = ["remini", "hd", "upscale"];
handler.tags = ["tools", "ai"];
handler.command = /^(remini|hd|upscale|jernih)$/i;
handler.register = true;
handler.limit = true;

export default handler;