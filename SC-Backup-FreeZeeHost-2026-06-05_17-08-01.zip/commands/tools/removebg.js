import axios from "axios"
import FormData from "form-data"

/* ================= FAKE QUOTED ================= */
const fkontak = {
    key: {
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast",
        fromMe: false
    },
    message: {
        conversation: "Remove BG ✨"
    }
}

/* ================= UPLOAD TELEGRAPH ================= */
async function uploadTelegraph(buffer) {
    try {
        const form = new FormData()
        form.append("file", buffer, "image.jpg")

        const res = await axios.post(
            "https://telegra.ph/upload",
            form, {
                headers: form.getHeaders()
            }
        )

        if (!res.data[0]?.src) throw new Error("Upload telegraph gagal")

        return "https://telegra.ph" + res.data[0].src

    } catch (e) {
        console.log("TELEGRAPH ERROR:", e.message)
        throw e
    }
}

/* ================= REMOVE BG ================= */
async function removeBg(url) {
    try {
        const res = await axios.get("https://api.neoxr.eu/api/nobg", {
            params: {
                image: url,
                apikey: global.neoxr
            },
            timeout: 60000,
            validateStatus: () => true
        })

        console.log("NEOXR RESPONSE:", res.data)

        if (!res.data || typeof res.data !== "object") {
            throw new Error("API tidak merespon JSON")
        }

        if (!res.data.status) {
            throw new Error(res.data.msg || "API gagal")
        }

        return res.data.data.no_background

    } catch (e) {
        console.log("REMOVE BG ERROR:", e.message)
        return null
    }
}

/* ================= HANDLER ================= */
const handler = async (m, {
    conn,
    usedPrefix,
    command
}) => {
    try {

        const q = m.quoted ? m.quoted : m
        const mime = q.mimetype || q.msg?.mimetype || ""

        if (!/image/.test(mime)) {
            return conn.sendMessage(
                m.chat, {
                    text: `📸 Reply gambar dengan *${usedPrefix + command}*`
                }, {
                    quoted: fkontak
                }
            )
        }

        await conn.sendMessage(m.chat, {
            react: {
                text: "⏳",
                key: m.key
            }
        })

        const img = await q.download()
        if (!img) throw new Error("Gagal download gambar")

        // 🔥 upload ke telegraph (WAJIB)
        const imageUrl = await uploadTelegraph(img)

        console.log("UPLOAD URL:", imageUrl)

        // delay biar stabil
        await new Promise(r => setTimeout(r, 2000))

        // 🔥 remove bg
        const result = await removeBg(imageUrl)

        if (!result) throw new Error("API neoxr gagal total")

        // kirim hasil
        await conn.sendMessage(
            m.chat, {
                image: {
                    url: result
                },
                caption: "🖤 Remove BG Berhasil (Neoxr)"
            }, {
                quoted: fkontak
            }
        )

        await conn.sendMessage(m.chat, {
            react: {
                text: "✅",
                key: m.key
            }
        })

    } catch (err) {

        console.error("REMOVE BG FINAL ERROR:", err)

        await conn.sendMessage(m.chat, {
            react: {
                text: "❌",
                key: m.key
            }
        })

        await conn.sendMessage(
            m.chat, {
                text: `❌ ${err.message}`
            }, {
                quoted: fkontak
            }
        )
    }
}

handler.help = ["removebg"]
handler.tags = ["tools"]
handler.command = ["removebg", "rmbg"]

export default handler