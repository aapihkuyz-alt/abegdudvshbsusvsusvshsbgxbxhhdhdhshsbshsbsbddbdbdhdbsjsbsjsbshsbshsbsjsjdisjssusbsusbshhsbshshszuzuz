import {
    sendMail
} from "../../core/mailer.js"
import {
    emailTemplate
} from "../../core/templates/email.js"

let handler = async (m, {
    text
}) => {
    if (!text || !text.includes("|")) {
        return m.reply(
            `✉️ *SEND EMAIL*

Format:
.sendmail email@tujuan.com|Judul|Isi pesan

Contoh:
.sendmail user@gmail.com|Notifikasi|Akun Anda berhasil diverifikasi`
        )
    }

    const [to, subject, ...msg] = text.split("|")
    const message = msg.join("|").trim()

    if (!to || !subject || !message) {
        return m.reply("❌ Data email tidak lengkap.")
    }

    await m.reply("📤 Mengirim email...")

    try {
        const html = emailTemplate({
            title: subject.trim(),
            subtitle: "Official Notification",
            content: message,
            footerNote: "Email ini dikirim otomatis oleh sistem."
        })

        await sendMail({
            to: to.trim(),
            subject: subject.trim(),
            html
        })

        m.reply(`✅ Email berhasil dikirim ke:\n${to}`)
    } catch (err) {
        console.error("SENDMAIL ERROR:", err)
        m.reply("❌ Gagal mengirim email. Cek konfigurasi email.")
    }
}

handler.command = ["sendmail"]
handler.tags = ["tools"]
handler.help = ["sendmail email|judul|pesan"]
handler.owner = true

export default handler