import axios from 'axios';

/**
 * 📨 NGL SPAMMER (AUTO RANDOM TEXT & CUSTOM)
 * Format 1: .spamngl link, total (Soal Acak)
 * Format 2: .spamngl link, pesan, total (Soal Custom)
 */

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    // 1. Validasi Input
    if (!text) {
        return m.reply(`*Format Salah!* ❌\n\n*Cara 1 (Pertanyaan Acak):*\n${usedPrefix + command} link, jumlah\n_Contoh:_ ${usedPrefix + command} ngl.link/jokowi, 10\n\n*Cara 2 (Pertanyaan Custom):*\n${usedPrefix + command} link, pesan, jumlah\n_Contoh:_ ${usedPrefix + command} ngl.link/jokowi, P, 10`);
    }

    // Pisahkan berdasarkan koma atau garis vertikal
    let args = text.split(/[,|]/).map(v => v.trim());

    let username = args[0].replace(/^(https?:\/\/)?(www\.)?ngl\.link\//i, '').split('/')[0];
    let pesan = "";
    let jumlah = 0;

    // 2. Logic Deteksi Format
    if (args.length === 2 && !isNaN(args[1])) {
        // Jika input cuma 2 dan input kedua adalah angka (Format 1)
        jumlah = parseInt(args[1]);
        pesan = "RANDOM";
    } else if (args.length >= 3) {
        // Jika input 3 atau lebih (Format 2)
        pesan = args[1];
        jumlah = parseInt(args[2]);
    } else {
        return m.reply("❌ Format tidak dikenali. Pastikan jumlah berupa angka.\n\nContoh: ngl.link/jokowi, 10");
    }

    if (!username || isNaN(jumlah)) return m.reply("Data tidak valid! Pastikan link NGL dan jumlah benar.");
    if (jumlah > 100) return m.reply("Maksimal 100 aja Bang, kasihan server NGL-nya ngebul! 🗿");

    await m.react("⏳");
    m.reply(`🚀 *Starting Spam NGL...*\n\n*Target:* ngl.link/${username}\n*Tipe Pesan:* ${pesan === "RANDOM" ? "Pertanyaan Acak 🎲" : "Custom ✍️"}\n*Jumlah:* ${jumlah}\n\n_Mohon tunggu sampai selesai..._`);

    // Bank Soal Acak
    const randomQuestions = [
        "Lagi apa kak?", "Boleh kenalan ga?", "Pap dong", "Sombong banget sih",
        "Udah makan belum?", "Semangat terus ya!", "Lagi sibuk ngapain nih?",
        "Cita-cita kamu apa?", "Spam dari bot 🗿", "Halo orang baik",
        "Mabar yuk", "Save nomor aku dong", "Kapan nikah?", "Lagi mikirin apa?",
        "Spill crush dong!", "Pernah nangis diam-diam ga?", "Kamu jomblo ya?"
    ];

    let sukses = 0;
    let gagal = 0;

    for (let i = 0; i < jumlah; i++) {
        // Ambil soal acak jika mode RANDOM, kalau tidak pakai pesan custom
        let textToSend = pesan === "RANDOM" ? randomQuestions[Math.floor(Math.random() * randomQuestions.length)] : pesan;

        // Generate Device ID palsu biar gak kena spam filter
        let fakeDeviceId = `uuid-${Math.random().toString(36).substring(2, 10)}-${Math.random().toString(36).substring(2, 6)}`;

        try {
            await axios.post(`https://ngl.link/api/submit`,
                new URLSearchParams({
                    username: username,
                    question: textToSend,
                    deviceId: fakeDeviceId,
                }), {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
                        'Accept-Language': 'en-US,en;q=0.9',
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                }
            );
            sukses++;
        } catch (e) {
            gagal++;
        }

        // Jeda 500ms biar aman dari rate limit NGL
        await new Promise(resolve => setTimeout(resolve, 500));
    }

    // 3. Laporan Akhir
    await m.react("✅");
    m.reply(`✅ *SPAM NGL SELESAI!*\n\n*Target:* ngl.link/${username}\n*Berhasil:* ${sukses}\n*Gagal:* ${gagal}\n\n> _Pesan anonim telah masuk ke inbox target._`);
};

handler.help = ['spamngl'];
handler.tags = ['tools'];
handler.command = /^(spamngl|nglspam)$/i;
handler.limit = true;

export default handler;