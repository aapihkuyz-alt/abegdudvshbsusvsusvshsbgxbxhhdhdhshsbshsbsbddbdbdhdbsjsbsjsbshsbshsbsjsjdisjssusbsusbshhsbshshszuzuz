import pkg from 'baileys'
const {
    generateWAMessageFromContent,
    proto
} = pkg

let handler = async (m, {
    text,
    conn
}) => {
    if (!global.neoxr)
        return m.reply('*[ ! ] APIKEY NEOXR BELUM DIPASANG!*')

    if (!text)
        return m.reply('Contoh:\nssweb google.com')

    // ===== NORMALISASI URL (AUTO HTTPS) =====
    let url = text.trim()
    if (!/^https?:\/\//i.test(url)) url = 'https://' + url

    try {
        new URL(url)
    } catch {
        return m.reply('[ x ] URL tidak valid.')
    }

    // encode URL ke button (ANTI RESTART)
    const encoded = Buffer.from(url).toString('base64')

    const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
            message: {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.fromObject({
                    body: proto.Message.InteractiveMessage.Body.create({
                        text: '*Pilih model screenshot:*'
                    }),
                    footer: proto.Message.InteractiveMessage.Footer.create({
                        text: global.footer
                    }),
                    header: proto.Message.InteractiveMessage.Header.create({
                        hasMediaAttachment: false
                    }),
                    nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
                        buttons: [{
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '🖥 Desktop',
                                    id: `ssweb|desktop|${encoded}`
                                })
                            },
                            {
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '📱 Phone',
                                    id: `ssweb|phone|${encoded}`
                                })
                            },
                            {
                                name: 'quick_reply',
                                buttonParamsJson: JSON.stringify({
                                    display_text: '📲 Tablet',
                                    id: `ssweb|tablet|${encoded}`
                                })
                            }
                        ]
                    })
                })
            }
        }
    }, {
        quoted: m
    })

    await conn.relayMessage(m.chat, msg.message, {
        messageId: msg.key.id
    })
}

/* ===============================
   BUTTON HANDLER (FAST)
================================ */
handler.before = async (m, {
    conn
}) => {
    // Detect from m.text (Already extracted by handler.js)
    let id = m.text || ''

    if (!id || !id.startsWith('ssweb|')) return

    if (!global.neoxr)
        return m.reply('*[ ! ] APIKEY NEOXR BELUM DIPASANG!*')

    const [, device, encoded] = id.split('|')
    let url

    try {
        url = Buffer.from(encoded, 'base64').toString()
        new URL(url)
    } catch {
        return m.reply('[ x ] URL rusak. Gunakan ulang /ssweb')
    }

    // ===== INIT CACHE =====
    conn.ssCache = conn.ssCache || {}
    const cacheKey = `${url}_${device}`

    // ===== CACHE HIT (SUPER CEPAT) =====
    if (conn.ssCache[cacheKey]) {
        return conn.sendMessage(m.chat, {
            image: {
                url: conn.ssCache[cacheKey]
            },
            caption: `*[ ✓ ] Screenshot ${device.toUpperCase()} (cache)*`
        }, {
            quoted: m
        })
    }

    // ===== FEEDBACK CEPAT KE USER =====
    if (global.loading) await global.loading(m, conn)

    try {
        const api = `https://api.neoxr.eu/api/ss?url=${encodeURIComponent(url)}&device=${device}&apikey=${global.neoxr}`
        const res = await fetch(api)
        const json = await res.json()

        if (!json.status || !json.data?.url) {
            console.error('NEOXR RESPONSE:', json)
            if (global.loading) await global.loading(m, conn, true)
            return m.reply('[ x ] Gagal mengambil screenshot.')
        }

        // SIMPAN CACHE
        conn.ssCache[cacheKey] = json.data.url

        await conn.sendMessage(m.chat, {
            image: {
                url: json.data.url
            },
            caption: `*[ ✓ ] Screenshot ${device.toUpperCase()} berhasil!*`
        }, {
            quoted: m
        })

        if (global.loading) await global.loading(m, conn, true)

    } catch (e) {
        console.error('SSWEB ERROR:', e)
        if (global.loading) await global.loading(m, conn, true)
        m.reply('[ x ] Terjadi kesalahan.')
    }
}

/* ================= CONFIG ================= */
handler.command = ['ssweb']
handler.tags = ['tools']
handler.help = ['ssweb <url>']

export default handler