import axios from "axios";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    if (!text) return m.reply(`📌 Contoh: *${usedPrefix + command} freezeehost*`);

    await m.react("🔍");
    
    try {
        let report = "";
        let profilePic = "";

        if (command === "stalkgh") {
            const { data } = await axios.get(`https://api.github.com/users/${text}`);
            profilePic = data.avatar_url;
            report = `╭─❍ *GITHUB STALKER* ❍─
│
│ 👤 *Username:* ${data.login}
│ 📛 *Name:* ${data.name || "-"}
│ 🏢 *Company:* ${data.company || "-"}
│ 📍 *Location:* ${data.location || "-"}
│ 📝 *Bio:* ${data.bio || "-"}
│ 👥 *Followers:* ${data.followers.toLocaleString()}
│ 🤝 *Following:* ${data.following.toLocaleString()}
│ 📂 *Public Repos:* ${data.public_repos}
│ 📅 *Joined:* ${new Date(data.created_at).toLocaleDateString()}
│
╰─────────────────────❍`;
        } 
        
        else if (command === "stalkig") {
            // Menggunakan Neoxr API untuk Instagram
            const { data } = await axios.get("https://api.neoxr.eu/api/igstalk", {
                params: { username: text, apikey: global.neoxr }
            });
            if (!data.status) throw new Error(data.msg || "User tidak ditemukan");
            
            const user = data.data;
            profilePic = user.profile_pic_url_hd;
            report = `╭─❍ *INSTAGRAM STALKER* ❍─
│
│ 👤 *Username:* ${user.username}
│ 📛 *Name:* ${user.full_name}
│ 👥 *Followers:* ${user.follower_count.toLocaleString()}
│ 🤝 *Following:* ${user.following_count.toLocaleString()}
│ 🎬 *Posts:* ${user.media_count.toLocaleString()}
│ 📝 *Bio:* ${user.biography || "-"}
│ 🔗 *Link:* ${user.external_url || "-"}
│ 🔐 *Private:* ${user.is_private ? "Yes" : "No"}
│ ✅ *Verified:* ${user.is_verified ? "Yes" : "No"}
│
╰─────────────────────❍`;
        }

        else if (command === "stalktt") {
            const { data } = await axios.get("https://api.neoxr.eu/api/tiktok-stalk", {
                params: { username: text, apikey: global.neoxr }
            });
            if (!data.status) throw new Error(data.msg || "User tidak ditemukan");
            
            const user = data.data.user;
            const stats = data.data.stats;
            profilePic = user.avatarLarger;
            report = `╭─❍ *TIKTOK STALKER* ❍─
│
│ 👤 *Username:* ${user.uniqueId}
│ 📛 *Nickname:* ${user.nickname}
│ 👥 *Followers:* ${stats.followerCount.toLocaleString()}
│ 🤝 *Following:* ${stats.followingCount.toLocaleString()}
│ ❤️ *Hearts:* ${stats.heartCount.toLocaleString()}
│ 🎬 *Videos:* ${stats.videoCount.toLocaleString()}
│ 📝 *Signature:* ${user.signature || "-"}
│ ✅ *Verified:* ${user.verified ? "Yes" : "No"}
│
╰─────────────────────❍`;
        }

        if (profilePic) {
            await conn.sendMessage(m.chat, { image: { url: profilePic }, caption: report }, { quoted: m });
        } else {
            await m.reply(report);
        }
        await m.react("✅");

    } catch (e) {
        console.error("Stalker Error:", e.message);
        m.reply(`❌ *[ ERROR ]* User tidak ditemukan atau API sedang limit.`);
        await m.react("❌");
    }
};

handler.help = ["stalkig", "stalkgh", "stalktt"];
handler.tags = ["tools"];
handler.command = /^(stalkig|stalkgh|stalktt)$/i;

export default handler;