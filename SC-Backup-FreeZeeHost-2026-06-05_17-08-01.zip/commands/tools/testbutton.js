let handler = async (m, { conn, text }) => {
    try {
        const ownerNumber = (global.noowner || global.owner?.[0] || "628123456789").replace(/[^0-9]/g, "")

        const safeButtons = [
            {
                name: "quick_reply",
                buttonParamsJson: JSON.stringify({
                    display_text: "Quick Reply",
                    id: ".menu"
                })
            },
            {
                name: "cta_url",
                buttonParamsJson: JSON.stringify({
                    display_text: "Action URL",
                    url: global.website || "https://example.com",
                    merchant_url: global.website || "https://example.com"
                })
            },
            {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "Action Copy",
                    copy_code: "12345678"
                })
            },
            {
                name: "cta_call",
                buttonParamsJson: JSON.stringify({
                    display_text: "Action Call",
                    phone_number: ownerNumber
                })
            },
            {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                    title: "Selection Button",
                    sections: [{
                        title: "Title 1",
                        highlight_label: "Highlight label 1",
                        rows: [
                            {
                                header: "Header 1",
                                title: "Title 1",
                                description: "Description 1",
                                id: ".menu"
                            },
                            {
                                header: "Header 2",
                                title: "Title 2",
                                description: "Description 2",
                                id: ".owner"
                            }
                        ]
                    }]
                })
            }
        ]

        const riskyButtons = [
            {
                name: "cta_catalog",
                buttonParamsJson: JSON.stringify({
                    business_phone_number: ownerNumber
                })
            },
            {
                name: "cta_reminder",
                buttonParamsJson: JSON.stringify({
                    display_text: "Action Reminder"
                })
            },
            {
                name: "cta_cancel_reminder",
                buttonParamsJson: JSON.stringify({
                    display_text: "Action Unreminder"
                })
            },
            {
                name: "address_message",
                buttonParamsJson: JSON.stringify({
                    display_text: "Form Location"
                })
            },
            {
                name: "send_location",
                buttonParamsJson: JSON.stringify({
                    display_text: "Send Location"
                })
            },
            {
                name: "open_webview",
                buttonParamsJson: JSON.stringify({
                    title: "URL Web View",
                    link: {
                        in_app_webview: true,
                        url: global.website || "https://example.com"
                    }
                })
            },
            {
                name: "mpm",
                buttonParamsJson: JSON.stringify({
                    product_id: "23942543532047956"
                })
            },
            {
                name: "wa_payment_transaction_details",
                buttonParamsJson: JSON.stringify({
                    transaction_id: "12345848"
                })
            },
            {
                name: "automated_greeting_message_view_catalog",
                buttonParamsJson: JSON.stringify({
                    business_phone_number: ownerNumber,
                    catalog_product_id: "23942543532047956"
                })
            },
            {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                    mode: "published",
                    flow_message_version: "3",
                    flow_token: "1:1307913409923914:293680f87029f5a13d1ec5e35e718af3",
                    flow_id: "1307913409923914",
                    flow_cta: "Here is button form",
                    flow_action: "navigate",
                    flow_action_payload: {
                        screen: "QUESTION_ONE",
                        params: {
                            user_id: "123456789",
                            referral: "campaign_xyz"
                        }
                    },
                    flow_metadata: {
                        flow_json_version: "201",
                        data_api_protocol: "v2",
                        flow_name: "Lead Qualification [en]",
                        data_api_version: "v2",
                        categories: ["Lead Generation", "Sales"]
                    }
                })
            }
        ]

        const isFullMode = text?.trim().toLowerCase() === "full"
        const native_flow_button = isFullMode
            ? [...safeButtons, ...riskyButtons]
            : safeButtons

        await conn.sendMessage(m.chat, {
            text: `🔥 *FREEZEEHOST NATIVE FLOW TEST*

Button di pesan ini sudah disesuaikan dengan format \`npm:baileys\`.

Mode: *${isFullMode ? "FULL" : "SAFE"}*

${isFullMode
                ? "Mode FULL mengirim semua varian, termasuk yang rawan forbidden di beberapa akun/client."
                : "Mode SAFE hanya mengirim varian yang paling aman. Pakai `.nativeflow full` untuk full stress test."}`,
            footer: "FreeZeeHost Button Lab",
            interactive: native_flow_button
        }, { quoted: m })

    } catch (err) {
        console.error("TESTBUTTON ERROR:", err)
        m.reply(`❌ Gagal kirim native flow button.\n${err?.message || err}`)
    }
}

handler.command = ["nativeflow"]
handler.tags = ["tools"]
handler.help = ["nativeflow"]

export default handler
