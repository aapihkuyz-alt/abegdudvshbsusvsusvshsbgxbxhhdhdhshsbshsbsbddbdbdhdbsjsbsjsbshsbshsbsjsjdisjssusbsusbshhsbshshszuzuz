let handler = async (m, { conn, Func }) => {
    await Func.sendRichTest(conn, m.chat);
}

handler.help = ["testrich"]
handler.tags = ["tools"]
handler.command = ["testrich"]

export default handler
