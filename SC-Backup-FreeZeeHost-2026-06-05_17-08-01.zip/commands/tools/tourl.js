import axios from "axios"
import FormData from "form-data"
import moment from "moment-timezone"

let handler = async (m, {
    conn
}) => {

    let quoted = m.quoted ? m.quoted : m
    let mime =
        quoted.mimetype ||
        quoted.msg?.mimetype ||
        quoted.mediaType ||
        ""

    if (!mime)
        return m.reply("❌ Reply atau kirim media yang valid.")

    try {

        await conn.sendReact(m.chat, "📤", m.key)

        const buffer = await quoted.download()
        if (!buffer)
            return m.reply("❌ Gagal download media.")

        const ext = mime.split("/")[1] || "bin"
        const filename = `upload.${ext}`

        let uguuUrl = "-"
        let catboxUrl = "-"
        let litterUrl = "-"
        let tmpUrl = "-"
        let quaxUrl = "-"

        /* ================= UGUU ================= */
        try {
            const form = new FormData()
            form.append("files[]", buffer, filename)

            const {
                data
            } = await axios.post(
                "https://uguu.se/upload",
                form, {
                    headers: form.getHeaders()
                }
            )

            if (data?.files?.[0]?.url)
                uguuUrl = data.files[0].url

        } catch (e) {
            console.log("UGUU ERROR:", e.message)
        }

        /* ================= CATBOX ================= */
        try {
            const form = new FormData()
            form.append("reqtype", "fileupload")
            form.append("fileToUpload", buffer, filename)

            const {
                data
            } = await axios.post(
                "https://catbox.moe/user/api.php",
                form, {
                    headers: form.getHeaders()
                }
            )

            if (typeof data === "string" && data.startsWith("https"))
                catboxUrl = data

        } catch (e) {
            console.log("CATBOX ERROR:", e.message)
        }

        /* ================= LITTERBOX (72H) ================= */
        try {
            const form = new FormData()
            form.append("reqtype", "fileupload")
            form.append("time", "72h")
            form.append("fileToUpload", buffer, filename)

            const {
                data
            } = await axios.post(
                "https://litterbox.catbox.moe/resources/internals/api.php",
                form, {
                    headers: form.getHeaders()
                }
            )

            if (typeof data === "string" && data.startsWith("https"))
                litterUrl = data

        } catch (e) {
            console.log("LITTERBOX ERROR:", e.message)
        }

        /* ================= TMPFILES (60 MENIT) ================= */
        try {
            const form = new FormData()
            form.append("file", buffer, filename)

            const {
                data
            } = await axios.post(
                "https://tmpfiles.org/api/v1/upload",
                form, {
                    headers: form.getHeaders()
                }
            )

            if (data?.data?.url) {
                const raw = data.data.url
                tmpUrl = raw.replace("tmpfiles.org/", "tmpfiles.org/dl/")
            }

        } catch (e) {
            console.log("TMPFILES ERROR:", e.message)
        }

        /* ================= QU.AX ================= */
        try {

            const form = new FormData()
            form.append("files[]", buffer, {
                filename: filename,
                contentType: mime
            })

            const response = await axios({
                method: "post",
                url: "https://qu.ax/upload",
                data: form,
                headers: {
                    ...form.getHeaders()
                },
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                timeout: 60000
            })

            // kalau dia balikin string HTML
            if (typeof response.data === "string") {
                try {
                    const parsed = JSON.parse(response.data)
                    if (parsed?.files?.[0]?.url)
                        quaxUrl = parsed.files[0].url
                } catch {
                    console.log("QUAX NON JSON RESPONSE")
                }
            }

            // kalau dia balikin JSON normal
            if (response.data?.files?.[0]?.url) {
                quaxUrl = response.data.files[0].url
            }

        } catch (err) {
            console.log("QUAX ERROR:", err.response?.data || err.message)
        }

        /* ================= GOFILE (GUEST) ================= */

        let gofileUrl = "-"

        try {

            const form = new FormData()
            form.append("file", buffer, filename)

            const {
                data
            } = await axios.post(
                "https://upload.gofile.io/uploadfile",
                form, {
                    headers: form.getHeaders(),
                    maxContentLength: Infinity,
                    maxBodyLength: Infinity,
                    timeout: 60000
                }
            )

            if (data?.status === "ok" && data?.data?.downloadPage) {
                gofileUrl = data.data.downloadPage
            }

        } catch (e) {
            console.log("GOFILE ERROR:", e.response?.data || e.message)
        }

        /* ================= TEMP.SH ================= */

        let tempUrl = "-"

        try {
            const form = new FormData()
            form.append("file", buffer, filename)

            const {
                data
            } = await axios.post(
                "https://temp.sh/upload",
                form, {
                    headers: form.getHeaders(),
                    timeout: 60000
                }
            )

            if (typeof data === "string" && data.startsWith("https")) {
                tempUrl = data.trim()
            }

        } catch (e) {
            console.log("TEMP.SH ERROR:", e.message)
        }

        /* ================= FILEDITCH ================= */

        let fileditchUrl = "-"

        try {

            const form = new FormData()
            form.append("files[]", buffer, filename)

            const {
                data
            } = await axios.post(
                "https://up1.fileditch.com/upload.php",
                form, {
                    headers: form.getHeaders(),
                    timeout: 60000
                }
            )

            // FileDitch return JSON
            // Biasanya struktur: { files: [ { url: "..." } ] }

            if (data?.files?.[0]?.url) {
                fileditchUrl = data.files[0].url
            }

        } catch (e) {
            console.log("FILEDITCH ERROR:", e.response?.data || e.message)
        }

        /* ================= 0x0.st ================= */
        let zeroUrl = "-"

        try {
            const formZero = new FormData()
            formZero.append("file", buffer, {
                filename,
                contentType: mime
            })

            const response = await axios({
                method: "post",
                url: "https://0x0.st",
                data: formZero,
                headers: {
                    ...formZero.getHeaders(),
                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
                    "Accept": "*/*",
                    "Accept-Language": "en-US,en;q=0.9",
                    "Origin": "https://0x0.st",
                    "Referer": "https://0x0.st/",
                    "Connection": "keep-alive"
                },
                maxContentLength: Infinity,
                maxBodyLength: Infinity,
                timeout: 60000,
                validateStatus: () => true
            })

            if (response.status === 200 && typeof response.data === "string") {
                const url = response.data.trim()
                if (url.startsWith("https://0x0.st/")) {
                    zeroUrl = url
                }
            } else {
                console.log("0x0 RAW:", response.data)
            }

        } catch (err) {
            console.log("0x0 ERROR:", err.response?.data || err.message)
        }

        if (
            uguuUrl === "-" &&
            catboxUrl === "-" &&
            litterUrl === "-" &&
            tmpUrl === "-" &&
            quaxUrl === "-" &&
            gofileUrl === "-" &&
            tempUrl === "-" &&
            fileditchUrl === "-" &&
            zeroUrl === "-"
        )
            return m.reply("❌ Semua uploader gagal.")

        /* ================= FORMAT OUTPUT ================= */

        const sizeKB = (buffer.length / 1024).toFixed(1)
        const now = moment().tz("Asia/Jakarta")

        const caption = `
╭━━━〔 🌍 GLOBAL UPLOADER 〕━━━⬣
┃ 👤 User   : ${m.pushName || "User"}
┃ 📁 Type   : ${ext.toUpperCase()}
┃ 📦 Size   : ${sizeKB} KB
┃ 🕒 Time   : ${now.format("HH.mm.ss")} WIB
┃ 📅 Date   : ${now.format("DD-MM-YYYY")}
┃
┃ 🌐 Uguu       : ${uguuUrl !== "-" ? "✅" : "❌"}
┃ 📦 Catbox     : ${catboxUrl !== "-" ? "✅" : "❌"}
┃ 🗑 Litterbox  : ${litterUrl !== "-" ? "✅" : "❌"}
┃ ⏳ Tmpfiles   : ${tmpUrl !== "-" ? "✅" : "❌"}
┃ 🚀 qu.ax      : ${quaxUrl !== "-" ? "✅" : "❌"}
┃ 📂 Gofile     : ${gofileUrl !== "-" ? "✅ " : "❌"}
┃ ⚡ Temp.sh    : ${tempUrl !== "-" ? "✅" : "❌"}
┃ 🧩 FileDitch : ${fileditchUrl !== "-" ? "✅" : "❌"}
┃ 🔗 0x0.st     : ${zeroUrl !== "-" ? "✅" : "❌"}
╰━━━━━━━━━━━━━━━━━━━━⬣

*Permanent* = selama file tidak idle terlalu lama.
`.trim()

        const buttons = []

        const addButton = (name, url) => {
            if (url !== "-") {
                buttons.push({
                    name: "cta_copy",
                    buttonParamsJson: JSON.stringify({
                        display_text: `📋 Copy ${name}`,
                        copy_code: url
                    })
                })
            }
        }

        addButton("Uguu", uguuUrl)
        addButton("Catbox", catboxUrl)
        addButton("Litterbox", litterUrl)
        addButton("Tmpfiles", tmpUrl)
        addButton("qu.ax", quaxUrl)
        addButton("Gofile", gofileUrl)
        addButton("Temp.sh", tempUrl)
        addButton("FileDitch", fileditchUrl)
        addButton("0x0.st", zeroUrl)

        await conn.sendMessage(m.chat, {
            text: caption,
            footer: "FreeZeeHost Multi Uploader",
            viewOnce: true,
            interactive: buttons
        }, {
            quoted: m
        })

        await conn.sendReact(m.chat, "✅", m.key)

    } catch (err) {
        console.log("TOURL ERROR:", err.message)
        await conn.sendReact(m.chat, "❌", m.key)
        m.reply("❌ Terjadi error saat upload.")
    }
}

handler.command = ["tourl"]
handler.tags = ["uploader"]
handler.help = ["tourl (reply media)"]

export default handler