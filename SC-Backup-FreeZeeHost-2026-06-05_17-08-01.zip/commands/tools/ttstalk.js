let handler = async (m, {
    conn,
    text,
    usedPrefix,
    command
}) => {
    if (!text)
        return m.reply(
            `❌ *Username TikTok belum diisi*\n\nContoh:\n${usedPrefix + command} zakkixd_dev`
        )

    await m.react("⏳")

    try {
        const url =
            `https://api.neoxr.eu/api/ttstalk` +
            `?username=${encodeURIComponent(text)}` +
            `&apikey=${global.neoxr}`

        const res = await fetch(url)
        const json = await res.json()

        if (!json.status || !json.data)
            throw "Akun tidak ditemukan atau private total"

        const d = json.data

        const caption = `
🎵 *TikTok Profile*
━━━━━━━━━━━━━━━
👤 *Nama*      : ${d.name || "-"}
🔖 *Username*  : @${d.username}
🆔 *ID*        : ${d.id}
🌍 *Region*    : ${d.region || "-"}
${d.verified ? "✅ *Verified Account*\n" : ""}

📊 *Statistik*
• Post     : ${d.posts}
• Followers: ${d.followers}
• Following: ${d.following}
• Likes    : ${d.likes}

🔐 *Privasi*
• Akun     : ${d.private ? "Private 🔒" : "Public 🌍"}

📝 *Bio*
${d.bio || "-"}

━━━━━━━━━━━━━━━
⚡ TikTok Stalker
`.trim()

        await conn.sendMessage(
            m.chat, {
                image: {
                    url: d.photo
                },
                caption
            }, {
                quoted: m
            }
        )

        await m.react("✅")
    } catch (e) {
        console.error(e)
        await m.react("❌")
        m.reply("❌ Gagal ambil data TikTok.\nAkun bisa jadi private / username salah.")
    }
}

handler.command = ["stalktt", "ttstalk"]
handler.tags = ["tools", "stalker"]
handler.help = ["stalktt <username>"]

export default handler