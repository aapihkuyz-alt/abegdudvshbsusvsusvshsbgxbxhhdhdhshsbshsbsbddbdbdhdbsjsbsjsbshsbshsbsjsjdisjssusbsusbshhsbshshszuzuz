/**
 ╔══════════════════════
      ⧉  [ytpost] — [tool]
╚══════════════════════

  ✺ Type     : Plugin ESM
  ✺ Source   : https://whatsapp.com/channel/0029VbAXhS26WaKugBLx4E05
  ✺ Creator  : SXZnightmare
  ✺ Scrape      : 
  [ https://whatsapp.com/channel/0029Vb4jDY82ER6beeXLOp0k/1431 ]
  ✺ Scrape Maker : [ Alfi ]
*/

import * as sharp from "sharp";
import { Buffer } from "buffer";

let handler = async (m, { conn, text, usedPrefix, command }) => {
    try {
        if (!text) return m.reply(`*Contoh:* ${usedPrefix + command} https://www.youtube.com/post/xxx`);

        await conn.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });

        const postUrl = text.includes("youtube.com/post/")
            ? text
            : `https://www.youtube.com/post/${text}`;

        const postData = await scrapeYTPost(postUrl);

        const caption = `*📝 YouTube Post Info*

👤 *Author:* ${postData.author}
🔗 *Channel:* ${postData.authorUrl}
⏰ *Published:* ${postData.published}
❤️ *Likes:* ${postData.likes}

📄 *Content:*
${postData.content || "*Tidak ada teks*"}
        `.trim();

        const images = postData.images;

        if (images.length === 0) {
            await conn.sendMessage(m.chat, { text: caption }, { quoted: m });
        } else if (images.length === 1) {
            const buffer = await fetchImageBuffer(images[0]);
            if (!buffer) {
                await conn.sendMessage(m.chat, { text: caption }, { quoted: m });
            } else {
                await conn.sendMessage(
                    m.chat,
                    {
                        image: buffer,
                        mimetype: "image/jpeg",
                        caption
                    },
                    { quoted: m }
                );
            }
        } else {
            await conn.sendMessage(m.chat, { text: caption }, { quoted: m });
            for (const img of images) {
                const buffer = await fetchImageBuffer(img);
                if (!buffer) continue;
                await conn.sendMessage(
                    m.chat,
                    {
                        image: buffer,
                        mimetype: "image/jpeg"
                    },
                    { quoted: m }
                );
            }
        }
    } catch (e) {
        await conn.sendMessage(
            m.chat,
            { text: `*🍂 Error:* ${e.message}` },
            { quoted: m }
        );
    } finally {
        await conn.sendMessage(m.chat, { react: { text: "", key: m.key } });
    }
};

async function fetchImageBuffer(url) {
    const res = await fetch(url, { headers: { "User-Agent": "Mozilla/5.0" } });
    if (!res.ok) return null;

    const input = Buffer.from(await res.arrayBuffer());

    return await sharp.default(input)
        .jpeg({ quality: 90 })
        .toBuffer();
}

async function scrapeYTPost(url) {
    const res = await fetch(url, {
        headers: {
            "user-agent":
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/140 Safari/537.36"
        }
    });

    const html = await res.text();

    const ogImage =
        html.match(/<meta property="og:image" content="([^"]+)"/)?.[1] || null;

    const match = html.match(/var ytInitialData = (.*?);<\/script>/s);
    if (!match) throw new Error("ytInitialData not found");

    const data = JSON.parse(match[1]);

    const post =
        data?.contents?.twoColumnBrowseResultsRenderer?.tabs?.[0]
            ?.tabRenderer?.content?.sectionListRenderer?.contents?.[0]
            ?.itemSectionRenderer?.contents?.[0]
            ?.backstagePostThreadRenderer?.post?.backstagePostRenderer;

    if (!post) throw new Error("Post structure not found");

    const author = post.authorText?.runs?.[0]?.text || "Unknown";
    const authorUrl =
        "https://youtube.com" +
        (post.authorEndpoint?.commandMetadata?.webCommandMetadata?.url || "");
    const content = post.contentText?.runs?.map(v => v.text).join("") || "";
    const published = post.publishedTimeText?.runs?.[0]?.text || "Unknown";
    const likes = post.voteCount?.simpleText || "0";

    let images = [];

    if (post.multiImageRenderer?.images?.length) {
        for (const img of post.multiImageRenderer.images) {
            const url = img.image?.thumbnails?.at(-1)?.url;
            if (url) images.push(url);
        }
    }

    else if (post.backstageAttachment?.backstageImageRenderer?.image?.thumbnails) {
        const thumbs = post.backstageAttachment.backstageImageRenderer.image.thumbnails;
        const url = thumbs.at(-1)?.url;
        if (url) images.push(url);
    }

    else if (ogImage) {
        images.push(ogImage);
    }

    return {
        author,
        authorUrl,
        published,
        content,
        likes,
        images
    };
}

handler.help = ["ytpost"];
handler.tags = ["tool"];
handler.command = ["ytpost"];
handler.limit = true;
handler.register = false; // true kan jika ada fitur register atau daftar di bot mu.

export default handler;