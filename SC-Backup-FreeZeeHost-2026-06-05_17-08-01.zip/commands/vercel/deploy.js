import axios from 'axios';

const handler = async (m, {
    conn,
    text,
    usedPrefix,
    command,
    isOwner,
    Func
}) => {
    if (!isOwner) return m.reply("❌ Khusus Owner.");

    // Ganti dengan Token Vercel Abang
    const VERCEL_TOKEN = "vcp_3sKvTgPMsHnvl3Qbo5QEIfCrDFdYETrxQRP7RfqBEHsAZmBOmv1k6Udg";

    const q = m.quoted ? m.quoted : m;
    const mime = (q.msg || q).mimetype || '';

    if (!text) return m.reply(`*CARA PAKAI:* \nReply filenya lalu ketik: \n*${usedPrefix + command} nama-web*`);

    const projectName = text.trim().toLowerCase().replace(/\s+/g, '-');
    await m.react("📂");

    try {
        let content = "";

        // Ambil konten dari file yang di-reply atau teks
        if (m.quoted) {
            const buffer = await q.download();
            content = buffer.toString('utf-8');
        } else if (text.includes('|')) {
            content = text.split('|')[1].trim();
        }

        if (!content) return m.reply("❌ Mana kodingannya? Reply file atau tulis kodenya.");

        await m.react("🚀");

        // Proses Deploy
        const res = await axios.post('https://api.vercel.com/v13/deployments', {
            name: projectName,
            files: [{
                file: 'index.html',
                data: content
            }],
            projectSettings: {
                framework: null
            }
        }, {
            headers: {
                Authorization: `Bearer ${VERCEL_TOKEN}`
            }
        });

        const data = res.data;
        const resultUrl = `https://${data.url}`;
        const prodUrl = `https://${projectName}.vercel.app`;

        // RESULT MEWAH SEPERTI FREEZEEHOST
        let caption = `🚀 *VERCEL DEPLOY SUCCESS* 🚀\n\n`;
        caption += `◦ *Project Name:* ${projectName}\n`;
        caption += `◦ *Status:* ${data.state} ✅\n`;
        caption += `◦ *Preview URL:* ${resultUrl}\n`;
        caption += `◦ *Production URL:* ${prodUrl}\n\n`;
        caption += `_💡 Web otomatis online dalam hitungan detik._\n`;
        caption += `_Powered by Google Generative AI_`;

        // Kirim dengan External Ad Reply agar ada thumbnail-nya
        await conn.sendMessage(m.chat, {
            text: caption
        }, {
            quoted: m
        });

        await m.react("✅");

    } catch (e) {
        console.error(e.response?.data || e.message);
        m.reply(`❌ *DEPLOY GAGAL!*
        
*Error:* ${e.response?.data?.error?.message || "Internal Server Error"}`);
        await m.react("❌");
    }
};

handler.command = ['deploy'];
handler.tags = ['vercel'];
handler.help = ['deploy <nama> (reply kodingan)'];
handler.owner = true;

export default handler;