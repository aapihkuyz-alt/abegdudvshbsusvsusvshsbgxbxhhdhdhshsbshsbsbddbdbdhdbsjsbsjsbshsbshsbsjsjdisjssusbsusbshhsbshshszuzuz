import fs from "fs";
import {
  fileURLToPath
} from 'url';
import CaseManager from "./core/case.js";
import util from "util";
import "./settings.js";
import axios from 'axios';
import {
  generateWAMessageFromContent,
  proto
} from 'baileys'
const Case = new CaseManager("./case.js");

const file = fileURLToPath(import.meta.url);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log(`Pembaruan terdeteksi di ${file}`);

});

export default async (m, {
  conn,
  isOwner,
  prefix,
  isCmd,
  command,
  text,
  user,
  db,
  Func,
  cmd,
  args,
  isPremium,
  isAdmin,
  isBotAdmin,
}) => {
  if (!isCmd) return;

  // ================= PARSER SINGLE_SELECT =================
  let textCmd = text

  if (m.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson) {
    try {
      const params = JSON.parse(
        m.message.interactiveResponseMessage.nativeFlowResponseMessage.paramsJson
      )
      textCmd = params.id || text
    } catch (e) {
      console.log("❌ Gagal parse paramsJson")
    }
  }
  // =======================================================

  try {
    switch (command) {
      case 'info2': {
        const name = m.pushName || 'No Name';
        const senderNumber = m.sender.split('@')[0];
        const status = isOwner ? 'Owner Bot ☑️' : 'Free User';

        const styles = [
          `👤 Info User
Nama   : ${name}
Nomor  : ${senderNumber}
Status : ${status}
— ${global.botname}`,

          `Halo 👋
Nama kamu ${name}
Nomor: ${senderNumber}
Role : ${status}

🤖 ${global.botname}`,

          `📌 USER DATA
• Nama   : ${name}
• Nomor  : ${senderNumber}
• Status : ${status}

${global.botname}`,

          `Hey!
${name} (${senderNumber})
Akses: ${status}

Powered by ${global.botname}`
        ];

        balas(styles[Math.floor(Math.random() * styles.length)]);
      }
      break;





      case "setprefix": {
        if (!isOwner) return m.reply("Khusus Owner!")
        if (!text) return m.reply(`Masukkan prefix baru!\nContoh: ${prefix}${command} #`)
        db.list().settings.prefix = text
        db.list().settings.multiprefix = false
        await db.save()
        m.reply(`Prefix berhasil diubah ke: *${text}*\nMultiprefix otomatis dimatikan.`)
      }
      break

      case "multiprefix": {
        if (!isOwner) return m.reply("Khusus Owner!")
        if (!args[0]) return m.reply(`Gunakan on/off!\nContoh: ${prefix}${command} on`)
        let status = args[0].toLowerCase() === "on"
        db.list().settings.multiprefix = status
        await db.save()
        m.reply(`Multiprefix berhasil di *${status ? "aktifkan" : "matikan"}*.`)
      }
      break

      case "noprefix": {
        if (!isOwner) return m.reply("Khusus Owner!")
        if (!args[0]) return m.reply(`Gunakan on/off!\nContoh: ${prefix}${command} on`)
        let status = args[0].toLowerCase() === "on"
        db.list().settings.noprefix = status
        await db.save()
        m.reply(`Noprefix berhasil di *${status ? "aktifkan" : "matikan"}*.`)
      }
      break

      case "createch": {
        if (!isOwner) return m.reply('Khusus Owneer Bngg🗿')
        if (!text) return m.reply(`Masukan nama channel!\n*Contoh:* ${cmd} FreeZeeHost Comunity`)
        let {
          id,
          invite,
          name
        } = await conn.newsletterCreate(text)
        let result = `
*Channel WhatsApp Berhasil Dibuat ✅*

- ID: ${id}
- Nama: ${name}
- https://whatsapp.com/channel/${invite}
`
        return m.reply(result)
      }
      break



      case "menu1": {
        const data = db.get("user", m.sender)
        const name = data.name
        const premium = isOwner ? "Developer" : data.premium ? "Premium User 👑" : "Free User"
        let teks = `
Hii @${m.sender.split("@")[0]} 🕊️
I'am ${global.botname}!
 
  — 𝗨𝘀𝗲𝗿 𝗜𝗻𝗳𝗼𝗿𝗺𝗮𝘁𝗶𝗼𝗻
 ┌ 👤 Name : ${name}
 └ ⭐ Status: ${premium}
 
 ┌∘ 𝗠𝗮𝗶𝗻 - 𝗠𝗲𝗻𝘂
 │∘ .my
 │∘ .cn
 │∘ .ceklimit
 │∘ .buylimit
 │∘ .topglobal
 │∘ .tflimit
 └∘ .tfbalance
 
 ┌∘ 𝗖𝗿𝗲𝗮𝘁𝗼𝗿 - 𝗠𝗲𝗻𝘂
 │∘ .emojimix
 │∘ .sticker
 │∘ .swm
 │∘ .rvo
 │∘ .togif
 │∘ .tohd
 │∘ .toghibli
 │∘ .remini
 │∘ .hdvid
 │∘ .jadianime
 │∘ .iqc
 │∘ .brat
 └∘ .bratvid
 
 ┌∘ 𝗗𝗼𝘄𝗻𝗹𝗼𝗮𝗱 - 𝗠𝗲𝗻𝘂
 │∘ .facebook
 │∘ .instagram
 │∘ .tiktok
 │∘ .ytmp3
 │∘ .ytmp4
 │∘ .npmdl
 │∘ .gitclone
 │∘ .spotify
 │∘ .mediafire
 │∘ .xnxxdl
 └∘ .play
 
 ┌∘ 𝗦𝗲𝗮𝗿𝗰𝗵 - 𝗠𝗲𝗻𝘂
 │∘ .npm
 │∘ .yts
 │∘ .spotifysearch
 │∘ .pinterest
 │∘ .xnxx
 └∘ .gimage
 
 ┌∘ 𝗧𝗼𝗼𝗹𝘀 - 𝗠𝗲𝗻𝘂
 │∘ .ai
 │∘ .tourl 
 │∘ .tourl2
 │∘ .ttstalk
 │∘ .tts
 └∘ .ocr
 
 ┌∘ 𝗚𝗮𝗺𝗲 - 𝗠𝗲𝗻𝘂
 │∘ .kuis
 │∘ .siapakahaku
 │∘ .family100
 │∘ .tebaktebakan
 │∘ .tebakflag
 │∘ .tictactoe
 │∘ .tebakboom
 └∘ .tebakgambar

 ┌∘ 𝗦𝘁𝗼𝗿𝗲 - 𝗠𝗲𝗻𝘂
 │∘ .addlist
 │∘ .dellist
 │∘ .list
 │∘ .payment
 │∘ .proses
 │∘ .done
 │∘ .pushkontak
 └∘ .jpm
  
 ┌∘ 𝗚𝗿𝗼𝘂𝗽 - 𝗠𝗲𝗻𝘂
 │∘ .addsewa
 │∘ .delsewa
 │∘ .ceksewa
 │∘ .listsewa
 │∘ .afk
 │∘ .antilink
 │∘ .welcome
 │∘ .statusgrup 
 │∘ .open
 │∘ .close
 │∘ .kick
 └∘ .hidetag

 ┌∘ 𝗢𝗯𝗳𝘂𝘀𝗰𝗮𝘁𝗼𝗿 - 𝗠𝗲𝗻𝘂
 │∘ .enc
 │∘ .enc2
 │∘ .enc3
 └∘ .minify

 ┌∘ 𝗖𝗵𝗮𝗻𝗻𝗲𝗹 - 𝗠𝗲𝗻𝘂
 │∘ .cekidch
 │∘ .buatch
 │∘ .stalkch
 │∘ .listch
 └∘ .jpmch

 ┌∘ 𝗣𝗮𝗻𝗲𝗹 - 𝗠𝗲𝗻𝘂
 │∘ .1gb - .unlimited
 │∘ .listpanel
 │∘ .delpanel
 │∘ .cadmin
 │∘ .listadmin
 └∘ .deladmin

 ┌∘ 𝗜𝗻𝘀𝘁𝗮𝗹𝗹𝗽𝗮𝗻𝗲𝗹 - 𝗠𝗲𝗻𝘂
 │∘ .subdomain
 │∘ .installpanel
 │∘ .startwings
 │∘ .installprotectpanel
 │∘ .uninstallpanel
 └∘ .uninstallprotectpanel
  
 ┌∘ 𝗦𝗲𝘁𝗯𝗼𝘁 - 𝗠𝗲𝗻𝘂
 │∘ .gconly
 │∘ .pconly
 │∘ .sewaonly
 │∘ .setthumbnail
 └∘ .statusbot

 ┌∘ 𝗢𝘄𝗻𝗲𝗿 - 𝗠𝗲𝗻𝘂
 │∘ .addownerbot
 │∘ .delownerbot
 │∘ .self
 │∘ .public
 │∘ .addlimit
 │∘ .dellimit
 │∘ .addbalance
 │∘ .delbalance
 │∘ .backup
 │∘ .bljpm
 │∘ .delbljpm
 │∘ .resetdb
 │∘ .setwelcome
 │∘ .setleave
 │∘ .tagsw
 │∘ .tagsw2
 │∘ .swgrup
 │∘ x
 │∘ xx
 └∘ $
`;
        return m.reply(teks)
      }
      break









      //ai
      case "muslimai": {
        if (!args[0]) {
          return m.reply(
            `❌ Masukkan pertanyaan.\n\nContoh:\n${usedPrefix + command} hi`
          );
        }

        await m.react("⏳");

        try {
          const query = args.join(" ");
          const apikey = global.z7;

          if (!apikey) {
            await m.react("❌");
            return m.reply("API Key belum diatur di global.z7");
          }

          const url = `https://z7.tokodex.biz.id/theresa/muslimai?apikey=${apikey}&query=${encodeURIComponent(query)}`;

          const res = await fetch(url);
          const json = await res.json();

          if (!json.status) {
            await m.react("❌");
            return m.reply("Gagal mendapatkan jawaban dari Muslim AI.");
          }

          const replyText = `
🕌 *Muslim AI*

📌 *Pertanyaan:*
${json.query}

📖 *Jawaban:*
${json.result}
        `.trim();

          await m.react("✅");
          return m.reply(replyText);

        } catch (err) {
          console.error(err);
          await m.react("❌");
          return m.reply(`Terjadi kesalahan:\n${err.message}`);
        }
      }
      break;
      //owner
      case "resetdb": {
        if (!isOwner) return m.reply("⚠️ Hanya owner yang bisa reset database!");

        await m.react('⏳');

        try {
          await db.reset();

          await m.react('✅');
          return m.reply("Database berhasil di-reset!");
        } catch (err) {
          console.error(err);
          return m.reply(`Terjadi kesalahan saat reset DB: ${err.message}`);
        }
      }
      break;
      case "cases": {
        if (!isOwner) return m.reply("Perintah ini khusus Owner.");
        if (!text) {
          return m.reply(`*Manajemen Case*\n\nGunakan format: \`${prefix + command} [opsi] [nama_case/kode]\`\n\n*Opsi:*\n \`--add\` : Tambah case baru (reply kode)\n \`--get\` : Ambil kode case\n \`--delete\` : Hapus case\n\n*– Daftar Case Tersedia:*\n${Case.list().map((a, i) => ` ◦ ${a}`).join("\n")}`);
        }

        if (text.includes("--add")) {
          let input = m.quoted ? m.quoted.text : text.replace("--add", "").trim();
          if (!input) return m.reply("Reply kode untuk ditambahkan ke case.");
          if (Case.add(input)) {
            m.reply("Berhasil menambahkan case. Mohon restart bot untuk menerapkan perubahan.");
          } else {
            m.reply("Gagal menambahkan case.");
          }
        } else if (text.includes("--get")) {
          let input = text.replace("--get", "").trim();
          if (!input) return m.reply("Masukkan nama case yang ingin diambil.");
          let content = await Case.get(input.toLowerCase());
          if (content) {
            m.reply(util.format(content));
          } else {
            m.reply(`Case '${input}' tidak ditemukan.`);
          }
        } else if (text.includes("--delete")) {
          let input = text.replace("--delete", "").trim();
          if (!input) return m.reply("Masukkan nama case yang ingin dihapus.");
          if (Case.delete(input.toLowerCase())) {
            m.reply("Berhasil menghapus case. Mohon restart bot untuk menerapkan perubahan.");
          } else {
            m.reply(`Case '${input}' tidak ditemukan.`);
          }
        }
      }
      break;
      //tools
      case 'cloudku':
      case 'shortcloud': {
        if (!text) return m.reply(`Masukkan URL!\nContoh: ${prefix + command} https://example.com [custom]`);

        const [link, customCode] = text.trim().split(' ');

        const timestamp = Math.floor(Date.now() / 1000);
        const custom = customCode || Math.floor(100000 + Math.random() * 900000).toString();

        const payload = {
          url: link,
          custom,
          timestamp
        };

        const headers = {
          'Content-Type': 'application/json',
          'Origin': 'https://cloudku.click',
          'Referer': 'https://cloudku.click/',
          'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107 Safari/537.36',
          'X-Requested-With': 'XMLHttpRequest'
        };

        try {
          const res = await fetch('https://cloudku.click/api/link.php', {
            method: 'POST',
            headers,
            body: JSON.stringify(payload)
          });

          const json = await res.json();
          if (!json.success || !json.data?.shortUrl) return m.reply("❌ Gagal membuat short URL.");

          const {
            shortUrl,
            originalUrl,
            created,
            key
          } = json.data;

          const caption = `
🔗 *Short URL Created!*
━━━━━━━━━━━━━━━
🌐 *Original:* ${originalUrl}
📎 *Shortened:* ${shortUrl}
🗝️ *Custom:* ${key}
🕒 *Created:* ${created}
`.trim();

          const interactive = await generateWAMessageFromContent(
            m.chat, {
              viewOnceMessage: {
                message: {
                  interactiveMessage: proto.Message.InteractiveMessage.create({
                    body: {
                      text: caption
                    },
                    footer: {
                      text: "📎 cloudku.click link shortener"
                    },
                    nativeFlowMessage: {
                      buttons: [{
                        name: "cta_copy",
                        buttonParamsJson: JSON.stringify({
                          display_text: "📋 Salin Link",
                          copy_code: shortUrl
                        })
                      }]
                    }
                  })
                }
              }
            }, {
              quoted: m
            }
          );

          await conn.relayMessage(m.chat, interactive.message, {
            messageId: interactive.key.id
          });

        } catch (err) {
          console.error('[SHORT ERROR]', err);
          m.reply("❌ Gagal memendekkan link.");
        }
      }
      break;

    }
  } catch (e) {
    console.error("Case Handler Error:", e);
    m.reply(`Terjadi error di case handler: ${e.message}`);
  }
};