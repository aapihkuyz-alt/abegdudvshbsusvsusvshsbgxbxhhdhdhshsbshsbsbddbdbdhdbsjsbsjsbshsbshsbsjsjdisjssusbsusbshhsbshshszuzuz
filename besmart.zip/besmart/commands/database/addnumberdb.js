import https from "https"

const addNumberDB = (number) => {
    return new Promise((resolve, reject) => {
        const url =
            `https://db.zpr0.com/addnumber` +
            `?apikey=FreeZeeHost12` +
            `&username=FreeZeeHost` +
            `&number=${number}`

        https.get(url, (res) => {
            let data = ""

            res.on("data", (chunk) => (data += chunk))
            res.on("end", () => {
                try {
                    const json = JSON.parse(data)
                    console.log("[DB ADD RESPONSE]", json)
                    resolve(json)
                } catch (e) {
                    reject(new Error("Gagal parse JSON DB"))
                }
            })
        }).on("error", (err) => reject(err))
    })
}

const handler = async (m, {
    text
}) => {
    if (!text)
        return m.reply(
            "❌ *Format salah*\n\n" +
            "Contoh:\n" +
            ".addnumberdb 628xxxxxxxxxx"
        )

    const number = text.replace(/\D/g, "")
    if (number.length < 8)
        return m.reply("❌ Nomor tidak valid")

    await m.reply("⏳ Menambahkan nomor ke database...")

    try {
        const res = await addNumberDB(number)

        if (res?.success === true) {
            const d = res.data || {}

            return m.reply(
                `✅ *NOMOR BERHASIL DITAMBAHKAN*\n\n` +
                `👤 Target User : ${res.target_user || "-"}\n` +
                `📱 Nomor       : ${d.number || number}\n` +
                `📦 Total DB    : ${d.total_stored || "-"} / ${d.limit_capacity || "-"}\n` +
                `🔄 Sinkron     : ${d.usage_synced || 0}\n\n` +
                `🛡️ Action By  : ${res.action_by || "system"}\n` +
                `💬 Message    : ${res.message || "-"}\n\n` +
                `⚡ Powered by ${global.ownername}`
            )
        }

        // gagal tapi respon masuk
        return m.reply(
            `❌ *GAGAL MENAMBAHKAN NOMOR*\n\n` +
            `📩 Respon DB:\n` +
            `${JSON.stringify(res, null, 2)}`
        )

    } catch (e) {
        console.error("[ADDNUMBERDB ERROR]", e)
        m.reply("❌ Terjadi kesalahan saat menghubungi database")
    }
}

handler.command = ["addnumberdb","adddb"]
handler.tags = ["database"]
handler.help = ["addnumberdb <nomor>"]
handler.dev = true

export default handler