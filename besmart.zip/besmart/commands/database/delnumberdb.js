import https from "https"

let handler = async (m, { conn, text }) => {

await m.react("⏳")

// ================= HAPUS LANGSUNG =================

if (text) {

let number = text.replace(/[^0-9]/g,"")

let url = `https://db.zpr0.com/delnumber?apikey=FreeZeeHost12&number=${number}`

https.get(url, (res)=>{

let data = ""

res.on("data",(chunk)=> data += chunk)

res.on("end", async ()=>{

try {

let json = JSON.parse(data)

let teks = `
┌───〔 🗑 DELETE NUMBER DATABASE 〕───┐

📱 Nomor
${number}

📊 Status
Nomor berhasil dihapus dari database

└────────────────────┘
`

await conn.sendMessage(m.chat,{text:teks},{quoted:m})
await m.react("✅")

} catch {

await m.react("❌")
m.reply("Gagal membaca respon API.")

}

})

})

return
}

// ================= AMBIL LIST =================

let url = "https://db.zpr0.com/listnumber?apikey=FreeZeeHost12&username=FreeZeeHost"

https.get(url,(res)=>{

let data=""

res.on("data",(chunk)=> data+=chunk)

res.on("end",async()=>{

try {

let json = JSON.parse(data)

if (!json?.numbers || json.numbers.length === 0) {
await m.react("❌")
return m.reply("Tidak ada nomor di database.")
}

// ================= BUILD MENU =================

let rows = []

for (let num of json.numbers) {

rows.push({
header:"DATABASE NUMBER",
title:num,
description:"Hapus nomor dari database",
id:`.delnumberdb ${num}`
})

}

await conn.sendMessage(m.chat,{
text:`📂 LIST NUMBER DATABASE

Pilih nomor yang ingin dihapus dari database.`,
footer:"FreeZeeHost Database System",
buttons:[
{
buttonId:'action',
buttonText:{displayText:'Pilih Nomor'},
type:4,
nativeFlowInfo:{
name:'single_select',
paramsJson:JSON.stringify({
title:"Delete Number Database",
sections:[
{
title:"List Nomor",
rows
}
]
})
}
}
],
headerType:1,
viewOnce:true
},{quoted:m})

await m.react("✅")

} catch {

await m.react("❌")
m.reply("Gagal membaca respon database.")

}

})

})

}

handler.command = ["delnumberdb","deldb"]
handler.tags = ["database"]
handler.dev = true

export default handler