import https from "https"

const getJson = (url) => new Promise((resolve, reject) => {
    https.get(url, (res) => {
        let data = ""

        res.on("data", (chunk) => {
            data += chunk
        })

        res.on("end", () => {
            try {
                resolve(JSON.parse(data))
            } catch (error) {
                reject(error)
            }
        })
    }).on("error", reject)
})

let handler = async (m) => {
    await m.react("⏳")

    try {
        const url = "https://db.zpr0.com/listnumber?apikey=FreeZeeHost12&username=FreeZeeHost"
        const json = await getJson(url)

        if (!json?.numbers || json.numbers.length === 0) {
            await m.react("❌")
            return m.reply("Tidak ada nomor di database.")
        }

        let teks = `
╭───〔 📂 LIST NUMBER DATABASE 〕───╮

👤 Owner
${json.owner}

📊 Total Nomor
${json.numbers.length}

────────────────────
`.trim() + "\n"

        for (const num of json.numbers) {
            teks += `📱 ${num}\n`
        }

        teks += `
────────────────────

📦 Database Stats
Used : ${json.stats.used}
Limit : ${json.stats.limit}
Remaining : ${json.stats.remaining}

⚡ Powered by FreeZeeHost
╰────────────────────╯
`.trim()

        await m.reply(teks)
        await m.react("✅")
    } catch (err) {
        console.error("LISTDB ERROR:", err)
        await m.react("❌").catch(() => {})
        return m.reply("Terjadi kesalahan saat mengambil data database.")
    }
}

handler.command = ["listnumberdb", "listdb"]
handler.tags = ["tools"]
handler.dev = true

export default handler
