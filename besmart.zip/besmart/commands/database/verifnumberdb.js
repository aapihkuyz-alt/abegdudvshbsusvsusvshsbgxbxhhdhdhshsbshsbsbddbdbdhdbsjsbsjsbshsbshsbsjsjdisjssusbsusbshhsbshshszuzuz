import https from "https"

let handler = async (m, { conn, text }) => {

if (!text && !m.quoted && !m.mentionedJid?.length)
return m.reply(`Contoh penggunaan:

#verifdb 628xxxx
#verifdb @tag
atau reply pesan user`)

await m.react("⏳")

let number

// ambil nomor
if (m.quoted) number = m.quoted.sender.split("@")[0]
else if (m.mentionedJid?.[0]) number = m.mentionedJid[0].split("@")[0]
else number = text.replace(/[^0-9]/g,"")

let url = `https://db.zpr0.com/verifynumber?apikey=FreeZeeHost12&username=FreeZeeHost&number=${number}`

https.get(url, (res)=>{

let data = ""

res.on("data",(chunk)=> data += chunk)

res.on("end", async ()=>{

try {

let json = JSON.parse(data)

let status = json.is_owned
? "VALID di database"
: "Tidak ditemukan di database"

let teks = `
┌───〔 🔎 VERIFY NUMBER DATABASE 〕───┐

📱 Nomor
${json.number}

📊 Status
${status}

👤 Owner
${json.owner}

💬 Message
${json.message}

────────────────────

⚙️ Informasi
Verifikasi nomor dilakukan langsung
ke server database eksternal.

└────────────────────┘
`

await conn.sendMessage(m.chat,{text:teks},{quoted:m})

await m.react("✅")

} catch {

await m.react("❌")
m.reply("Gagal membaca respon API.")

}

})

}).on("error", async ()=>{

await m.react("❌")
m.reply("Gagal menghubungi server database.")

})

}

handler.command = ["verifnumberdb","verifdb"]
handler.tags = ["tools"]
handler.dev = true

export default handler