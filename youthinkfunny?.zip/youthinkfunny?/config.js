// config.js
// CREDIST BY ARYA JANGAN DI HAPUS TOLOL GUA LAMA NI BIKIN SC
// AND JANGAN SEBAR FREE KALO MAU JUAL AE KALO LU RESELLER
// CONNTACT @arya10Q TESTI @testiarya10
module.exports = {
  BOT_TOKEN: "8209605899:AAE2JJm_cDJlnMfBoErCc2Vzc43rPj-mW7g",
  OWNER_ID: "7908003544", //owner addprem/admin
  ADMIN_USERS: 7908003544, // isi user_id admin utama
  CHANNEL_ID: "-1002817042134",
  CHANNEL_USERNAME: "testiarya10",
  BOT_USERNAME: "BOT_JASHER_VVIP_BOT",
  GROUP_USERNAME: "publicCaca",
  vercelToken: "bSLWixg8JNQIiEogwnlV4um4" // 🔑 Token Vercel
};