// CREDIST BY ARYA JANGAN DI HAPUS TOLOL GUA LAMA NI BIKIN SC
// AND JANGAN SEBAR FREE KALO MAU JUAL AE KALO LU RESELLER
// CONNTACT @arya10Q TESTI @testiarya10
const settings = {
  OWNER_USERNAME: 'arya10Q', // jangan pake @
  DANA_NUMBER: '085950062448',
  DANA_NAME: 'sasi',

  GOPAY_NUMBER: '085950062448',
  GOPAY_NAME: 'BELUM ADA',

  QRIS_IMAGE: 'https://files.catbox.moe/o1r55q.jpg',
  
  LEAVE_ID: 7908003544, // ganti jadi id tele lu
  
  qris:
  'https://files.catbox.moe/o1r55q.jpg', // isi dengan url photo qris
  dana:
  'Nomor : 085950062448', // Isi dengan Nomor dana mu
  ovo:
  'Nomor : GADA BOSS', // Isi dengan Nomor ovo mu
  gopay:
  'Nomor : 085950062448', // Isi dengan Nomor gopay mu
  bca:
  'Nomor : GADA SYAANG'
};

module.exports = settings;